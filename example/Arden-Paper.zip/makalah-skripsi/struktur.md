# Makalah Skripsi — Struktur dan Panduan Penulisan

> Makalah IEEE conference paper, 4-6 halaman, bahasa Indonesia, ringkasan dari thesis.

---

## Judul

**"Tokenisasi Aset Dunia Nyata (RWA) Berbasis Blockchain untuk Pencatatan Kalibrasi Peralatan Laboratorium Tegangan Tinggi"**

## Penulis

- Nama, Program Studi, Departemen, Fakultas, Universitas

---

## Abstrak (~150 kata)

Paragraf tunggal mencakup:
- **Konteks**: Laboratorium tegangan tinggi memiliki peralatan kritis yang memerlukan pencatatan kalibrasi akurat dan terverifikasi
- **Masalah**: Pencatatan kalibrasi saat ini menggunakan cloud storage (OneDrive, Google Drive) dan SIMADU/LPPT, namun pengelolaan arsip tidak konsisten, data dapat diedit tanpa jejak perubahan (tidak immutable), dan tidak terdapat mekanisme verifikasi publik
- **Solusi**: Paper ini mengusulkan sistem pencatatan kalibrasi berbasis blockchain menggunakan konsep Real World Assets (RWA) Tokenization, di mana peralatan lab direpresentasikan sebagai NFT ERC-721 dan riwayat kalibrasi dicatat secara immutable on-chain
- **Hasil**: Sistem berhasil diimplementasikan dan diuji pada jaringan EVM-compatible, dengan seluruh fungsi smart contract dan portal frontend berjalan sesuai spesifikasi
- **Kesimpulan**: Sistem memberikan transparansi, immutability, dan audit trail yang superior dibandingkan pendekatan pencatatan digital konvensional

## Kata Kunci

blockchain, RWA tokenization, ERC-721, kalibrasi, laboratorium tegangan tinggi, smart contract, IPFS

---

## I. Pendahuluan (~1 kolom)

Paragraf 1 — **Konteks dan urgensi**:
- Laboratorium Teknik Tegangan Tinggi memiliki aset bernilai tinggi (trafo uji, generator impuls, alat ukur)
- Kalibrasi berkala wajib dilakukan untuk menjaga akurasi pengukuran dan memenuhi standar akreditasi (ISO 17025)
- Pencatatan kalibrasi yang akurat dan traceable merupakan kebutuhan kritikal

Paragraf 2 — **Masalah**:
- Pencatatan kalibrasi saat ini dilakukan melalui pengarsipan digital menggunakan cloud storage (OneDrive, Google Drive) dan Sistem Informasi Terpadu (SIMADU/LPPT)
- Kelemahan: (1) pengelolaan arsip tidak konsisten — folder tidak terstruktur, pencarian dokumen sulit, (2) data dapat diedit atau dihapus tanpa jejak perubahan (tidak immutable), (3) tidak ada akses publik untuk verifikasi independen
- Tidak ada mekanisme verifikasi independen untuk memastikan integritas data kalibrasi

Paragraf 3 — **Solusi dan kontribusi**:
- Paper ini mengusulkan sistem berbasis blockchain yang memanfaatkan konsep RWA Tokenization
- Tujuan: (1) merancang & mengimplementasikan sistem pencatatan kalibrasi berbasis smart contract pada blockchain EVM-compatible, (2) menerapkan RWA Tokenization untuk merepresentasikan peralatan lab sebagai NFT ERC-721 dengan metadata on-chain, (3) menganalisis kemampuan sistem dalam menjamin transparansi dan imutabilitas
- Kontribusi: penerapan ERC-721 untuk merepresentasikan peralatan lab TVT sebagai aset digital, pencatatan kalibrasi immutable on-chain, portal verifikasi publik tanpa perantara

Paragraf 4 — **Organisasi paper**:
- Bagian II membahas tinjauan pustaka, Bagian III perancangan sistem, Bagian IV implementasi dan pengujian, Bagian V kesimpulan

---

## II. Tinjauan Pustaka (~1 kolom)

### A. Blockchain dan Smart Contract
- Definisi singkat blockchain sebagai distributed ledger yang immutable
- Smart contract sebagai program yang berjalan on-chain secara deterministik
- EVM-compatible chain (Ethereum, DCHAIN) sebagai platform

### B. Real World Assets (RWA) Tokenization
- Konsep tokenisasi aset fisik menjadi token digital on-chain
- Jenis tokenisasi: fungible (ERC-20) vs non-fungible (ERC-721)
- Mengapa peralatan lab bersifat unik → tokenisasi non-fungible

### C. ERC-721 dan NFT
- Standar token non-fungible: setiap token memiliki identitas unik
- Metadata on-chain merepresentasikan atribut peralatan (nama, pabrikan, tipe, serial number)
- AccessControl (RBAC) untuk pemisahan peran

### D. Penelitian Terdahulu
- Bai et al. (2019): blockchain untuk manajemen laboratorium universitas
- Al-Zoubi et al. (2022): Ethereum-based Labs 4.0
- Yuan et al. (2022): blockchain untuk electrical testing laboratory
- Ho et al. (2021): blockchain untuk asset traceability
- Gap: belum ada yang menggabungkan RWA tokenization dengan kalibrasi peralatan lab TVT

---

## III. Perancangan Sistem (~1.5 kolom)

### A. Arsitektur Sistem
- Diagram arsitektur 4 layer:

```
[Presentation Layer — Next.js Frontend]
         ↓
[Application Layer — API Routes + JWT Auth]
         ↓
[Blockchain Layer — LabEquipmentTracker.sol (ERC-721)]
         ↓
[Storage Layer — IPFS/Pinata (Sertifikat PDF)]
```

- Penjelasan singkat per layer dan interaksinya

### B. Desain Smart Contract

**Struktur Data:**
- `Tool`: name, factory, typeModel, serialNumber → metadata peralatan
- `CalibrationRecord`: timestamp, calibrationDate, calibrator, ipfsHash → riwayat kalibrasi

**Role-Based Access Control:**
- `ADMIN`: mint peralatan baru, kelola calibrator
- `CALIBRATOR`: input catatan kalibrasi

**Fungsi Utama:**
- `mintTool()` — registrasi peralatan sebagai NFT (Admin only)
- `addCalibration()` — tambah catatan kalibrasi (Calibrator only)
- `getToolInfo()` — baca info peralatan (public)
- `getCalibrationHistory()` — baca riwayat kalibrasi (public)

### C. Alur Kerja Sistem

**Sequence diagram (1 diagram gabungan atau pilih 1 skenario utama):**

Skenario utama — Input Kalibrasi:
1. Calibrator login → autentikasi JWT
2. Upload sertifikat PDF ke IPFS → dapat CID
3. Input data kalibrasi (tokenId, tanggal, lembaga, IPFS hash)
4. Frontend memanggil `addCalibration()` via Viem
5. Smart contract menyimpan record on-chain, emit `CalibrationAdded`
6. Konfirmasi transaksi ditampilkan

**Verifikasi publik:**
1. Pengguna akses /verify tanpa login
2. Input Token ID → baca `getToolInfo()` + `getCalibrationHistory()`
3. Tampil: info peralatan, status kalibrasi, link sertifikat

---

## IV. Implementasi dan Pengujian (~1.5 kolom)

### A. Stack Teknologi

| Komponen | Teknologi |
|----------|-----------|
| Smart Contract | Solidity ^0.8.24, OpenZeppelin |
| Framework | Hardhat |
| Frontend | Next.js 16, React 19, Tailwind CSS 4 |
| Blockchain Integration | Viem 2.46.3 |
| Database | SQLite + Prisma ORM |
| Storage | IPFS via Pinata |
| Jaringan | Ethereum Sepolia (testing), DCHAIN (target) |

### B. Hasil Implementasi

**Smart Contract:**
- Berhasil di-deploy di jaringan DCHAIN (consortium blockchain pendidikan tinggi Indonesia)
- Contract address: `0x64610889372d06f8E9761B0eeB77b3A3e2880AeE`
- Screenshot block explorer DCHAIN

**Frontend — Portal Admin:**
- Screenshot: form registrasi peralatan, konfirmasi minting
- Fungsi: mint NFT, manajemen user calibrator

**Frontend — Portal Calibrator:**
- Screenshot: form input kalibrasi, upload sertifikat ke IPFS
- Fungsi: input record kalibrasi, upload PDF

**Frontend — Portal Verifikasi Publik:**
- Screenshot: hasil pencarian peralatan, riwayat kalibrasi
- Fungsi: baca info dan riwayat tanpa autentikasi

### C. Hasil Pengujian

**Tabel pengujian fungsional smart contract (16 skenario, 4 kelompok):**

| Kelompok | Jumlah | Skenario Utama | Status |
|----------|--------|---------------|--------|
| Minting | 4 | Mint oleh Admin, event ToolMinted, non-Admin revert, token ID berurutan | 4/4 Pass |
| Kalibrasi | 5 | Add calibration, event CalibrationAdded, non-Calibrator revert, multi-calibration, tokenId tidak ada revert | 5/5 Pass |
| Manajemen Peran | 3 | Grant role, revoke role, non-Admin revert | 3/3 Pass |
| Total Supply | 4 | Supply=0, supply=1, supply=N, supply tetap saat kalibrasi | 4/4 Pass |

**Tabel pengujian black-box frontend (12 skenario):**

| Portal | Jumlah | Status |
|--------|--------|--------|
| Admin | 5 | 5/5 Pass |
| Kalibrator | 4 | 4/4 Pass |
| Verifikasi | 3 | 3/3 Pass |

**Tabel uji imutabilitas (5 skenario percobaan manipulasi data):**

| No | Skenario Percobaan | Hasil |
|----|--------------------|-------|
| 1 | Memanggil fungsi modifikasi data kalibrasi | Fungsi tidak ada — penolakan saat kompilasi |
| 2 | Menghapus catatan kalibrasi dari smart contract | Fungsi tidak ada — penolakan saat kompilasi |
| 3 | Non-admin memanggil mintTool() | Revert: akses ditolak |
| 4 | Non-calibrator memanggil addCalibration() | Revert: akses ditolak |
| 5 | Memodifikasi _calibrations langsung dari luar kontrak | Mapping private — tidak dapat diakses |

Kesimpulan: seluruh 28 skenario pengujian (16 smart contract + 12 frontend) menunjukkan status Pass. Uji imutabilitas mengkonfirmasi tidak ada mekanisme untuk mengubah/menghapus data on-chain.

### D. Analisis

- **Transparansi**: Portal publik memungkinkan verifikasi tanpa perantara; fungsi view bersifat publik; block explorer DCHAIN memungkinkan verifikasi independen
- **Immutability**: Smart contract append-only (tidak ada fungsi update/delete), data on-chain tidak dapat diubah setelah dikonfirmasi, event logging sebagai bukti permanen
- **RWA Tokenization**: Peralatan fisik berhasil direpresentasikan sebagai NFT ERC-721 dengan metadata on-chain (nama, pabrikan, tipe, nomor seri)

**Perbandingan ringkas:**

| Aspek | Cloud Storage Konvensional | Blockchain |
|-------|---------------------------|------------|
| Konsistensi arsip | Tidak konsisten | Terstruktur on-chain |
| Transparansi | Terbatas (internal) | Publik |
| Immutability | Dapat diedit/dihapus | Immutable |
| Audit trail | Manual | Otomatis (event log) |
| Single point of failure | Ya | Tidak |

---

## V. Kesimpulan (~0.5 kolom)

Paragraf 1 — **Ringkasan**:
Paper ini telah mempresentasikan sistem pencatatan kalibrasi peralatan lab tegangan tinggi berbasis blockchain menggunakan konsep RWA Tokenization. Peralatan direpresentasikan sebagai NFT ERC-721, sementara riwayat kalibrasi dan sertifikat dicatat secara immutable on-chain dan IPFS.

Paragraf 2 — **Hasil**:
Pengujian menunjukkan seluruh fungsi smart contract dan fungsionalitas frontend berjalan sesuai spesifikasi. Sistem memberikan transparansi melalui portal verifikasi publik dan immutability melalui sifat dasar blockchain.

Paragraf 3 — **Saran**:
Pengembangan selanjutnya meliputi integrasi IoT untuk pencatatan kalibrasi otomatis, pengembangan aplikasi mobile, dan pengujian skala yang lebih luas pada jaringan DCHAIN.

---

## Daftar Pustaka (8-12 referensi)

Target referensi:

1. Bai et al. (2019) — Blockchain untuk manajemen lab universitas
2. Al-Zoubi et al. (2022) — Blockchain Labs 4.0
3. Yuan et al. (2022) — Blockchain untuk electrical testing lab
4. Chang et al. (2019) — Smart contract tracking framework
5. Ho et al. (2021) — Blockchain asset traceability
6. Hasan et al. (2019) — Ethereum smart contract untuk asset management
7. Sheldon (2022) — RWA dan blockchain provenance
8. Bhaskar et al. (2021) — Blockchain di pendidikan
9. Dias et al. (2024) — Blockchain untuk higher education
10. Purnawan (2025) — SLR asset management pendidikan
11. ISO 17025 — Standar kalibrasi laboratorium
12. ERC-721 Standard (EIP-721)

---

## Estimasi Proporsi Halaman

| Bagian | Halaman |
|--------|---------|
| Judul + Abstrak + Keywords | 0.5 |
| I. Pendahuluan | 0.5 |
| II. Tinjauan Pustaka | 0.5 |
| III. Perancangan Sistem | 1.5 |
| IV. Implementasi dan Pengujian | 1.5 |
| V. Kesimpulan + Daftar Pustaka | 1 |
| **Total** | **~5.5** |

---

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| Makalah = ringkasan thesis, bukan mini-thesis | Makalah dengan konten baru | Tidak ada double work, konsisten |
| 3 portal dibahas singkat | Fokus 1 portal saja | Perlu menunjukkan completeness sistem |
| Sequence diagram 1 skenario utama | 3 sequence diagram | Keterbatasan ruang 4-6 halaman |
| Tabel pengujian ringkas | Tabel lengkap seperti thesis | Ruang terbatas, detail ada di thesis |
| Bahasa Indonesia | Bahasa Inggris | Keputusan user |
