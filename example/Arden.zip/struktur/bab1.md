# Bab 1: Pendahuluan

## 1.1 Latar Belakang

- Gambaran umum Laboratorium Teknik Tegangan Tinggi (TVT) dan peralatan kritis yang dimiliki (trafo uji, generator impuls, alat ukur tegangan tinggi, sistem pengujian isolasi)
- Peralatan tersebut digunakan oleh banyak pihak: mahasiswa, dosen, dan teknisi untuk praktikum, penelitian, dan pengujian industri
- Masalah pencatatan kalibrasi yang masih manual (spreadsheet/buku) — rawan hilang, tidak sinkron, sulit diaudit
- Urgensi traceability kalibrasi untuk akreditasi lab (ISO 17025 / SNI)
- Potensi teknologi blockchain sebagai solusi: immutable, transparan, terdesentralisasi
- Konsep Real World Assets (RWA) Tokenization — merepresentasikan aset fisik (peralatan lab) sebagai token digital (NFT) on-chain
- DCHAIN sebagai jaringan blockchain pendidikan tinggi Indonesia yang menjadi infrastruktur target deployment
- Gap penelitian: belum ada penelitian yang menggabungkan blockchain dengan manajemen kalibrasi peralatan lab tegangan tinggi

## 1.2 Rumusan Masalah

1. Bagaimana merancang sistem pencatatan kalibrasi peralatan lab tegangan tinggi berbasis blockchain?
2. Bagaimana konsep tokenisasi aset dunia nyata (RWA) dapat merepresentasikan peralatan lab sebagai aset digital?
3. Sejauh mana sistem ini memberikan transparansi dan immutability dalam pencatatan kalibrasi?

## 1.3 Tujuan Penelitian

1. Merancang dan mengimplementasikan sistem pencatatan kalibrasi peralatan lab tegangan tinggi menggunakan smart contract pada blockchain
2. Menerapkan konsep RWA tokenization untuk merepresentasikan peralatan lab sebagai NFT (ERC-721) on-chain
3. Menganalisis transparansi dan immutability yang diberikan sistem terhadap pencatatan kalibrasi

## 1.4 Batasan Penelitian

- Fokus pada pencatatan kalibrasi peralatan, bukan keseluruhan manajemen aset (inventaris, peminjaman, dsb.)
- Deployment target: DCHAIN (jaringan blockchain pendidikan tinggi Indonesia)
- Testing saat ini menggunakan Ethereum Sepolia karena DCHAIN belum aktif; karena DCHAIN EVM-compatible (base Ethereum), behavior smart contract identik
- Sistem merupakan proof of concept, bukan production deployment
- Tidak membahas integrasi IoT untuk otomasi pencatatan

## 1.5 Manfaat Penelitian

**Manfaat Akademis:**
- Kontribusi pada bidang RWA tokenization dalam konteks laboratorium akademik
- Menambah literatur tentang penerapan blockchain di institusi pendidikan tinggi Indonesia

**Manfaat Praktis:**
- Proof of concept yang dapat diadopsi oleh Lab TVT dan laboratorium lainnya
- Mendukung proses audit akreditasi dengan audit trail yang immutable

## 1.6 Sistematika Penulisan

- Bab 1: Pendahuluan — latar belakang, rumusan masalah, tujuan, batasan, manfaat
- Bab 2: Tinjauan Pustaka dan Dasar Teori — landasan teori blockchain, smart contract, RWA tokenization, ERC-721, IPFS, kalibrasi
- Bab 3: Metode Penelitian — alat dan bahan, arsitektur sistem, desain smart contract, desain frontend, alur kerja, pengujian
- Bab 4: Hasil dan Pembahasan — hasil implementasi, hasil pengujian, analisis terhadap rumusan masalah
- Bab 5: Kesimpulan dan Saran — jawaban tujuan penelitian, saran pengembangan

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| Deployment target: DCHAIN | Ethereum Sepolia, Polygon | DCHAIN adalah jaringan blockchain pendidikan tinggi Indonesia, relevan secara institusional |
| Fokus: kalibrasi saja | Manajemen aset lengkap | Sesuai dengan smart contract yang sudah dibangun (LabEquipmentTracker) |
| Pendekatan: Proof of Concept | Studi komparatif, Framework proposal | Tujuan utama adalah membuktikan kelayakan, bukan mengukur kuantitatif |
