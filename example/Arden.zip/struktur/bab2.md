# Bab 2: Tinjauan Pustaka dan Dasar Teori

> **Catatan**: Setiap sub-bab membangun fondasi untuk sub-bab berikutnya.
> Alur: Blockchain (dasar) → EVM (platform) → Smart Contract (mekanisme) → RWA Tokenization (framework) → ERC-721 (standar) → IPFS (storage) → Kalibrasi (domain) → Tinjauan Penelitian (posisi)

## 2.1 Teknologi Blockchain

- Definisi dan konsep dasar blockchain (distributed ledger, block, hash, chain)
- Mekanisme konsensus (PoW, PoS) — ringkasan singkat, fokus pada relevansi
- Tipe jaringan: public, private, consortium
- Properti utama: immutability, transparansi, desentralisasi
- Relevansi blockchain consortium (DCHAIN) untuk konteks pendidikan tinggi

## 2.2 Ethereum dan Ethereum Virtual Machine (EVM)

- Arsitektur jaringan Ethereum
- EVM sebagai runtime environment untuk smart contract
- Konsep gas, transaksi, dan block confirmation
- Jaringan testnet (Sepolia) vs mainnet
- DCHAIN sebagai consortium chain berbasis EVM — kompatibilitas dan perbedaan dengan public Ethereum

## 2.3 Smart Contract

- Definisi: program yang berjalan on-chain, mengeksekusi logic secara deterministik
- Siklus hidup: penulisan (Solidity) → kompilasi → deployment → interaksi
- Peran sebagai business logic layer dalam arsitektur dApp
- Keunggulan: trustless execution, auditability, tamper resistance
- OpenZeppelin sebagai library standar untuk keamanan smart contract

## 2.4 Tokenisasi dan Real World Assets (RWA)

- Definisi tokenisasi: representasi aset (fisik/ digital) sebagai token on-chain
- Konsep Real World Assets (RWA): menghubungkan aset dunia nyata ke blockchain
- Jenis tokenisasi: fungible (ERC-20) vs non-fungible (ERC-721)
- Mengapa peralatan lab bersifat unik → cocok untuk tokenisasi non-fungible
- Use cases RWA tokenization: real estate, commodity, equipment tracking
- Bagaimana RWA tokenization diterapkan dalam sistem ini: peralatan lab → NFT

## 2.5 Standar ERC-721 dan NFT

- Definisi NFT (Non-Fungible Token) dan perbedaannya dengan FT
- Standar ERC-721: interface, fungsi utama (ownerOf, transferFrom, approve)
- Metadata on-chain vs off-chain
- Mengapa ERC-721 dipilih: setiap peralatan lab memiliki identitas unik (serial number, tipe, pabrikan)
- Pemetaan: Tool struct (name, factory, typeModel, serialNumber) sebagai metadata on-chain NFT
- AccessControl (RBAC): pemisahan peran Admin dan Calibrator

## 2.6 InterPlanetary File System (IPFS)

- Definisi dan konsep distributed file storage
- Content addressing (CID) vs location addressing
- Pinning dan gateway (Pinata)
- Peran IPFS dalam sistem ini: penyimpanan sertifikat kalibrasi PDF
- Pemetaan: CalibrationRecord.ipfsHash sebagai link ke sertifikat di IPFS
- Keunggulan: sertifikat tidak tersimpan on-chain (hemat gas), tapi hash-nya immutable di blockchain

## 2.7 Kalibrasi Peralatan Laboratorium Tegangan Tinggi

- Definisi kalibrasi dan pentingnya di lab tegangan tinggi
- Standar kalibrasi yang berlaku (ISO 17025, SNI, IEC)
- Traceability: rantai ketertelusuran dari alat ukur ke standar nasional/internasional
- Dokumentasi kalibrasi: sertifikat, tanggal, lembaga kalibrator, hasil
- Tantangan pencatatan manual dan kebutuhan akan sistem digital yang terverifikasi
- Hubungan dengan akreditasi laboratorium

## 2.8 Tinjauan Penelitian Terdahulu

- Blockchain untuk manajemen laboratorium universitas (Bai et al., 2019; Al-Zoubi et al., 2022)
- Blockchain untuk testing laboratory (Yuan et al., 2022)
- RWA tokenization dan asset tracking (Sheldon, 2022; Ho et al., 2021)
- Smart contract untuk inventory/asset management (Chang et al., 2019; Hasan et al., 2019)
- Blockchain di pendidikan tinggi (Bhaskar et al., 2021; Dias et al., 2024)
- Analisis gap: belum ada yang menggabungkan RWA tokenization dengan kalibrasi peralatan lab TVT
- Posisi penelitian ini: mengisi gap dengan mengimplementasikan RWA tokenization (ERC-721) untuk pencatatan kalibrasi peralatan lab TVT di DCHAIN

---

## Keterkaitan Antar Sub-bab

```
2.1 Blockchain (fondasi teknologi)
  → 2.2 Ethereum/EVM (platform spesifik)
    → 2.3 Smart Contract (mekanisme di atas platform)
      → 2.4 RWA Tokenization (framework: aset fisik → token digital)
        → 2.5 ERC-721/NFT (standar teknis implementasi tokenisasi)
          → 2.6 IPFS (storage layer untuk dokumen pendukung)
            → 2.7 Kalibrasi (domain masalah yang diselesaikan)
              → 2.8 Tinjauan Penelitian (posisi dalam landscape)
```

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| RWA Tokenization sebagai landasan teori utama | Blockchain transparency saja | Konsep RWA menjembatani teori blockchain dengan domain fisik (peralatan lab), sesuai implementasi NFT |
| Alur dari umum ke spesifik | Topik-based acak | Pembaca non-blockchain bisa membangun pemahaman bertahap |
| IPFS sebagai sub-bab terpisah | Digabung ke smart contract | IPFS punya peran distrik (storage off-chain) dan perlu dijelaskan hubungannya dengan on-chain data |
| Tinjauan penelitian di akhir bab | Di awal bab | Setelah teori kuat, baru posisi penelitian bisa dipahami dalam konteks |
