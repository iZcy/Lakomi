# Bab 3: Metode Penelitian

> **Catatan**: Bab ini mengimplementasikan teori Bab 2 dan menjawab rumusan masalah Bab 1.

## 3.1 Alat dan Bahan

### Perangkat Lunak
- **Smart Contract**: Solidity ^0.8.24, Hardhat framework, OpenZeppelin Contracts
- **Frontend**: Next.js 16, React 19, Tailwind CSS 4, TypeScript
- **Blockchain Integration**: Viem 2.46.3
- **Database**: SQLite dengan Prisma ORM
- **Storage**: IPFS via Pinata
- **Testing**: Hardhat test runner (Chai/Mocha)

### Infrastruktur
- **Jaringan testing**: Ethereum Sepolia testnet
- **Jaringan deployment**: DCHAIN (jaringan blockchain pendidikan tinggi Indonesia, EVM-compatible)
- **Wallet**: MetaMask atau wallet EVM-compatible

### Perangkat Keras
- Spesifikasi mesin pengembangan (PC/laptop yang digunakan)

## 3.2 Metode Penelitian

- Metode: **Research and Development (R&D)** dengan pendekatan **prototype development**
- Alur penelitian:
  1. Studi literatur → Bab 2
  2. Analisis kebutuhan sistem → identifikasi requirement dari domain kalibrasi lab TVT
  3. Desain sistem → arsitektur, data model, smart contract design
  4. Implementasi → coding smart contract dan frontend
  5. Pengujian → functional testing (smart contract) dan black-box testing (frontend)
  6. Analisis hasil → evaluasi terhadap tujuan penelitian (Bab 4)

## 3.3 Arsitektur Sistem

- Diagram arsitektur end-to-end (tier diagram):
  ```
  [User Browser]
       ↓
  [Frontend - Next.js]
       ↓
  [API Routes] → [SQLite/Prisma] (autentikasi user)
       ↓
  [Blockchain Layer - LabEquipmentTracker.sol] (on-chain data)
       ↓
  [IPFS/Pinata] (sertifikat PDF)
  ```
- Penjelasan per layer:
  - **Presentation Layer**: Next.js frontend (3 portal)
  - **Application Layer**: API routes + JWT auth
  - **Blockchain Layer**: Smart contract (business logic on-chain)
  - **Storage Layer**: IPFS untuk file, SQLite untuk user management

## 3.4 Desain Smart Contract

### Struktur Data
- `Tool` struct: name, factory, typeModel, serialNumber → metadata alat
- `CalibrationRecord` struct: timestamp, calibrationDate, calibrator, ipfsHash → riwayat kalibrasi

### Role-Based Access Control (RBAC)
- `DEFAULT_ADMIN_ROLE`: mint peralatan baru, mengelola calibrator
- `CALIBRATOR_ROLE`: input catatan kalibrasi dan upload sertifikat

### Fungsi Utama
- `mintTool()`: registrasi peralatan baru sebagai NFT (Admin only)
- `addCalibration()`: tambah catatan kalibrasi ke peralatan tertentu (Calibrator only)
- `getToolInfo()`: baca informasi peralatan (public)
- `getCalibrationHistory()`: baca riwayat kalibrasi lengkap (public)

### Event Logging
- `ToolMinted`: emitted saat alat baru didaftarkan
- `CalibrationAdded`: emitted saat kalibrasi dicatat

## 3.5 Desain Frontend

### Arsitektur Aplikasi
- Next.js App Router dengan React Server Components + Client Components
- Autentikasi JWT (httpOnly cookie) untuk Admin dan Calibrator

### Portal dan Fungsionalitas

**1. Portal Admin (/admin)**
- Autentikasi diperlukan (role: ADMIN)
- Registrasi peralatan baru (mint NFT)
- Manajemen user (buat/hapus akun calibrator)
- Melihat konfirmasi transaksi

**2. Portal Calibrator (/calibrate)**
- Autentikasi diperlukan (role: CALIBRATOR)
- Input catatan kalibrasi untuk peralatan tertentu (tokenId)
- Upload sertifikat PDF ke IPFS (atau input IPFS hash manual)
- Melihat konfirmasi transaksi

**3. Portal Verifikasi Publik (/verify)**
- Tanpa autentikasi
- Cari peralatan berdasarkan Token ID
- Tampilkan informasi peralatan dan status kalibrasi
- Tampilkan riwayat kalibrasi lengkap dengan link sertifikat IPFS

### Integrasi Blockchain
- Library: Viem untuk interaksi dengan smart contract
- Wallet client untuk transaksi write (Admin, Calibrator)
- Public client untuk transaksi read (verifikasi)

## 3.6 Alur Kerja Sistem

### Skenario 1: Registrasi Peralatan Baru
1. Admin login → masuk portal admin
2. Isi form data peralatan (nama, pabrikan, tipe, serial number)
3. Sistem memanggil `mintTool()` pada smart contract
4. NFT dicetak, data tersimpan on-chain
5. Event `ToolMinted` teremit, konfirmasi ditampilkan

### Skenario 2: Input Catatan Kalibrasi
1. Calibrator login → masuk portal calibrator
2. Upload sertifikat PDF ke IPFS via Pinata → dapat CID
3. Input tokenId, tanggal kalibrasi, nama lembaga, IPFS hash
4. Sistem memanggil `addCalibration()` pada smart contract
5. Catatan kalibrasi tersimpan on-chain
6. Event `CalibrationAdded` teremit, konfirmasi ditampilkan

### Skenario 3: Verifikasi Publik
1. Pengguna mengakses portal verifikasi (tanpa login)
2. Input Token ID peralatan
3. Sistem membaca `getToolInfo()` dan `getCalibrationHistory()`
4. Ditampilkan: info peralatan, status kalibrasi, riwayat kalibrasi, link sertifikat

> Setiap skenario disertai sequence diagram

## 3.7 Pengujian

### 3.7.1 Pengujian Smart Contract (Functional Testing)
- Framework: Hardhat test runner
- Skenario pengujian:
  - Minting peralatan (hanya Admin)
  - Penambahan catatan kalibrasi (hanya Calibrator)
  - Manajemen role (grant/revoke)
  - Negative test: akses tanpa role yang sesuai
  - Multiple calibration records per peralatan
  - Event emission verification

### 3.7.2 Pengujian Frontend (Black-Box Testing)
- Uji fungsionalitas per portal berdasarkan requirement
- Tabel test case: ID, skenario, input expected, output expected, hasil

---

## Keterkaitan dengan Bab Lain

| Konsep di Bab 2 | Implementasi di Bab 3 |
|-----------------|----------------------|
| Blockchain (2.1) | Arsitektur sistem on-chain (3.3) |
| Ethereum/EVM (2.2) | Hardhat deployment ke Sepolia/DCHAIN (3.1) |
| Smart Contract (2.3) | Desain LabEquipmentTracker.sol (3.4) |
| RWA Tokenization (2.4) | Tool struct sebagai representasi aset fisik (3.4) |
| ERC-721/NFT (2.5) | mintTool() mencetak NFT per peralatan (3.4) |
| IPFS (2.6) | Upload sertifikat ke Pinata, ipfsHash di CalibrationRecord (3.6) |
| Kalibrasi (2.7) | Alur input kalibrasi dan verifikasi (3.6) |

| Rumusan Masalah Bab 1 | Dijawab di Bab 3 |
|----------------------|-------------------|
| Merancang sistem kalibrasi berbasis blockchain | Arsitektur dan desain sistem (3.3-3.5) |
| RWA tokenization merepresentasikan peralatan | Desain smart contract dengan Tool struct + NFT (3.4) |
| Transparansi dan immutability | Alur kerja + pengujian (3.6-3.7) |

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| Metode R&D dengan prototype | SDLC Waterfall, Agile | Sesuai untuk proof of concept, iteratif dan praktis |
| Hardhat sebagai framework | Truffle, Foundry | Hardhat paling populer dan sudah digunakan di development |
| 3 skenario alur kerja | Lebih banyak skenario | 3 skenario mencakup seluruh use case utama sistem |
| Black-box testing frontend | White-box, integration | Fokus pada fungsionalitas dari perspektif pengguna |
