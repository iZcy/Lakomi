# Bab 4: Hasil dan Pembahasan

> **Catatan**: Bab ini menjawab 3 rumusan masalah dari Bab 1 dengan bukti dari implementasi dan pengujian.

## 4.1 Hasil Implementasi Smart Contract

- Bukti deployment: contract address, transaction hash, block number di jaringan Sepolia
- Penjelasan setiap fungsi yang berhasil diimplementasikan:
  - `mintTool()`: registrasi peralatan sebagai NFT ERC-721
  - `addCalibration()`: pencatatan kalibrasi dengan IPFS hash
  - `getToolInfo()`: pembacaan informasi peralatan (public)
  - `getCalibrationHistory()`: pembacaan riwayat kalibrasi lengkap (public)
- Role management: grant/revoke CALIBRATOR_ROLE
- Event logs sebagai bukti immutability on-chain (ToolMinted, CalibrationAdded)
- Screenshot dari block explorer (Etherscan) menunjukkan transaksi dan event

## 4.2 Hasil Implementasi Frontend

### Portal Admin (/admin)
- Screenshot: form registrasi peralatan baru
- Screenshot: daftar user dan manajemen user
- Screenshot: konfirmasi transaksi minting berhasil
- Penjelasan fungsionalitas yang berjalan

### Portal Calibrator (/calibrate)
- Screenshot: form input kalibrasi (tokenId, tanggal, lembaga, sertifikat)
- Screenshot: upload sertifikat PDF ke IPFS via Pinata
- Screenshot: konfirmasi transaksi kalibrasi berhasil
- Penjelasan fungsionalitas yang berjalan

### Portal Verifikasi Publik (/verify)
- Screenshot: pencarian peralatan berdasarkan Token ID
- Screenshot: tampilan informasi peralatan dan status kalibrasi
- Screenshot: riwayat kalibrasi lengkap dengan link sertifikat IPFS
- Penjelasan fungsionalitas yang berjalan — tanpa autentikasi, publik

### Autentikasi dan Keamanan
- Screenshot: halaman login
- Penjelasan JWT-based auth, bcrypt password hashing, httpOnly cookie

## 4.3 Hasil Pengujian Smart Contract

- Tabel hasil unit test:

| No | Skenario Pengujian | Input | Expected Output | Actual Output | Status |
|----|-------------------|-------|-----------------|---------------|--------|
| 1 | Mint tool oleh Admin | Data peralatan valid | NFT tercetak, tokenId dikembalikan | Sesuai | Pass |
| 2 | Mint tool oleh non-Admin | Data peralatan valid | Revert (access denied) | Sesuai | Pass |
| 3 | Add calibration oleh Calibrator | Data kalibrasi valid | Record tersimpan | Sesuai | Pass |
| 4 | Add calibration oleh non-Calibrator | Data kalibrasi valid | Revert (access denied) | Sesuai | Pass |
| 5 | Get tool info | tokenId valid | Struct Tool dikembalikan | Sesuai | Pass |
| 6 | Get calibration history | tokenId valid | Array CalibrationRecord | Sesuai | Pass |
| 7 | Multiple calibrations per tool | Beberapa record kalibrasi | Semua record tersimpan terurut | Sesuai | Pass |
| 8 | Grant/revoke calibrator role | Address calibrator | Role berubah | Sesuai | Pass |
| 9 | Event ToolMinted emission | Mint berhasil | Event teremit dengan data benar | Sesuai | Pass |
| 10 | Event CalibrationAdded emission | Kalibrasi berhasil | Event teremit dengan data benar | Sesuai | Pass |

- Coverage analysis: semua fungsi dan path (happy path + error path) tercakup
- Kesimpulan: smart contract berfungsi sesuai spesifikasi desain

## 4.4 Hasil Pengujian Frontend (Black-Box Testing)

- Tabel test case per portal:

**Portal Admin:**

| No | Skenario | Input | Expected | Hasil |
|----|----------|-------|----------|-------|
| 1 | Login Admin valid | Credentials benar | Redirect ke dashboard | Pass |
| 2 | Login Admin invalid | Password salah | Error message | Pass |
| 3 | Registrasi peralatan baru | Form lengkap | NFT tercetak, konfirmasi | Pass |
| 4 | Buat user Calibrator | Username, password, role | User terbuat | Pass |
| 5 | Hapus user | Pilih user | User terhapus | Pass |

**Portal Calibrator:**

| No | Skenario | Input | Expected | Hasil |
|----|----------|-------|----------|-------|
| 1 | Login Calibrator valid | Credentials benar | Redirect ke portal | Pass |
| 2 | Upload sertifikat PDF | File PDF | CID IPFS dikembalikan | Pass |
| 3 | Input kalibrasi | Form lengkap | Record tersimpan, konfirmasi | Pass |
| 4 | Input kalibrasi tanpa tokenId | Form kosong | Error validation | Pass |

**Portal Verifikasi:**

| No | Skenario | Input | Expected | Hasil |
|----|----------|-------|----------|-------|
| 1 | Cari peralatan valid | Token ID exist | Info peralatan + riwayat kalibrasi | Pass |
| 2 | Cari peralatan tidak ada | Token ID invalid | Pesan tidak ditemukan | Pass |
| 3 | Akses tanpa login | Langsung buka /verify | Bisa diakses | Pass |

- Kesimpulan: semua fungsionalitas frontend berjalan sesuai requirement

## 4.5 Analisis Transparansi (Jawaban Rumusan Masalah #3a)

- **Transparansi akses**: Siapa saja dapat memverifikasi riwayat kalibrasi peralatan melalui portal publik tanpa perlu login atau wallet
- **Transparansi data**: Semua informasi peralatan dan riwayat kalibrasi dapat dibaca on-chain melalui `getToolInfo()` dan `getCalibrationHistory()`
- **Transparansi aktor**: Setiap catatan kalibrasi tercatat siapa calibrator-nya (field `calibrator` dalam CalibrationRecord)
- **Bukti**: Screenshot block explorer menunjukkan semua transaksi visible, termasuk event logs
- **Perbandingan dengan sistem manual**: Dalam sistem manual, riwayat kalibrasi hanya diketahui oleh pihak yang mengelola spreadsheet/buku catatan

## 4.6 Analisis Immutability (Jawaban Rumusan Masalah #3b)

- **Immutability on-chain**: Setelah catatan kalibrasi ditulis ke blockchain, data tidak dapat diubah atau dihapus
- **Mekanisme**: Hash kriptografis pada setiap block memastikan retroactive alteration secara komputasional tidak feasible
- **Smart contract design**: Fungsi `addCalibration()` hanya menambah (append-only), tidak ada fungsi update/delete
- **Bukti**: Tunjukkan bahwa transaksi di block explorer tidak dapat di-modify setelah dikonfirmasi
- **Perbandingan dengan sistem manual**: Spreadsheet dapat diedit, kolom dapat dihapus, tidak ada audit trail perubahan

## 4.7 Analisis RWA Tokenization (Jawaban Rumusan Masalah #2)

- **Tokenisasi berhasil**: Peralatan fisik (trafo uji, generator impuls, dsb.) berhasil direpresentasikan sebagai NFT ERC-721 on-chain
- **Metadata mapping**:
  - Aset fisik → Tool struct (name, factory, typeModel, serialNumber)
  - Sertifikat fisik → IPFS hash dalam CalibrationRecord
  - Lembaga kalibrator → field `calibrator` dalam CalibrationRecord
- **Evaluasi kesesuaian**: Apakah metadata on-chain cukup merepresentasikan identitas unik peralatan?
- **Manfaat tokenisasi**: Ownership tracking, transfer history, lifecycle documentation dalam satu token
- **Keterbatasan**: Metadata bersifat string — tidak ada validasi format on-chain (bergantung pada frontend validation)

## 4.8 Perbandingan dengan Sistem Manual

Tabel komparatif:

| Aspek | Sistem Manual (Spreadsheet) | Sistem Blockchain |
|-------|----------------------------|-------------------|
| Transparansi | Terbatas, hanya pihak pengelola | Publik, siapa saja bisa verifikasi |
| Immutability data | Dapat diedit/dihapus | Immutable, tidak dapat diubah |
| Audit trail | Tidak ada atau manual | Otomatis via event logs dan block history |
| Aksesibilitas | Lokal, perlu akses file | Online, via web portal |
| Keamanan data | Rentan manipulasi | Dilindungi kriptografi |
| Keterlacakan kalibrator | Manual, tidak konsisten | Tercatat on-chain per transaksi |
| Penyimpanan sertifikat | Fisik atau lokal | Terdesentralisasi (IPFS) |
| Single point of failure | Ya (file hilang/rusak) | Tidak (terdistribusi di node) |

- Pembahasan: keunggulan dan keterbatasan sistem blockchain dibandingkan pendekatan konvensional
- Catatan: sistem ini merupakan proof of concept, adoption di dunia nyata membutuhkan pertimbangan cost (gas fee) dan UX

---

## Keterkaitan dengan Bab Lain

| Sumber | Digunakan di Bab 4 |
|--------|-------------------|
| Rumusan masalah Bab 1 (3 pertanyaan) | Dijawab di 4.5, 4.6, 4.7 |
| Teori blockchain Bab 2.1 | Dasar analisis immutability (4.6) |
| Teori RWA Tokenization Bab 2.4 | Dasar analisis tokenisasi (4.7) |
| Teori ERC-721 Bab 2.5 | Evaluasi kesesuaian NFT metadata (4.7) |
| Teori IPFS Bab 2.6 | Bukti penyimpanan sertifikat (4.2, 4.7) |
| Desain smart contract Bab 3.4 | Dibuktikan implementasinya (4.1, 4.3) |
| Skenario alur kerja Bab 3.6 | Dibuktikan fungsionalitasnya (4.2, 4.4) |
| Pengujian Bab 3.7 | Hasilnya dilaporkan (4.3, 4.4) |

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| Analisis per rumusan masalah | Analisis per fitur sistem | Langsung menjawab tujuan penelitian |
| Tabel komparatif dengan sistem manual | Benchmark kuantitatif (gas, latency) | Scope proof of concept, fokus pada value proposition |
| Screenshot sebagai bukti | Video demo | Format thesis statis, screenshot lebih tepat |
