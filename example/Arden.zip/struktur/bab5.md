# Bab 5: Kesimpulan dan Saran

## 5.1 Kesimpulan

Kesimpulan disusun menjawab 3 tujuan penelitian secara langsung:

### Kesimpulan 1 (Jawaban Tujuan #1 — Perancangan Sistem)
Berdasarkan hasil penelitian, telah berhasil dirancang dan diimplementasikan sistem pencatatan kalibrasi peralatan laboratorium tegangan tinggi berbasis blockchain menggunakan smart contract LabEquipmentTracker. Sistem ini menerapkan arsitektur multi-layer yang terdiri dari frontend (Next.js), smart contract (Solidity pada EVM-compatible blockchain), dan penyimpanan terdesentralisasi (IPFS). Pengujian fungsional menunjukkan seluruh fungsi smart contract dan fungsionalitas frontend berjalan sesuai spesifikasi desain.

### Kesimpulan 2 (Jawaban Tujuan #2 — RWA Tokenization)
Konsep Real World Assets (RWA) Tokenization telah berhasil diterapkan untuk merepresentasikan peralatan lab tegangan tinggi sebagai aset digital. Setiap peralatan didaftarkan sebagai NFT ERC-721 dengan metadata on-chain (nama, pabrikan, tipe, serial number), sementara sertifikat kalibrasi disimpan di IPFS dengan hash-nya tercatat on-chain. Pendekatan ini menghubungkan aset fisik dengan representasi digital secara verifiable dan traceable.

### Kesimpulan 3 (Jawaban Tujuan #3 — Transparansi dan Immutability)
Sistem yang dikembangkan memberikan transparansi melalui portal verifikasi publik yang memungkinkan siapa saja membaca informasi peralatan dan riwayat kalibrasi tanpa autentikasi. Immutability dicapai melalui sifat dasar blockchain di mana setiap catatan kalibrasi bersifat append-only dan tidak dapat diubah setelah dikonfirmasi on-chain. Dibandingkan dengan sistem manual (spreadsheet), sistem blockchain menawarkan keunggulan signifikan dalam hal audit trail, keamanan data, dan keterlacakan.

## 5.2 Saran

### Pengembangan Teknis
1. **Deployment ke DCHAIN**: Setelah jaringan DCHAIN aktif, deploy smart contract ke jaringan tersebut untuk memanfaatkan infrastruktur blockchain pendidikan tinggi Indonesia
2. **Integrasi IoT**: Menghubungkan sensor peralatan lab dengan smart contract untuk pencatatan kalibrasi yang lebih otomatis dan real-time
3. **Mobile Application**: Mengembangkan aplikasi mobile untuk kemudahan akses verifikasi kalibrasi di lapangan

### Pengembangan Fungsional
4. **Notifikasi kalibrasi**: Menambahkan fitur peringatan otomatis saat masa berlaku kalibrasi peralatan mendekati habis
5. **Multi-lab interoperability**: Memperluas sistem agar dapat digunakan oleh beberapa laboratorium secara interoperable dalam satu jaringan consortium
6. **Pengukuran kuantitatif**: Melakukan benchmark performa (gas cost, latency, throughput) secara kuantitatif untuk evaluasi yang lebih komprehensif

### Adopsi Institusional
7. **Integrasi dengan sistem akreditasi**: Menghubungkan data kalibrasi on-chain dengan proses akreditasi laboratorium (ISO 17025)
8. **Standardisasi metadata**: Menetapkan standar metadata on-chain untuk peralatan lab agar interoperable antar institusi

---

## Keterkaitan dengan Bab Lain

| Kesimpulan | Merangkum dari |
|-----------|----------------|
| Kesimpulan 1 | Bab 3 (desain & implementasi) + Bab 4.1-4.4 (hasil) |
| Kesimpulan 2 | Bab 2.4-2.5 (teori RWA & ERC-721) + Bab 4.7 (analisis tokenisasi) |
| Kesimpulan 3 | Bab 2.1 (teori blockchain) + Bab 4.5-4.6 (analisis transparansi & immutability) |

## Decision Log

| Keputusan | Alternatif | Alasan |
|-----------|-----------|--------|
| 3 kesimpulan = 3 tujuan | Kesimpulan umum | Langsung menjawab tujuan penelitian, konsisten dengan rumusan masalah |
| Saran terstruktur (teknis, fungsional, institusional) | Daftar saran acak | Menunjukkan roadmap pengembangan yang jelas dan terorganisir |
| Deployment ke DCHAIN sebagai saran #1 | Sudah termasuk dalam batasan | DCHAIN belum aktif, jadi masih realistis sebagai saran pengembangan |
