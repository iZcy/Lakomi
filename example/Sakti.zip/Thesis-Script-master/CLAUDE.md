# CLAUDE.md — Research 4: Skripsi AES

## What This Is

Undergraduate thesis (skripsi) by **Sakti Cahya**, DTETI UGM.
Topic: **Automated Essay Scoring (AES) for IELTS Academic Writing Task 1** using multimodal inputs.
Dataset: EssayJudge (Singh et al. 2025) — 1,054 essays, 10 traits, images (charts/graphs).
Best result: **Exp161, avg test QWK = 0.5802** (T2T CrossAttn CLS, Qwen7B excl bar+pie, seed=42).

Two approaches explored:
- **Pendekatan A** — ResNet + RoBERTa multimodal fusion. Best: Exp057 (RoBERTa+ResNet50+CrossAttn+CE), QWK=0.5270.
- **Pendekatan B** — VLM caption → Dual RoBERTa text-to-text. Best: Exp161 (DualRobertaCrossAttnCls), QWK=0.5802.

---

## Who Is Involved

- **User**: Sakti — undergrad student, thesis author. Runs experiments on Kaggle (P100 GPU) and writes thesis in Google Docs via Python scripts.
- **Claude**: assists with writing scripts, analyzing results, and drafting thesis chapters.

---

## Prime Rules (Always Follow)

1. **Terminology**: Use "Pendekatan A" / "Pendekatan B" in all thesis writing. Never "Track A/B" in prose (scripts may use Track A/B internally).
2. **Writing rules**: All 6 rules in `context/writing_rules.md` are mandatory for any BAB writing.
3. **No em dash (—)** in thesis body text. **Colon (:) is only allowed before a list of 2 or more explicit items** (e.g., "terdapat dua pendekatan: Pendekatan A dan Pendekatan B"). Never use a colon to introduce a single concept, explanation, finding, or continuation of a sentence — rewrite with "yaitu", "yakni", "bahwa", or a comma instead.
4. **English technical terms** in Indonesian prose must be *italicized*.
5. **No QWK results or experiment references** in BAB II (dasar teori/tinjauan pustaka).
6. **VLM ≤7B params** constraint — stated in BAB I, must be consistent everywhere.
7. **Git push**: never push directly from Research 4 to `origin`. Use subtree push for `thesis-script` remote. See `context/00_START_HERE.md`.
8. **No Unicode** in Python print statements (Windows cp1252 encoding issue).

9. **No Claude as contributor**: Never add "Co-Authored-By: Claude" or any Claude/Anthropic attribution in git commits, commit messages, PRs, or any file. This rule is permanent and unchanged unless explicitly overridden by the user.

10. **Diagram style standard** (draw.io): use `late_fusion.drawio` as the canonical reference for all future architecture diagrams. Rules derived from that file:
    - **Font**: Times New Roman on all elements (nodes, labels, edges, group box titles)
    - **Node colors** (fill / stroke):
      - Input: `#f5f5f5` / `#666666` (gray), `fontColor=#333333`
      - Encoder: `#dae8fc` / `#6c8ebf` (blue)
      - Process/intermediate: `#ffe6cc` / `#d79b00` (orange)
      - Fusion: `#d5e8d4` / `#82b366` (green)
      - Output: `#f8cecc` / `#b85450` (red)
    - **Node style**: `rounded=1;whiteSpace=wrap;html=1;` + fill/stroke + `fontFamily=Times New Roman;`
    - **Group/background boxes**: `rounded=0;whiteSpace=wrap;html=1;labelBorderColor=none;dashed=1;verticalAlign=top;fontStyle=1;fillColor=none;` — **no fill color**, just dashed border; label in Times New Roman
    - **Arrows**: `orthogonalEdgeStyle;endArrow=block;endFill=1;fontFamily=Times New Roman;`
    - **TikZ equivalent**: `gray!12` / `blue!12` / `orange!15` / `green!15` / `red!12`; background boxes use `fill=none` with dashed border (`draw=blue!40, dashed`)

---

## Priority Order for Conflicting Information

`history/` > `CLAUDE.md` > `context/` files

---


## Research Rule
1. **Paper citations must be verified via web search**: Before citing any paper, search for it, fetch the full page (not just abstract), and confirm: correct authors, title, DOI, venue, year, and that the paper's actual content (methodology + findings) matches how it is cited in the thesis. Abstracts can mislead — read the full paper. Prioritize highly cited and recent sources. Never guess or invent DOIs.

## Navigation

See **Route.md** for the index of all context files, external resources, and tool references.

---

## History Instruction

After every prompt, spawn a subagent to:
1. Append a history entry to `history/YYYY-MM-DD.md` (today's date).
2. Update any `context/` files that changed (set `status: current`).
3. Add a `Changelog.md` entry if a version or research finding occurred.
