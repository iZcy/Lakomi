# Changelog

> Log of software versions, configuration changes, and research findings.
> Format: `## [YYYY-MM-DD] vX.X or Research: Topic`

---

## [2026-04-21] Research: Context System Initialized

- Created `CLAUDE.md`, `Route.md`, `Changelog.md`, `context/README.md`, `history/` structure.
- All pre-existing context files (`00_START_HERE.md`, `writing_rules.md`, `writing_status.md`, `bab2_structure.md`, `bab4_structure.md`, `experiments.json`) folded into Route.md index.
- Establishes session-end subagent protocol for history + context updates.

---

## [2026-04-20] Research: flow.md Updated

- Exp020 (MATCHA) and Exp021 (PaliGemma) formally dropped from narrative flow.
- DePlot (Exp103) selected as canonical captioner for bar+pie.
- Caption error rates added: Qwen7B bar=54%/pie=67%, DePlot+Qwen7B bar=23%/pie=67%, MATCHA bar=100%/pie=100%.
- Key finding confirmed: caption factual accuracy ≠ downstream AES QWK.

---

## [2026-04-19] Research: RQ5 Updated + BAB I Point 7 Added

- RQ5 changed from InternVL2 comparison to Qwen2-VL-7B vs DeepSeek-VL-7B (both ≤7B, fair comparison).
- BAB I section 1.4 patched: added point 7 (VLM ≤7B constraint, Qwen vs DeepSeek).
- Numbering style fixed in Google Docs.

---

## [Earlier] Research: Exp093 = Best Result

- Exp093 (T2T Qwen7B excl bar+pie, seed=42): test QWK = **0.5778** — best across all experiments.
- Per-trait: AC=0.330, JP=0.572, OS=0.589, CH=0.606, EL=0.503, GA=0.688, GD=0.653, LA=0.658, LD=0.610, PA=0.570.
- Seeding (+0.083 vs non-seeded 0.4945) confirmed as critical for reproducibility.

---

## [Earlier] Research: T2T > Fusion Confirmed

- Pendekatan B (T2T) best: 0.5778 vs Pendekatan A (fusion) best: 0.5126.
- Exception: OS (organizational structure) trait — Pendekatan A slightly better.
- Finding: larger VLM (InternVL2-8B) not the bottleneck; DePlot specialized captioning helps bar charts specifically.

---

## [Earlier] Research: Multi-task >> Per-trait Training

- Multi-task (10 traits jointly): significantly better than 10 separate models.
- EDA text augmentation: **confirmed to fail** (Exp062, QWK=0.000) — corrupts essay text and creates conflicting labels.
- Siamese RoBERTa (shared encoder): worse than dual independent encoders at 737-sample scale.
