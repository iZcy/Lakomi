# Route.md — Resource Index

> All context files, external links, tools, credentials. Last verified dates shown.

---

## Context Files

| File | Description | Last Verified |
|------|-------------|---------------|
| `context/00_START_HERE.md` | Project overview, RQs, current chapter status, key decisions, git rules | 2026-04-21 |
| `context/writing_rules.md` | 6 mandatory rules for all BAB writing (depth, em dash, italic, Pendekatan, media, citations) | 2026-04-21 |
| `context/writing_status.md` | Google Docs IDs, tab IDs, all script names/status, formatting standards, BAB I–III structure | 2026-04-21 |
| `context/bab2_structure.md` | BAB II 26-subsection plan with content notes, progress tracker, citation corrections | 2026-04-21 |
| `context/bab4_structure.md` | BAB IV section map, which experiments go where, pending data needs | 2026-04-21 |
| `context/experiments.json` | All experiment results: QWK per-trait, configs, seeded/non-seeded variants | 2026-04-21 |
| `thesis_01/flow.md` | Narrative flow Steps 1–8 (source of truth for thesis storyline) | 2026-04-21 |
| `thesis_01/bab4_outline.md` | BAB IV full outline v4 (detailed, subsection level) | 2026-04-21 |
| `thesis_01/write_bab3.py` | Canonical template for all write_babX.py scripts | 2026-04-21 |

---

## History

| File | Description | Last Verified |
|------|-------------|---------------|
| `history/README.md` | History folder rules (append-only, format) | 2026-04-21 |
| `history/2026-04-21.md` | Session log: context system setup | 2026-04-21 |

---

## External Services & Credentials

| Resource | Description | Last Verified |
|----------|-------------|---------------|
| Google Docs — Doc ID `1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY` | Thesis Google Doc with all chapter tabs | 2026-04-21 |
| Service account key — `primal-index-492509-s6-133bb47b7a74.json` | Google Docs API credentials (local, do not commit) | 2026-04-21 |
| Kaggle kernel — `sakticahya/exp10-deplot-qwen7b-barpicomposite` | Reference kernel for DePlot+Qwen7B pipeline | 2026-04-21 |
| HuggingFace token — see `memory/reference_hf_token.md` | For gated models (Llama, etc.) | 2026-04-21 |

---

## Key Paths (Local)

| Path | Description |
|------|-------------|
| `C:/Outpost/Skripsi/Research 3/EssayJudge/data.csv` | EssayJudge dataset (1054 rows) |
| `C:/Outpost/Skripsi/Research 3/shared_data/image_cache/` | Cached chart images (image_0.jpg … image_1053.jpg) |
| `C:/Outpost/Skripsi/Research 3/Experiment/054_T2T-Qwen-Improved/captions/qwen7b_captions_full1054.json` | Qwen2-VL-7B captions for all 1054 images |
| `C:/Outpost/Skripsi/Research 4/thesis_01/` | All thesis writing scripts + context files |
| `C:/Outpost/Skripsi/Research 4/thesis_latex/` | LaTeX thesis draft (in progress) |
| `C:/Users/LEGION/AppData/Local/Programs/Python/Python312/python.exe` | Python executable |

---

## Git Remotes

| Remote | Repo | Push Command |
|--------|------|-------------|
| `origin` (from `C:\Outpost\Skripsi\`) | Full thesis repo | `git push origin master` |
| `thesis-script` (from `C:\Outpost\Skripsi\`) | Research 4 only | `git subtree push --prefix "Research 4" thesis-script master` |
