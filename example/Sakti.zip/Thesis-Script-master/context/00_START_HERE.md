# START HERE — Research 4 Context Index
> Read this first. It tells you what the project is, where we are, and what to do next.

---

## What Is This Project

**Skripsi (undergrad thesis)** — Sakti, DTETI UGM  
**Topic**: Automated Essay Scoring (AES) for IELTS Academic Writing Task 1  
**Dataset**: EssayJudge (Singh et al. 2024) — 1,054 essays, 10 traits, scored 0–5  
**Metric**: QWK (Quadratic Weighted Kappa), higher = better  
**Best result so far**: Exp093, QWK = **0.5778**

---

## Two Approaches

| Pendekatan | Method | Best QWK |
|------------|--------|----------|
| **Pendekatan A** | ResNet18 + RoBERTa (multimodal fusion) | 0.5126 (Exp033) |
| **Pendekatan B** | VLM caption → Dual RoBERTa (text-to-text) | **0.5778 (Exp093)** |

Pendekatan B wins overall. Pendekatan A only wins on OS (organizational structure) trait.

> **Terminology rule**: In ALL thesis writing (BAB II–V), use "Pendekatan A" and "Pendekatan B". Never "Track A/B". Scripts/experiments.json may keep "Track A/B" internally.

---

## 6 Research Questions

| RQ | Question | Status |
|----|----------|--------|
| RQ1 | Best fusion strategy: early/mid/late? (BERT+ResNet18) | DONE → Late wins |
| RQ2 | BERT vs RoBERTa as text encoder? | DONE → RoBERTa +0.029 |
| RQ3 | Pendekatan A (fusion) vs Pendekatan B (T2T)? | DONE → Pendekatan B +0.065 |
| RQ4 | DePlot vs MATCHA as bar+pie captioner? | DONE → DePlot selected |
| RQ5 | Qwen2-VL-7B vs DeepSeek-VL-7B as captioner? | PENDING (exp not run) |
| RQ6 | Is best system statistically significant vs baseline? | PENDING (needs predictions) |

**Research constraint**: All VLMs ≤7B parameters (GPU limit, stated in BAB I + BAB II)

---

## Current State of Work

| Chapter | Status |
|---------|--------|
| BAB I — Pendahuluan | ✅ WRITTEN in Google Docs |
| BAB II — Tinjauan Pustaka | 🔄 IN PROGRESS — rewriting with 26-subsection structure (see `context/bab2_structure.md`) |
| BAB III — Metodologi | ✅ WRITTEN in Google Docs |
| BAB IV — Hasil & Pembahasan | ⏳ OUTLINE DONE (v4), writing NOT started |
| BAB V — Kesimpulan | ❌ Not started |

**Immediate next step**: Write 2.2.2 Pemrosesan Multimoda → tab `t.v7l3rd9jsdie`. Pattern: new script per subsection (see `write_221_aes_evolution.py`). After each subsection, append its references to `t.catchhmle3jf` via `write_references_tab.py`. See `context/bab2_structure.md` for progress tracker and full plan.

---

## Key Files

| File | Purpose |
|------|---------|
| `context/00_START_HERE.md` | This file |
| `context/experiments.json` | All experiment results (QWK, traits, config) |
| `context/writing_status.md` | Google Docs IDs, tab IDs, scripts, formatting |
| `context/bab4_structure.md` | BAB IV outline summary + key content decisions |
| `context/bab2_structure.md` | BAB II new 26-subsection plan with content notes |
| `context/writing_rules.md` | 6 mandatory writing rules for all BAB writing |
| `thesis_01/bab4_outline.md` | Full BAB IV outline (v4, detailed) |
| `thesis_01/flow.md` | Narrative flow of thesis (Steps 1–8, source of truth) |
| `thesis_01/write_bab3.py` | Template pattern for write_babX.py scripts |

---

## Key Decisions (Do Not Revisit Without Reason)

1. **MATCHA (Exp020)**: DROPPED — QWK=0.5213 but caption review showed high error rate. DePlot selected despite lower QWK (0.5026) because factual accuracy matters more than fluency.
2. **PaliGemma (Exp021)**: DROPPED — caption generation failed entirely on Kaggle P100.
3. **InternVL2-8B (Exp12)**: OUT OF SCOPE — 8B > 7B limit. Included only as context reference (QWK=0.5017, shows ≤7B is enough).
4. **RQ5**: Changed from InternVL2 comparison to **Qwen2-VL-7B vs DeepSeek-VL-7B** (both 7B, fair comparison).
5. **Seeding**: All final experiments use seed=42 (shuffled split). Non-seeded variants exist but are superseded.
6. **Composite chart**: NOT excluded — 18% error rate is tolerable, 107 samples are valuable.

---

## Git Push Rules

- **Thesis.git** (remote: `origin`) — whole project, push from `C:\Outpost\Skripsi\`
- **Thesis-Script.git** (remote: `thesis-script`) — Research 4 ONLY
  - Push: `git subtree push --prefix "Research 4" thesis-script master` from `C:\Outpost\Skripsi\`
  - NEVER push directly from parent repo to thesis-script

---

## Context Files Index

- `experiments.json` → all QWK numbers, trait breakdowns, configs
- `writing_status.md` → Google Docs IDs, tab IDs, script list, formatting rules, BAB I–III structure
- `bab4_structure.md` → BAB IV section map, which experiments go where, pending data
