# context/ — Project Context Files

> One file per topic. Each file must have frontmatter. Written densely — facts and decisions only.
> A fresh Claude session reading any file here alone must understand the topic immediately.

---

## Frontmatter Template

```
---
last_updated: YYYY-MM-DD
updated_by: claude-session
status: current | stale | draft
---
```

Mark `status: stale` if not verified in 14+ days.

---

## Files in This Folder

| File | Topic | Status |
|------|-------|--------|
| `00_START_HERE.md` | Project overview, RQs, chapter status, key decisions, git rules | current |
| `writing_rules.md` | 6 mandatory writing rules for all BAB drafts | current |
| `writing_status.md` | Google Docs IDs, tab IDs, script list, formatting standards | current |
| `bab2_structure.md` | BAB II 26-subsection plan, progress tracker, content notes | current |
| `bab4_structure.md` | BAB IV section map, experiment-to-section mapping, pending data | current |
| `experiments.json` | All experiment QWK results, per-trait breakdowns, configs | current |

---

## Do Not Store Here

- Git history or commit logs (use `git log`)
- Ephemeral task lists (use session tasks)
- Duplicate of what's in CLAUDE.md
