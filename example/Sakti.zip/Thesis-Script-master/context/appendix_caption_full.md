---
title: Appendix Plan — Full Caption Text
status: pending
created: 2026-05-07
---

# Rencana Lampiran: Teks Caption Lengkap

## Konteks

Pada Subbab 4.4.3, tabel `tab:caption-excerpts` menampilkan kutipan diagnostik
dari tiga captioner (Qwen2-VL-7B, DePlot+Qwen2-VL-7B, MATCHA) untuk 5 grafik contoh.
Kutipan diperpendek agar muat di tabel. Teks caption lengkap direncanakan ditempatkan
di Lampiran.

## Status

- Tabel kutipan diagnostik: SELESAI (Subbab 4.4.3, `tab:caption-excerpts`)
- Lampiran teks lengkap: BELUM DIBUAT

## Isi Lampiran yang Direncanakan

Untuk setiap grafik, tampilkan teks caption lengkap dari ketiga captioner.

---

### image_924 (pie chart — label langsung pada segmen)

**Qwen2-VL-7B:**
> The pie chart illustrates the distribution of the UAE government's budget in 2000, totaling
> AED 315 billion. The largest portion of the budget, amounting to AED 100 billion, is allocated
> to social security. This is followed by health and personal social services, which receive AED 53
> billion. Education receives AED 38 billion, while transport and defense each receive AED 9 billion
> and AED 22 billion, respectively. Other categories include law and order (AED 17 billion),
> industry, agriculture, and employment (AED 13 billion), housing, heritage, and environment
> (AED 15 billion), other expenditure (AED 23 billion), debt interest (AED 23 billion). The chart
> provides a clear visual representation of how the government's resources are allocated across
> various sectors.

**DePlot+Qwen2-VL-7B:**
> The pie chart titled "Where the Money Goes" illustrates the distribution of the UAE government's
> budget in 2000, with a total budget of AED 315 billion. The largest portion of the budget,
> amounting to AED 100 billion, is allocated to social security. The second-largest expenditure
> is for health and personal social services, totaling AED 53 billion. Education receives a
> significant allocation of AED 38 billion, followed by defense with AED 22 billion. Transport
> and law and order each receive AED 9 billion and AED 17 billion, respectively. Industry,
> agriculture, and employment receive AED 13 billion. Other expenditure, including debt interest,
> housing heritage, and the environment, amounts to AED 23 billion.

**MATCHA:**
> This graph shows the results of a survey on the mobile6666799006 where the0700000000000000
> 0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
> [incoherent character sequence continues for ~500 characters]

---

### image_231 (pie chart — label hanya pada legenda berikon)

**Qwen2-VL-7B:**
> The image presents pie charts illustrating the methods used to deal with dangerous waste products
> in three different countries: the Republic of Korea, Sweden, and the United Kingdom. Each chart
> is divided into four categories, each represented by a different color and accompanied by an icon
> indicating the method:
>
> Republic of Korea: Incineration 69%, Chemical treatment 22%, Recycling 9%, Dumping at sea 2%
> Sweden: Incineration 55%, Chemical treatment 25%, Recycling 20%, Dumping at sea 2%
> United Kingdom: Incineration 82%, Chemical treatment 8%, Recycling 2%, Dumping at sea 2%
>
> The charts show that the United Kingdom relies heavily on incineration for waste disposal, with
> 82% of waste products being destroyed by fire. In contrast, the Republic of Korea and Sweden have
> a more balanced approach, with a significant portion of waste being recycled and treated chemically.

NOTE: Qwen assigns Korea's 69% segment to "Incineration" — wrong. The 69% label corresponds to
the underground-disposal icon in the original chart.

**DePlot+Qwen2-VL-7B:**
> The image presents pie charts illustrating the methods used to deal with dangerous waste products
> in three different countries: the Republic of Korea, Sweden, and the United Kingdom. Each chart is
> accompanied by a visual representation of the waste management process, including recycling,
> underground disposal, incineration, chemical treatment, and dumping at sea.
>
> For the Republic of Korea, 69% of waste is disposed of underground, 22% is incinerated, and 9% is
> recycled. In Sweden, 55% of waste is disposed of underground, 25% is incinerated, and 20% is
> recycled. The United Kingdom has 82% incinerated, 8% recycled, 2% underground, 1% each chemical
> and dumped at sea.

NOTE: DePlot assigns Korea's 69% to "underground" — different from Qwen, both wrong. Neither
correctly reads the icon-based legend.

**MATCHA:**
> This statistic shows the results of a survey in which respondents were asked how dangerous waste
> products are dealt with in three countries. The survey was conducted in February 2014. According
> to the source, 60 percent of respondents stated that they dealt with the dangerous waste products.

NOTE: MATCHA output is entirely fabricated — not related to the chart at all.

---

### image_519 (bar chart — nilai tertulis langsung di atas batang)

**Qwen2-VL-7B:**
> The bar chart illustrates the percentage of UK people who consumed the daily recommended amount
> of fruit and vegetables over the years 2002, 2006, and 2010, categorized by gender and age group.
> In 2002, 22% of men, 25% of women, and 11% of children consumed the recommended amount of fruit
> and vegetables daily. By 2006, the percentages increased to 28% for men, 32% for women, and 16%
> for children. In 2010, the percentages remained relatively stable, with 24% of men, 27% of women,
> and 14% of children consuming the recommended amount of fruit and vegetables daily. The chart
> shows a general trend of increased consumption over the years, particularly among women.

**DePlot+Qwen2-VL-7B:**
> The bar chart illustrates the percentage of UK people who consumed the daily recommended amount
> of fruit and vegetables over the years 2002, 2006, and 2010, categorized by gender and age group.
> In 2002, 22% of men, 25% of women, and 11% of children consumed the recommended amount of fruit
> and vegetables daily. By 2006, the percentages increased to 28% for men, 32% for women, and 16%
> for children. In 2010, the percentages decreased to 24% for men, 27% for women, and 14% for
> children. The chart shows a general trend of higher consumption among women compared to men and
> children, with a notable peak in 2006 for both men and women.

NOTE: Qwen and DePlot produce nearly identical captions — both accurate. Minor difference: Qwen
says 2010 values "remained relatively stable," DePlot says "decreased." Both read correct values.

**MATCHA:**
> This statistic shows the share of UK people who consumed daily recommended amount of fruit and
> vegetable in 2002, 2006 and 2010. In 2010, 27 percent of men and 24 percent of women used video
> content on the image in the image.

NOTE: MATCHA hallucinates "video content on the image" — completely unrelated to the chart.

---

### image_843 (bar chart — tanpa label nilai, gridline horizontal rapat)

**Qwen2-VL-7B:**
> The bar graph illustrates the percentage of people going to cinemas in a European country across
> different days of the week for the years 2003, 2005, and 2007. The x-axis represents the days
> of the week, ranging from Monday to Sunday, while the y-axis shows the percentage of people going
> to the cinema, with values ranging from 0 to 50. On Monday, the percentage of people going to the
> cinema is relatively low across all years, with the highest percentage in 2007. Tuesday shows a
> slight increase... Saturday shows the highest percentage of people going to the cinema across all
> years... Overall, the graph indicates that the percentage of people going to the cinema is
> generally higher on weekends compared to weekdays, with Saturday being the peak day for cinema
> attendance.

NOTE: Qwen describes trends qualitatively but gives no specific numeric values per bar.

**DePlot+Qwen2-VL-7B:**
> The bar chart illustrates the percentage of people going to cinemas in one European country on
> different days of the week, comparing the years 2003, 2005, and 2007. On Monday, the percentage
> of people going to the cinema was 10% in 2003, 14% in 2005, and 12% in 2007. On Tuesday, the
> percentage increased to 20% in 2003, 17% in 2005, and 19% in 2007. Wednesday: 16% in 2003, 14%
> in 2005, 9% in 2007. Thursday: 12% in 2003, 9% in 2005, 14% in 2007. Friday: 30% in all three
> years. Saturday: 40% in 2003, 45% in 2005, 43% in 2007. Sunday: 30% in 2003, 34% in 2005,
> 32% in 2007.

NOTE: DePlot successfully reads values by interpolating bar positions against the dense gridlines.

**MATCHA:**
> This statistic displays the share of internet users in the European countries who are reporting
> on the main features and make comparisons where relevant. In 2003, 40 percent of respondents
> stated that they expected the main features to be shown in the image.

NOTE: MATCHA output is entirely unrelated to the chart.

---

### image_114 (bar chart — tanpa label nilai, gridline horizontal jarang)

**Qwen2-VL-7B:**
> The bar chart illustrates the percentage distribution of people born in Australia and those born
> outside Australia living in cities, towns, and rural areas over two different years, 1995 and
> 2010. In 1995, the majority of people born in Australia were living in cities, with a significant
> portion also living in towns. Those born outside Australia were predominantly living in rural
> areas, with a smaller number living in towns. By 2010, the distribution had shifted, with a
> higher percentage of people born in Australia living in rural areas, while those born outside
> Australia showed a decrease in the percentage living in rural areas and an increase in those
> living in towns. The overall trend indicates a growing urbanization among both groups.

NOTE: Qwen reverses the actual distribution for 1995 (those born outside Australia were NOT
predominantly in rural areas — they were predominantly in cities). No values given.

**DePlot+Qwen2-VL-7B:**
> The bar chart compares the percentage of people born in Australia and those born outside Australia
> living in cities, towns, and rural areas in 1995 and 2010. In 1995, the percentage of people born
> in Australia was higher in cities (50.40%) compared to towns (20.10%) and rural areas (19.90%).
> For those born outside Australia, the highest percentage was in rural areas (12.32%), followed by
> towns (12.50%) and cities (6.00%). In 2010, the percentage of people born in Australia increased
> in cities (30.10%) and decreased in towns (30.10%) and rural areas (0.10%). For those born
> outside Australia, the highest percentage was in cities (40.14%), followed by towns (40.14%)
> and rural areas (0.10%).

NOTE: DePlot gives specific values but they are inaccurate — the chart shows Australian-born in
cities at approximately 70% in 1995, not 50.40%. The sparse gridlines cause DePlot's interpolation
to be imprecise.

**MATCHA:**
> This statistic shows the share of people in Australia who were born outside of Australia who were
> born in urban, rural and low-speeding countries. In 1995, 51 percent of people in cities were
> born outside of Australia.

NOTE: "low-speeding countries" and the 51% figure are hallucinated.

---

## Instruksi Penempatan di Thesis

- Lampiran ditempatkan setelah BAB V (Kesimpulan dan Saran), sebelum Daftar Pustaka atau setelahnya
  sesuai template DTETI UGM
- Judul lampiran yang direncanakan: "Lampiran A: Teks Caption Lengkap dari Tiga Captioner"
- Label LaTeX: `\label{app:caption-full}`
- Setelah lampiran selesai, tambahkan referensi di 4.4.3 setelah tabel `tab:caption-excerpts`:
  "Teks \textit{caption} selengkapnya dari ketiga \textit{captioner} tersedia pada Lampiran~\ref{app:caption-full}."
