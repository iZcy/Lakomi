# BAB II — Dasar Teori: 26-Subsection Structure Plan
> This is the source of truth for `write_bab2_v5.py`. Follow all rules in `context/writing_rules.md`.
> **New draft tab**: `t.v7l3rd9jsdie` (subsections written one-by-one here, not the old `t.ulqqr4hsh3xe`)
> **References tab**: `t.catchhmle3jf` — links grouped by subsection, updated via `write_references_tab.py`

## Progress Tracker

| Subsection | Status | Script |
|------------|--------|--------|
| 2.2.1 Evolusi AES | ✅ DONE | `write_221_aes_evolution.py` |
| 2.2.2 Pemrosesan Multimoda | ⏳ NEXT | — |
| 2.2.3–2.2.26 | ❌ Not started | — |

## Citation Corrections Found (fix in final naskah)

| Cited as | Actual | Correction needed |
|----------|--------|------------------|
| Landauer et al. (1997) | Landauer, Foltz & Laham (1998) | Year is 1998, not 1997. DOI: 10.1080/01638539809545028 |
| Singh et al. (2024) | Singh et al. (2025) | arXiv:2502.11916 submitted Feb 2025. Confirm final pub year. |

---

## Section 2.1 — Tinjauan Pustaka (Unchanged)

Six papers reviewed (A–F) + research gap. No changes from previous version.

---

## Section 2.2 — Dasar Teori (26 Subsections)

### Group 1: Domain Context (set the problem before the tools)

#### 2.2.1 Evolusi Automated Essay Scoring ✅ DONE
- ✅ Written in tab `t.v7l3rd9jsdie` via `write_221_aes_evolution.py`
- Content: 3 body paragraphs (rule-based era → ML era → DL/multimodal era) + lead-in + discussion
- Media: Tabel 2.1 (5×3: Generasi / Pendekatan Utama / Referensi), inserted via `insertTable` API
- Italic applied: 38 ranges (AES, machine learning, encoder, pipeline, benchmark, etc.)
- Formatting: subsection space_above=12pt, lineSpacing=150 (1.5x) corrected from old 6pt
- References logged in `t.catchhmle3jf`: Page 1966, Burstein 2003, Landauer 1998, Shermis 2013, Vaswani 2017, Devlin 2019, Caruana 1997, Singh 2025, Zhao 2025

#### 2.2.2 Pemrosesan Multimoda
- Definition: combining signals from ≥2 modalities (text, image, audio, video)
- Why relevant: IELTS Task 1 pairs image (chart) + text (essay)
- Modality types: unimodal vs multimodal, early literature
- Key papers: Baltrusaitis et al. (2019), Ngiam et al. (2011)
- **Media**: Diagram showing modality types and their combinations

#### 2.2.3 Strategi Multimodal Fusion
- Three strategies: early fusion (input-level), intermediate/late fusion
- Trade-offs: early = shared representation but requires aligned inputs; late = modular but loses cross-modal interaction
- Intermediate: cross-attention, bottleneck fusion, gated fusion
- Key papers: Baltrusaitis et al. (2019), Gold et al. (2025 fusion comparison for AES)
- **Media**: Architecture diagram showing early / intermediate / late fusion side by side (gen_fusion_diagram.py)

#### 2.2.4 Penilaian Esai Multimoda
- Multimodal AES: scoring when essay references a visual stimulus
- Specific to IELTS Task 1: essay describes a chart, table, map, or process diagram
- Challenge: chart understanding requires visual parsing; essay text alone misses factual anchors
- Key papers: Singh et al. (2024), Zhao et al. (2025 EDU-CIRCUIT-HW), Bursztyn et al. (2024 text > image)
- **Media**: Example showing an IELTS Task 1 chart + essay excerpt (table/description)

---

### Group 2: Deep Learning Foundations

#### 2.2.5 Jaringan Saraf Tiruan dan Fungsi Aktivasi
- Perceptron → MLP → deep networks
- Activation functions: ReLU, GELU (used in Transformers), Sigmoid (used in scoring head)
- Why Sigmoid: maps output to [0,1], scaled ×5 for [0,5] score range
- Key papers: LeCun et al. (2015 deep learning review), Hendrycks & Gimpel (2016 GELU)
- **Media**: Equation for Sigmoid and GELU; small table of activation properties

#### 2.2.6 Backpropagation dan Optimisasi Gradient
- Chain rule, gradient descent, mini-batch SGD
- Loss landscape intuition; why deep networks need careful initialization
- Key papers: Rumelhart et al. (1986), Goodfellow et al. (2016 Deep Learning textbook)
- **Media**: Mathematical formula for gradient update step

#### 2.2.7 Regularisasi
- Dropout (Srivastava et al. 2014): randomly zeros activations during training
- Weight decay: L2 penalty (part of AdamW)
- Why relevant: dropout=0.3 used in scoring head
- Key papers: Srivastava et al. (2014), Loshchilov & Hutter (2019 AdamW)
- **Media**: Table: regularization technique vs effect vs hyperparameter used in this work

#### 2.2.8 AdamW dan Learning Rate Scheduling
- Adam: adaptive moment estimation (Kingma & Ba 2015)
- AdamW: decoupled weight decay (Loshchilov & Hutter 2019)
- LR scheduling: linear warmup + decay; ReduceLROnPlateau used in this work (patience=5)
- Key papers: Kingma & Ba (2015), Loshchilov & Hutter (2019)
- **Media**: Equation for AdamW update

#### 2.2.9 Transfer Learning dan Fine-tuning
- Pretrain on large corpus → fine-tune on target task
- Feature extraction vs full fine-tuning vs PEFT (LoRA/QLoRA)
- Why relevant: RoBERTa pretrained on 160GB text; VLMs pretrained on image-text pairs
- Key papers: Pan & Yang (2010 transfer learning survey), Hu et al. (2022 LoRA)
- **Media**: Diagram showing pretrain → fine-tune pipeline

---

### Group 3: Text Processing Pipeline

#### 2.2.10 Tokenisasi
- Subword tokenization: BPE (GPT), WordPiece (BERT/RoBERTa), SentencePiece
- Vocabulary size trade-off: too small = many UNKs; too large = sparse embeddings
- RoBERTa uses BPE with 50k vocab; special tokens [CLS], [SEP]
- Key papers: Sennrich et al. (2016 BPE), Devlin et al. (2019)
- **Media**: Example showing tokenization of an IELTS essay sentence

#### 2.2.11 Transformer
- Encoder-decoder architecture (Vaswani et al. 2017)
- Encoder-only for classification/regression (BERT family)
- Positional encoding, multi-head self-attention, feed-forward sublayers
- Key papers: Vaswani et al. (2017)
- **Media**: Diagram of Transformer encoder block (from Vaswani et al.)

#### 2.2.12 Mekanisme Attention
- Scaled dot-product attention: Q, K, V matrices
- Multi-head: h parallel heads concatenated
- Self-attention vs cross-attention
- Key papers: Vaswani et al. (2017), Bahdanau et al. (2015)
- **Media**: Equation for scaled dot-product attention

#### 2.2.13 BERT
- Bidirectional Encoder Representations from Transformers (Devlin et al. 2019)
- Architecture: 12 layers, 12 heads, 768-dim hidden, 110M params
- Pretraining: MLM + NSP on 16GB (BooksCorpus + Wikipedia)
- [CLS] token as sentence representation for downstream tasks
- Key papers: Devlin et al. (2019)
- **Media**: Table: BERT-base vs BERT-large architecture specs

#### 2.2.14 RoBERTa
- Robustly Optimized BERT (Liu et al. 2019)
- 4 key improvements over BERT: (1) no NSP, (2) dynamic masking, (3) larger batches, (4) 160GB training data
- Same architecture as BERT-base (12L/768H/110M) but significantly better performance
- Used as text encoder in both Pendekatan A and Pendekatan B
- Key papers: Liu et al. (2019)
- **Media**: Table comparing BERT vs RoBERTa on key differences + GLUE scores

---

### Group 4: Visual Processing Pipeline

#### 2.2.15 Convolutional Neural Network (CNN)
- Convolution operation, feature maps, pooling
- Hierarchy: edges → textures → objects
- Key papers: LeCun et al. (1998 LeNet), Krizhevsky et al. (2012 AlexNet)
- **Media**: Diagram of CNN layers (conv → relu → pool)

#### 2.2.16 ResNet18
- Residual learning (He et al. 2016): skip connections solve vanishing gradient
- ResNet18: 18 layers, 11M params, output 512-dim feature vector after global avg pool
- Used in Pendekatan A as visual encoder
- Key papers: He et al. (2016)
- **Media**: Diagram of residual block with skip connection

#### 2.2.17 Vision Transformer (ViT)
- Patch embedding: image split into 16×16 patches, each projected to embedding
- Self-attention over patch sequence (Dosovitskiy et al. 2021)
- Foundation for modern VLMs (Qwen2-VL uses ViT-based visual encoder)
- Key papers: Dosovitskiy et al. (2021), Zhai et al. (2022 ViT-G)
- **Media**: Diagram showing image → patches → patch embeddings

#### 2.2.18 Pix2Struct
- Screenshot-to-text pretraining on 80M web document screenshots (Lee et al. 2023)
- Pretrained to OCR and parse visual structure (tables, charts, forms)
- Foundation for DePlot and MATCHA
- Key papers: Lee et al. (2023)
- **Media**: Comparison table: Pix2Struct vs standard OCR approaches

#### 2.2.19 Kuantisasi Model
- FP32 → FP16 → INT8 → NF4 (Normal Float 4-bit)
- QLoRA (Dettmers et al. 2023): 4-bit NF4 quantization with LoRA adapters
- Practical: allows 7B VLM inference on 16GB GPU (Kaggle P100)
- Key papers: Dettmers et al. (2023 QLoRA)
- **Media**: Table: precision vs memory vs quality trade-off

#### 2.2.20 Qwen2-VL (VLM)
- Qwen2-VL-7B-Instruct (Wang et al. 2024): multimodal LLM with visual encoder + LLM decoder
- Visual encoder: ViT-based with dynamic resolution; text: Qwen2-7B LLM backbone
- Used in Pendekatan B for chart captioning (inference only, not fine-tuned)
- Loaded with 4-bit NF4 quantization on Kaggle P100
- Key papers: Wang et al. (2024), Bai et al. (2023 Qwen original)
- **Media**: Architecture diagram showing ViT → projection → LLM pipeline

#### 2.2.21 DePlot
- plot-to-table model (Liu et al. 2023): Pix2Struct fine-tuned on chart→table pairs
- Input: chart image; Output: linearized markdown table
- Works for: bar_chart, pie_chart, line_chart; Does NOT work for: flow_chart, map
- 282M params, no quantization needed
- Key papers: Liu et al. (2023 DePlot)
- **Media**: Example: bar chart image → DePlot output table

#### 2.2.22 MATCHA
- chart-to-text model (Liu et al. 2023): Pix2Struct fine-tuned on chart understanding + math reasoning
- End-to-end (chart → natural language caption) vs DePlot two-step pipeline
- Used for bar+pie captioning in Exp020; dropped due to high factual error rate despite higher QWK
- Key papers: Liu et al. (2023 MATCHA)
- **Media**: Comparison table: DePlot vs MATCHA (approach, output type, error rate)

---

### Group 5: Training & Evaluation

#### 2.2.23 Multi-task Learning
- Joint training on multiple related tasks (Caruana 1997)
- Shared representation + task-specific heads
- Benefits: implicit regularization, gradient diversity, fewer parameters vs 10 separate models
- Used in this work: single model trained on all 10 traits simultaneously
- Key papers: Caruana (1997), Ruder (2017 multi-task survey)
- **Media**: Diagram: shared encoder → 10 trait output heads

#### 2.2.24 Scoring Head dan Arsitektur FC
- FC layers: 1536→768→256→10 (Pendekatan B), 1280→768→256→10 (Pendekatan A)
- Activation: ReLU at hidden layers; Sigmoid×5.0 at output
- Loss: MSE per trait, summed over 10 traits
- Dropout 0.3 between layers
- Key papers: (standard practice; cite Singh et al. 2024 for AES context)
- **Media**: Diagram of FC head architecture with dimensions

#### 2.2.25 Uji Statistik
- Paired t-test: compare per-sample QWK between two systems (H0: no difference)
- Bonferroni correction: α = 0.05/10 = 0.005 per trait to control family-wise error rate
- Why: 10 simultaneous trait comparisons inflate Type I error
- Key papers: Cohen (1988 statistical power), Bonferroni (standard ref)
- **Media**: Equation for paired t-test statistic; table of α levels

#### 2.2.26 Quadratic Weighted Kappa (QWK)
- Cohen's Kappa weighted by squared distance from diagonal
- Accounts for chance agreement; penalizes large disagreements more than small
- Range: [-1, 1]; >0.6 = substantial, >0.8 = near-perfect (Landis & Koch 1977)
- Used as primary metric for all traits and overall score
- Key papers: Cohen (1968), Yannakoudakis et al. (2011 AES-QWK)
- **Media**: QWK formula + weight matrix explanation

---

## Section 2.3 — Analisis Perbandingan Metode (Unchanged)

## Section 2.4 — Pertanyaan Tugas Akhir (Unchanged, RQ1–RQ6)

---

## Writing Checklist (per subsection)

- [ ] Minimum 3 paragraphs
- [ ] No em dash (—)
- [ ] Colon only before lists of ≥2 items
- [ ] All English terms in *italic*
- [ ] Use "Pendekatan A" / "Pendekatan B" (not Track A/B)
- [ ] At least one media (table / diagram / figure / chart)
- [ ] Most recent papers cited first, then seminal papers
