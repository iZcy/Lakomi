# BAB IV Structure & Content Guide

> Source of truth: `thesis_01/bab4_outline.md` (v4, detailed)
> Narrative source: `thesis_01/flow.md` (Steps 1–8)
> This file = quick map for cold-start orientation.

---

## Core Principle

**Pattern for every RQ section:**
1. `X.X.1` — Paper(s) that motivated this RQ + hypothesis
2. `X.X.2..N` — One subsection per experiment variant (arch + setup + results + analysis)
3. `X.X.N+1` — Comparison + answer RQ (confirm/deny the paper's prediction)

**Section 4.3** = NOT an RQ section. It is the T2T discovery narrative:
motivation → baseline → caption quality → empirical proof → conclusion.

**Max heading depth**: 3 levels (X.X.X). No X.X.X.X. Multi-experiment subsections use **bold headers** in prose.

---

## Section Map

| Section | Title | Sub-sections | Est. Pages | Experiments |
|---------|-------|-------------|------------|-------------|
| Intro | Overview 2 jalur + 6 RQ | — | 0.5 | — |
| **4.1 RQ1** | Fusion Strategy Comparison | 4.1.1–4.1.5 | 5.5 | Exp030, 031, 032 |
| **4.2 RQ2** | BERT vs RoBERTa | 4.2.1–4.2.5 | 4.5 | Exp032, 033 |
| **4.3** | T2T Approach: Motivation, Baseline, Caption Quality | 4.3.1–4.3.6 | 5.5 | Exp081, 092, 093 |
| **4.4 RQ3** | Track A vs Track B | 4.4.1–4.4.7 | 6 | Exp033 vs 093, Exp101–103, 016, 017, 121–125 |
| **4.5 RQ4** | Captioner: DePlot vs MATCHA | 4.5.1–4.5.6 | 4.5 | Exp103, 020, 021, 13, 112 |
| **4.6 RQ5** | VLM: Qwen vs DeepSeek | 4.6.1–4.6.5 | 3.5 | Exp093, DeepSeek(pending), Exp12 |
| **4.6 RQ6** | Statistical Significance | 4.6.1–4.6.3 | 3 | Exp093 per-sample predictions (pending) |
| **4.8** | Literature Comparison + Limitations | 4.8.1–4.8.3 | 3.5 | All exps |
| **TOTAL** | | | **~37.5 hal** | |

---

## 4.1 — RQ1: Fusion Strategy

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.1.1 | Baltrusaitis (2019): late fusion better when modalities differ | Hypothesis: late wins |
| 4.1.2 | Exp030 Early Fusion | QWK=0.4777 |
| 4.1.3 | Exp031 Intermediate Fusion | QWK=0.4799 |
| 4.1.4 | Exp032 Late Fusion | QWK=0.4838 ← wins |
| 4.1.5 | Comparison + RQ1 answer | Late fusion confirmed ✓ |

---

## 4.2 — RQ2: BERT vs RoBERTa

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.2.1 | Liu et al. (2019): RoBERTa removes NSP, dynamic masking, 10× data | Hypothesis: RoBERTa wins |
| 4.2.2 | Exp032 BERT Late Fusion | QWK=0.4838 (reference from 4.1) |
| 4.2.3 | Exp033 RoBERTa Late Fusion | QWK=0.5126, +0.029 |
| 4.2.4 | Analysis: NSP relevance for AES traits | OS+AC slightly prefer BERT (NSP helps cross-sentence) |
| 4.2.5 | RQ2 answer | RoBERTa confirmed ✓ |

---

## 4.3 — T2T Discovery (Not an RQ)

| Subsection | Content | Key Finding |
|-----------|---------|------------|
| 4.3.1 | Papers: Bursztyn (2024) 99% vs 63%, Zhao (2025) VLM→text pipeline | Hypothesis: T2T should work |
| 4.3.2 | Exp081: T2T baseline full 1054 | QWK=0.4796, below Track A (0.5126) |
| 4.3.3 | Chart type distribution: 125 unique/1054, bar+pie=26.7% | Setup for error analysis |
| 4.3.4 | Manual 100-sample review: pie ~67% error, bar ~54%, overall ~22% | Bar+pie captions unreliable |
| 4.3.5 | Exp092 (excl 3 types): 0.4941; Exp093 (excl bar+pie): **0.5778** | Removing bar+pie = biggest gain ever |
| 4.3.6 | Conclusion: Qwen7B not reliable on bar+pie → motivates RQ4 (captioner) + RQ5 (VLM) | |

---

## 4.4 — RQ3: Track A vs Track B

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.4.1 | Framing: Track A best (Exp033=0.5126) vs Track B best (Exp093=0.5778), paper refs from 4.3 | |
| 4.4.2 | DePlot hybrid variants: Exp101 (0.4555), Exp102 (0.4660), Exp103 (0.5026) | DePlot helps but < exclusion strategy |
| 4.4.3 | Ablation: Siamese Exp016 (0.4582), Exp017 (0.4463) | Dual independent encoder wins |
| 4.4.4 | Ablation: Freeze Exp121–125 | 6/12 freeze = optimal |
| 4.4.5 | Seeding impact table | Exp093 gain +0.083 from seed |
| 4.4.6 | Head-to-head Exp033 vs Exp093 per-trait | Track B +0.065, except OS |
| 4.4.7 | RQ3 answer | T2T confirmed ✓, except OS trait |

---

## 4.5 — RQ4: Captioner Selection

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.5.1 | DePlot (Liu 2023): structured table. MATCHA (Liu 2023): direct narrative | Hypothesis: DePlot better (numeric grounding) |
| 4.5.2 | Exp103 DePlot+Qwen7B | QWK=0.5026, baseline for RQ4 |
| 4.5.3 | Exp020 MATCHA | QWK=0.5213 but **DROPPED** — caption review showed high error rate |
| 4.5.4 | Why DePlot selected despite lower QWK | QWK ≠ caption accuracy; factual correctness is prerequisite |
| 4.5.5 | Exp13 Llama3.2-11B (0.4701), Exp112 DePlot+Llama (0.4690) | Larger model ≠ better captions |
| 4.5.6 | RQ4 answer | DePlot selected; key insight: QWK insufficient for captioner eval |

---

## 4.6 — RQ5: VLM Comparison

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.6.1 | Singh et al. (2024) zero-shot: Qwen ~0.164, DeepSeek ~0.11 | Hypothesis: Qwen better |
| 4.6.2 | Qwen2-VL-7B baseline (Exp093) | QWK=0.5778 |
| 4.6.3 | DeepSeek-VL-7B | **PENDING — experiment not run** |
| 4.6.4 | InternVL2-8B context (Exp12, out-of-scope) | QWK=0.5017, on par with Exp103 |
| 4.6.5 | RQ5 answer | **TBD after DeepSeek experiment** |

---

## 4.6 — RQ6: Statistical Significance

| Subsection | Content | Pending |
|-----------|---------|---------|
| 4.6.1 | Methodology: paired t-test per trait, Bonferroni α=0.005 | |
| 4.6.2 | Paired t-test results: Exp093 predictions vs ground truth | Needs per-sample predictions Exp093 |
| 4.6.3 | Interpretation: which traits are reliable, why AC is hardest | |

---

## 4.7 — Ablasi Arsitektur Pendekatan A: BRCAF (Exp046–057)

> NEW SECTION — not in original outline. Insert after 4.6 RQ5/RQ6 blocks.

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.7.1 | Gold et al. (2025) BRCAF: BERT + dual ResNet + CrossAttn + CE. Motivation for ablation | Replication baseline |
| 4.7.2 | Exp046 BRCAF replication (dual ResNet152+ResNet50) | QWK=0.4839 |
| 4.7.3 | Backbone ablation (Exp047 ResNet18/048 ResNet50/049 ResNet152) | ResNet50 best: 0.5134 |
| 4.7.4 | Loss ablation (Exp050 MSE vs Exp048 CE) | CE wins: 0.5134 vs ~0.490 |
| 4.7.5 | Fusion ablation (Exp055 early/048 cross-attn/056 late) | CrossAttn wins: 0.5134 |
| 4.7.6 | Encoder ablation (Exp048 BERT vs Exp057 RoBERTa) | RoBERTa: 0.5270 ← Approach A best |

Config for 046-057: lr=2e-5, AdamW, wd=0.01, CE 11-class weighted, batch=4/accum=8, no freeze, seed=42

---

## 4.8 — Arsitektur Cross-Attention T2T: Exp158–164

> NEW SECTION — transfer 057-style config to Pendekatan B.

| Subsection | Content | Key Result |
|-----------|---------|-----------|
| 4.8.1 | Motivation: transfer 057-style config to T2T; new arch DualRobertaCrossAttnCls | Setup |
| 4.8.2 | Phase 1 query ablation (Exp158 CLS/159 Seq/160 CLScap) | CLS wins: 0.5041 val+test |
| 4.8.3 | Why CLS query: fast convergence (ep11), no padding concern, aggregated representation | Analysis |
| 4.8.4 | Phase 2 caption set (Exp161 excl bar+pie/162 DePlot/163 excl bar+pie+comp/164 MATCHA) | Exp161 NEW BEST: 0.5802 |
| 4.8.5 | MATCHA overfitting: val=0.5524 but test=0.4702; DePlot (0.5066) generalizes better | RQ4 confirmation |
| 4.8.6 | Overall best: Exp161 (0.5802) vs Exp093 (0.5778) — excl bar+pie generalizes to new arch | |

key_padding_mask note: required here (H_cap is padded); not needed in Exp057 (single image token).

---

## 4.9 — Literature + Limitations

| Subsection | Content |
|-----------|---------|
| 4.9.1 | Zero-shot comparison table (our **0.5802** vs GPT-4o 0.54 vs all open-source ≤0.21) |
| 4.9.2 | Literature claim confirmation table (Baltrusaitis ✓, Liu ✓, Bursztyn ✓, Gold ✓, etc.) |
| 4.9.3 | Limitations: small test set (158), ≤7B constraint, RQ5 pending, AC hardest, no cross-dataset eval |

---

## Pending Data Needed Before Writing

| Section | What's Missing |
|---------|---------------|
| 4.6.3–4.6.5 | DeepSeek-VL-7B captions + training results |
| 4.6.2 | Per-sample predictions from Exp093 (JSON file) |
| 4.5.3 | MATCHA per-trait QWK breakdown (if available) |

---

## Literature Papers Used in BAB IV

| Paper | Used in | Claim confirmed? |
|-------|---------|-----------------|
| Baltrusaitis et al. (2019) — multimodal fusion taxonomy | 4.1.1 | ✓ Late > Early/Mid |
| Liu et al. (2019) — RoBERTa | 4.2.1 | ✓ RoBERTa > BERT +0.029 |
| Bursztyn et al. (2024) — text > image for chart QA | 4.3.1 + 4.4.1 | ✓ T2T > fusion |
| Zhao et al. (2025) — EDU-CIRCUIT-HW | 4.3.1 + 4.4.1 | ✓ VLM→text pipeline works |
| Liu et al. (2023) — DePlot | 4.5.1 | ✓ DePlot grounding helps |
| Liu et al. (2023) — MATCHA | 4.5.1 | Partial (higher QWK but dropped) |
| Singh et al. (2024) — EssayJudge | 4.6.1 + 4.8.1 | Context/baseline reference |
| Howard & Ruder (2018) — ULMFiT freeze | 4.4.4 | ✓ Partial freeze optimal |
