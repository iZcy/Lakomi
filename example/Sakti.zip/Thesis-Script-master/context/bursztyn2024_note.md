# Note: Bursztyn 2024 — Correct Framing for Thesis

## What the paper actually does
Bursztyn et al. use **pre-existing structured chart specifications** (CSV + JSON Vega-Lite files from NVBench) converted to natural language templates. They never convert an image to text — the text version is derived directly from the chart's source data files.

## The 99% vs 63% figure
- 99%: T5-Large (text-only, given structured chart specs as text)
- 63%: GPT-4 Vision (image-based)
- Task: Visual Explanation Generation (VEG) — not general chart QA
- QA task: 57–67% for text models (less dramatic)

## Key limitation for our thesis
Bursztyn's text representations are perfect (zero information loss, derived from source data). Our Pendekatan B uses VLM-generated captions — one step further removed, susceptible to hallucination.

## Correct framing (added to BAB IV)
Bursztyn establishes the upper bound: perfect text representations of charts yield far superior performance over image-based processing. Pendekatan B pursues the same direction using VLM captions as a **practical approximation** when underlying chart data is unavailable — which is the real-world condition for IELTS essays where only the chart image is provided.

## Citation
- Key: `bursztyn2024`
- Venue: IEEE VIS 2024
- DOI: 10.1109/VIS55277.2024.00061
- PDF: C:\Outpost\Skripsi\Research 3\Papers\Representing_Charts_as_Text_for_Language_Models_An_In-Depth_Study_of_Question_Answering_for_Bar_Charts.pdf
