# Writing Brief: Chapter 3.2.3 Per-Experiment Subsubsections (Exp 047–057)
# Status: ACTIVE REFERENCE
# Created: 2026-05-02

---

## Scope

This brief covers Exp 047–057 (Pendekatan A, remaining after 046 is done).
Each experiment gets one `\subsubsection{}` inside `\subsection{Arsitektur Model}`.

Numbering in PDF:
- 3.2.3.1 Eksperimen 046 ✅ DONE
- 3.2.3.2 Eksperimen 047
- 3.2.3.3 Eksperimen 048
- 3.2.3.4 Eksperimen 049
- 3.2.3.5 Eksperimen 050
- 3.2.3.6 Eksperimen 055
- 3.2.3.7 Eksperimen 056
- 3.2.3.8 Eksperimen 057

---

## Experiment Reference

| Exp | Key difference from previous | Architecture | Loss | QWK test |
|-----|------------------------------|--------------|------|----------|
| 047 | Single ResNet18 (smaller, frozen vs dual) | BERT + ResNet18 + CrossAttn | CE | 0,5070 |
| 048 | ResNet50 instead of ResNet18 | BERT + ResNet50 + CrossAttn | CE | 0,5134 |
| 049 | ResNet152 instead of ResNet50 | BERT + ResNet152 + CrossAttn | CE | 0,5081 |
| 050 | MSE loss instead of CE | BERT + ResNet50 + CrossAttn | MSE | ≈0,490 |
| 055 | Early fusion instead of CrossAttn | BERT + ResNet50 + Early fusion | CE | 0,4716 |
| 056 | Late fusion instead of CrossAttn | BERT + ResNet50 + Late fusion | CE | ≈0,480 |
| 057 | RoBERTa instead of BERT (BEST Pend.A) | RoBERTa + ResNet50 + CrossAttn | CE | 0,5270 |

Shared config for all (include in every table):
- Optimizer: AdamW
- Learning rate: 2×10⁻⁵
- Weight decay: 0,01
- Batch size: 4 + akumulasi ×8 = 32 efektif
- Dropout: 0,5
- Layer freeze: Tidak ada
- Seed: 42

Exception — Exp 050 uses MSE, so:
- Prediction head: 1536 → 768 → 256 → 10, Sigmoid × 5,0 (not 110/reshape)
- Loss function: MSE (regresi)

---

## Per-Experiment .tex Structure

Insert each subsubsection AFTER the previous one, before `\subsubsection*{Pendekatan B:...}`.

Template:

```latex
\subsubsection{Eksperimen XXX: <Short Title>}

<Descriptive paragraph — 3–5 sentences. Explain what this experiment tests and
how it differs from the previous. Mention key result in the last sentence only.>

\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.88\textwidth]{images/expXXX_<shortname>.pdf}
  \caption{<One-line caption describing the architecture variant.>}
  \label{fig:expXXX}
\end{figure}

\begin{longtable}{|l|l|}
  \caption{Konfigurasi Eksperimen XXX (<Short Title>).}
  \label{tab:expXXX-config} \\
  \hline
  \textbf{Parameter} & \textbf{Nilai} \\
  \hline
  \endfirsthead
  \hline
  \textbf{Parameter} & \textbf{Nilai} \\
  \hline
  \endhead
  \hline
  \endfoot
  \hline
  \endlastfoot
  \textit{Text encoder}     & ... \\
  \hline
  \textit{Image encoder}    & ... \\
  \hline
  \textit{Image projection} & ... \\
  \hline
  \textit{Fusion}           & ... \\
  \hline
  \textit{Prediction head}  & ... \\
  \hline
  \textit{Loss function}    & ... \\
  \hline
  \textit{Optimizer}        & AdamW \\
  \hline
  \textit{Learning rate}    & $2 \times 10^{-5}$ \\
  \hline
  \textit{Weight decay}     & $0{,}01$ \\
  \hline
  \textit{Batch size}       & 4 + akumulasi $\times 8 = 32$ efektif \\
  \hline
  \textit{Dropout}          & $0{,}5$ \\
  \hline
  \textit{Layer freeze}     & Tidak ada \\
  \hline
  \textit{Seed}             & 42 \\
\end{longtable}
```

---

## Descriptive Paragraph Rules

- **Light terms in prose**: say "BERT", "ResNet50", "ResNet18" — never "BERT-base-uncased"
- **What to explain**: what the experiment tests (the one variable that changed), why it was tried, and the result in the final sentence
- **Length**: 3–5 sentences, no more
- **No em dash (—)** in text; use comma or rewrite
- **Colon** only before a list of 2+ explicit items
- **Technical terms** in prose always `\textit{}`
- **No QWK number in the middle** of the paragraph — keep it at the end only

---

## Longtable Config Table Rules

- **Parameter column**: English technical terms, always `\textit{}`
- **Value column**: can mix Indonesian + English (e.g., "Tidak ada" for None is fine)
- **Standard rows** (in order): Text encoder, Image encoder, Image projection, Fusion, Prediction head, Loss function, Optimizer, Learning rate, Weight decay, Batch size, Dropout, Layer freeze, Seed
- **\hline between every row** including after the last data row (before `\end{longtable}`)
- Caption: short, 1 sentence max
- No `\begin{table}` wrapper — longtable is standalone

---

## Diagram (.drawio) Rules

Reference file: `thesis-main/images/exp046_brcaf.drawio`

### Node colors (fill / stroke)
| Role | Fill | Stroke |
|------|------|--------|
| Input | `#f5f5f5` | `#666666`, fontColor `#333333` |
| Encoder | `#dae8fc` | `#6c8ebf` |
| Intermediate/feature | `#ffe6cc` | `#d79b00` |
| Fusion | `#d5e8d4` | `#82b366` |
| Output | `#f8cecc` | `#b85450` |

### Node style
`rounded=1;whiteSpace=wrap;html=1;fillColor=...;strokeColor=...;fontFamily=Times New Roman;`

### Group boxes
`rounded=0;whiteSpace=wrap;html=1;labelBorderColor=none;dashed=1;verticalAlign=top;fontStyle=1;fillColor=none;`
Label: `<font face="Times New Roman">...</font>`

### Arrows (ALL arrows must be sharp orthogonal)
`edgeStyle=orthogonalEdgeStyle;rounded=0;curved=0;endArrow=block;endFill=1;fontFamily=Times New Roman;`

### Diagram variants per experiment group

| Exp | Base diagram to adapt | Key change in diagram |
|-----|-----------------------|-----------------------|
| 047 | exp046_brcaf.drawio | Remove one ResNet branch; ResNet18 single; no dual |
| 048 | exp047 | Change encoder label ResNet18 → ResNet50 |
| 049 | exp047 | Change encoder label ResNet50 → ResNet152 |
| 050 | exp048 | Change loss label in head node; note MSE/Sigmoid output |
| 055 | early_fusion.drawio | Adapt for BERT+ResNet50+Early fusion |
| 056 | late_fusion.drawio | Adapt for BERT+ResNet50+Late fusion |
| 057 | exp048 | Change text encoder label BERT → RoBERTa |

### Naming convention
- File: `images/expXXX_<shortname>.drawio` and `.pdf`
- Examples: `exp047_resnet18.drawio`, `exp055_earlyfusion.drawio`, `exp057_roberta.drawio`

---

## Workflow Per Experiment

1. **Claude**: Create `images/expXXX_<shortname>.drawio`
2. **Claude**: Write the `\subsubsection{}` block in chapter-3.tex including `\includegraphics{images/expXXX_<shortname>.pdf}` (PDF does not exist yet — **do not build yet**)
3. **User**: Open drawio, adjust diagram if needed, export as PDF, place at `images/expXXX_<shortname>.pdf`
4. **User**: Run `latexmk` to build
5. Proceed to next experiment

> ⚠️ Build will fail if PDF is missing. Only build after placing the exported PDF.

---

## Insertion Point in chapter-3.tex

All new subsubsections go between the last `\end{longtable}` of the previous experiment
and the line `\subsubsection*{Pendekatan B: \textit{Text-to-Text} melalui Kaptening VLM}`.

---

## Done Checklist

- [x] 3.2.3.1 Exp 046 — drawio ✅, tex ✅, PDF ✅, longtable ✅
- [x] 3.2.3.2 Exp 047 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.3 Exp 048 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.4 Exp 049 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.5 Exp 050 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.6 Exp 055 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.7 Exp 056 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.3.8 Exp 057 — drawio ✅, tex ✅, PDF ⏳ (user exports)
