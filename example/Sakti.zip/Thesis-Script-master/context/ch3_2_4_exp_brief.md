# Writing Brief: Chapter 3.2.4 Per-Experiment Subsubsections (Exp 158–164)
# Status: ACTIVE REFERENCE
# Created: 2026-05-03

---

## Scope

This brief covers Exp 158–164 (Pendekatan B) inside `\subsection{Metode Pelatihan}` (3.2.4).
Each experiment gets one `\subsubsection{}`.

Numbering in PDF (order: 158, 159, 160, 161, 163, 164, 162):
- 3.2.4.1 Eksperimen 158
- 3.2.4.2 Eksperimen 159
- 3.2.4.3 Eksperimen 160
- 3.2.4.4 Eksperimen 161
- 3.2.4.5 Eksperimen 163
- 3.2.4.6 Eksperimen 164
- 3.2.4.7 Eksperimen 162

---

## Experiment Reference

| Exp | Key difference | Caption set | Query | N sampel | Test QWK |
|-----|----------------|-------------|-------|----------|----------|
| 158 | Base DualRobertaCrossAttnCls | Qwen2-VL-7B penuh | CLS | 1.054 | 0,5041 |
| 159 | Sequential query (masked mean H_esai) | Qwen2-VL-7B penuh | Seq mean | 1.054 | 0,4962 |
| 160 | CLS-cap-key: Q=mean(H_esai), K/V=h_cls_cap | Qwen2-VL-7B penuh | CLS-cap-key | 1.054 | 0,4664 |
| 161 | Excl bar+pie (subset 772) | Qwen2-VL-7B eks. bar+pie | CLS | 772 | 0,5802 (BEST) |
| 163 | Excl bar+pie+composite (subset 665) | Qwen2-VL-7B eks. bar+pie+komposit | CLS | 665 | 0,5105 |
| 164 | MATCHA for bar+pie, Qwen7B rest | MATCHA+Qwen2-VL-7B penuh | CLS | 1.054 | 0,4702 |
| 162 | DePlot for bar+pie, Qwen7B rest | DePlot+Qwen2-VL-7B penuh | CLS | 1.054 | 0,5066 |

Shared config for all:
- Essay encoder: RoBERTa-base
- Caption encoder: RoBERTa-base
- Cross-attention: 8 head, d=768
- Prediction head: 1536→768→256→110, reshape [B,10,11]
- Loss: CE 11-class (class-weighted)
- Optimizer: AdamW, lr=2×10⁻⁵, weight decay 0,01
- Batch: 4 + akumulasi ×8 = 32 efektif
- Dropout: 0,5
- Layer freeze: Tidak ada
- Seed: 42

---

## Architecture: DualRobertaCrossAttnCls (Forward Pass, CLS variant)

```
h_cls_esai = essay_encoder([essay])[CLS]          # [B, 768]
H_cap, h_cls_cap = caption_encoder([caption])     # [B, m, 768] and [B, 768]
cross_att = CrossAttn(Q=h_cls_esai, K/V=H_cap)    # [B, 1, 768]
attn_fusion = h_cls_esai ⊙ cross_att              # [B, 768]  (element-wise)
fused = cat(h_cls_cap, attn_fusion)               # [B, 1536]
logits = FC(fused).view(-1, 10, 11)
```

Query variants:
- CLS (Exp 158, 161, 162, 163, 164): Q = h_cls_esai.unsqueeze(1) [B,1,768]
- Seq mean (Exp 159): Q = masked_mean(H_esai) [B,1,768] (full essay sequence)
- CLS-cap-key (Exp 160): Q = masked_mean(H_esai), K/V = h_cls_cap.unsqueeze(1) [B,1,768]
  (For 160, no key_padding_mask needed; attn output replaces h_cls_cap role)

---

## Per-Experiment .tex Structure

Insert each subsubsection AFTER the summary paragraph following `tab:exp-pend-b`
and BEFORE `% ────` / `\subsection{Pipeline Captioning}`.

Template:

```latex
\subsubsection{Eksperimen XXX: <Short Title>}

<Descriptive paragraph — 3–5 sentences. What this experiment tests, how it differs
from the previous, result in the last sentence only.>

\begin{figure}[htbp]
  \centering
  \includegraphics[width=0.88\textwidth]{images/expXXX_<shortname>.pdf}
  \caption{<One-line caption.>}
  \label{fig:expXXX}
\end{figure}

\begin{longtable}{|l|l|}
  \caption{Konfigurasi Eksperimen XXX (<Short Title>).}
  \label{tab:expXXX-config} \\
  \hline
  \textbf{Parameter} & \textbf{Nilai} \\
  \hline
  \endfirsthead
  \hline
  \textbf{Parameter} & \textbf{Nilai} \\
  \hline
  \endhead
  \hline
  \endfoot
  \hline
  \endlastfoot
  \textit{Essay encoder}        & RoBERTa \\
  \hline
  \textit{Caption encoder}      & RoBERTa \\
  \hline
  \textit{Caption set}          & ... \\
  \hline
  \textit{Query strategy}       & ... \\
  \hline
  \textit{Key/Value}            & ... \\
  \hline
  \textit{Fusion}               & \textit{Cross-attention} (8 \textit{head}, $d=768$) \\
  \hline
  \textit{Prediction head}      & $1536 \rightarrow 768 \rightarrow 256 \rightarrow 110$, \textit{reshape} $[B, 10, 11]$ \\
  \hline
  \textit{Loss function}        & \textit{Cross-entropy} 11-kelas (\textit{class-weighted}) \\
  \hline
  \textit{Optimizer}            & AdamW \\
  \hline
  \textit{Learning rate}        & $2 \times 10^{-5}$ \\
  \hline
  \textit{Weight decay}         & $0{,}01$ \\
  \hline
  \textit{Batch size}           & 4 + akumulasi $\times 8 = 32$ efektif \\
  \hline
  \textit{Dropout}              & $0{,}5$ \\
  \hline
  \textit{Layer freeze}         & Tidak ada \\
  \hline
  \textit{Seed}                 & 42 \\
\end{longtable}
```

Standard parameter rows (in order): Essay encoder, Caption encoder, Caption set,
Query strategy, Key/Value, Fusion, Prediction head, Loss function, Optimizer,
Learning rate, Weight decay, Batch size, Dropout, Layer freeze, Seed.
No QWK row in table — QWK appears in prose only.

---

## Descriptive Paragraph Rules

Same as ch3_2_3_exp_brief.md:
- Light terms: say "RoBERTa", "cross-attention" — not "roberta-base"
- Explain what changes from the previous experiment, why, and result at the end
- 3–5 sentences max
- No em dash (—); use comma or rewrite
- Technical terms always `\textit{}`
- QWK number at the end only

---

## Diagram Design: Base Layout (Exp 158)

Two group boxes: Cabang Esai (left) and Cabang Caption (right).

Node colors follow CLAUDE.md standard:
- Input (gray): Teks Esai, Teks Caption
- Encoder (blue): RoBERTa (Esai), RoBERTa (Caption)
- Intermediate/feature (orange): h_cls_esai, H_cap, h_cls_cap, h_fused, FC Head
- Fusion (green): Cross-Attention node
- Output (red): Skor [B, 10, 11]

Key layout:
- Left group: Teks Esai → RoBERTa (Esai) → h_cls_esai [768d]
- Right group: Teks Caption → RoBERTa (Caption) splits to:
    → H_cap [B,m,768]   (upper output, goes to K/V of CrossAttn)
    → h_cls_cap [768d]  (lower output, goes directly to h_fused)
- CrossAttn (green): Q ← h_cls_esai, K/V ← H_cap
- h_fused [1536d] (orange): receives CrossAttn output + h_cls_cap (via concat + element-wise)
- FC Prediction Head → Skor [B,10,11]

### Diagram Variants per Experiment

| Exp | Base | Caption label | Q node | K/V node |
|-----|------|--------------|--------|----------|
| 158 | NEW  | Qwen2-VL-7B (1.054) | h_cls_esai [768d] | H_cap [B,m,768] |
| 159 | exp158 | Qwen2-VL-7B (1.054) | mean(H_esai) [768d] | H_cap [B,m,768] |
| 160 | exp158 | Qwen2-VL-7B (1.054) | mean(H_esai) [768d] | h_cls_cap [768d] |
| 161 | exp158 | Qwen2-VL-7B eks. bar+pie (772) | h_cls_esai [768d] | H_cap [B,m,768] |
| 163 | exp161 | Qwen2-VL-7B eks. bar+pie+komposit (665) | h_cls_esai [768d] | H_cap [B,m,768] |
| 164 | exp158 | MATCHA+Qwen2-VL-7B (1.054) | h_cls_esai [768d] | H_cap [B,m,768] |
| 162 | exp158 | DePlot+Qwen2-VL-7B (1.054) | h_cls_esai [768d] | H_cap [B,m,768] |

### Naming Convention

- File: `images/expXXX_<shortname>.drawio` and `.pdf`
- Examples: `exp158_clsquery.drawio`, `exp159_seqquery.drawio`, `exp160_clscapkey.drawio`,
  `exp161_exclbarpie.drawio`, `exp163_exclbarpiecomp.drawio`, `exp164_matcha.drawio`,
  `exp162_deplot.drawio`

---

## Insertion Point in chapter-3.tex

Insert all subsubsections between the summary paragraph (ends with "...MATCHA+Qwen2-VL-7B (Exp~164, 0,4702).")
and the line `% ────────` / `\subsection{\textit{Pipeline Captioning}}`.

---

## Workflow Per Experiment

1. Claude: Create `images/expXXX_<shortname>.drawio`
2. Claude: Write `\subsubsection{}` block including `\includegraphics{images/expXXX_<shortname>.pdf}`
3. User: Open drawio, adjust, export PDF, place in `images/`
4. User: Run `latexmk`
5. Proceed to next experiment

> ⚠️ Build will fail if PDF is missing. Only build after placing all exported PDFs.

---

## Done Checklist

- [x] 3.2.4.1 Exp 158 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.2 Exp 159 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.3 Exp 160 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.4 Exp 161 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.5 Exp 163 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.6 Exp 164 — drawio ✅, tex ✅, PDF ⏳ (user exports)
- [x] 3.2.4.7 Exp 162 — drawio ✅, tex ✅, PDF ⏳ (user exports)
