# Revision Plan: Chapter 3.3 + 3.4
# Status: COMPLETED
# Created: 2026-05-03

---

## Current Structure

- **3.3.1 Gambaran Umum Penelitian** — overview paragraph + fig:flowchart-alur
- **3.3.2 Alur Eksperimen Utama** — 11-step narrative paragraphs + tab:alur-eksperimen (11 rows)
- **3.4 Batasan Penelitian** — prose + tab:batasan (10 rows)

---

## Issues Found (3 fixes required)

### Fix 1 — Langkah 4 prose: missing "(konfigurasi lama)" qualifier
**Location**: lines 1661–1662  
**Current text**:
```
mengkonfirmasi peningkatan signifikan dengan QWK 0,5126, menjadikannya hasil terbaik
Pendekatan A.
```
**Problem**: States Exp 033 (0,5126) is "hasil terbaik Pendekatan A" without qualification.
This is superseded by Exp 057 (0,5270) in Langkah 10. The table (row 4) already correctly
says "Terbaik Pend. A (konfigurasi lama)" — the prose needs to match.

**Fix**: Change "menjadikannya hasil terbaik Pendekatan A" →
"menjadikannya hasil terbaik Pendekatan A pada konfigurasi lama"

---

### Fix 2 — Langkah 8 prose: absolute "terbaik penelitian" claim is wrong
**Location**: lines 1697–1698  
**Current text**:
```
Pendekatan A (0,5126) maupun semua eksperimen sebelumnya. Sistem ini ditetapkan sebagai
sistem terbaik penelitian ini.
```
**Problem**: Claims Exp 093 (0,5778) is "sistem terbaik penelitian ini" — but Exp 161
(0,5802, Langkah 11) supersedes it. The table (row 8) already correctly says
"Terbaik Pend. B (konfigurasi lama)" — the prose must be consistent.

**Fix**: Change "Sistem ini ditetapkan sebagai sistem terbaik penelitian ini." →
"Sistem ini menjadi sistem terbaik Pendekatan B pada konfigurasi lama."

---

### Fix 3 — tab:batasan row 5: missing ResNet18
**Location**: line 1817  
**Current text**:
```
5 & Model gambar & ResNet50 dan ResNet152 \textit{pretrained} pada ImageNet \\
```
**Problem**: The prose in 3.4 (lines 1783–1785) correctly says "ResNet18, ResNet50, dan
ResNet152 sebagai kandidat pengekstrak fitur gambar" — but the table row omits ResNet18.
The BRCAF ablation (Exp 047–057) evaluates all three backbones, so ResNet18 must appear
in the batasan table.

**Fix**: Change cell value to "ResNet18, ResNet50, dan ResNet152 \textit{pretrained}
pada ImageNet"

---

## Items Confirmed Correct (no changes needed)

| Item | Location | Status |
|------|----------|--------|
| "kelima pertanyaan penelitian" | line 1594 | Correct (5 RQs since RQ6 was removed) |
| 3.3.1 Gambaran Umum paragraph | lines 1587–1610 | Correct |
| tab:alur-eksperimen all rows | lines 1746–1757 | Correct (rows 4/8 already say "konfigurasi lama", row 11 has bold 0,5802 as best) |
| Langkah 5 T2T intro | lines 1665–1672 | Correct (contextual "masih di bawah Pend. A terbaik") |
| Langkah 9 InternVL2-8B | lines 1700–1704 | Correct |
| Langkah 10 BRCAF ablation | lines 1706–1718 | Correct |
| Langkah 11 CrossAttn T2T | lines 1720–1731 | Correct |
| 3.4 prose: ResNet mentions | lines 1783–1785 | Correct (all three listed) |
| 3.4 prose: VLM constraint ≤7B | lines 1796–1798 | Correct |
| tab:batasan rows 1–4, 6–10 | lines 1812–1822 | Correct |

---

## Edit Summary (all in chapter-3.tex)

| # | Line | Old | New |
|---|------|-----|-----|
| 1 | 1661–1662 | `menjadikannya hasil terbaik Pendekatan A.` | `menjadikannya hasil terbaik Pendekatan A pada konfigurasi lama.` |
| 2 | 1697–1698 | `Sistem ini ditetapkan sebagai sistem terbaik penelitian ini.` | `Sistem ini menjadi sistem terbaik Pendekatan B pada konfigurasi lama.` |
| 3 | 1817 | `ResNet50 dan ResNet152 \textit{pretrained} pada ImageNet` | `ResNet18, ResNet50, dan ResNet152 \textit{pretrained} pada ImageNet` |

---

## Status

COMPLETED. All 3 fixes applied to chapter-3.tex on 2026-05-03. Build verified at 169 pages.
