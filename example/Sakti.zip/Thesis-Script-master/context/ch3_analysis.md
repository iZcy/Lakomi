# Current State Analysis: Chapter 3.2
# Generated: 2026-05-02 | Updated: 2026-05-02 (v2 revisions EXECUTED)
# Based on: thesis-main/contents/chapter-3/chapter-3.tex lines 160–659
# STATUS: ALL v2 REVISIONS COMPLETE — 3.2.1 ✅ 3.2.2 ✅ 3.2.3 ✅ 3.2.4 ✅ 3.2.5 ✅ 3.2.6 ✅

---

## 3.2.1 — Pra-pemrosesan Data (lines 161–210)

### What's there
- Opening: three data components (image, essay, label)
- Image: PIL load → resize 224×224 → ImageNet normalize → [3,224,224] tensor
- Text: RoBERTa tokenizer, max 512, padding/truncation
- Labels: two schemes described (MSE s/5.0, CE round(s/0.5))
- Table tab:preprocessing: 7 rows (Gambar ×2, Teks esai ×2, Teks caption ×2, Label MSE, Label CE)
  - Uses \hline only at top, after header, and at bottom — NO row-level borders between data rows

### What's MISSING per plan
- **IMAGE DOWNLOAD STEP**: dataset stores image URLs (GitHub raw PNG links); need to
  download/fetch image from URL and convert to RGB PNG before resize/normalize
- **Table borders**: need \hline between EVERY row (not just header/footer)

### What to change
- Add paragraph BEFORE the PIL/resize paragraph describing the URL fetch step:
  "Dataset EssayJudge menyimpan gambar grafik sebagai URL (contoh:
  https://raw.githubusercontent.com/jsu360/MLLM-for-AES/...), sehingga setiap gambar
  diunduh terlebih dahulu menggunakan pustaka requests/PIL, dikonversi ke format RGB PNG,
  kemudian disimpan secara lokal sebelum proses resize dan normalisasi."
- Add table row for "Pemuatan gambar | Unduh dari URL | requests + PIL.Image.open | PNG RGB"
- Add \hline after EVERY row in the table (not just the header separator)

---

## 3.2.2 — Ekstraksi Fitur (lines 212–274)

### What's there
- Opening: differentiates Pend.A and Pend.B jalur explicitly
- Image encoders: ResNet18 (frozen, 512d), ResNet50/152 (no freeze, 2048d→768d), dual BRCAF
- Text encoder: RoBERTa-base (768d, [CLS]), BERT mentioned for early stages
- Table tab:feature-dims: split by "Pendekatan" column — rows show A(Exp033), A(Exp046), A(Exp057), B(Exp081-103) ×2, B(Exp158-164) ×2

### What's WRONG per plan
- Table has "Pendekatan" column with A/B split and doubles (e.g., RoBERTa appears 4 times for Pend.B)
- Opening paragraph already has approach-level split before 3.2.3 introduces it
- Plan says: just list each encoder ONCE without Approach A/B differentiation

### What to change
- Remove "Pendekatan" column from tab:feature-dims
- Merge duplicate RoBERTa rows into single rows describing variants
- Opening paragraph: neutral, just "research ini menggunakan dua jenis encoder..."
- Table should be: encoder name | model | dim output | freeze option used
  Row 1: Image encoder (ResNet18) | ResNet18 (ImageNet) | 512d | fully frozen
  Row 2: Image encoder (ResNet50) | ResNet50 (ImageNet) | 2048d→768d | no freeze
  Row 3: Image encoder (ResNet152) | ResNet152 (ImageNet) | 2048d→768d | no freeze
  Row 4: Image encoder (dual) | ResNet152/ImageNet + ResNet50/Places365 | 2048d→768d each | no freeze
  Row 5: Text encoder | RoBERTa-base | 768d | frozen 6/12 or no freeze
  Row 6: Text encoder (caption) | RoBERTa-base (Pend.B only) | 768d | no freeze
  → Actually user says NO DOUBLES so merge rows 5+6 into one RoBERTa row

---

## 3.2.3 — Arsitektur Model (lines 276–474)

### What's there
- Intro paragraph + tab:arsitektur-ringkasan (best config comparison A vs B)
- subsubsection* Pend.A: 5-step NARRATIVE (Langkah 1..5)
- Figure fig:arsitektur-a
- subsubsection* Pend.B: 4-step NARRATIVE (Langkah 1..4)
- CrossAttn equations (3 equations)
- tab:arsitektur-crossattn (CrossAttn component table)

### What to REPLACE per plan
- Remove narrative step-by-step structure
- Replace with per-experiment tables for Exp 046, 047, 048, 049, 050, 055, 056, 057
- Each experiment gets a config table with rows: Encoder text, Encoder image, Fusion, Loss, LR, Freeze, Batch, Dropout, QWK result
- Keep the architecture equations and tab:arsitektur-crossattn (still needed)
- Keep fig:arsitektur-a or adapt
- Keep tab:arsitektur-ringkasan (summary comparison)
- The Pendekatan B experiments (158-164) MOVE to 3.2.4

### Structure after change
- Intro: two approaches, what 3.2.3 covers (Pend.A, Exp046-057)
- tab:arsitektur-ringkasan (best config summary)
- Pend.A subsubsection: table per experiment 046, 047, 048, 049, 050, 055, 056, 057
- Pend.B subsubsection: intro + CrossAttn equations + tab:arsitektur-crossattn
  (individual Pend.B exp configs to appear in 3.2.4 as per user)

---

## 3.2.4 — Pelatihan Multi-task (lines 476–552)

### What's there
- Title: "Pelatihan Multi-task"
- Describes only multi-task paradigm (no comparison with per-trait)
- Two training configs: old (MSE) and new (CE) with equations and comparison table
- tab:hyperparameters: old vs new config

### What to CHANGE per plan
- Rename section title to "Metode Pelatihan" (or similar)
- Add explanation of TWO training paradigms: multi-task vs per-trait
- Explain WHY multi-task chosen (10× gradient signal per step, shared encoder regularization)
- Add per-experiment config tables for Exp 158, 159, 160, 161, 162, 163, 164 (Pend.B)
- Keep the MSE/CE equations and hyperparameter comparison table

---

## 3.2.5 — Pipeline Captioning (lines 554–616)

### What's there
- Narrative: DePlot hybrid pipeline for bar+pie; direct Qwen7B for others; MATCHA as alternative
- Table tab:pipeline-captioning:
  CURRENT structure: rows = chart types (Flow chart, Bar chart, Table, Line chart, Composite, Pie chart, Map)
  columns = Jenis Grafik | Jumlah | Strategi | Model yang Digunakan

### What to CHANGE per plan
- Restructure table:
  COLUMNS: Exp ID | Qwen2-VL-7B | DePlot + Qwen2-VL-7B | MATCHA
  ROWS: experiment IDs (081/093, 103, 158, 161, 162, 163, 164)
  Cell content: which chart types go through that captioner in that experiment
  e.g., Exp 161 row: bar+pie = EXCLUDED (n/a), others = Qwen2-VL-7B
        Exp 162 row: bar+pie = DePlot+Qwen, others = Qwen2-VL-7B

---

## 3.2.6 — Evaluasi dan Uji Statistik (lines 618–659)

### What's there
- Single flat subsection: QWK description + equation + t-test description
- No sub-subsections

### What to CHANGE per plan
- Split into two sub-subsections:
  3.2.6.1 QWK: metric description, formula (eq:qwk-bab3), 11-level scale
  3.2.6.2 Paired T-Test: method, Bonferroni correction, H0 statement
- Use \subsubsection{} (numbered) not \subsubsection*{}

---

## Labels and cross-references to watch
- \label{tab:preprocessing} → referenced in text of 3.2.1
- \label{tab:feature-dims} → referenced in 3.2.2 prose
- \label{subsec:arsitektur-model} → referenced from ch4 (tab:approach-comparison caption)
- \label{tab:arsitektur-ringkasan} → referenced in 3.2.3 prose
- \label{fig:arsitektur-a} → referenced in 3.2.3 prose + may be in ch4
- \label{eq:crossattn-fusion} → referenced in Pend.B prose
- \label{tab:arsitektur-crossattn} → referenced in prose
- \label{tab:hyperparameters} → referenced in 3.2.4 prose
- \label{tab:pipeline-captioning} → referenced in 3.2.5 prose
- \label{subsec:evaluasi-metode} → may be referenced from ch2/ch4
- \label{eq:qwk-bab3} → referenced in 3.2.6 prose
- \label{eq:loss-multitask} → referenced in 3.2.4 prose
- \label{eq:loss-ce} → referenced in 3.2.4 prose

## Captioner assignment per experiment (for 3.2.5 table)
| Exp | bar chart | pie chart | composite | flow/line/table/map |
|-----|-----------|-----------|-----------|---------------------|
| 081/093/103-old | Qwen7B | Qwen7B | Qwen7B | Qwen7B |
| 103 | DePlot+Qwen7B | DePlot+Qwen7B | Qwen7B | Qwen7B |
| 158 | Qwen7B | Qwen7B | Qwen7B | Qwen7B |
| 159 | Qwen7B | Qwen7B | Qwen7B | Qwen7B |
| 160 | Qwen7B | Qwen7B | Qwen7B | Qwen7B |
| 161 | EXCLUDED | EXCLUDED | Qwen7B | Qwen7B |
| 162 | DePlot+Qwen7B | DePlot+Qwen7B | Qwen7B | Qwen7B |
| 163 | EXCLUDED | EXCLUDED | EXCLUDED | Qwen7B |
| 164 | MATCHA | MATCHA | Qwen7B | Qwen7B |
