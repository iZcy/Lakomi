# Chapter 4 — Experiment Reasoning Draft
> Source: exp-reasoning.md
> Writing rules applied: no em dash, colon only before 2+ items, English terms *italicized*
> One paragraph per experiment transition. To be added as analysis paragraphs in each subsection.

---

## 4.1.1 — Replikasi Arsitektur BRCAF (Eksperimen 046)
**Placement**: After the results paragraph in 4.1.1, before the transition to 4.1.2.

Arsitektur BRCAF menggunakan dua *backbone* ResNet yang terpisah, yaitu ResNet152 untuk fitur objek dan ResNet50 untuk konteks skenario, karena desain tersebut dikembangkan untuk gambar alami di mana pemisahan objek dari latar belakang memiliki makna semantik. Grafik IELTS bersifat abstrak dan tidak memiliki pemisahan objek atau latar belakang yang bermakna, sehingga dua *backbone* besar yang terpisah menambah kompleksitas model tanpa memberikan manfaat representasi yang sepadan. Dengan 737 sampel pelatihan, pengoptimalan dua *backbone* besar secara bersamaan juga memperburuk tekanan terhadap kapasitas generalisasi, yang menjelaskan mengapa konfigurasi *single-backbone* pada Eksperimen 047–049 secara konsisten menghasilkan QWK yang lebih tinggi.

---

## 4.1.2 — Perbandingan Komponen Pengolah Gambar (Eksperimen 047, 048, 049)
**Placement**: After the results table/paragraph in 4.1.2.

Perbandingan tiga ukuran *backbone* menunjukkan bahwa ResNet50 menghasilkan rata-rata QWK tertinggi, dengan selisih sekitar 0,005–0,006 terhadap ResNet18 dan ResNet152. ResNet18 terlalu kecil untuk menangkap seluruh struktur visual yang relevan dalam grafik IELTS, sedangkan ResNet152 memiliki kapasitas yang lebih besar namun cenderung *overfit* pada 737 sampel pelatihan. ResNet50 berada pada titik keseimbangan antara kapasitas representasi dan generalisasi untuk ukuran *dataset* ini.

---

## 4.1.3 — Perbandingan Pendekatan Prediksi (Eksperimen 048, 050)
**Placement**: After the results paragraph in 4.1.3.

Satu-satunya perubahan antara Eksperimen 048 dan 050 adalah fungsi *loss*. *Cross-entropy* memperlakukan setiap langkah skor 0,5 dalam rentang 0–5 sebagai satu dari 11 kelas diskrit, yang selaras langsung dengan cara QWK dihitung. MSE memperlakukan skor sebagai nilai kontinu dan menghaluskan batas-batas diskrit yang justru diperhitungkan oleh QWK sebagai bobot kuadratik. Selisih rata-rata QWK sebesar 0,037 antara kedua konfigurasi ini merupakan sinyal terbesar dalam seluruh ablasi Pendekatan A, menunjukkan bahwa pemilihan fungsi *loss* memberikan dampak lebih besar dibandingkan pemilihan *backbone* visual.

---

## 4.1.4 — Perbandingan Strategi Fusion (Eksperimen 055, 048, 056)
**Placement**: After the results paragraph in 4.1.4.

*Early fusion* menggabungkan fitur mentah ResNet dan BERT sebelum pemrosesan bersama dilakukan, sehingga kedua modalitas dapat saling mengganggu sebelum masing-masing *encoder* menghasilkan representasi yang bermakna. *Late fusion* membiarkan setiap *encoder* bekerja secara independen kemudian menggabungkan hasilnya pada tahap akhir, yang lebih bersih namun tidak memungkinkan penyelarasan lintas modalitas. *Cross-attention* memungkinkan representasi esai untuk secara selektif memperhatikan bagian-bagian relevan dari representasi visual, sehingga terjadi penyelarasan halus antara apa yang ditulis dalam esai dan apa yang ditampilkan dalam grafik.

---

## 4.2.3 — Analisis Perbandingan dan Jawaban RQ2 (BERT vs RoBERTa)
**Placement**: After the results paragraph in 4.2.3, before the RQ2 answer.

Perubahan tunggal dari BERT ke RoBERTa pada arsitektur yang identik menghasilkan peningkatan rata-rata QWK sebesar 0,014. RoBERTa dilatih dengan *dynamic masking* dan tanpa *Next Sentence Prediction* pada data yang lebih besar, yang menghasilkan representasi *downstream* yang lebih kuat sebagaimana dilaporkan oleh \citet{liu2019roberta}. Hasil ini mengonfirmasi temuan tersebut secara spesifik pada domain penilaian esai IELTS berbasis kriteria majemuk.

---

## 4.3.1 — T2T Baseline dan Analisis Kualitas Caption
**Placement**: After the caption quality inspection paragraph in 4.3.1.

Dengan 282 sampel *bar chart* dan *pie chart* dari total 1.054 sampel, yaitu sekitar 27% dari keseluruhan data, *caption* yang tidak akurat pada kelompok ini secara langsung menekan rata-rata QWK keseluruhan. Hal ini menjelaskan mengapa hasil Pendekatan B pada data penuh masih berada di bawah Pendekatan A meskipun arsitektur *text-to-text* memiliki potensi yang lebih besar ketika *caption* berkualitas tinggi tersedia untuk semua jenis grafik.

---

## 4.3.2 — Pendekatan A vs. Pendekatan B dan Jawaban RQ3
**Placement**: After the QWK comparison paragraph in 4.3.2.

Pada 1.054 sampel penuh, Pendekatan A mengungguli Pendekatan B karena fitur visual ResNet50 menangkap informasi yang tidak sepenuhnya terwakili dalam *caption* teks, kemungkinan mencakup tata letak spasial, pengkodean warna, atau informasi proporsional dalam grafik yang hanya dapat diaproksimasi secara tidak sempurna melalui deskripsi teks. Uji statistik mengonfirmasi pola ini, di mana Eksperimen 162 menunjukkan bias sistematis pada 8 dari 10 *trait* sementara Eksperimen 048 hanya pada 2 dari 10, menunjukkan bahwa model T2T mempelajari pola penilaian yang lebih konsisten namun mengalami *offset* sistematis terhadap anotasi manusia.

---

## 4.3.3 — Ablasi Strategi Query (Eksperimen 158, 159, 160)
**Placement**: After the convergence/results paragraph in 4.3.3.

Strategi *query* CLS mencapai konvergensi pada *epoch* ke-11, strategi *sequence mean* pada *epoch* ke-22, dan strategi *CLS-cap-key* pada *epoch* ke-8. Konvergensi *CLS-cap-key* yang terlalu cepat mengindikasikan *underfitting*, karena penggunaan satu *token* *caption* sebagai *key* meruntuhkan informasi posisional yang kaya dalam urutan *caption*. *Sequence mean* lebih lambat karena *masked mean pooling* atas seluruh *token* esai memasukkan lebih banyak *noise* pada proses optimasi. *Token* CLS telah mengagregasi representasi seluruh esai melalui 12 lapisan *transformer*, menjadikannya *query* satu vektor yang paling bersih dan stabil.

---

## 4.3.4 — Konfirmasi Strategi Eksklusi (Eksperimen 161 dan 163)
**Placement**: After the results table in 4.3.4.

Eksklusi *bar chart* dan *pie chart* saja (Eksperimen 161, rata-rata QWK 0,5802) menghasilkan performa yang jauh lebih tinggi dibandingkan eksklusi ketiga jenis grafik termasuk *composite chart* (Eksperimen 163, rata-rata QWK 0,5105). Mempertahankan *composite chart* meskipun kualitas *caption*-nya tidak sempurna terbukti lebih menguntungkan daripada mengekslusikannya. *Trait* OS (*organizational structure*) pada Eksperimen 161 mencapai QWK 0,583, yang mengindikasikan bahwa grafik komposit mengandung isyarat struktural yang berguna untuk menilai kejelasan organisasi esai dan hilang ketika jenis grafik tersebut dieksklusi.

---

## 4.4.2 — DePlot vs. MATCHA pada Arsitektur CrossAttn (Eksperimen 162 dan 164)
**Placement**: After the results table in 4.4.2.

MATCHA mencapai *validation* QWK 0,5524 namun *test* QWK 0,4702, dengan selisih besar yang mengindikasikan *overfitting*. Inspeksi manual menunjukkan bahwa *caption* MATCHA memiliki tingkat kesalahan faktual mendekati 100% pada *bar chart* dan *pie chart*; model menghasilkan teks yang fasih secara linguistik namun nilai-nilai numeriknya tidak akurat, sehingga model penilaian mempelajari pola *caption* yang fasih namun keliru pada data pelatihan dan gagal menggeneralisasi pada data uji. DePlot terlebih dahulu mengekstraksi tabel *markdown* yang berpijak pada data grafik aktual, kemudian Qwen2-VL-7B menghasilkan narasi dari tabel tersebut; tahap penambatan data ini mengurangi halusinasi secara substansial dibandingkan *captioning* satu langkah.
