# Chapter Restructure Draft
Last updated: 2026-05-07
Status: DRAFT — check off each item as applied

---

## CHANGE 1 — Ch2.4 Opening Sentence (GPU-constraint framing)

**Location:** `chapter-2.tex` line 1025, first sentence of Pertanyaan Tugas Akhir section.

**OLD:**
> Berdasarkan tinjauan pustaka (Subbab~\ref{sec:tinjauan-pustaka}), dasar teori
> (Subbab~\ref{sec:dasar-teori}), dan analisis perbandingan metode
> (Subbab~\ref{sec:analisis-perbandingan}) yang telah dipaparkan, dirumuskan lima
> pertanyaan tugas akhir (\textit{Research Question}) yang masing-masing memiliki
> keterkaitan langsung dengan tujuan penelitian yang ditetapkan pada Bab~I. Seluruh
> eksperimen dalam penelitian ini dibatasi pada penggunaan model VLM
> \textit{open-source} dengan kapasitas maksimal 7 miliar parameter akibat
> keterbatasan memori GPU yang tersedia.

**NEW:**
> Berdasarkan tinjauan pustaka (Subbab~\ref{sec:tinjauan-pustaka}), dasar teori
> (Subbab~\ref{sec:dasar-teori}), dan analisis perbandingan metode
> (Subbab~\ref{sec:analisis-perbandingan}) yang telah dipaparkan, dirumuskan lima
> pertanyaan tugas akhir (\textit{Research Question}) yang masing-masing memiliki
> keterkaitan langsung dengan tujuan penelitian yang ditetapkan pada Bab~I. Seluruh
> eksperimen dalam penelitian ini menggunakan model VLM \textit{open-source} dengan
> kapasitas tidak melebihi 7 miliar parameter, dipilih berdasarkan kinerja terbaik
> pada \textit{benchmark} pemahaman dokumen dan grafik di antara model yang
> dievaluasi oleh \citet{su2025}.

**Notes:** removes GPU-constraint framing, consistent with ch3 pipeline captioning section.

---

## CHANGE 2 — Ch2.4 RQ3 Definition

**Location:** `chapter-2.tex` line 1033, item 3 in the enumerate.

**OLD:**
> \item \textbf{RQ3 (Pendekatan A vs.\ Pendekatan B):} Apakah pendekatan
> \textit{text-to-text} berbasis \textit{caption} VLM (Pendekatan B) menghasilkan
> skor QWK yang lebih tinggi dibandingkan pendekatan fusi multimoda langsung
> berbasis RoBERTa (Pendekatan A) untuk penilaian esai IELTS \textit{Task~1}?

**NEW:**
> \item \textbf{RQ3 (Konfigurasi Optimal Pendekatan B):} Konfigurasi sistem AES
> berbasis \textit{text-to-text} dengan \textit{caption} VLM manakah yang
> menghasilkan QWK optimal pada \textit{dataset} EssayJudge, mencakup strategi
> \textit{query cross-attention} dan pemilihan data pelatihan berdasarkan kualitas
> \textit{caption}?

**Notes:** Parallel to RQ2 ("Konfigurasi optimal Pendekatan A"). Matches ch1 rumusan masalah item 3 and ch5 RQ3 exactly.

---

## CHANGE 3 — Ch3.2.4 Pendekatan B Introduction (one sentence)

**Location:** `chapter-3.tex` lines 1013–1018, Pendekatan B subsubsection intro.

**OLD:**
> Pendekatan B menggantikan \textit{encoder} gambar ResNet50 dengan \textit{encoder}
> teks RoBERTa-base kedua yang memproses teks \textit{caption} yang dihasilkan VLM
> dari gambar grafik. Arsitektur ini disebut \textit{DualRobertaCrossAttnCls}, dan
> mengadopsi konfigurasi terbaik Pendekatan A dengan integrasi \textit{pipeline
> captioning} dari Subbab~\ref{subsec:pipeline-captioning}. Konfigurasi dan hasil
> eksperimen Pendekatan B (Exp~158--164) diuraikan pada
> Subbab~\ref{subsec:metode-pelatihan}.

**NEW:**
> Pendekatan B menggantikan \textit{encoder} gambar ResNet50 dengan \textit{encoder}
> teks RoBERTa-base kedua yang memproses teks \textit{caption} yang dihasilkan VLM
> dari gambar grafik. Mekanisme \textit{cross-attention} yang ditetapkan sebagai
> strategi \textit{fusion} terbaik pada Pendekatan A dipertahankan secara identik,
> dengan perbedaan bahwa \textit{key} dan \textit{value} kini berasal dari urutan
> token \textit{caption} alih-alih dari fitur ResNet. Arsitektur ini disebut
> \textit{DualRobertaCrossAttnCls}, dan mengadopsi konfigurasi pelatihan terbaik
> Pendekatan A dengan integrasi \textit{pipeline captioning} dari
> Subbab~\ref{subsec:pipeline-captioning}. Konfigurasi dan hasil eksperimen
> Pendekatan B (Exp~158--164) diuraikan pada Subbab~\ref{subsec:metode-pelatihan}.

**Notes:** Adds architectural bridge sentence. Establishes that CrossAttn is inherited, not independently designed.

---

## CHANGE 4 — Ch3.3.2 Langkah 7 (one sentence)

**Location:** `chapter-3.tex` ~line 1785, Langkah 7 paragraph.

**OLD:**
> Pendekatan B dirancang sebagai alternatif yang menggantikan komponen pengolah
> gambar dengan deskripsi tekstual grafik yang dihasilkan oleh
> Qwen2-VL-7B-\textit{Instruct}. Dua model RoBERTa independen kemudian mengolah
> deskripsi grafik dan esai secara paralel, dengan representasi keduanya digabungkan
> melalui mekanisme \textit{cross-attention} sebelum digunakan untuk prediksi skor.
> Konfigurasi pelatihan identik dengan Langkah 6 diterapkan pada arsitektur ini.

**NEW:**
> Pendekatan B dirancang sebagai alternatif yang menggantikan komponen pengolah
> gambar dengan deskripsi tekstual grafik yang dihasilkan oleh
> Qwen2-VL-7B-\textit{Instruct}. Dua model RoBERTa independen mengolah deskripsi
> grafik dan esai secara paralel, dengan representasi keduanya digabungkan melalui
> mekanisme \textit{cross-attention} yang diwarisi dari Pendekatan A; perbedaannya
> adalah \textit{key} dan \textit{value} kini berasal dari token \textit{caption}
> alih-alih dari fitur ResNet. Konfigurasi pelatihan identik dengan Langkah 6
> diterapkan pada arsitektur ini.

**Notes:** Reinforces the architectural bridge in the experimental flow narrative.

---

## CHANGE 5 — Ch4 Section 4.3 Full Restructure

### 5a. Section title and intro

**Location:** `chapter-4.tex`, current `\section{Pendekatan \textit{Text-to-Text} pada Pendekatan B}` and its RQ3 intro paragraph.

**OLD section title + intro:**
> \section{Pendekatan \textit{Text-to-Text} pada Pendekatan B}
> \label{sec:rq3}
>
> Subbab ini menjawab Pertanyaan Penelitian 3 (RQ3), yaitu apakah pendekatan
> \textit{text-to-text} berbasis \textit{caption} VLM (Pendekatan B) menghasilkan
> QWK lebih tinggi dibandingkan pendekatan \textit{fusion} multimodal langsung
> berbasis RoBERTa (Pendekatan A)?
>
> Pemilihan Qwen2-VL-7B-\textit{Instruct} sebagai \textit{captioner} utama pada
> Pendekatan B didasarkan pada evaluasi \textit{benchmark} pemahaman dokumen dan
> grafik yang dijelaskan pada Subbab~\ref{subsec:pipeline-captioning}.

**NEW:**
> \section{Konfigurasi Optimal Pendekatan B}
> \label{sec:rq3}
>
> Subbab ini menjawab Pertanyaan Penelitian 3 (RQ3), yaitu konfigurasi sistem AES
> berbasis \textit{text-to-text} dengan \textit{caption} VLM manakah yang
> menghasilkan QWK optimal pada \textit{dataset} EssayJudge?
>
> Pendekatan B mengadopsi mekanisme \textit{cross-attention} yang ditetapkan sebagai
> strategi \textit{fusion} terbaik pada Pendekatan A (Eksperimen 048), namun
> mengganti representasi visual berbasis piksel ResNet dengan representasi teks
> berbasis \textit{caption} VLM. Dalam arsitektur \textit{DualRobertaCrossAttnCls},
> \textit{encoder} RoBERTa pertama memproses teks esai (setara dengan
> \textit{text encoder} pada Pendekatan A) dan \textit{encoder} RoBERTa kedua
> memproses \textit{caption} grafik (menggantikan peran ResNet sebagai enkoder
> representasi grafik). Mekanisme \textit{cross-attention} menghubungkan kedua
> representasi tersebut dengan cara yang identik secara arsitektural. Pemilihan
> Qwen2-VL-7B-\textit{Instruct} sebagai \textit{captioner} utama didasarkan pada
> evaluasi \textit{benchmark} pemahaman dokumen dan grafik yang dijelaskan pada
> Subbab~\ref{subsec:pipeline-captioning}.

---

### 5b. Remove old 4.3.2 (A vs B comparison) — move content to new 4.5

**Content to REMOVE from 4.3:**
- `\subsection{Pendekatan A vs.\ Pendekatan B dan Jawaban RQ3}` and all its content (comparison table `tab:approacha-vs-b`, analysis paragraphs, RQ3 answer paragraph)
- The caption error analysis paragraph ("Dengan 282 sampel...") that now belongs with caption quality in 4.4
- The spatial/color and cross-approach trait paragraphs (move to 4.5.1)
- "Kesenjangan ini dapat dijelaskan..." paragraph (move to 4.5.1)
- Old RQ3 answer paragraph (replace with new one in 4.3.4)

---

### 5c. Reorder subsections

**New 4.3 subsection order:**
1. **4.3.1** `\subsection{T2T \textit{Baseline} dan Identifikasi Masalah \textit{Caption}}` — keep current 4.3.1 content BUT remove the full error rate table (tab:caption-error-rates) and its 282-sample paragraph; keep only the prose that identifies caption quality as the problem motivation
2. **4.3.2** Current `\subsection{Ablasi Strategi \textit{Query}...}` — move here from current 4.3.3 (no content change)
3. **4.3.3** Current `\subsection{Konfirmasi Strategi Eksklusi...}` — move here from current 4.3.4 (no content change)
4. **4.3.4** NEW `\subsection{Jawaban RQ3}` — new answer paragraph below

**New 4.3.4 answer draft:**
> Jawaban dari RQ3, berdasarkan hasil di atas, adalah bahwa konfigurasi optimal
> sistem AES berbasis \textit{text-to-text} adalah arsitektur
> \textit{DualRobertaCrossAttnCls} dengan strategi \textit{query} CLS dan eksklusi
> \textit{bar chart} serta \textit{pie chart} dari data pelatihan dan pengujian
> (Eksperimen 161), dengan rata-rata QWK 0,5802 pada \textit{test set}. Konfigurasi
> ini ditetapkan secara bertahap: mekanisme \textit{cross-attention} diwarisi dari
> Pendekatan A, strategi \textit{query} CLS dipilih berdasarkan konvergensi dan
> stabilitas terbaik, dan eksklusi \textit{bar}+\textit{pie} diambil sebagai respons
> terhadap tingginya tingkat kesalahan faktual \textit{caption} untuk kedua jenis
> grafik tersebut (dibahas pada Subbab~\ref{sec:rq4}).

---

## CHANGE 6 — Ch4 Section 4.4 Full Restructure

### 6a. Section title and new intro

**OLD title:**
> \section{Perbandingan \textit{Captioner} untuk \textit{Bar Chart} dan
> \textit{Pie Chart}}
> \label{sec:rq4}

**NEW title + new intro paragraph before 4.4.1:**
> \section{Analisis \textit{Captioner} untuk \textit{Bar Chart} dan
> \textit{Pie Chart}}
> \label{sec:rq4}
>
> Subbab ini menginvestigasi secara mendalam kualitas \textit{caption} yang
> dihasilkan oleh \textit{captioner} yang tersedia untuk \textit{bar chart} dan
> \textit{pie chart}, dua jenis grafik yang teridentifikasi sebagai faktor pembatas
> pada Pendekatan B. Investigasi dimulai dengan tinjauan manual kualitas
> \textit{caption} per jenis grafik, diikuti perbandingan \textit{captioner}
> DePlot+Qwen2-VL-7B terhadap MATCHA.

---

### 6b. New 4.4.1 — Tinjauan Manual Kualitas Caption

**NEW subsection** inserted before current 4.4.1:
> \subsection{Tinjauan Manual Kualitas \textit{Caption} per Jenis Grafik}
>
> [MOVE HERE: the 100-sample manual analysis content currently in 4.3.1]
> — prose about <10% error for flow/table/map/line, 54% for bar, 67% for pie, ~18% for composite
> — table tab:caption-error-rates
> — the "Dengan 282 sampel bar chart dan pie chart..." quantitative paragraph

---

### 6c. Renumber existing 4.4 subsections

| Old | New | Content |
|---|---|---|
| 4.4.1 DePlot vs MATCHA quality eval | 4.4.2 | unchanged |
| 4.4.2 CrossAttn comparison 162/164 | 4.4.3 | unchanged |
| 4.4.3 Jawaban RQ4 | 4.4.4 | minor update: retitle as "Jawaban RQ4" if not already |

**Note:** RQ4 question stays the same ("which captioner is better?") — only the section structure changes.

---

## CHANGE 7 — Ch4 New Section 4.5 (Perbandingan Kedua Pendekatan dan Signifikansi Statistik)

### 7a. New section intro

**NEW section** inserted after current 4.4 (before current sec:rq5):
> \section{Perbandingan Kedua Pendekatan dan Signifikansi Statistik}
> \label{sec:rq5}
>
> Dengan konfigurasi optimal masing-masing pendekatan telah ditetapkan, yaitu
> Eksperimen 057 untuk Pendekatan A dan Eksperimen 161 untuk Pendekatan B, subbab
> ini membandingkan kedua pendekatan secara langsung pada kondisi data penuh dan
> mengevaluasi signifikansi statistik prediksi masing-masing sistem terhadap anotasi
> manusia.

---

### 7b. 4.5.1 — Perbandingan Pendekatan A dan Pendekatan B

**MOVE HERE from old 4.3.2:**
- Tabel perbandingan `tab:approacha-vs-b` (A vs B per-trait)
- All analysis paragraphs:
  - "Pada data penuh (1.054 sampel), Pendekatan A secara konsisten mengungguli..."
  - "Pada 1.054 sampel penuh, fitur visual ResNet50..." (spatial/color paragraph)
  - "Analisis per-trait...pola silang yang sistematis..." (cross-approach trait paragraph)
  - "Kesenjangan ini dapat dijelaskan melalui analisis kualitas caption..."
- **New combined RQ answer** (replaces old RQ3 answer + old RQ5 answer):
  > Pada data penuh 1.054 sampel, Pendekatan A mengungguli Pendekatan B dengan
  > rata-rata QWK 0,5270 (Eksperimen 057) berbanding 0,5041 (Eksperimen 158).
  > Hambatan utama Pendekatan B adalah kualitas \textit{caption} \textit{bar chart}
  > (54\% kesalahan) dan \textit{pie chart} (67\% kesalahan). Ketika keterbatasan
  > ini diatasi melalui eksklusi kedua jenis grafik tersebut, Pendekatan B mencapai
  > rata-rata QWK 0,5802 (Eksperimen 161), melampaui Pendekatan A dan
  > \textit{baseline zero-shot} GPT-4o ($\approx$0,54).

---

### 7c. 4.5.2 — Hasil Paired T-Test per Trait

**MOVE HERE:** entire current `\section{Signifikansi Statistik}` content (tables tab:stat-048, tab:stat-162, analysis paragraphs, RQ5 answer) — no content change, just moved.

---

### 7d. Old section labels

Current `\label{sec:rq5}` (Signifikansi Statistik) moves into 4.5.2 as `\label{subsec:stat-results}`.
Current `\section{Signifikansi Statistik}` is deleted as a standalone section; its content becomes subsection 4.5.2.

---

## CHANGE 8 — Ch4 Section 4.6 (unchanged)

`\section{Perbandingan dengan Penelitian Terdahulu dan Keterbatasan}` — no changes needed.

---

## Execution Checklist

- [x] CHANGE 1: Ch2.4 — GPU-constraint opening sentence
- [x] CHANGE 2: Ch2.4 — RQ3 definition
- [x] CHANGE 3: Ch3.2.4 — Pendekatan B intro bridge sentence
- [x] CHANGE 4: Ch3.3.2 — Langkah 7 bridge sentence
- [x] CHANGE 5a: Ch4 4.3 — section title + new intro
- [x] CHANGE 5b: Ch4 4.3 — remove old 4.3.2 comparison content
- [x] CHANGE 5c: Ch4 4.3 — reorder subsections + new 4.3.4 RQ3 answer
- [x] CHANGE 6a: Ch4 4.4 — new section title + intro
- [x] CHANGE 6b: Ch4 4.4 — new 4.4.1 (100-sample analysis moved here)
- [x] CHANGE 6c: Ch4 4.4 — renumber existing subsections (4.4.2–4.4.4)
- [x] CHANGE 7a: Ch4 new 4.5 — section intro
- [x] CHANGE 7b: Ch4 4.5.1 — A vs B comparison (moved from old 4.3.2)
- [x] CHANGE 7c: Ch4 4.5.2 — t-test (moved from old sec:rq5)
- [x] CHANGE 7d: Ch4 — old standalone Signifikansi Statistik folded into new 4.5
- [x] Rebuild PDF
- [x] Verify section numbers in PDF — confirmed correct 2026-05-07
