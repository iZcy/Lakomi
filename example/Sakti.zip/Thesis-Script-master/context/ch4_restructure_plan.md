# Chapter 4 Restructure Plan
Last updated: 2026-05-07

---

## New Section Map

| Section | Title | Content | Answers |
|---|---|---|---|
| 4.1 | Perbandingan Strategi Fusion (Pendekatan A) | Backbone, loss, fusion ablation | RQ1 |
| 4.2 | Pengaruh Pilihan Text Encoder | BERT vs RoBERTa | RQ2 |
| 4.3 | Konfigurasi Optimal Pendekatan B | T2T baseline, query ablation, exclusion, RQ3 answer | RQ3 |
| 4.4 | Analisis Captioner untuk Bar Chart dan Pie Chart | 100-sample manual analysis, DePlot vs MATCHA | — |
| 4.5 | Perbandingan Kedua Pendekatan dan Signifikansi Statistik | A vs B comparison table, t-test | RQ4 + RQ5 |
| 4.6 | Perbandingan dengan Penelitian Terdahulu dan Keterbatasan | Zero-shot comparison, literature confirmation, limitations | — |

---

## Detailed Changes

### 4.3 — Konfigurasi Optimal Pendekatan B (RQ3)

**New section intro** replaces: "Subbab ini menjawab RQ3 yaitu apakah T2T menghasilkan QWK lebih tinggi dibandingkan fusion..."

**New intro draft:**
> Subbab ini menjawab Pertanyaan Penelitian 3 (RQ3), yaitu konfigurasi sistem AES
> berbasis *text-to-text* dengan *caption* VLM manakah yang menghasilkan QWK optimal
> pada *dataset* EssayJudge?
>
> Pendekatan B mengadopsi mekanisme *cross-attention* yang ditetapkan sebagai standar
> pada Pendekatan A (Eksperimen 048), namun mengganti representasi visual berbasis
> piksel ResNet dengan representasi teks berbasis *caption* VLM. Dalam arsitektur
> *DualRobertaCrossAttnCls*, RoBERTa pertama memproses teks esai (setara dengan
> *text encoder* pada Pendekatan A) dan RoBERTa kedua memproses *caption* grafik
> (menggantikan peran ResNet sebagai encoder representasi grafik). Mekanisme
> *cross-attention* menghubungkan kedua representasi tersebut dengan cara yang
> identik secara arsitektural dengan Pendekatan A.

**Subsection order:**
1. 4.3.1 — T2T *Baseline* dan Identifikasi Masalah *Caption* (same as current 4.3.1, but WITHOUT the full 100-sample error table → table moves to 4.4; only prose summary retained here)
2. 4.3.2 — Ablasi Strategi *Query* (currently 4.3.3)
3. 4.3.3 — Konfirmasi Strategi Eksklusi (currently 4.3.4)
4. 4.3.4 — **NEW** Jawaban RQ3

**New RQ3 answer draft:**
> Jawaban dari RQ3, berdasarkan hasil di atas, adalah bahwa konfigurasi optimal sistem
> AES berbasis *text-to-text* adalah arsitektur *DualRobertaCrossAttnCls* dengan strategi
> *query* CLS dan eksklusi *bar chart* serta *pie chart* dari data pelatihan dan pengujian
> (Eksperimen 161), dengan rata-rata QWK 0,5802. Konfigurasi ini ditetapkan secara
> bertahap: mekanisme *cross-attention* diwarisi dari Pendekatan A, strategi *query* CLS
> dipilih berdasarkan konvergensi dan stabilitas terbaik, dan eksklusi *bar+pie* diambil
> sebagai respons terhadap keterbatasan kualitas *caption* untuk jenis grafik tersebut.
> Qwen2-VL-7B-*Instruct* dan *DualRobertaCrossAttnCls* menjadi komponen *captioner* dan
> *scoring model* terbaik Pendekatan B.

**Removed from 4.3:** entire old 4.3.2 (A vs B comparison table and analysis) → moved to 4.5.

---

### 4.4 — Analisis *Captioner* untuk *Bar Chart* dan *Pie Chart*

**New section intro:**
> Subbab ini menginvestigasi kualitas *caption* yang dihasilkan oleh *captioner* yang
> tersedia untuk *bar chart* dan *pie chart*, yaitu dua jenis grafik yang terbukti
> menjadi faktor pembatas pada Pendekatan B. Investigasi ini mencakup tinjauan manual
> kualitas *caption* dan perbandingan *captioner* DePlot+Qwen2-VL-7B dengan MATCHA
> pada arsitektur *CrossAttn*.

**Subsections:**
1. 4.4.1 — **NEW** Tinjauan Manual Kualitas *Caption* (currently in 4.3.1 — the 100-sample table `tab:caption-error-rates`, Tabel kualitas caption per jenis grafik)
2. 4.4.2 — DePlot vs MATCHA: Evaluasi Kualitas *Caption* (currently 4.4.1)
3. 4.4.3 — DePlot vs MATCHA pada Arsitektur *CrossAttn* (currently 4.4.2)
4. 4.4.4 — Jawaban RQ4 (currently 4.4.3 — retitled, no content change)

---

### 4.5 — Perbandingan Kedua Pendekatan dan Signifikansi Statistik

**New section** combining current 4.3.2 (A vs B comparison) + current sec:rq5 (t-test).

**New section intro:**
> Dengan konfigurasi optimal masing-masing pendekatan telah ditetapkan — Eksperimen 057
> untuk Pendekatan A dan Eksperimen 161 untuk Pendekatan B — subbab ini membandingkan
> kedua pendekatan secara langsung dan mengevaluasi signifikansi statistik prediksi
> masing-masing sistem terhadap anotasi manusia.

**Subsections:**
1. 4.5.1 — Perbandingan Pendekatan A dan Pendekatan B (A vs B table, currently in 4.3.2)
2. 4.5.2 — Hasil *Paired T-Test* per *Trait* (currently in sec:rq5)
3. 4.5.3 — Analisis dan Jawaban RQ4+RQ5 (combined answer: comparison conclusion + statistical calibration finding)

**Note:** the comparison analysis paragraphs I added (spatial/color, cross-approach trait) stay in 4.5.1.

---

### 4.6 — Unchanged
Perbandingan dengan Penelitian Terdahulu dan Keterbatasan — same content, no changes.

---

## Execution Order

1. Restructure 4.3: new intro + reorder subsections + new RQ3 answer + remove old 4.3.2 comparison content
2. Restructure 4.4: new intro + add 100-sample table as 4.4.1 + renumber existing subsections
3. Build new 4.5: new intro + move A vs B comparison from old 4.3.2 + move t-test from old sec:rq5
4. Verify 4.6 unchanged
5. Rebuild PDF and check section numbers

---

## RQ3 Framing (Summary)

| | Old RQ3 | New RQ3 |
|---|---|---|
| Question | "Apakah T2T menghasilkan QWK lebih tinggi dari fusion?" | "Konfigurasi T2T manakah yang optimal?" |
| Type | Comparison | Configuration optimization (parallel to RQ2) |
| Answer | "Not yet, on full data" | "Exp161: DualRobertaCrossAttnCls + CLS query + excl bar+pie, QWK 0.5802" |
| Aligns with ch1 RQ3 | No (ch1 asks for optimal config, not comparison) | Yes |
| Aligns with ch5 RQ3 | No | Yes |
