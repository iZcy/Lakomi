# BAB IV Structure Schema
# Status: CURRENT — IMPLEMENTED (2026-05-03)
# Last updated: 2026-05-03

---

## Overview

BAB IV is fully restructured and implemented (1,378 lines as of 2026-05-03).
**Best result in thesis**: Exp161, Avg QWK = 0.5802 (Pendekatan B, subset excl bar+pie).
**Best full-data result**: Exp057, Avg QWK = 0.5270 (Pendekatan A).
**Best full-data Pend. B**: Exp162, Avg QWK = 0.5066 (CrossAttn DePlot+Qwen7B).

---

## Sections

### 4.1 — Gambaran Umum Eksperimen (`sec` not labeled)
Lines: ~1–160

- Dataset: EssayJudge, 1054 essays, 10 traits, 0–5 scale
- `tab:data-splits` — 4 data split configs (full non-seeded, full seeded, excl bar+pie, excl bar+pie+comp)
- `tab:approach-comparison` — Exp057 (Pend. A) vs Exp162 (Pend. B full-data) components side-by-side
- `fig:t2t-overview` — T2T architecture diagram
- `tab:master-results` — ALL experiments (zero-shot, Exp030–164) with Avg QWK; Exp046–056 added 2026-05-03

---

### 4.2 — Strategi Fusion Optimal pada Pendekatan A (`sec:rq1`)
Lines: ~162–398

RQ1: which fusion strategy produces best QWK on Pendekatan A architecture?

Answers via BRCAF ablation sequence:

**4.2.1** `subsec:exp046` — Replikasi BRCAF (Exp046)
- `tab:exp046-results` — per-trait, Avg **0.4839**

**4.2.2** `subsec:exp047-049` — Backbone comparison: ResNet18/50/152 (Exp047, 048, 049)
- `tab:backbone-comparison` — 3-col per-trait; ResNet50 wins (0.5134)

**4.2.3** `subsec:exp048-050` — Classification vs Regression (Exp048 vs 050)
- `tab:ce-vs-mse` — CE=0.5134 vs MSE=0.4767 + delta; CE wins 8/10 traits

**4.2.4** `subsec:exp055-056` — Fusion strategy: Early / CrossAttn / Late (Exp055, 048, 056)
- `tab:fusion-comparison-rq1` — 3-col; CrossAttn wins (0.5134); Early=0.4716, Late=0.4826

**4.2.5** `subsec:rq1-answer` — Synthesis + RQ1 answer
- `tab:rq1-progression` — ablation step progression: BRCAF (0.4839) → +0.030 backbone → +0.037 CE → +0.031 CrossAttn → Exp048 (0.5134)
- **RQ1 answer**: Cross-attention (Exp048, 0.5134) is optimal; standard architecture established

---

### 4.3 — Pengaruh Pilihan Text Encoder: BERT vs. RoBERTa (`sec:rq2`)
Lines: ~399–511

RQ2: does switching BERT→RoBERTa improve QWK on the selected cross-attention architecture?

**4.3.1** `subsec:rq2-bert` — BERT-base as baseline (Exp048)
- Results from 4.2 (no new table); Avg QWK 0.5134

**4.3.2** `subsec:rq2-roberta` — RoBERTa-base as replacement (Exp057)
- `tab:exp057-results` — per-trait, Avg **0.5270**

**4.3.3** `subsec:rq2-answer` — Comparison + RQ2 answer
- `tab:bert-roberta-comparison` — Exp048 (BERT) vs 057 (RoBERTa), per-trait + delta
- RoBERTa +0.014, wins 7/10 traits; gains on EL, PA, GD, OS; BERT still better on AC, CH, LD
- **RQ2 answer**: RoBERTa +0.014 (0.5134 → 0.5270); Exp057 = best Pendekatan A configuration

---

### 4.4 — Pendekatan Text-to-Text pada Pendekatan B (`sec:rq3`)
Lines: ~513–938

RQ3: does T2T VLM caption approach (Pendekatan B) surpass fusion (Pendekatan A)?

**4.4.1** T2T Baseline — Exp081
- `tab:exp081-spec`, `tab:exp081-results` — Dual RoBERTa concat, Qwen7B full 1054, Avg **0.4796**
- 0.4796 << Pend. A best (Exp057, 0.5270); T2T potential not realized; caption noise suspected

**4.4.2** Caption quality analysis
- `tab:caption-error-rates` — per-type error rates: bar 54%, pie 67%, composite 18%, others <10%
- Motivates exclusion experiments and specialized captioner (Subbab 4.5)

**4.4.3** Exclusion empirical proof — Exp092, Exp093
- `tab:exp092-config`, `tab:exp092-results` — excl bar+pie+composite (665), Avg **0.4941**
  - OS drops sharply → composite exclusion harmful
- `tab:exp093-config`, `tab:exp093-results` — excl bar+pie only (772), Avg **0.5778**
  - Confirms bar+pie caption is bottleneck; composite retention correct

**4.4.4** Pendekatan A vs B comparison + RQ3 answer (`subsec:rq3-answer`)
- `tab:approacha-vs-b` — Exp057 (0.5270) vs Exp103 (0.5026), per-trait + delta
  - Pend. A leads 9/10 traits; Pend. B only wins JP (+0.010)
  - Avg gap −0.024; GD and CH show largest difference (−0.044 each)
  - Note: CrossAttn Pend. B (Exp162) reaches 0.5066 but still below Exp057 (−0.020)
- **RQ3 answer**: Pend. B (best full-data: 0.5066) < Pend. A (0.5270) on full data;
  exclusion shows T2T potential ceiling (Exp161: 0.5802) surpasses fusion; caption quality is binding constraint

**4.4.5** CrossAttn query ablation — Exp158, 159, 160 (`subsec:crossattn-query-ablation`)
- `tab:crossattn-query-comparison` — CLS=0.5041, SeqMean=0.4962, CLS-cap-key=0.4664
- CLS query selected (holistic essay representation, converges fastest at epoch 11)

**4.4.6** Exclusion validation on CrossAttn — Exp161, 163 (`subsec:crossattn-excl-comparison`)
- `tab:crossattn-excl-comparison` — baseline Exp158 (0.5041), Exp163 (0.5105), Exp161 (0.5802)
- `tab:exp161-results` — Exp161 per-trait vs Exp093 comparison
- Exp161 = **overall best result in thesis** (0.5802, subset excl bar+pie); CrossAttn +0.002 over concat
- Exp163 < Exp161: composite retention finding robust on CrossAttn arch

---

### 4.5 — Perbandingan Captioner untuk Bar Chart dan Pie Chart (`sec:rq4`)
Lines: ~939–1160

RQ4: DePlot or MATCHA as bar+pie captioner?

- DePlot (Exp103 old arch, 0.5026; Exp162 CrossAttn, 0.5066)
- MATCHA (Exp020 old arch, 0.5213*; Exp164 CrossAttn, 0.4702)
- `fig:deplot-pipeline`
- `tab:exp103-spec`, `tab:exp103-results` — DePlot+Qwen7B old arch per-trait
- `tab:captioner-error-rates` — Qwen baseline/DePlot/MATCHA error rates + QWK
  - MATCHA 0.5213 is an artifact (100% factual error on bar+pie)
- `tab:deplot-matcha-crossattn` — CrossAttn: Exp158 baseline / Exp162 DePlot / Exp164 MATCHA
- `tab:rq4-summary` — all 6 captioner configs
- **RQ4 answer**: DePlot+Qwen7B wins on generalization (both architectures);
  MATCHA shows overfitting pattern (val high, test low); factual accuracy > linguistic fluency

---

### 4.6 — Signifikansi Statistik (`sec:rq5`)
Lines: ~1161–1268

RQ5: systematic bias analysis via paired t-test

- Tests Exp033 (Pend. A representative; architecture class: RoBERTa+ResNet18 late fusion)
  and Exp103 (Pend. B representative; DePlot+Qwen7B full data)
- Note: Exp057 t-test data not available; Exp033 used as data-available representative
- `tab:stat-033` — Exp033: JP, OS, CH significant (3/10); others not
- `tab:stat-103` — Exp103: JP, CH significant (2/10); others not
- Both systems overestimate scores; JP and CH have inherent annotation ambiguity
- **RQ5 answer**: Exp033 significant on 3 traits; Exp103 on 2; Pend. B slightly better alignment

---

### 4.7 — Perbandingan dengan Penelitian Terdahulu dan Keterbatasan (`sec:comparison`)
Lines: ~1269–1378
(Comment in file says "4.8" — minor mismatch)

- `tab:comparison-prior` — vs Su2025 zero-shot baselines
  - Exp057 (0.5270) vs GPT-4o (≈0.54): −0.013; near parity
  - Exp161 (0.5802) vs GPT-4o (≈0.54): +0.040; surpasses
- `tab:literature-confirmation` — 4 claims confirmed (late fusion, RoBERTa, chart text, DePlot)
  - Late fusion: Exp030–032 (0.4777 < 0.4799 < 0.4838) ✓
  - RoBERTa: Exp048–057 (+0.014, cross-attn identik) ✓
  - Chart text > visual: Pend. B > Pend. A after caption optimization ✓
  - DePlot: Exp081 → 103 (+0.023, bar error 54% → 23%) ✓
- Limitations: 1054 samples only; VLM ≤7B; pie chart DePlot still 67% error; AC trait hardest

---

## Tables and Figures Index

| Label | Section | Description |
|-------|---------|-------------|
| `tab:data-splits` | 4.1 | 4 data split configs |
| `tab:approach-comparison` | 4.1 | Exp057 vs Exp162 components |
| `fig:t2t-overview` | 4.1 | T2T architecture diagram |
| `tab:master-results` | 4.1 | All experiment QWK summary |
| `tab:exp046-results` | 4.2.1 | BRCAF replication per-trait (0.4839) |
| `tab:backbone-comparison` | 4.2.2 | ResNet18/50/152 per-trait |
| `tab:ce-vs-mse` | 4.2.3 | CE vs MSE per-trait + delta |
| `tab:fusion-comparison-rq1` | 4.2.4 | Early/CrossAttn/Late per-trait |
| `tab:rq1-progression` | 4.2.5 | Ablation step progression |
| `tab:exp057-results` | 4.3.2 | RoBERTa per-trait (0.5270) |
| `tab:bert-roberta-comparison` | 4.3.3 | BERT vs RoBERTa per-trait + delta |
| `tab:exp081-spec` | 4.4 | T2T baseline config |
| `tab:exp081-results` | 4.4 | T2T baseline per-trait (0.4796) |
| `tab:caption-error-rates` | 4.4 | Caption error rates by chart type |
| `tab:exp092-config` | 4.4 | Exp092 dataset config |
| `tab:exp092-results` | 4.4 | Exp092 per-trait (0.4941) |
| `tab:exp093-config` | 4.4 | Exp093 dataset config |
| `tab:exp093-results` | 4.4 | Exp093 per-trait (0.5778) |
| `tab:approacha-vs-b` | 4.4 | Exp057 vs Exp103 per-trait + delta |
| `tab:crossattn-query-comparison` | 4.4 | Exp158/159/160 CLS/seq/cap-key |
| `tab:crossattn-excl-comparison` | 4.4 | Exp158/161/163 excl strategy comparison |
| `tab:exp161-results` | 4.4 | Exp161 per-trait vs Exp093 (0.5802) |
| `fig:deplot-pipeline` | 4.5 | DePlot two-step pipeline |
| `tab:exp103-spec` | 4.5 | Exp103 scoring model spec |
| `tab:exp103-results` | 4.5 | Exp103 per-trait (0.5026) |
| `tab:captioner-error-rates` | 4.5 | Qwen/DePlot/MATCHA bar+pie errors |
| `tab:deplot-matcha-crossattn` | 4.5 | Exp162 vs 164 on CrossAttn |
| `tab:rq4-summary` | 4.5 | All 6 captioner configs |
| `tab:stat-033` | 4.6 | Exp033 paired t-test per trait |
| `tab:stat-103` | 4.6 | Exp103 paired t-test per trait |
| `tab:comparison-prior` | 4.7 | vs Su2025 zero-shot baselines |
| `tab:literature-confirmation` | 4.7 | 4 literature claims confirmed |

---

## Experiment → Section Mapping

| Exp | Section | Role |
|-----|---------|------|
| Zero-shot (~0.16) | 4.1 | Context reference |
| Exp030–033 | 4.1 table only | Listed in master table; not in narrative |
| Exp046 | 4.2.1 | BRCAF replication |
| Exp047, 048, 049 | 4.2.2 | Backbone ablation |
| Exp050 | 4.2.3 | Regression vs classification |
| Exp055, 048, 056 | 4.2.4 | Fusion strategy ablation |
| Exp057 | 4.3.2 | RQ2: RoBERTa replaces BERT |
| Exp081 | 4.4.1 | T2T baseline |
| (caption analysis) | 4.4.2 | Error rate analysis |
| Exp092, 093 | 4.4.3 | Exclusion ablation (subset) |
| Exp057 vs 103 | 4.4.4 | Pend. A vs Pend. B comparison |
| Exp158, 159, 160 | 4.4.5 | Query strategy ablation |
| Exp161, 163 | 4.4.6 | Exclusion validation on CrossAttn (subset) |
| Exp103 | 4.5 | DePlot old arch |
| Exp020 | 4.5 | MATCHA old arch |
| Exp162 | 4.5 | DePlot CrossAttn |
| Exp164 | 4.5 | MATCHA CrossAttn |
| Exp033, 103 | 4.6 | Statistical significance (t-test data available) |
| Exp057, 161 | 4.7 | Comparison with prior work |

---

## Remaining Issues

1. **4.7 literature claim #1**: says "late fusion lebih baik" (Exp030–032), but RQ1 shows
   cross-attention is better. These are not contradictory (030–032 are BERT+ResNet18 only;
   RQ1 includes cross-attn as a new option), but text could clarify more explicitly.

2. **4.6 uses Exp033**: Paired t-test was run on Exp033 (not Exp057). Framing corrected to say
   "Exp033 is the data-available representative" — but ideally should eventually be rerun on Exp057.

3. **Exp161 framing**: Called "hasil terbaik keseluruhan penelitian ini" in 4.4 — this is consistent
   with CLAUDE.md (best result = 0.5802) but uses a 772-sample subset. The tab:data-splits in 4.1
   clarifies the subset nature. No action needed.
