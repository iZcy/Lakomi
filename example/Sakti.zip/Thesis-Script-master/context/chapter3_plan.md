# BAB III — Implementation Plan
> Created: 2026-04-25 | Working directory: thesis_03/ → output: thesis-main/contents/chapter-3/

---

## Target Structure

```
BAB III Metode Penelitian
│
├── 3.1  Alat dan Bahan
│   ├── 3.1.1  Alat
│   │   ├── a. Perangkat Keras
│   │   ├── b. Komputasi Awan
│   │   └── c. Perangkat Lunak Utama (with justification)
│   └── 3.1.2  Bahan
│       ├── Dataset EssayJudge prose
│       ├── Table: 3 raw sample rows
│       ├── Table: 10 trait descriptions
│       └── Data split protocol (738/158/158, seed=42)
│
├── 3.2  Metode yang Digunakan
│   ├── 3.2.1  Pra-pemrosesan Data
│   ├── 3.2.2  Ekstraksi Fitur
│   ├── 3.2.3  Arsitektur Model (Pendekatan A + B)
│   ├── 3.2.4  Pelatihan Multi-task
│   ├── 3.2.5  Pipeline Captioning (VLM + DePlot hybrid)
│   └── 3.2.6  Evaluasi dan Uji Statistik
│
├── 3.3  Alur Tugas Akhir
│   ├── 3.3.1  Gambaran Umum Penelitian  (problem → lit review → data → exp → analysis → conclusion)
│   ├── 3.3.2  Alur Eksperimen Utama     (10 steps from flow.md, bird-eye view)
│   └──        Flowchart figure (drawio/matplotlib, B&W, TNR, Visio-style, white bg)
│
└── 3.4  Batasan Penelitian              (from BAB I 1.4)
```

---

## Batch Sequence (Information Hierarchy)

Batches are ordered so each one only depends on information already established.

> **STATUS: ALL BATCHES COMPLETED — 2026-04-25**

### BATCH 1 — Grounding (3.1.1 + 3.1.2) — COMPLETED
**Depends on:** EssayJudge CSV, hardware specs (known), software list  
**Produces:** Alat section (hardware/cloud/software) + Bahan section (dataset tables)  
**Key tasks:**
- 3.1.1: Format hardware as lettered list (a/b/c), no comma-separated prose
  - a. Perangkat Keras: Intel Core i7, RTX 3060 Laptop 6GB VRAM, RAM 16GB
  - b. Komputasi Awan (NOT "komputasi cloud"): Kaggle Notebook, Tesla P100 16GB
  - c. Perangkat Lunak Utama: each item on new line WITH justification
    - Python 3.12 → mature ML ecosystem, cross-platform
    - PyTorch 2.x + CUDA 12 → industry standard, HuggingFace native
    - HuggingFace Transformers → unified API for BERT/RoBERTa/VLM
    - bitsandbytes → 4-bit quantization for 7B VLMs on 16GB GPU
    - torchvision → ResNet18 pretrained on ImageNet
    - pandas + scikit-learn → data management + QWK metric
    - LaTeX (TeX Live 2026) → thesis typesetting
- 3.1.2: Title = just "Bahan" (no "Dataset EssayJudge" in title)
  - Dataset prose description
  - Table 1 (tab:essayjudge-sample): 3 rows — columns: No., Tipe Grafik, Cuplikan Esai, AC, JP, OS, ...
    (truncate essay to ~60 chars, show all 10 trait scores)
  - Table 2 (tab:trait-descriptions): 10 rows — Trait | Nama Lengkap | Deskripsi
  - Data split prose (738/158/158, seed=42, sequential)

**Source files:**
- EssayJudge: C:\Outpost\Skripsi\Research 3\EssayJudge\data.csv (latin-1 encoding)
- Hardware: known from CLAUDE.md + draft

---

### BATCH 2 — Constraints (3.4) — COMPLETED
**Depends on:** BAB I Draft tab (t.prr0oo8xt561), BATCH 1 complete  
**Produces:** Batasan Penelitian section  
**Key tasks:**
- Rewrite BAB I section 1.4 into BAB III 3.4 format
- Compress and restructure as a standalone subsection
- All items already in 1.4: dataset scope, IELTS Task 1 only, model list, QWK metric, multi-task only, no VLM fine-tuning, DeepSeek-VL-7B as 7B comparison

**Source files:**
- GDocs BAB I Draft tab content (fetched: see below)

---

### BATCH 3 — Methods (3.2) — COMPLETED
**Depends on:** BATCH 1 (dataset/split established), flow.md, experiment context files  
**Produces:** Metode yang Digunakan (longest section, ~6 subsections)  
**Key tasks:**
- 3.2.1 Pra-pemrosesan Data: image loading (PIL → tensor), text tokenization (RoBERTa 512 tokens), caption JSON loading, label normalization (score/5.0)
- 3.2.2 Ekstraksi Fitur:
  - ResNet18: pretrained ImageNet, avgpool layer → 512d vector
  - RoBERTa: [CLS] token → 768d vector, max_length=512
  - VLM captioning: Qwen2-VL-7B 4-bit NF4, prompt template, output text
- 3.2.3 Arsitektur Model:
  - Pendekatan A: DualEncoderFusion (ResNet18 512d + RoBERTa 768d → concat 1280d → FC → 10 scores)
    - Early/Intermediate/Late variants
  - Pendekatan B: DualRoBERTa (caption RoBERTa 768d + essay RoBERTa 768d → concat 1536d → FC → 10 scores)
    - FC: 1536 → 768 → 256 → 10, Sigmoid × 5.0
- 3.2.4 Pelatihan Multi-task:
  - Loss: sum of MSE over 10 traits
  - Optimizer: AdamW, lr=1e-4, weight_decay=0.01
  - Scheduler: ReduceLROnPlateau (patience=3, factor=0.5)
  - Batch size=16, max_epochs=30, early_stopping patience=10
  - seed=42 for reproducibility
- 3.2.5 Pipeline Captioning:
  - Qwen2-VL-7B: 4-bit NF4 on Kaggle P100, prompt engineering
  - DePlot: google/deplot 282M, float32, "Generate underlying data table..."
  - Hybrid: DePlot for bar+pie → markdown table → Qwen7B narrative; Qwen7B for rest
- 3.2.6 Evaluasi:
  - QWK per trait (11-level: 0–5 step 0.5), then average
  - Paired t-test per trait (Bonferroni α=0.005)

**Source files:**
- flow.md: C:\Outpost\Skripsi\Research 4\thesis_02\flow.md
- Exp context: C:\Outpost\Skripsi\Research 3\context\exp_09_091_092_093.txt
- Exp context: C:\Outpost\Skripsi\Research 3\context\exp_10_101_102_103.txt
- Hyperparameter: C:\Outpost\Skripsi\Research 3\context\hyperparameter_reasoning.txt

---

### BATCH 4 — Flow + Flowchart (3.3) — COMPLETED
**Depends on:** BATCH 3 (methods established), flow.md  
**Produces:** Alur Tugas Akhir section + flowchart PNG  
**Key tasks:**
- 3.3.1 Gambaran Umum: full research narrative from problem identification to conclusion
  Sequence: identifikasi masalah → tinjauan pustaka → persiapan data → desain arsitektur →
  eksperimen bertahap → analisis kualitas caption → pemilihan model terbaik → uji statistik → kesimpulan
- 3.3.2 Alur Eksperimen Utama: the 10-step incremental flow from flow.md
  Each step: numbered paragraph with motivation + experiment + finding
- Flowchart:
  - Tool: matplotlib or drawio XML
  - Standard Visio shapes: oval (start/end), rectangle (process), diamond (decision), arrow (flow)
  - Black & white, white background, TNR font (via matplotlib fontfamily='DejaVu Serif' or Times New Roman)
  - No header/footer text
  - Save as PNG → thesis-main/contents/chapter-3/figures/flowchart_alur.png

**Flowchart content (top-level):**
  START → Identifikasi Masalah → Tinjauan Pustaka → Persiapan Dataset EssayJudge →
  [Pendekatan A path] Desain Arsitektur Fusion → Pelatihan & Evaluasi Fusion →
  [Pendekatan B path] Desain Pipeline T2T → Caption Generation → Pelatihan & Evaluasi T2T →
  Analisis Kualitas Caption → Pemilihan Sistem Terbaik → Uji Statistik → Kesimpulan → END

---

### BATCH 5 — Assembly — COMPLETED
**Depends on:** BATCH 1–4 complete  
**Produces:** thesis-main/contents/chapter-3/chapter-3.tex + PDF rebuild  
**Key tasks:**
- Create chapter-3/ directory in thesis-main/contents/
- Create figures/ subdirectory, copy flowchart PNG
- Assemble all drafted sections into chapter-3.tex
- Uncomment \include{contents/chapter-3/chapter-3} in main.tex (already there)
- Run latexmk -pdf build
- Verify page count and no fatal errors

---

## Raw Source Data (captured 2026-04-25)

### EssayJudge Columns
graph, Question, Essay, image_number, Type,
argument_clarity(ground_truth), justifying_persuasiveness(ground_truth),
organizational_structure(ground_truth), coherence(ground_truth),
essay_length(ground_truth), grammatical_accuracy(ground_truth),
grammatical_diversity(ground_truth), lexical_accuracy(ground_truth),
lexical_diversity(ground_truth), punctuation_accuracy(ground_truth)

### Sample Row 1 (bar_chart)
- Type: bar_chart
- Question: "The bar chart below describes some changes about the percentage of people were born in Australia..."
- Essay: "Between 1995 and 2010, a study was conducted representing the percentages of people born in Australia..."
- Scores: AC=2.5, JP=2.0, OS=0.0, CH=3.0, EL=3.0, GA=2.5, GD=4.0, LA=4.0, LD=3.0, PA=3.0

### Sample Row 2 (bar_chart, same image different essay)
- Essay: "The left chart shows the population change happened in Austrilia from 1995 to 2010..."
- Scores: AC=2.5, JP=3.5, OS=3.5, CH=3.5, EL=3.5, GA=3.0, GD=2.5, LA=2.5, LD=3.0, PA=3.5

### BAB I 1.4 Batasan (key constraints for 3.4):
1. Dataset: EssayJudge 1,054 esai IELTS Task 1, 10 trait (skala 0–5, step 0.5)
2. Scope: IELTS Academic Writing Task 1 only (bukan Task 2)
3. Models used:
   - Fusion: BERT-base-uncased + RoBERTa-base as text encoder; ResNet18 as image encoder
   - T2T: Qwen2-VL-7B-Instruct (generalist captioner); DePlot (specialized chart captioner); two RoBERTa-base as dual encoder
4. Metric: QWK, 11 levels (0–5 step 0.5)
5. Training: multi-task (single model for all 10 traits)
6. No fine-tuning on VLM or DePlot; captions generated once, used statically
7. VLM comparison limited to 7B open-source: Qwen2-VL-7B-Instruct and DeepSeek-VL-7B

---

## Pending Items Before Writing

| Item | Status | Notes |
|------|--------|-------|
| flowchart design | DONE | Generated thesis_03/figures/flowchart_alur.png via matplotlib, B&W, 300 DPI |
| 3.2 detailed method prose | DONE | All 6 subsections written in section_32.tex |
| EssayJudge row 3 for table | DONE | flow_chart type row included in sample table |
| chapter-3/ dir creation | DONE | thesis-main/contents/chapter-3/ created with figures/ subdir |

> All pending items resolved. BAB III fully assembled into chapter-3.tex. PDF: 102 pages, clean build. (2026-04-25)

---

## Writing Rules Reminder
- No colon before single item (use "yaitu" / "yakni" / comma instead)
- No em dash
- English terms in Indonesian prose → \textit{}
- Min 3 paragraphs per subsection
- Each subsection must have at least one table/figure
- No "Track A/B" → use "Pendekatan A/B"
- No forward reference to our own results in method sections
