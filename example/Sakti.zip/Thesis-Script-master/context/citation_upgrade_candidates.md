# Citation Upgrade Candidates
> Status: Research done, not yet applied to LaTeX.
> These are potential newer (2021+) replacements for old references cited outside BAB II.

---

## Background

Three pre-2021 references are currently cited outside BAB II (methodology/results chapters).
Goal: find 2021+ alternatives that make the same or stronger claim in the same context.

---

## 1. `liu2019roberta` — Liu et al. (2019), RoBERTa

**Currently cited in:**
- BAB III › Ekstraksi Fitur (justifying RoBERTa as text encoder choice)
- BAB IV › Pengaruh Pilihan Text Encoder (confirming RoBERTa > BERT)
- BAB IV › Konfirmasi Temuan Literatur (literature confirmation table)

**Research findings (investigated, now resolved):**

### ❌ Rejected — Naseer et al. (2021) · ICAIIC 2021 (IEEE)
- Task: Fact verification (FEVER dataset) — unrelated to text quality/AES
- RoBERTa 95.4% vs BERT 94.3%, but fact verification is 3-class claim classification, not text understanding

### ❌ Rejected — sun2024 (already in bib)
- Compares RoBERTa vs DistilBERT only — does NOT compare RoBERTa vs BERT at all
- Cannot be used to justify "RoBERTa > BERT"

### ✅ SELECTED — Akhila, Sanjanasri & Soman (2023) · CONIT 2023 (IEEE)
- Full title: "Comparative Study of Bert Models and Roberta in Transformer based Question Answering"
- DOI: 10.1109/CONIT59222.2023.10205622
- Bib key: `akhila2023` (added to references.bib ✅)
- Dataset: SQuAD v2 (100,000 QA pairs from Wikipedia)
- Task: Extractive Question Answering — reading comprehension = direct text understanding
- Result: RoBERTa validation loss consistently lowest across all 3 epochs vs BERT-base-uncased and DistilBERT variants
  - Epoch 1: RoBERTa 0.7331 vs BERT 1.1743
  - Epoch 3: RoBERTa 1.0743 vs BERT 1.3092
- Conclusion (direct quote): "ROBERTa produces the best results out of all of these models because its training and validation losses are lower"
- ✅ IEEE, 2023, direct multi-model comparison, QA = text understanding task
- PDF on file: C:\Outpost\Skripsi\Research 3\Papers\Comparative_Study_of_Bert_Models_and_Roberta_in_Transformer_based_Question_Answering.pdf

**Final recommendation:**
- BAB III Ekstraksi Fitur: cite `liu2019roberta` + `akhila2023` — original paper + 2023 IEEE empirical confirmation on text understanding task
- BAB IV Konfirmasi Temuan Literatur: keep `liu2019roberta` only (it is the original paper being confirmed)

---

## 2. `loshchilov2019` — Loshchilov & Hutter (2019), AdamW

**Currently cited in:**
- BAB III › Pelatihan Multi-task (justifying AdamW as optimizer for fine-tuning)

**Candidates:**

### Option A — Mosbach et al. (2024) · ACL 2024 Findings ⭐ PREFERRED
- Full title: "Should I try multiple optimizers when fine-tuning pre-trained Transformers for NLP tasks?"
- arXiv: 2402.06948 · https://arxiv.org/abs/2402.06948
- Claim: Empirical comparison of Adam, AdamW, Nadam, AdaBound, SGD variants on BERT/RoBERTa fine-tuning across GLUE. Confirms AdamW is effective for transformer fine-tuning in NLP.
- ✅ Directly validates AdamW for the exact use case (transformer fine-tuning for NLP)

### Option B — Zhuang et al. (2023) · IJCAI 2023
- Full title: "A Survey on Efficient Training of Transformers"
- arXiv: 2302.01107 · https://arxiv.org/abs/2302.01107
- Claim: Survey contextualizing AdamW within modern transformer optimization strategies

**Recommendation:** Add Mosbach et al. (2024) alongside `loshchilov2019` in BAB III — don't replace, just supplement with a 2024 empirical validation. This keeps the original definition paper and adds a recent endorsement.

---

## 3. `baltrusaitis2019` — Baltrusaitis et al. (2019), Multimodal ML Survey

**Currently cited in:**
- BAB IV › Perbandingan Strategi Fusion (predicting late fusion will win)
- BAB IV › Perbandingan Ketiga Strategi dan Jawaban RQ1 (confirming late fusion wins)
- BAB IV › Konfirmasi Temuan Literatur

**⚠️ ALERT — `gold2025` may not exist:**
- The bib entry `gold2025` ("Multimodal Fusion Strategies for Automated Essay Scoring", Gold et al.) could NOT be verified as a real published paper.
- Must be verified before final submission. If fabricated/placeholder, remove immediately.

**Candidates:**

### Option A — Zhao et al. (2024) · ACM Computing Surveys ⭐ PREFERRED
- Full title: "Deep Multimodal Data Fusion"
- DOI: 10.1145/3649447 · https://dl.acm.org/doi/10.1145/3649447
- Claim: Peer-reviewed ACM survey with fine-grained taxonomy of fusion methods (early, late, attention-based, GNN, generative). 159 citations. Covers heterogeneous modality fusion directly.
- ✅ Peer-reviewed, highly cited, directly covers the fusion taxonomy claim

### Option B — Li & Tang (2024) · arXiv → Springer IJCV 2025
- Full title: "Multimodal Alignment and Fusion: A Survey"
- arXiv: 2411.17040 · https://arxiv.org/abs/2411.17040
- Claim: Discusses late vs early fusion for heterogeneous modalities, proposes modern taxonomy
- ✅ Most directly relevant to the heterogeneous modality argument used in BAB IV

**Recommendation:** Replace `baltrusaitis2019` in BAB IV with Zhao et al. (2024) as the primary citation, keeping `baltrusaitis2019` only in BAB II where it's used as a historical foundation.

**⚠️ BIB ANOMALY:** Entry is typed `@inproceedings` but the paper is a journal article published in *IEEE Transactions on Pattern Analysis and Machine Intelligence* (TPAMI), Vol. 41, No. 2, pp. 423–443. The `booktitle` field should be `journal`. Fix to `@article` before submission.

---

## Action Checklist

- [x] Verify `gold2025` — real paper (RIT M.S. thesis, Ronen G. Gold, sentiment classification). Bib fixed to @mastersthesis ✅
- [x] `liu2019roberta` supplement: `akhila2023` selected and added to references.bib ✅
- [x] Add approved new bib entries to references.bib — `akhila2023` done ✅
- [x] Update references.md with new entries — done ✅
- [x] Apply `akhila2023` citation to BAB III Ekstraksi Fitur .tex file ✅
- [x] Apply `akhila2023` to BAB II Section 2.3 (line 849), replacing wrong sun2024 claim ✅
- [x] Fix `baltrusaitis2019` bib entry type — N/A, entry dropped entirely ✅
- [ ] `he2016` citation at BAB III line 215 — DEFERRED. he2016 argues deeper ResNet = better accuracy; citing it while using ResNet-18 (shallowest variant) without explanation contradicts the paper's own findings. Pending experiment comparing ResNet-18 vs ResNet-50/152 (Pendekatan A). After results: if ResNet-18 stays, add he2016 + lightweight justification; if upgraded, add he2016 as proper motivation.
- [ ] Note: `gold2025` uses ResNet152+ResNet50, not ResNet18. BAB II line 14 says "BERT+ResNet" (accurate, since ResNet18 is a ResNet). No text change needed, but verify no line says "gold2025 uses ResNet18" anywhere.
- [x] Replace `baltrusaitis2019` in BAB IV — resolved with pereira2023 + wang2021celft ✅
- [x] `loshchilov2019` in BAB III — replaced with zhou2024 (IEEE TPAMI 2024) ✅

---

## Priority Order

1. **`gold2025` verification** — highest risk, may need immediate removal
2. **`baltrusaitis2019` in BAB IV** — clearest upgrade path (Zhao 2024 ACM Surveys)
3. **`loshchilov2019` in BAB III** — easy addition (Mosbach 2024 ACL)
4. **`liu2019roberta` in BAB III** — lowest priority, keeping original is defensible
