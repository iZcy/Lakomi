# Drop Plan: Exp 159 & 160 from Thesis and Paper

**Reason:** Exp 159 (sequence-mean query) and Exp 160 (CLS-cap-key) have no backing literature — no paper justifies these specific cross-attention query strategies. Only Exp 158 (CLS query) can be grounded in prior work. Dropping 159 and 160 simplifies the narrative without losing any research contribution.

---

## 1. MENTION MAP — THESIS

### Chapter 3 (`chapter-3.tex`)

| Location | Type | Content |
|---|---|---|
| tab:pipeline-captioning row | Table row | `158/159/160 & Semua jenis (1.054 sampel) & --- & ---` |
| Subsubsection ~L1131–1191 | Full section | `Eksperimen 159: Ablasi Query, Rata-rata Urutan` — description, figure, config table |
| Subsubsection ~L1193–1254 | Full section | `Eksperimen 160: Ablasi Query, CLS-cap-key` — description, figure, config table |
| tab:exp-pend-b rows | Table rows | Rows for 159 (`Rata-rata urutan`) and 160 (`CLS-cap-key`) |
| Langkah 8 body ~L1764–1770 | Prose | `(Exp~158, 159, 160): CLS query... sequential query... CLS-cap-key...` |
| tab:alur-eksperimen row 8 | Table row | `Ablasi Query & Exp~158--160 & 0,5041` |

### Chapter 4 (`chapter-4.tex`)

| Location | Type | Content |
|---|---|---|
| Subsection heading L534 | Section title | `Ablasi Strategi Query ... (Eksperimen 158--160)` |
| Enumeration L540–549 | List items | Items 2 (Exp 159 seq-mean) and 3 (Exp 160 CLS-cap-key) |
| Table caption L555–556 | Caption | `Perbandingan strategi query ... (Eksperimen 158--160)` |
| Table rows L571, L573 | Table rows | Rows for 159 (0,4962) and 160 (0,4664) |
| Discussion L578–591 | Prose | Mentions Exp 159 (epoch 22) and Exp 160 (underfitting, epoch 8) |
| Jawaban RQ3 L601–602 | Prose | `strategi query CLS dipilih berdasarkan konvergensi ... pada Subbab~\ref{subsec:crossattn-query-ablation}` |
| Master results table L1377, L1379 | Table rows | Rows for 159 and 160 in `tab:master-results` |

---

## 2. MENTION MAP — PAPER (`paper-backup/main.tex`)

| Location | Type | Content |
|---|---|---|
| L240–246 | Prose paragraph | `Query strategy ablation (Exp~158--160) ... Three strategies: (i) CLS-query ... (ii) Seq-mean ... (iii) CLS-cap-key` |
| tab:approach-b L421–422 | Table rows | Rows for 159 (Seq-mean, 0.4962) and 160 (CLS-cap-key, 0.4664) |

---

## 3. DROPPING PLAN — THESIS

### Batch 1 — Chapter 3 structural deletions
- **Delete** entire `\subsubsection{Eksperimen 159 ...}` (figure + config table, ~L1131–1191)
- **Delete** entire `\subsubsection{Eksperimen 160 ...}` (figure + config table, ~L1193–1254)
- **Delete** rows 159 and 160 from `tab:exp-pend-b`
- **Edit** `tab:pipeline-captioning` row `158/159/160` → `158`

### Batch 2 — Chapter 3 prose and summary table
- **Edit** Langkah 8 heading: `(Pendekatan B)` stays, remove "(Exp~158, 159, 160)" list → rewrite to state Exp 158 implements CLS query as the adopted strategy
- **Edit** `tab:alur-eksperimen` row 8: `Exp~158--160` → `Exp~158`

### Batch 3 — Chapter 4 subsection rewrite
- **Rename** subsection heading to `Implementasi Basis Pendekatan B (Eksperimen 158)`
- **Remove** enumeration list of 3 strategies; replace with 1-paragraph description of CLS query (keep the "why" reasoning from the existing text)
- **Remove** comparison table `tab:crossattn-query-comparison` (single-row table after dropping 159/160 adds no value); fold result into prose
- **Rewrite** discussion paragraph: remove mentions of Exp 159 (epoch 22) and Exp 160 (underfitting, epoch 8); keep the rationale for CLS token superiority
- **Edit** Jawaban RQ3: remove direct reference to "epoch ke-22 Eksperimen 159"; keep the `\ref{subsec:crossattn-query-ablation}` reference (section still exists, just renamed)
- **Delete** rows 159 and 160 from `tab:master-results`

---

## 4. DROPPING PLAN — PAPER

### Batch 4 — Paper
- **Rewrite** L240–246: Remove three-strategy enumeration; replace with one sentence stating CLS query (Exp 158) was used as the query strategy for all Approach B experiments
- **Delete** rows 159 and 160 from `tab:approach-b`

---

## 5. BRIDGING ANALYSIS — THESIS

### Chapter 3, Langkah 8
**Before:** "Langkah ini membandingkan tiga strategi... (Exp 158, 159, 160): CLS query... sequential query... CLS-cap-key..."
**After:** Restate Langkah 8 as implementing and validating the CLS query strategy (Exp 158) that becomes the fixed configuration for all Pendekatan B experiments. No enumeration of alternatives needed.
**Bridge sentence:** "Pada langkah ini, arsitektur *DualRobertaCrossAttnCls* diimplementasikan dengan strategi *query* CLS (Exp~158), yaitu penggunaan token [CLS] esai sebagai *query* terhadap seluruh urutan token *caption*. Strategi ini ditetapkan sebagai konfigurasi tetap untuk seluruh eksperimen Pendekatan B berikutnya berdasarkan stabilitas konvergensi yang dicapai."

### Chapter 3, Exp 161 intro
**Currently:** "Eksperimen ini menerapkan strategi *query* CLS terbaik dari Langkah 8..."
**After:** Already references "Langkah 8" — this stays valid without change since we are retaining Exp 158 in Langkah 8. No bridging edit needed.

### Chapter 4, Subsection formerly "Ablasi Strategi Query (158--160)"
**New title:** `Implementasi Basis Pendekatan B (Eksperimen 158)`
**New structure (2 paragraphs to satisfy writing rules):**
- Para 1: Describe CLS query mechanism — token [CLS] esai sebagai *query* tunggal terhadap seluruh token *caption*, dengan *key_padding_mask*. State results: Val QWK 0,5425; Test QWK 0,5041; epoch terbaik 11.
- Para 2: Justify CLS token choice using the existing reasoning (CLS aggregates full essay across 12 transformer layers → cleanest single-vector query). State that CLS query is adopted as the fixed strategy for Exp 161–164.

**Removed:** The comparison table is dropped. The result (0,5041) is stated in prose.

### Chapter 4, Jawaban RQ3
**Currently:** "strategi *query* CLS dipilih berdasarkan konvergensi dan stabilitas terbaik pada Subbab~\ref{subsec:crossattn-query-ablation}..."
**After:** Change to "strategi *query* CLS pada Eksperimen 158 ditetapkan sebagai konfigurasi tetap berdasarkan stabilitas konvergensi yang dicapai (Subbab~\ref{subsec:crossattn-query-ablation}), ..." — no bridging gap since the section label is preserved.

### Chapter 4, Master results table
Rows 159 and 160 deleted. Row 158 stays. No bridging needed — rows are self-contained.

---

## 6. BRIDGING ANALYSIS — PAPER

### Approach B description paragraph
**Before:** 3-strategy enumeration (i)(ii)(iii) for Exp 158--160
**After:** Single sentence — "The essay \texttt{[CLS]} token is used as the query against all caption token representations (CLS-query, Exp~158), which is adopted as the fixed query strategy for all Approach B experiments."
**Next sentence already in place:** "Captioner selection (Exp~161--164) uses the best query strategy (CLS)." — this stays valid and bridges cleanly.

### Paper table tab:approach-b
After removing rows 159 and 160, table has 5 rows (158, 161, 162, 163, 164). Table caption and column headers remain unchanged.

---

## 7. STATUS

- [x] Batch 1: Ch3 structural deletions (159/160 subsubsections, table rows)
- [x] Batch 2: Ch3 prose edits (Langkah 8, alur-eksperimen table)
- [x] Batch 3: Ch4 subsection rewrite + master table
- [x] Batch 4: Paper prose + table
- [x] Rebuild PDF (thesis)
- [x] Rebuild PDF (paper)
