# Final Writing Rules — Skripsi AES
> Single source of truth. Supersedes writing_rules.md, writing_style_ch4.md, writing_style_33_alur.md.
> Applies to ALL chapters (BAB I–V) unless a rule is explicitly marked chapter-specific.
> Last updated: 2026-05-05

---

## PART 1 — GLOBAL LANGUAGE RULES
*These apply in every sentence of every chapter without exception.*

---

### 1.1 No Em Dash

Em dash (—) is **forbidden** in all body text. Never use it as a parenthetical, as a pause, or as a separator. Rewrite the sentence instead.

**Wrong:**
> Model ini menggunakan dua \textit{encoder} — satu untuk gambar, satu untuk teks.

**Correct:**
> Model ini menggunakan dua \textit{encoder}, yaitu satu untuk gambar dan satu untuk teks.

---

### 1.2 Colon Only Before an Explicit List of ≥2 Items

A colon (:) is **only allowed** when it directly precedes a list of two or more explicit items written out immediately after it. Never use a colon to introduce a single concept, a clause, an explanation, or a continuation of thought. Replace with "yaitu", "yakni", "bahwa", or a comma.

**Wrong (single concept):**
> Metode yang digunakan adalah: \textit{cross-attention}.

> Hasil utama penelitian ini adalah: QWK 0,5802.

**Correct (list of ≥2 items):**
> Terdapat dua pendekatan yang dievaluasi: Pendekatan A dan Pendekatan B.

> Tiga strategi diuji: \textit{early fusion}, \textit{intermediate fusion}, dan \textit{late fusion}.

**Exception — labeled list items in `\enumerate`:** A colon after a label inside a formal `\enumerate` item (e.g., `\item Objek penelitian: ...`, `\item Keterbatasan penelitian: ...`) is acceptable. This is the "label: value" pattern in structured lists, not a sentence colon.

---

### 1.3 All English Technical Terms Must Be Italicized

Every English-language technical term appearing inside Indonesian prose must be wrapped in `\textit{}`. This applies whether it is a noun, adjective, or verb form.

**Mandatory italic terms (non-exhaustive):**

| Term | LaTeX |
|------|-------|
| encoder, decoder | `\textit{encoder}`, `\textit{decoder}` |
| pipeline | `\textit{pipeline}` |
| caption, captioning | `\textit{caption}`, `\textit{captioning}` |
| benchmark | `\textit{benchmark}` |
| fine-tuning, pre-training | `\textit{fine-tuning}`, `\textit{pre-training}` |
| dropout | `\textit{dropout}` |
| batch size, learning rate | `\textit{batch size}`, `\textit{learning rate}` |
| epoch | `\textit{epoch}` |
| checkpoint, inference | `\textit{checkpoint}`, `\textit{inference}` |
| transfer learning | `\textit{transfer learning}` |
| zero-shot | `\textit{zero-shot}` |
| downstream | `\textit{downstream}` |
| early fusion, late fusion, intermediate fusion | `\textit{early fusion}`, etc. |
| cross-attention | `\textit{cross-attention}` |
| text-to-text | `\textit{text-to-text}` |
| feature map, feature vector | `\textit{feature map}`, etc. |
| embedding, pooling | `\textit{embedding}`, `\textit{pooling}` |
| backbone | `\textit{backbone}` |
| overfitting, regularization | `\textit{overfitting}`, etc. |
| loss function | `\textit{loss function}` |
| multi-task | `\textit{multi-task}` |
| forward pass, backward pass | `\textit{forward pass}`, etc. |
| ground truth | `\textit{ground truth}` |
| query, key, value (attention) | `\textit{query}`, `\textit{key}`, `\textit{value}` |
| token, tokenisasi | `\textit{token}` (noun); "tokenisasi" is acceptable Indonesian |
| head (prediction head) | `\textit{prediction head}` |
| trait | `\textit{trait}` |
| bar chart, pie chart, flow chart | `\textit{bar chart}`, `\textit{pie chart}`, `\textit{flow chart}` |
| composite chart | `\textit{composite chart}` |
| markdown | `\textit{markdown}` |
| Avg (in QWK context) | `\textit{Avg}` |

**Never italicize:** Proper model names (BERT, RoBERTa, ResNet, DePlot, MATCHA, Qwen2-VL-7B, etc.) — they are proper nouns, not generic English terms.

---

### 1.4 Pendekatan A / Pendekatan B — Never "Track A/B"

In all thesis writing, always use:
- **Pendekatan A** — the multimodal fusion approach (ResNet + RoBERTa direct fusion)
- **Pendekatan B** — the text-to-text approach (VLM caption + Dual RoBERTa)

"Track A" and "Track B" are permitted only in Python scripts for internal reference.

---

### 1.5 "dimana" vs "di mana" / "dibawah" vs "di bawah"

- **dimana** — use when it means "where" in a relative/comparative clause (mathematical, logical sense): "model dimana seluruh parameter dilatih", "kondisi dimana QWK melebihi 0,5"
- **di mana** — use ONLY when referring to a physical location: "di mana eksperimen dijalankan" (the physical place)
- **dibawah** — use in comparative sense: "performa yang masih dibawah Pendekatan A", "nilai dibawah ambang signifikansi"
- **di bawah** — use for literal physical position: "gambar di bawah teks", "di bawah tabel ini"

---

### 1.6 "fungsi kerugian" → Always "\textit{loss function}"

Never write "fungsi kerugian" in prose. Always use `\textit{loss function}`. The Indonesian translation is not standard in this thesis.

---

### 1.7 VLM Size Constraint Must Be Consistent

The ≤7 billion parameter constraint for VLMs is stated in BAB I and must remain consistent across all chapters. Never describe any VLM used in this thesis as exceeding 7B parameters, and never omit the constraint when introducing the VLM choice.

---

## PART 2 — STRUCTURE AND LENGTH RULES
*Applies to all chapters.*


---


### 2.1 No Results or Conclusions in BAB II or BAB III Prose

BAB II is literature review — it contains only theory, prior work, and background. BAB III is methodology — it describes what was done and why. Neither chapter should contain:
- QWK scores from this thesis's experiments
- Conclusions about which approach won
- Forward references to BAB IV findings

Exception: the summary table `tab:alur-eksperimen` in BAB III may contain QWK values as a reference index.

---

### 2.2 RQ Answers Must Be Natural Paragraphs

Do NOT bold the RQ answer. Do NOT use the format `Jawaban RQ1: \textbf{...}`. Write it as a natural explanatory paragraph following this template:

> Jawaban dari RQ[N], berdasarkan hasil di atas, adalah bahwa [finding in plain language], dengan [metric] [value] pada Eksperimen [XXX]. [Model/component] menjadi [role] yang digunakan pada eksperimen ini.

**Wrong:**
```latex
Jawaban RQ1: \textbf{\textit{cross-attention} menghasilkan QWK tertinggi (0,5134),
melampaui \textit{late fusion} sebesar $+0{,}031$.}
```

**Correct:**
```latex
Jawaban dari RQ1, berdasarkan hasil di atas, adalah bahwa strategi \textit{cross-attention}
menghasilkan \textit{Avg} QWK tertinggi di antara strategi \textit{fusion} yang dievaluasi,
dengan \textit{Avg} QWK 0,5134 pada Eksperimen 048. BERT dan ResNet50 menjadi komponen
teks dan gambar yang digunakan pada eksperimen ini.
```

Key points: no `\textbf{}` wrapping the answer, no gap notation in the answer sentence, ends with statement about which models were used.

---


### 3.1 Figure Placement

All figures in BAB III use `[H]` (forced placement) to prevent drift across subsection boundaries. Do not use `[htbp]` for any figure in chapter 3.

```latex
\begin{figure}[H]
  \centering
  \includegraphics[width=0.88\textwidth]{images/filename.pdf}
  \caption{...}
  \label{fig:label}
\end{figure}
```

---

### 3.2 Table Captions: Minimal

Table captions identify what the table shows and which experiments. Do NOT re-explain the architecture, models, or configuration in the caption — that belongs in body text.

**Wrong:**
```latex
\caption{Hasil QWK per-\textit{trait} Eksperimen 046 (replikasi BRCAF: BERT,
         \textit{dual} ResNet152+ResNet50, \textit{cross-attention}).}
```

**Correct:**
```latex
\caption{Hasil QWK per-\textit{trait} Eksperimen 046.}
```

Do NOT add "Nilai tertinggi per baris dicetak tebal" or other formatting instructions in captions.

---

### 3.3 Bolding in Result Tables

In comparison tables:
- Only bold the first and avg qwk row label 
- Do NOT bold individual per-trait highest scores across columns
- Other Avg QWK values (non-winning) are not bolded

```latex
% WRONG
\textit{Coherence} & 0,605 & \textbf{0,628} & 0,599 \\
\textbf{Avg QWK}   & 0,5070 & \textbf{0,5134} & 0,5081 \\

% CORRECT
\textit{Coherence}         & 0,605  & 0,628           & 0,599  \\
\textbf{\textit{Avg} QWK}  & 0,5070 & \textbf{0,5134} & 0,5081 \\
```

---

### 3.4 "\textit{Avg}" Formatting Is Mandatory

The word "Avg" must always be italicized everywhere it appears:
- In table row labels: `\textbf{\textit{Avg} QWK}`
- In table column headers: `\textbf{\textit{Avg} QWK}`
- In prose: `\textit{Avg} QWK 0,5134`

```latex
% WRONG in all contexts
Avg QWK
\textbf{Avg QWK}

% CORRECT
\textit{Avg} QWK
\textbf{\textit{Avg} QWK}
```

---

## PART 4 — CITATION RULES
*Applies to all chapters.*

---

### 4.1 Cite Newest First, Seminal Second

When explaining a concept:
1. Cite the most recent paper that uses or extends it in a way relevant to this research
2. Cite the original/seminal paper for attribution

If a newer paper contradicts or supersedes an older finding, cite the newer one and note the difference. Never present outdated findings without acknowledging more recent evidence.



---

### 4.2 Verify Before Citing

Before citing any paper: confirm correct authors, title, year, venue, and that the paper's actual methodology and findings match how it is cited. Abstracts can mislead — check the actual paper content.

---

## PART 5 — BAB III SPECIFIC RULES

---

### 5.1 Prose Describes What Was Done, Not What Was Found

Every paragraph in BAB III answers: *what is this component/step/experiment, and why is it designed this way?* Not: *what result did it produce?*

---

### 5.2 Hyperparameters Belong in Longtables, Not Prose

Values like `lr=2e-5`, `batch=32`, `dropout=0.5`, `weight_decay=0.01`, `seed=42` belong in the per-experiment configuration longtables (section 3.2.3 / 3.2.4), not in narrative prose. The prose names what is being done; the table carries the specifics.

---

### 5.3 Section 3.3.2 — Alur Eksperimen (Narrative Flow): Special Rules

This section is a **high-level research journey narrative**, not a config dump and not a results preview. Additional rules apply only here:

**a) No QWK scores in prose.** No results of any kind. The summary table carries numbers.

**b) No heavy implementation jargon in prose.**

| Banned in 3.3.2 prose | Use instead |
|----------------------|-------------|
| `backbone` | "komponen pengolah gambar" or model name (ResNet18/50/152) |
| `encoder` alone | "model pemrosesan teks" or model name (BERT, RoBERTa) |
| `MSE`, `CE`, `cross-entropy` | "regresi" / "klasifikasi" |
| `gradient accumulation`, `weight decay`, `lr=2e-5` | omit entirely |
| `logits`, `hidden states`, `batch size` | omit entirely |

**c) Always name specific models** — not "sebuah model bahasa-visual" but "Qwen2-VL-7B-\textit{Instruct}".

**d) Paragraph structure for each step:**
```
\noindent\textbf{Langkah N, <Short Title>.}
<1 sentence: context / motivation — why is this step needed?>
<1–2 sentences: what is being compared/tested, naming specific models and Exp~numbers.>
<Optional 1 sentence: what is held fixed, to isolate the variable.>
```
Maximum 3–4 sentences per step. No results. No QWK.

**e) Use English fusion terms, italicized:**

| Use | Not |
|-----|-----|
| `\textit{early fusion}` | "penggabungan awal" |
| `\textit{intermediate fusion}` | "penggabungan menengah" |
| `\textit{late fusion}` | "penggabungan akhir" |
| `\textit{CLS query}` | (explain once as "token ringkasan esai sebagai pertanyaan") |

**f) Explain new terms on first use.** If a technical term must appear, gloss it the first time:
> `\textit{CLS query}` yang menggunakan token ringkasan esai sebagai representasi pertanyaan

---

## PART 6 — BAB IV SPECIFIC RULES

---

### 6.1 No Re-Explaining Architecture

BAB IV is results and discussion — not architecture description. Chapter 3 already covers all model architectures and configurations. In BAB IV, only name the component and cite the result. Do NOT re-explain:
- How an encoder works or was pre-trained
- Why a component should theoretically outperform another
- What changed mechanically between two experiments

**Wrong:**
```
RoBERTa menggunakan \textit{dynamic masking} dan data pra-pelatihan yang jauh lebih
besar dibandingkan BERT \citep{liu2019roberta}, sehingga diharapkan menghasilkan
representasi yang lebih \textit{robust} untuk teks esai IELTS.
```

**Correct:**
```
Eksperimen 057 mengganti BERT dengan RoBERTa pada arsitektur yang identik.
Hasil per-\textit{trait} disajikan pada Tabel~\ref{tab:exp057-results}.
```

---

### 6.2 No Gap Notation (+xxx) in Prose Paragraphs

Do not write `$+0{,}030$` or `$-0{,}015$` inline in running prose. If the gap is important, put it in a dedicated **Selisih** or **$\Delta$** column in the table.

**Wrong (in prose):**
> ResNet50 menghasilkan QWK tertinggi (0,5134), melampaui ResNet18 sebesar $+0{,}006$.

**Correct (in prose):**
> ResNet50 menghasilkan \textit{Avg} QWK tertinggi (0,5134) di antara ketiga konfigurasi.

**Correct (in table):**
```latex
\textbf{\textit{Avg} QWK} & \textbf{0,5134} & 0,5070 & $+0{,}006$ \\
```

Gap notation is acceptable ONLY in progression tables (tab:rq1-progression style) where there is an explicit $\Delta$ column.

---



### 6.3 No Parameter Counts in Prose Analysis

Do not cite specific parameter counts (e.g., "198 juta parameter", "282 juta parameter") in prose analysis paragraphs unless model size is the explicit variable being discussed. Parameter counts belong in architecture descriptions (BAB III) or configuration tables.

---

### 6.4 Architectural Context When Explaining Ablation Motivation

When noting that an architectural component is unsuitable for the current task, explain:
1. Why it was originally designed that way
2. Why that reasoning does not apply here
3. What the consequence is

**Wrong:**
> Kombinasi dua komponen pengolah gambar berpotensi terlalu kompleks untuk 737 sampel pelatihan.

**Correct:**
> Arsitektur \textit{dual} ResNet pada BRCAF awalnya dirancang untuk memisahkan representasi
> objek (ResNet152 berbasis ImageNet) dan konteks latar belakang (ResNet50 berbasis Places365)
> dalam sebuah gambar. Dalam konteks grafik IELTS yang bersifat abstrak, pemisahan objek dan
> latar belakang tidak relevan, sehingga konfigurasi \textit{dual} ini berpotensi terlalu
> kompleks untuk jumlah data pelatihan yang tersedia.

---

### 6.5 BAB II: No Experiment References or QWK Scores

BAB II (Dasar Teori / Tinjauan Pustaka) must contain no QWK results from this thesis, no experiment numbers (Exp~046 etc.), and no conclusions about which approach performed better. BAB II is pure literature review.

---

## PART 7 — LATEX FORMATTING RULES

---

### 7.1 Checklist Before Every .tex Edit Session

- [ ] English terms in `\textit{}`
- [ ] "Avg" in `\textit{Avg}`
- [ ] "loss function" not "fungsi kerugian"
- [ ] No em dash
- [ ] Colon only before list of ≥2 items
- [ ] "dimana" / "di mana" distinction correct
- [ ] "dibawah" / "di bawah" distinction correct
- [ ] Figure placement `[H]` in BAB III
- [ ] Table captions minimal (experiment number only)
- [ ] Bold only winning Avg QWK in comparison tables
- [ ] No QWK in BAB II or BAB III prose

---

### 7.2 Longtable Width Safety

TextWidth = 14.92cm ≈ 423pt. Column overhead = N_cols × 12pt + (N_cols+1) × 0.4pt.
Sum of all `p{}` widths + overhead must not exceed 423pt.

For wide tables use: `\begingroup\small\setlength{\tabcolsep}{3pt}...\endgroup`.
Always use `p{}` columns for text content. Only use `l`, `c`, `r` for narrow numeric/code columns.

---

### 7.3 \arraybackslash Requires array Package

`>{\centering\arraybackslash}p{Xcm}` requires `\usepackage{array}` in preamble.
This is already added to `main.tex`. Do not remove it.

---

## PART 8 — VERIFICATION WORKFLOW

This is the mandatory iteration loop for every writing/editing session on any chapter.

---

### The Loop

```
1. Read rules        → re-read this file (final_writing_rule.md)
2. Read thesis       → read the target chapter .tex file
3. List changes      → write all violations found to playground_verification.md
                       (one line per violation: location + rule violated + fix)
4. Apply changes     → fix violations one by one, checking each off in playground_verification.md
5. Iterate           → return to step 1 for the next chapter or next pass
```

**playground_verification.md** lives at `Research 4/playground_verification.md`.
Format for each entry:

```markdown
- [ ] LINE XX: <quoted original> → <fix> [Rule X.X]
```

Mark `[x]` when applied. Do not delete entries — they serve as audit trail.

---

## PART 9 — QUICK REFERENCE CHECKLISTS

---

### Before Writing a New Section

1. What chapter is this? (BAB II = no results; BAB III = no results; BAB IV = results only)
2. Does this subsection have ≥3 paragraphs worth of content?
3. Does it include a table or figure?
4. Have I named specific models rather than generic terms?
5. Are English terms italicized throughout?

---

### Before Committing to Git

1. Run `pdflatex -interaction=nonstopmode main.tex` twice (longtable needs 2 passes)
2. Check `grep "^!" main.log` — must be empty
3. No "Co-Authored-By: Claude" or any Claude/Anthropic attribution in commit message
4. Stage only Research 4 files — do not stage Research 3 / Research 5 files
5. Push to `thesis-script` via subtree: `git subtree push --prefix "Research 4" thesis-script master`

---

### Terminology Quick Swap

| Wrong | Correct |
|-------|---------|
| Track A / Track B | Pendekatan A / Pendekatan B |
| fungsi kerugian | `\textit{loss function}` |
| Avg QWK (unformatted) | `\textit{Avg}` QWK |
| backbone visual | komponen pengolah gambar / ResNet18/50/152 |
| — (em dash) | rewrite sentence |
| colon before one item | yaitu / yakni / comma |
| di mana (comparative) | dimana |
| di bawah (comparative) | dibawah |
| gap notation in prose | move to $\Delta$ table column |
| bolded RQ answer | natural paragraph without bold |
