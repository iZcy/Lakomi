# Paper Remap Plan — IEEE Conference Version
Created: 2026-05-07
Target: 4–6 pages, IEEEtran two-column

---

## Current State (3 pages)
- Abstract, Intro, Related Work, Methodology (A+B), Results (A+B+Baselines), Conclusion
- Missing: proper Related Work subsections, architecture diagrams, per-trait table, t-test, expanded discussion

---

## Target Structure

### I. Introduction (~350 words)
- Open: IELTS Task 1 AES requires simultaneous text + chart understanding; manual scoring is slow and inconsistent
- EssayJudge (Su et al. 2025): first IELTS multimodal AES benchmark, 1,054 essays, 10 traits; zero-shot Qwen2-VL-7B achieves only QWK ~0.16 — supervised fine-tuning is essential
- Gap: no systematic comparison of supervised fusion strategies on this benchmark
- Two complementary paradigms: (A) multimodal fusion (ResNet + RoBERTa + cross-attention), (B) text-to-text (VLM caption → Dual RoBERTa)
- Contributions:
  1. Systematic ablation of backbone, fusion strategy, loss, and text encoder for Approach A
  2. Query strategy and captioner ablation for Approach B (DualRobertaCrossAttnCls)
  3. Visual-structural caption quality analysis linking chart geometry to captioner accuracy
  4. Statistical significance evaluation and zero-shot MLLM comparison on full EssayJudge

### II. Related Work (~450 words, 3 subsections)

**A. Automated Essay Scoring**
- ProTACT (Do et al. 2023, ACL Findings): cross-prompt multi-trait AES on ASAP, QWK ~0.59 text-only; multi-task head and essay-prompt attention
- AEMS (Sun & Wang 2024, arXiv): RoBERTa multi-dim IELTS scoring QWK >0.84 on 14,500 essays
- Gap: both are text-only, no chart modality; EssayJudge is first chart-grounded AES benchmark

**B. Multimodal Fusion for Text+Image**
- P1 (Pereira et al. IEEE Access 2023): early fusion optimal with large data; late/hybrid better at small scale (~1k samples)
- P3 (Gadzicki et al. IJCNN 2020): early fusion +3.8% over late on 56k-sample activity recognition
- P4 (Kumar et al. ICASSP 2021): hybrid fusion (intermediate+late) effective with insufficient labeled data; text dominates (~47%)
- BRCAF (Gold 2025): BERT+ResNet cross-attention for multimodal sentiment; text MU=97%, image=3% — explains why ResNet adds limited signal

**C. Chart Understanding and Text Representation**
- P14 (Bursztyn et al. IEEE VIS 2024): text representations of charts outperform GPT-4 Vision (99% vs 63%) on visual explanation — motivates T2T approach
- DePlot (Liu et al. ACL 2023): chart→table translation, 67.6% ChartQA human; excels on structured charts
- MATCHA (Liu et al. ACL 2023): chart derendering pretraining; 64.2% ChartQA; better than raw Pix2Struct
- P13 (Nowak et al. NAACL 2024): DePlot+VLM combination is best across chart types; DePlot fails on complex multi-subplot

### III. Methodology (~600 words + 2 TikZ figures)

**A. Dataset and Training Setup**
- EssayJudge: 1,054 IELTS Task 1 essays, 10 traits, 7 chart types (distribution), 70/15/15 split seed=42
- Unified config: AdamW lr=1e-4, dropout=0.3, batch=16, patience=10, multi-task CE head (1536→768→256→10, sigmoid×5.0), avg QWK across 10 traits as metric

**B. Approach A: Multimodal Fusion**
- Figure 1: TikZ diagram of Exp 057 (RoBERTa + ResNet50 + CrossAttn)
- Essay → RoBERTa-base → CLS (768d, query); Chart → ResNet50 → Linear(768d, key/value)
- Cross-attention → concat (1536d) → MLP head → 10 trait scores
- Ablation axes: backbone (ResNet18/50/152), fusion (early/cross/late), loss (CE/MSE), text encoder (BERT/RoBERTa)

**C. Approach B: Text-to-Text**
- Figure 2: TikZ diagram of Exp 161 (DualRobertaCrossAttnCls, CLS-Q, excl bar+pie)
- Chart → Qwen2-VL-7B (≤7B, caption text); Essay → RoBERTa_1 (CLS, query)
- Caption → RoBERTa_2 (all tokens, key/value); cross-attention → concat → MLP → 10 scores
- Three query strategies ablated: CLS, sequence mean, CLS-cap-key
- Captioner selection: Qwen2-VL-7B for low-error types; DePlot+Qwen for bar+pie (54%→23% error)
- Caption quality taxonomy table (5 examples, 3 captioners, Benar/Salah)

### IV. Results and Discussion (~750 words + 4 tables)

**A. Approach A Ablation (Table I — existing)**
- Discuss each design decision: backbone depth, fusion strategy, loss, text encoder

**B. Approach B Ablation (Table II — existing)**
- Query strategy: CLS best (epoch 11 vs 22, QWK 0.5041)
- Exclusion (Exp 161, 0.5802) vs full-data DePlot (Exp 162, 0.5066)
- MATCHA overfitting: val 0.5524 → test 0.4702

**C. Caption Quality Analysis (Table III — 5-image Benar/Salah table)**
- Three visual-structural conditions; explains DePlot advantage and residual error
- Source: manual review of 100 samples per chart type

**D. Statistical Significance (Table IV — NEW from thesis 4.5.2)**
- Paired t-test: Approach A predictions vs human annotations, Approach B vs human
- Interpretation: which traits are statistically significantly aligned; confidence in the 0.5270 vs 0.5802 gap

**E. Comparison with Zero-Shot Baselines (Table V — existing, renumbered)**
- Both approaches vs zero-shot MLLMs; Approach A near GPT-4o; Exp 161 ceiling above GPT-4o

### V. Conclusion (~200 words)
- Summary: fusion ablation → cross-attention best; T2T ceiling (0.5802) > A (0.5270) when caption quality is controlled
- Both surpass all open-source zero-shot MLLMs
- DePlot+Qwen2-VL-7B more reliable than MATCHA (factual accuracy > linguistic fluency)
- Future: improve captioner for bar+pie (sparse gridline case); explore chart-type-specific VLM

---

## Architecture Diagrams (TikZ, single-column width)

### Fig 1 — Exp 057 (Approach A)
- Input nodes: [Essay Text], [Chart Image]
- Encoder nodes: [RoBERTa-base (CLS → Q)], [ResNet50 → Linear (K/V)]
- Process: [Cross-Attention]
- Fusion: [Concat 1536d]
- Output: [MLP Head → 10 Trait Scores]
- Colors: gray=input, blue=encoder, orange=process, green=fusion, red=output

### Fig 2 — Exp 161 (Approach B)
- Input nodes: [Essay Text], [Chart Image]  
- Process: [Qwen2-VL-7B (Caption)]
- Encoder nodes: [RoBERTa_1 (CLS → Q)], [RoBERTa_2 (Tokens → K/V)]
- Process: [Cross-Attention (CLS-Q)]
- Fusion: [Concat 1536d]
- Output: [MLP Head → 10 Trait Scores]
- Dashed box around [Chart Image → Qwen → RoBERTa_2] labeled "T2T Caption Branch"
- Colors: same as Fig 1

---

## Execution Batches

| Batch | Task | Status |
|-------|------|--------|
| 3 | TikZ architecture diagrams | DONE (2026-05-08) |
| 4 | Rewrite Introduction + Related Work | DONE (2026-05-08) |
| 5 | Expand Methodology sections | DONE (2026-05-08) |
| 6 | Expand Results + add t-test section | DONE (2026-05-08) |
| 7 | Compile, verify, fix | DONE (2026-05-08) |

## Final State (2026-05-08)

- Page count: **5 pages** (within 4–6 page target)
- Figures: Fig 1 (Exp 057 TikZ), Fig 2 (Exp 161 TikZ)
- Tables: I (App A ablation), II (App B ablation), III (caption examples), IV (t-test), V (baselines)
- New bib entries: do2023, sun2024, pereira2023, gadzicki2020, kumar2021, nowak2024
- T-test: Exp 048 (A) 2/10 sig; Exp 162 (B) 8/10 sig; Bonferroni α=0.005
- Committed: 6b785c3
