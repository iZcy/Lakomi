# Qwen2-VL-7B Justification Audit

All passages in thesis-main that justify or explain the choice of Qwen2-VL-7B.
**Status**: Needs reframing — hardware constraint reason is now outdated (HPC available).

---

## 1. EssayJudge Benchmark Performance
**File**: `contents/chapter-4/chapter-4.tex` ~line 447–453

> "Pemilihan Qwen2-VL-7B-Instruct sebagai *captioner* utama pada Pendekatan B didasarkan pada evaluasi *zero-shot* [su2025] pada *benchmark* EssayJudge, dimana Qwen2-VL-7B memperoleh *Avg* QWK tertinggi (≈0,16) di antara seluruh VLM *open-source* berukuran ≤7 miliar parameter yang diuji."

**Issue**: References "batasan parameter" — links to GPU constraint. Needs decoupling.

---

## 2. Hardware Constraint: Local GPU (6 GB VRAM)
**File**: `contents/chapter-3/chapter-3.tex` ~line 22

> "Kapasitas VRAM 6 GB tidak mencukupi untuk menjalankan inferensi VLM 7 miliar parameter tanpa teknik kompresi tambahan, sehingga proses pembuatan *caption* menggunakan VLM dialihkan ke lingkungan komputasi awan."

**Issue**: Cites local GPU as bottleneck — still true for local setup, but HPC removes this as a global constraint.

---

## 3. Hardware Constraint: Kaggle P100 (16 GB VRAM)
**File**: `contents/chapter-3/chapter-3.tex` ~line 34

> "Kapasitas VRAM 16 GB memungkinkan penjalanan VLM 7 miliar parameter dalam mode kuantisasi 4-bit NF4 tanpa mengalami kekurangan memori."

**Issue**: Frames 7B as the upper limit of what Kaggle P100 can run. Now incorrect given HPC access.

---

## 4. Performance-Efficiency Trade-off (ChartQA)
**File**: `contents/chapter-2/chapter-2.tex` ~line 826

> "Qwen2-VL-7B menawarkan keseimbangan antara kapasitas dan efisiensi: dengan 7 miliar parameter, model ini mencapai skor ChartQA 83,0 yang signifikan lebih tinggi dari varian 2B (73,5) namun masih dapat dijalankan pada GPU dengan memori 16 GB menggunakan kuantisasi 4-bit, tidak seperti varian 72B yang membutuhkan infrastruktur GPU yang jauh lebih besar."

**Issue**: Still frames 16 GB GPU as the reason for not using 72B. Needs reframing around time/scope constraint instead.

---

## 5. MLLM ≤7B Open-Weight Context
**File**: `contents/chapter-2/chapter-2.tex` ~line 794

> "MLLM dengan ukuran parameter yang relatif kecil, pada umumnya tidak melebihi 7 miliar parameter, telah menunjukkan kemampuan yang mumpuni... Dengan teknik kuantisasi 4-bit, model berukuran 7 miliar parameter dapat dijalankan pada GPU dengan memori 16 GB, membuka akses penggunaan MLLM pada perangkat keras yang terjangkau."

**Issue**: Frames 7B as a "standard GPU" limit — needs adjustment.

---

## 6. Explicit GPU Limitation (Keterbatasan)
**File**: `contents/chapter-4/chapter-4.tex` ~line 1144 (Keterbatasan Penelitian)

> "Model VLM dengan lebih dari 7 miliar parameter tidak dievaluasi akibat keterbatasan GPU; belum dapat dipastikan apakah model yang jauh lebih besar akan menghasilkan *caption* yang lebih berguna untuk penilaian hilir."

**Issue**: Directly states GPU as reason for ≤7B limit — must be updated.

---

## 7. Chapter 1 — Latar Belakang
**File**: `contents/chapter-1/chapter-1.tex` ~line 33–35

> "Hasil evaluasi menunjukkan bahwa model MLLM *open-source* Qwen2-VL-7B, dengan 7 miliar parameter, hanya mampu mencapai rata-rata QWK sekitar 0,16 dalam skenario *zero-shot*."

**Issue**: Contextual mention only, not a direct justification. Low priority.

---

## 8. Chapter 1 — Batasan Penelitian
**File**: `contents/chapter-1/chapter-1.tex` ~line 130–132

> "Model VLM yang digunakan adalah Qwen2-VL-7B-Instruct, yaitu model *open-source* berukuran 7 miliar parameter yang digunakan sebagai *baseline* oleh [su2025]."

**Issue**: Correctly ties choice to su2025 baseline without GPU constraint — keep as-is.

---

## 9. Chapter 5 (or 6) — Saran
**File**: `contents/chapter-5/chapter-5.tex` (if present) or chapter-6

> "Mengeksplorasi VLM berukuran lebih besar dari 7 miliar parameter sebagai *captioner*, mengingat batas 7 miliar parameter dalam penelitian ini disebabkan oleh keterbatasan GPU..."

**Issue**: Directly attributes 7B limit to GPU — remove or reframe.

---

## Proposed New Justification Frame

Replace GPU-constraint framing with **two independent reasons**:

1. **Benchmark alignment**: su2025 evaluated Qwen2-VL-7B as the top-performing open-source VLM ≤7B on EssayJudge zero-shot. Using the same model enables direct comparison with their baseline.
2. **Scope constraint**: Evaluating larger VLMs (>7B) is beyond the scope of this thesis, which focuses on comparing fusion strategies and T2T architectures — not VLM scale. The 7B size represents the best-performing model in the class benchmarked by the dataset authors.

The HPC availability note can be acknowledged in **Saran** as enabling future work with larger models, rather than being used to justify why 7B was chosen.

---

## Priority Order for Edits

| # | Location | Urgency |
|---|----------|---------|
| 1 | ch4 Keterbatasan (~line 1144) | HIGH — explicitly wrong |
| 2 | ch4 RQ3 captioner justification (~line 447) | HIGH — links selection to GPU |
| 3 | ch2 Qwen2-VL section (~line 826) | MEDIUM — ChartQA trade-off framing |
| 4 | ch3 hardware sections (~line 22, 34) | MEDIUM — factual, but context changed |
| 5 | ch2 MLLM intro (~line 794) | LOW — general background, minor tweak |
| 6 | ch5/ch6 Saran | LOW — reframe as future work |
| 7 | ch1 Latar Belakang | KEEP — just context, no fix needed |
| 8 | ch1 Batasan | KEEP — already correctly framed |
