# Revision Plan: Chapter 3.2 (v2)
# Status: EXECUTED — completed 2026-05-02
# Created: 2026-05-02

## Summary of Changes Requested

### 3.2.1 — Pra-pemrosesan Data
- ADD: image download step — dataset stores URLs (e.g. raw GitHub PNG URLs), so
  images must be fetched/downloaded and converted to PNG before resizing/normalizing
- Table tab:preprocessing: add explicit row borders so each row is clearly separated
  (use \hline between every row, not just header/footer)

### 3.2.2 — Ekstraksi Fitur
- REMOVE differentiation by Pendekatan A vs B (no "A (Exp033)" style rows)
- Just list each encoder used once, without doubles
- Don't split into approach-specific groups yet — that comes in 3.2.3

### 3.2.3 — Arsitektur Model
- Change structure: instead of step-by-step ablation narrative, explain per experiment ID
- For each experiment, use a config table with rows:
  - Encoder (text, image/caption)
  - Dropout
  - Loss function
  - Learning rate
  - Freeze strategy
  - Batch size
  - Fusion method
  - etc.
- Experiments covered: **046, 047, 048, 049, 050, 055, 056, 057**
- These are all Pendekatan A (ResNet + BERT/RoBERTa fusion)
- Still explain Pendekatan A and B as two approaches, but per-experiment detail

### 3.2.4 — Metode Pelatihan (rename from "Pelatihan Multi-task")
- Rename section title to reflect training methodology broadly
- Explain: there are two training paradigms — multi-task (all 10 traits jointly) and
  per-trait (separate model per trait)
- Explain WHY multi-task was chosen (signal amplification, shared encoder regularization)
- Same per-experiment config table format as 3.2.3
- Experiments covered: **158, 159, 160, 161, 162, 163, 164**
- These are Pendekatan B (DualRobertaCrossAttnCls)

### 3.2.5 — Pipeline Captioning
- Table tab:pipeline-captioning: restructure as:
  - COLUMNS: Qwen2-VL-7B | DePlot + Qwen2-VL-7B | MATCHA
  - ROWS: experiment IDs (e.g. 081/093, 103, 158, 161, 162, 163, 164)
  - Cell content: which chart types use that captioner for that experiment

### 3.2.6 — Evaluasi dan Uji Statistik
- Split into two numbered sub-subsections:
  - **3.2.6.1 Quadratic Weighted Kappa (QWK)** — metric formula, 11-level scale, rounding
  - **3.2.6.2 Uji Paired T-Test** — t-test per trait vs ground truth, Bonferroni α=0.005

---

## Execution Order
1. Save this plan (done)
2. Read current chapter-3.tex → save analysis to ch3_analysis.md
3. Execute 3.2.1 → check analysis
4. Execute 3.2.2 → check analysis
5. Execute 3.2.3 → check analysis
6. Execute 3.2.4 → check analysis
7. Execute 3.2.5 → check analysis
8. Execute 3.2.6 → check analysis
9. Rebuild PDF and verify

---

## Experiments Reference

### Pendekatan A (3.2.3): 046–057
| Exp | Config difference |
|-----|-----------------|
| 046 | BRCAF replication: BERT + dual ResNet (ResNet152/ImageNet + ResNet50/Places365) + CrossAttn + CE |
| 047 | BERT + ResNet18 (single) + CrossAttn + CE |
| 048 | BERT + ResNet50 (single) + CrossAttn + CE |
| 049 | BERT + ResNet152 (single) + CrossAttn + CE |
| 050 | BERT + ResNet50 + CrossAttn + MSE (regression comparison) |
| 055 | BERT + ResNet50 + Early fusion + CE |
| 056 | BERT + ResNet50 + Late fusion + CE |
| 057 | RoBERTa + ResNet50 + CrossAttn + CE ← BEST Pend. A |

### Pendekatan B (3.2.4): 158–164
| Exp | Config difference |
|-----|-----------------|
| 158 | DualRobertaCrossAttnCls, CLS query, Qwen7B full 1054 |
| 159 | DualRobertaCrossAttnCls, Sequential query (full essay tokens), Qwen7B full 1054 |
| 160 | DualRobertaCrossAttnCls, CLS-cap-key query variant, Qwen7B full 1054 |
| 161 | DualRobertaCrossAttnCls, CLS query, Qwen7B excl bar+pie (772 samples) ← BEST OVERALL |
| 162 | DualRobertaCrossAttnCls, CLS query, DePlot+Qwen7B full 1054 |
| 163 | DualRobertaCrossAttnCls, CLS query, Qwen7B excl bar+pie+composite (665 samples) |
| 164 | DualRobertaCrossAttnCls, CLS query, MATCHA+Qwen7B full 1054 |

### Shared new config (046–057, 158–164)
- Optimizer: AdamW, lr=2e-5, weight_decay=0.01
- Batch: 4 + gradient accumulation ×8 = 32 effective
- Freeze: None (all 12 transformer layers trainable)
- Dropout: 0.5
- Loss: CE 11-class (per trait, 11 classes)
- Scheduler: linear warmup + linear decay, 200 warmup steps
- Max epochs: 30, patience: 10, seed: 42
- Head: 1536 → 768 → 256 → 110, reshape [B,10,11]

### Old config (030–033, 081–103)
- Optimizer: AdamW, lr=1e-4, weight_decay=0.01
- Batch: 16
- Freeze: 6/12 transformer layers
- Loss: MSE (regression)
- Head: 1536 → 768 → 256 → 10, Sigmoid × 5.0
