# Rewrite Plan: Chapter 3.2 (Metode yang Digunakan)
# Status: EXECUTED — completed 2026-05-02
# Created: 2026-05-02

## Intent
Move ALL architecture overview, configs, and experiment setups from Chapter 4 into Chapter 3.2,
so Chapter 4 becomes results + analysis only.

Chapter 3.2 subsections to rewrite:
- 3.2.1 Pra-pemrosesan Data
- 3.2.2 Ekstraksi Fitur
- 3.2.3 Arsitektur Model (major rewrite — Pendekatan A narrative + Pendekatan B narrative)
- 3.2.4 Pelatihan Multi-task (describe TWO configs: old and new)
- 3.2.5 Pipeline Captioning (minor updates)
- 3.2.6 Evaluasi dan Uji Statistik (fix paired t-test description)

---

## 3.2.1 — Pra-pemrosesan Data

### Change A
Line 172: "arsitektur ResNet18 yang dilatih pada ImageNet"
→ "arsitektur ResNet yang dilatih pada ImageNet"
Reason: ResNet18, ResNet50, ResNet152 all use same 224×224 input — don't hardcode version.

### Change B
Label normalization paragraph (lines 182–184): currently says s' = s/5.0 → [0,1] for Sigmoid.
Split into two schemes:
- MSE/regression (Exp032–039, Exp081–103): s' = s/5.0 → [0,1], Sigmoid × 5.0 output
- CE/classification (Exp046–057, Exp158–164): s_idx = round(s / 0.5) → integer class 0–10, CE loss 11 classes

### Change C
Table tab:preprocessing: add second label preprocessing row for CE scheme.
Current row: "Label skor | Normalisasi | s' = s/5,0 | s' ∈ [0, 1]"
Add row: "Label skor (CE) | Konversi kelas | s_idx = round(s/0,5) | s_idx ∈ {0,...,10}"

---

## 3.2.2 — Ekstraksi Fitur

### Change D
Opening paragraph line 212: "jalur gambar menggunakan ResNet18 dan jalur teks menggunakan RoBERTa-base"
→ Mention all encoder options:
  - Image: ResNet18 (old baseline), ResNet50, ResNet152, dan dual ResNet50+ResNet152 (BRCAF replication)
  - Text: BERT-base-uncased (baseline), RoBERTa-base (best)
  - Approach B: image encoder replaced by second RoBERTa processing caption text

### Change E
Image encoder paragraph (lines 215–221): currently only describes ResNet18 (512d, fully frozen).
Add ResNet50 and ResNet152 description:
- ResNet18: removes FC layer → 512d vector, fully frozen in old config
- ResNet50 / ResNet152: removes FC layer → 2048d vector, projected to 768d via learnable linear layer, NOT frozen in new config (Exp046–057)
Also note: dual ResNet (BRCAF replication, Exp046) used ResNet152/ImageNet + ResNet50/Places365 simultaneously.

### Change F (verify)
Table tab:feature-dims — already has rows for:
  A (Exp 033): ResNet18, frozen, 512 ✓
  A (Exp 057): ResNet50, no freeze, 2048→768 ✓
  B (Exp 081–103): caption encoder + essay encoder, both RoBERTa, freeze 6 ✓
  B (Exp 158–164): both RoBERTa, no freeze ✓
→ ADD row for A (Exp 046): dual ResNet (ResNet152+ResNet50), no freeze, 2048d each → projected 768d

---

## 3.2.3 — Arsitektur Model

### MAJOR REWRITE — structure into two clear narrative blocks

#### PENDEKATAN A — Sequential ablation narrative:

**Step 1: BRCAF Replication (Exp046)**
- Paper anchor: Gold et al. (2025) BRCAF — BERT + ResNet152/ImageNet + ResNet50/Places365 + CrossAttn + CE 11-class
- Replicate on EssayJudge → Exp046: test QWK = 0.4839
- Purpose: establishes whether BRCAF architecture works on this dataset

**Step 2: Single ResNet Ablation (Exp047–049)**
- Hypothesis: dual ResNet (198M params) may overfit 737 training samples
- Test: ResNet18 (Exp047 = 0.5070), ResNet50 (Exp048 = 0.5134★), ResNet152 (Exp049 = 0.5081)
- Result: R* = ResNet50 (single encoder, better than dual)

**Step 3: Loss Function Comparison (Exp048 CE vs Exp050 MSE)**
- Exp048: BERT + ResNet50 + CrossAttn + CE = 0.5134
- Exp050: BERT + ResNet50 + CrossAttn + MSE ≈ 0.490 (avg 2 runs)
- Result: CE confirmed as better loss function; regression dropped

**Step 4: Fusion Strategy Ablation (Exp055/048/056)**
All use BERT + ResNet50 + CE
- Exp055 (Early fusion): test = 0.4716
- Exp048 (Cross-Attention / intermediate): test = 0.5134 ★
- Exp056 (Late fusion): test ≈ 0.480 (avg 2 runs)
- Result: F* = Cross-Attention (Exp048)

**Step 5: Text Encoder Comparison (Exp048 vs Exp057)**
- Exp048: BERT + ResNet50 + CrossAttn + CE = 0.5134
- Exp057: RoBERTa + ResNet50 + CrossAttn + CE = 0.5270 ★
- Result: RoBERTa +0.0136 over BERT → Exp057 = Best Pendekatan A

#### PENDEKATAN B — T2T narrative:

**Step 1: Replace ResNet with second RoBERTa**
- Adopt best config from Pendekatan A (CrossAttn, CE, lr=2e-5, no freeze, seed=42)
- Replace ResNet image encoder with second RoBERTa processing Qwen2-VL-7B caption text
- Architecture: DualRobertaCrossAttnCls — essay [CLS] as query → caption token sequence H_cap as key/value
- Exp158 (CLS query, Qwen7B full 1054): test = 0.5041

**Step 2: Caption Quality Error Analysis**
- 100 random samples manually reviewed
- bar chart: 54% factual error rate
- pie chart: 67% factual error rate
- Other types (flow chart, table, line chart, etc.): <10% error
- Motivation: these two chart types may be dragging down overall performance

**Step 3: Exclusion Strategy**
- Exclude bar+pie (282 samples removed → 772 remaining)
  - Exp161 (CrossAttn CLS, Qwen7B, excl bar+pie, seeded): test = 0.5802 ★ BEST OVERALL
  - Big improvement — confirms bar/pie captions were hurting the model

- Exclude bar+pie+composite (389 samples removed → 665 remaining)
  - Exp163 (CrossAttn CLS, excl bar+pie+composite): test = 0.5105
  - Marginal improvement over full-data, not much better → composite exclusion not pursued

**Step 4: Specialised Captioner for bar+pie**
- Since exclusion improves but reduces training data, try better captioners instead
- MATCHA (Exp164, full 1054, MATCHA+Qwen7B): test = 0.4702 → WORSE
- DePlot+Qwen7B (Exp162, full 1054): test = 0.5066 ★ Best full-data T2T
- Result: DePlot wins over MATCHA for bar+pie captioning
- Note: Exp161 (excl) still best overall but uses smaller dataset (772 vs 1054)

#### Tables to UPDATE in 3.2.3:
- tab:arsitektur-ringkasan: 
  - Row "Image encoder": "ResNet18 (512d)" → "ResNet50 (2048d → 768d via linear proj.)"
  - Row "Aktivasi keluaran" for Pend.B: "Sigmoid × 5,0" → "Softmax (CE 11-kelas)" for CrossAttn arch
- tab:arsitektur-crossattn: already describes CrossAttn correctly ✓

#### Figure captions to UPDATE in 3.2.3:
- Line 284: "ResNet18 (512d diproyeksikan ke 768d)" → "ResNet50 (2.048d diproyeksikan ke 768d)"
  (The figure fig:arsitektur-a should show the BEST config = ResNet50)

---

## 3.2.4 — Pelatihan Multi-task

### MAJOR REWRITE — describe both configs explicitly

#### Konfigurasi Lama (Exp032–039, Exp081–103):
- Loss: MSE → sum of 10 per-trait MSE losses
- Optimizer: AdamW, lr = 1e-4, weight_decay = 0.01
- Batch size: 16
- Freeze: 6 of 12 transformer layers (embedding + layers 0–5)
- Max epochs: 30, patience: 10
- Seed: 42 (for seeded variants 081, 093, 103)
- Scheduler: linear warmup + linear decay, 200 warmup steps

#### Konfigurasi Baru (Exp046–057, Exp158–164):
- Loss: CE (cross-entropy) 11-class per trait, averaged over 10 traits
  Output head: 1536 → 768 → 256 → 110, reshape to [B, 10, 11]
- Optimizer: AdamW, lr = 2e-5, weight_decay = 0.01
- Batch size: 4 + gradient accumulation ×8 = effective batch 32
- Freeze: NONE (no freeze, all 12 layers trainable)
- Max epochs: 30, patience: 10
- Seed: 42 (all experiments in this series)
- Scheduler: linear warmup + linear decay, 200 warmup steps

### Change to hyperparameter table (tab:hyperparameters):
Add second column for new config, or split into two separate tables.
Key diffs:
| Param           | Old config         | New config                    |
|-----------------|--------------------|-------------------------------|
| Loss function   | MSE (regression)   | CE 11-class (classification)  |
| Learning rate   | 1e-4               | 2e-5                          |
| Batch size      | 16                 | 4 + accum×8 = 32 eff.         |
| Freeze          | 6/12 layers        | None                          |
| Output          | Sigmoid × 5.0      | Softmax, argmax → 0.0–5.0     |

### Loss equation update:
Currently shows only MSE equation. Add CE equation:
L = (1/10) * sum_{k=1}^{10} CE(y_hat_k, y_k)
where y_k ∈ {0,1,...,10} is the class index for trait k.

---

## 3.2.5 — Pipeline Captioning

### Minor changes:
- Keep the description of DePlot+Qwen7B hybrid pipeline for bar+pie ✓
- Keep the MATCHA description ✓
- Remove PaliGemma if it's no longer relevant (Exp021 failed — can mention briefly or omit)
- Update captioner selection to reference Exp162 (DePlot full 1054 = 0.5066) and Exp164 (MATCHA = 0.4702)
- Note that bar+pie exclusion result (Exp161 = 0.5802) is also discussed as alternative strategy

---

## 3.2.6 — Evaluasi dan Uji Statistik

### Change L
Lines 561–568: "paired t-test dua arah pada nilai QWK per trait antara dua sistem yang dibandingkan"
→ Rewrite: paired t-test compares each approach's predictions against human annotation (ground truth),
  not a head-to-head system-vs-system comparison.
This aligns with the RQ5 fix already made in Chapter 2.

---

## What moves FROM Chapter 4 TO Chapter 3.2

The following items are currently in Chapter 4 but should move to Chapter 3.2:

FROM ch4 section 4.2 (RQ1 setup):
- Table tab:rq1-shared-config (shared config Exp030–032) → goes into 3.2.4 or 3.2.3
- Architecture figure sub-descriptions for early/intermediate/late → 3.2.3
- Spec tables (tab:exp032-spec, tab:exp033-spec) → 3.2.3 or 3.2.2

FROM ch4 section 4.3 (RQ2 setup):
- Spec tables for BERT and RoBERTa → 3.2.2

FROM ch4 section 4.4 (RQ3 setup):
- Table tab:exp081-spec (T2T baseline spec) → 3.2.4 or 3.2.3
- Table tab:approach-comparison → 3.2.3
- Figure fig:t2t-overview (T2T architecture) → 3.2.3

What STAYS in Chapter 4:
- All per-trait QWK result tables
- All comparison tables (e.g., tab:fusion-comparison-exp, tab:bert-roberta-comparison)
- All analysis paragraphs ("RoBERTa mengungguli BERT...", "late fusion adalah strategi optimal...")
- "Jawaban RQ1/RQ2/..." paragraphs
- Master results table (tab:master-results)
- Data splits table (tab:data-splits)
- Overview paragraphs about zero-shot baseline

---

## Execution Order (when ready to edit)

1. Rewrite 3.2.1 (Changes A, B, C) — straightforward text + table edits
2. Rewrite 3.2.2 (Changes D, E, F) — expand image encoder paragraph, update opening
3. Rewrite 3.2.3 — LARGE rewrite: new Pendekatan A ablation narrative + Pendekatan B narrative
4. Rewrite 3.2.4 — add second config, update equations and tables
5. Minor fixes 3.2.5 (captioner updates)
6. Fix 3.2.6 (paired t-test description)
7. Move setup tables/figures from ch4 into ch3.2 (or simply add cross-references)
8. Strip setup content from ch4 (leave only results + analysis)
9. Rebuild PDF and verify
