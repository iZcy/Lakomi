# Tables Index — All Longtable Specs
Last updated: 2026-05-04
TextWidth = 14.92cm ≈ 423pt. Each column gets 2×tabcolsep (default 6pt=12pt) padding. Each `|` border ≈ 0.4pt.
Overhead formula: N_cols×12pt + (N_cols+1)×0.4pt. Content must fit in 423pt - overhead.

**Status key:** ✅ OK | ⚠️ overflow (Xpt) | 🔧 fixed this session

---

## Chapter 2

| Line | Label | Column Spec | Status |
|------|-------|-------------|--------|
| 41 | tab:tinjauan-pustaka | `{|p{2.5cm}|p{3cm}|p{4.5cm}|p{3cm}|}` | ✅ |
| 88 | tab:evolusi-aes | `{|p{3.5cm}|p{5cm}|p{4cm}|}` | ✅ |
| 117 | tab:modalitas | `{|p{2cm}|p{3cm}|p{4cm}|p{4cm}|}` | ✅ |
| 147 | tab:fusion-comparison | `{|p{2.3cm}|p{3.5cm}|p{3.5cm}|p{3cm}|}` | ✅ |
| 235 | tab:unimodal-vs-multimoda | `{|p{3cm}|p{4.5cm}|p{4.5cm}|}` | ✅ |
| 273 | tab:aktivasi | `{|p{2cm}|p{4cm}|p{2.5cm}|p{4cm}|}` | ✅ |
| 321 | tab:regularisasi | `{|p{2.5cm}|p{6cm}|p{3.5cm}|}` | ✅ |
| 351 | tab:adam-comparison | `{|p{3cm}|p{5cm}|p{5cm}|}` | ✅ |
| 383 | tab:transfer-strategies | `{|p{2.5cm}|p{5cm}|p{4.5cm}|}` | ✅ |
| 430 | tab:tokenisasi | `{|p{3cm}|p{4cm}|p{5cm}|}` | ✅ |
| 464 | tab:transformer-components | `{|p{3.5cm}|p{5cm}|p{3.5cm}|}` | ✅ |
| 512 | tab:jenis-attention | `{|p{2.5cm}|p{2.5cm}|p{2.5cm}|p{4cm}|}` | ✅ |
| 553 | tab:bert-arch | `{|l|l|l|}` | ✅ (content narrow) |
| 596 | tab:bert-roberta | `{|p{3cm}|p{5cm}|p{4cm}|}` | ✅ |
| 645 | tab:cnn-komponen | `{|p{2.5cm}|p{4cm}|p{5cm}|}` | ✅ |
| 686 | tab:resnet-variants | `{|l|l|l|l|}` | ✅ (content narrow) |
| 727 | tab:vit-variants | `{|l|l|l|l|l|}` | ✅ (content narrow) |
| 759 | tab:pix2struct-perbandingan | `{|p{2.5cm}|p{3.5cm}|p{3.5cm}|p{3cm}|}` | ✅ |
| 793 | tab:kuantisasi | `{|p{2cm}|p{0.8cm}|p{2cm}|p{2cm}|p{4cm}|}` | ✅ |
| 845 | tab:qwen2vl-variants | `{|l|l|l|l|l|}` | ✅ (content narrow) |
| 877 | tab:deplot-kemampuan | `{|p{2.5cm}|p{5cm}|p{4cm}|}` | ✅ |
| 911 | tab:deplot-matcha | `{|p{3cm}|p{5cm}|p{4cm}|}` | ✅ |
| 1027 | tab:perbandingan-metode | `{|p{2.2cm}|p{3.0cm}|p{3.8cm}|p{3.5cm}|}` | ✅ |

---

## Chapter 3

| Line | Label | Column Spec | Status | Notes |
|------|-------|-------------|--------|-------|
| 48 | tab:software | `{|c|l|l|p{5cm}|}` | ✅ | |
| 101 | tab:essayjudge-sample | `{|c|p{1.5cm}|p{3cm}|c|c|c|c|c|c|c|c|c|c|}` | 🔧 still ⚠️ 85pt | wrapped in `\begingroup\small\tabcolsep=3pt` |
| 142 | tab:trait-descriptions | `{|c|l|p{4cm}|p{5.5cm}|}` | ✅ | |
| 229 | tab:preprocessing | `{|p{2.5cm}|p{3.5cm}|p{2.5cm}|p{3cm}|}` | 🔧 need verify | was `{|l|l|p{3.5cm}|l|}` |
| 292 | tab:feature-dims | `{|p{2.5cm}|p{4.5cm}|p{2.5cm}|p{3.5cm}|}` | 🔧 still ⚠️ 369pt | was `{|l|l|c|l|}` — still failing |
| 335 | tab:arsitektur-ringkasan | `{|p{3cm}|p{5cm}|p{5cm}|}` | 🔧 still ⚠️ 36pt | was `{|l|l|l|}` — still failing |
| 395–816 | tab:exp046–057-config (×8) | `{|l|l|}` | ✅ (content fits) | |
| 901 | tab:arsitektur-crossattn | `{|l|p{8cm}|}` | ✅ | |
| 955–1214 | tab:exp158–163-config (×5) | `{|l|l|}` | ✅ (content fits) | |
| 1279 | tab:exp164-config | `{|p{4cm}|p{9cm}|}` | 🔧 still ⚠️ 40pt | was `{|l|l|}` — WORSE after fix |
| 1343 | tab:exp162-config | `{|l|l|}` | ✅ (content fits) | |
| 1450 | tab:hyperparameters | `{|p{2cm}|p{3cm}|p{2.8cm}|p{2.8cm}|}` | ✅ | |
| 1496 | tab:exp-pend-b | `{|c|p{3cm}|p{4.5cm}|>{\centering}p{2cm}|>{\centering}p{2cm}|}` | ✅ | was `{|c|l|l|c|c|}` |
| 1574 | tab:pipeline-captioning | `{|c|p{3.8cm}|p{3.2cm}|p{1.8cm}|}` | ✅ | |
| 1783 | tab:alur-eksperimen | `{|c|p{3.5cm}|p{3cm}|c|p{3.5cm}|}` | ✅ | |

---

## Chapter 4

| Line | Label | Column Spec | Status | Notes |
|------|-------|-------------|--------|-------|
| 32 | tab:exp046-results | `{|l|c|}` | ✅ | |
| 90 | tab:backbone-comparison | `{|l|c|c|c|}` | ✅ | |
| 148 | tab:ce-vs-mse | `{|l|c|c|c|}` | ✅ | |
| 207 | tab:fusion-comparison-rq1 | `{|l|c|c|c|}` | ✅ | |
| 265 | tab:rq1-progression | `{|c|p{2cm}|p{5.5cm}|r|r|}` | ✅ | |
| 337 | tab:exp057-results | `{|l|c|}` | ✅ | |
| 384 | tab:bert-roberta-comparison | `{|l|c|c|c|}` | ✅ | |
| 461 | tab:exp081-spec | `{|l|p{8.5cm}|}` | ✅ | |
| 483 | tab:exp081-results | `{|l|c|}` | ✅ | |
| 537 | tab:caption-error-rates | `{|l|r|r|}` | ✅ | |
| 584 | tab:exp092-config | `{|l|l|}` | ✅ | |
| 610 | tab:exp092-results | `{|l|c|}` | ✅ | |
| 659 | tab:exp093-config | `{|l|l|}` | ✅ | |
| 687 | tab:exp093-results | `{|l|c|}` | ✅ | |
| 740 | tab:approacha-vs-b | `{|l|c|c|c|}` | ✅ | |
| 823 | tab:crossattn-query-comparison | `{|c|l|c|c|c|}` | ✅ | |
| 867 | tab:crossattn-excl-comparison | `{|c|p{5cm}|c|c|}` | ✅ | |
| 906 | tab:exp161-results | `{|l|c|c|}` | ✅ | |
| 983 | tab:exp103-spec | `{|l|l|}` | ✅ | |
| 1007 | tab:exp103-results | `{|l|c|}` | ✅ | |
| 1056 | tab:captioner-error-rates | `{|l|r|r|r|}` | ✅ | |
| 1113 | tab:deplot-matcha-crossattn | `{|c|l|c|c|}` | ✅ | |
| 1148 | tab:rq4-summary | `{|c|l|l|r|}` | ✅ | |
| 1207 | tab:stat-048 | `{|l|c|c|c|c|l|}` | ✅ | |
| 1245 | tab:stat-162 | `{|l|c|c|c|c|l|}` | ✅ | |
| 1325 | tab:master-results | `{|c|c|p{5cm}|p{2.5cm}|r|}` | ✅ | |
| 1380 | tab:comparison-prior | `{|l|l|l|r|}` | ✅ | |
| 1428 | tab:literature-confirmation | `{|p{4.5cm}|p{2.5cm}|p{4cm}|p{2cm}|}` | ✅ | |

---

## Still Overflowing (needs fix)

| Table | Current Spec | Overflow | Root cause |
|-------|-------------|----------|------------|
| tab:essayjudge-sample (ch3:101) | `{|c|p{1.5cm}|p{3cm}|c×10|}` + `\small\tabcolsep=3pt` | 85pt | `c` cols auto-size to header width; need explicit `p{}` for trait cols |
| tab:feature-dims (ch3:292) | `{|p{2.5cm}|p{4.5cm}|p{2.5cm}|p{3.5cm}|}` | 369pt | Total 13cm + overhead > 14.92cm — BUG: sum is 13cm = 368.5pt, overhead = 50pt → 418pt < 423pt; should be OK — recheck if edit took |
| tab:arsitektur-ringkasan (ch3:335) | `{|p{3cm}|p{5cm}|p{5cm}|}` | 36pt | Total 13cm + overhead ≈ 406pt < 423pt — should be OK — recheck |
| tab:exp164-config (ch3:1279) | `{|p{4cm}|p{9cm}|}` | 40pt | 13cm + 26pt = 394pt < 423pt — should be OK but got WORSE; check if edit applied to wrong table |
| tab:exp-pend-b (ch3:1496) | `{|c|p{3cm}|p{6.5cm}|c|c|}` | 28pt | Check if edit applied correctly |

---

## Diagnosis Notes
- `p{}` columns are FIXED width and cannot overflow sideways — if overflow persists after switching to `p{}`, the edit likely didn't apply to the right table, or the line numbers shifted after prior edits.
- Line numbers in ch3 shifted by +3 after adding `\begingroup`/`\endgroup` for tab:essayjudge-sample.
- The `c` columns in tab:essayjudge-sample are set by widest content (the header `\textbf{AC}` etc.), not by explicit width — replace with `>{\centering\arraybackslash}p{0.7cm}` or wrap headers in `\makebox`.
- tab:feature-dims and tab:arsitektur-ringkasan: both show correct p{} specs now but still overflow in log — likely the log is from the FIRST compile pass (before longtable resolves refs). Need a SECOND pass to confirm.
