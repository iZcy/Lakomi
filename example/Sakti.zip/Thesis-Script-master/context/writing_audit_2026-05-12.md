# Writing Rules Audit — 2026-05-12

All chapters audited against `context/writing_rules.md`.

---

## Rule 2 — Semicolons (7 found, all fixed)

| File | Line | Old text | Fix |
|---|---|---|---|
| ch1 | 150 | `pada model VLM; seluruh` | `. Seluruh` |
| ch2 | 35 | `yang terdefinisi; jenis visual` | `. Jenis visual` |
| ch2 | 836 | `antar jenis grafik; \textit{bar chart}` | `. \textit{Bar chart}` |
| ch2 | 866 | `Subbab~\ref{subsec:deplot}; kedua,` | `. Kedua,` |
| ch3 | 1632 | `dari Pendekatan A; perbedaannya` | `. Perbedaannya` |
| ch4 | 965 | `kategori yang benar;` | `yang benar.` |
| ch4 | 1498 | `antar jenis grafik;` (in `\item`) | `. Eksklusi` |

## Rule 2 — Em dash: none found

## Rule 2 — Colon before single item: none found

## Rule 3 — Non-italicized English terms: none found

## Rule 4 — Track A/B: none found

---

## Consistency check — PASSED

- All QWK values in prose match tables. Note: Exp046 = 0,4839 (my checklist had a typo 0.4939 — thesis is correct).
- No Exp159/160 references in any compiled chapter (ch1–ch5, appendix).
- chapter-6.tex has stale 159/160 references but is NOT included in the build (main.tex includes only chapters 1–5).
- All cross-references valid. `tab:crossattn-query-comparison` is live with Exp158 row.
- No captioner description inconsistencies found.
- No flow gaps from Exp159/160 removal in compiled chapters.
