# Thesis Writing Rules
> Applies to all BAB writing going forward (BAB II onwards). Do not deviate without explicit user approval.

---

## Rule 1 — Depth and Length

Every subsection must have a **minimum of 3 paragraphs**, unless the topic is genuinely elementary (e.g., a definition that has only one meaningful thing to say). For any topic that has theory, history, mechanism, and application — all four must be addressed. Surface-level summaries are not acceptable.

---

## Rule 2 — No Em Dash, Colon Only Before Lists

- **Em dash (—) is forbidden** in all body text.
- **Colon (:) is only allowed** when introducing a list of 2 or more explicit items (e.g., "terdapat dua pendekatan: Pendekatan A dan Pendekatan B"). Never use a colon to introduce a single concept, explanation, finding, or continuation of a sentence. Rewrite with "yaitu", "yakni", "bahwa", or a comma instead.

---

## Rule 3 — English Terms Must Be Italic

All English-language technical terms appearing in Indonesian prose must be italicized.

Examples:
- *encoder*, *decoder*, *pipeline*, *caption*, *benchmark*, *fine-tuning*, *pre-training*, *dropout*, *batch size*, *learning rate*, *epoch*, *checkpoint*, *inference*, *transfer learning*, *reasoning*, *zero-shot*, *downstream*, *early fusion*, *late fusion*, *intermediate fusion*, *text-to-text*, *scoring head*, *feature map*, *feature vector*, *embedding*, *pooling*, *backbone*, *overfitting*, *regularization*, *self-supervised*, *cross-attention*, *plot-to-table*, *end-to-end*

This applies in the Google Docs script (ITALIC_TERMS list) AND in the LaTeX file (\textit{}).

---

## Rule 4 — Track A / Track B → Pendekatan A / Pendekatan B

**Do not use "Track A" or "Track B" in thesis writing.** Use:
- **Pendekatan A** — for the multimodal fusion approach (ResNet18 + RoBERTa)
- **Pendekatan B** — for the text-to-text approach (VLM caption + Dual RoBERTa)

This applies in all chapter writing (BAB II, III, IV, V). The Python scripts (experiments.json, etc.) may keep "Track A/B" for internal reference.

---

## Rule 5 — Media Requirement

Every subsection must include **at least one** of the following:
- **Image/Foto**: find an existing published figure (from the paper being cited). Reference with proper caption.
- **Table**: generate an actual table (not Markdown pipe format — use proper Google Docs table API requests or LaTeX tabular). Examples: comparison tables, architecture parameter tables, results summaries.
- **Diagram**: generate the diagram first (using matplotlib or TikZ), save as PNG, then reference it in the text with a proper caption.
- **Chart**: data visualization (bar chart, line chart, etc.) if quantitative comparison is being made.

**For Google Docs drafts**: tables must be built using the `insertTable` + `insertText` API approach, not embedded as text. Diagrams must be generated as PNG files first. Images from papers must be described precisely with caption noting the source.

**For LaTeX**: use `\begin{table}`, `\begin{figure}` with `\includegraphics`. No Markdown tables.

---

## Rule 6 — Citation Priority

**Always prioritize the most recent papers first.** When explaining a concept:
1. Cite the original/seminal paper (for attribution)
2. Cite the most recent paper that uses or extends it in a way relevant to this research

If a newer paper contradicts or supersedes an older finding — cite the newer one and note the difference. Never cite outdated findings without acknowledging more recent evidence.

Preferred citation format in prose: `Author et al. (year)` inline, e.g., "Vaswani et al. (2017) menunjukkan bahwa..."

---

## Media Generation Reference

| Type | Tool | Output location |
|------|------|----------------|
| Architecture diagrams | `thesis_latex/diagrams/gen_*.py` (matplotlib) | `thesis_latex/contents/chapter-X/figures/` |
| Flowcharts | `thesis_latex/diagrams/gen_*.py` (matplotlib) | same |
| Data tables | Google Docs API `insertTable` request in write_babX.py | inline in doc |
| LaTeX tables | `\begin{table}...\end{table}` in chapter-X.tex | inline |

---

## Terminology Reference

| Avoid | Use instead |
|-------|------------|
| Track A | Pendekatan A |
| Track B | Pendekatan B |
| em dash (—) | rewrite the sentence |
| colon before single item | rewrite without colon |
| plain English term in Indonesian text | *italicized English term* |
