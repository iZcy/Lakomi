# Thesis Writing Status & Google Docs Reference

## Google Docs

| Field | Value |
|-------|-------|
| Document ID | `1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY` |
| Service Account | `C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json` |
| Scopes | `https://www.googleapis.com/auth/documents` |

### Tab IDs

| Tab | tabId | Status |
|-----|-------|--------|
| BAB I — Pendahuluan | `t.prr0oo8xt561` | ✅ COMPLETE |
| BAB II — Tinjauan Pustaka | `t.ulqqr4hsh3xe` | ✅ COMPLETE (old 12-subsection version) |
| BAB III — Metodologi | `t.re803sjptjxa` | 🔄 Needs updates (new arch + new config sections) |
| BAB IV — Hasil & Pembahasan | `t.qqd2qneuql48` | ⏳ Writing not started |
| BAB II Dasar Teori (new draft) | `t.v7l3rd9jsdie` | 🔄 IN PROGRESS — 26-subsection rewrite |
| Referensi per Subbab | `t.catchhmle3jf` | 🔄 IN PROGRESS — links grouped by subsection |

---

## Scripts Written (`C:/Outpost/Skripsi/Research 4/thesis_01/`)

| Script | Purpose | Status |
|--------|---------|--------|
| `write_bab1_v3.py` | Wrote full BAB I | DONE |
| `write_bab2_v3.py` | Wrote BAB II sections 2.1–2.3 | DONE |
| `rewrite_bab2_24.py` | Rewrote section 2.4 (Pertanyaan Tugas Akhir) | DONE |
| `patch_rq_numbering.py` | Applied numbered list RQ1–RQ6 | DONE |
| `patch_rq5.py` | Patched RQ5 text to Qwen vs DeepSeek | DONE |
| `write_bab3.py` | Wrote full BAB III | DONE |
| `patch_bab1_limit7.py` | Added point 7 to BAB I section 1.4 | DONE |
| `patch_bab1_fix_numbering.py` | Fixed point 7 numbering style | DONE |
| `write_bab2_v4.py` | BAB II with 12 subsections (old, superseded) | DONE (superseded) |
| `write_bab2_v5.py` | BAB II full rewrite with 26 subsections | **NEXT TASK** |
| `write_221_aes_evolution.py` | 2.2.1 Evolusi AES → tab `t.v7l3rd9jsdie` | DONE |
| `write_references_tab.py` | Reference links per subsection → tab `t.catchhmle3jf` | DONE (reusable) |
| `write_bab4.py` | BAB IV writer | NOT WRITTEN YET |

### Pattern for write_babX.py
See `write_bab3.py` as the canonical template. Key pattern:
- Segments list: `[("type", "text"), ...]`
- Types: `chapter`, `section`, `subsection`, `body`, `numbered`
- Insert all segments in **reverse order** at index 1
- Apply paragraph/text styles **forward** using calculated positions
- Batch API calls in groups of 50
- ITALIC_TERMS list for auto-italicizing technical terms

---

## Formatting Standards (DTETI UGM Template)

| Element | Font | Size | Style | Alignment | SpaceAbove | SpaceBelow |
|---------|------|------|-------|-----------|------------|------------|
| Chapter heading | TNR | 14pt | Bold | CENTER | 0 | 6pt |
| Section (X.X) | TNR | 12pt | Bold | START | 12pt | 6pt |
| Subsection (X.X.X) | TNR | 12pt | Bold | START | 6pt | 3pt |
| Body paragraph | TNR | 12pt | Normal | JUSTIFIED | 0 | 0 |
| Numbered list item | TNR | 12pt | Normal | JUSTIFIED | 0 | 0 |

- Body paragraph first-line indent: `35.43pt`
- Numbered list: `createParagraphBullets` with `NUMBERED_DECIMAL_ALPHA_ROMAN` (="1." style, NOT "1)")
- Subsubsection (X.X.X.X): NOT USED — max 3 levels in DTETI template. Use **bold headers** in body text instead.

---

## BAB I — Pendahuluan (t.prr0oo8xt561)

```
1.1 Latar Belakang
1.2 Rumusan Masalah
1.3 Tujuan Penelitian
1.4 Batasan Penelitian (7 numbered points)
    1. Dataset EssayJudge (Su et al. 2025), 1054 esai, 10 trait
    2. IELTS Academic Writing Task 1 only
    3. Model list (Track A: BERT+RoBERTa+ResNet18; Track B: Qwen7B+DePlot+Dual RoBERTa)
    4. QWK metric, 11-level scale
    5. Multi-task training (10 traits jointly)
    6. No fine-tuning on VLM/DePlot
    7. VLM ≤7B params; Qwen2-VL-7B vs DeepSeek-VL-7B [added 2026-04-19]
1.5 Manfaat Penelitian
1.6 Sistematika Penulisan
```

## BAB II — Tinjauan Pustaka (t.ulqqr4hsh3xe)

> STATUS: 🔄 IN PROGRESS — being rewritten with 26-subsection structure. Full plan in `context/bab2_structure.md`.
> Writing rules: see `context/writing_rules.md` (all 6 rules mandatory).
> Terminology: "Pendekatan A" (ResNet18+RoBERTa), "Pendekatan B" (VLM+Dual RoBERTa). NOT "Track A/B".

```
RULE: No our QWK results, no experiment references in BAB II.

2.1 Tinjauan Pustaka (6 papers) ✅ WRITTEN — thesis-main/contents/chapter-2/chapter-2.tex
    (A) Singh et al. 2025 — EssayJudge benchmark
    (B) Gold et al. 2025 — Multimodal fusion strategies (late > intermediate > early)
    (C) Sun & Wang (2024) — Multi-dimensional AES, RoBERTa > BERT
    (D) Bursztyn et al. 2024 — Text > image for chart QA (99% vs 63%)
    (E) Liu et al. 2023a — DePlot (plot-to-table, Pix2Struct-based)
    (F) Liu et al. 2023b — MATCHA (chart2text, high hallucination risk on bar/pie)
    + Summary table (tab:tinjauan-pustaka) + 4-item research gaps paragraph
    Note: Written from local sources (Google Docs 401 error). PDF: 106 pages, clean build.

2.2 Dasar Teori — NEW 26-SUBSECTION STRUCTURE (write_bab2_v5.py)
    Group 1 — Domain Context:
    2.2.1  Evolusi Automated Essay Scoring
    2.2.2  Pemrosesan Multimoda
    2.2.3  Strategi Multimodal Fusion
    2.2.4  Penilaian Esai Multimoda

    Group 2 — DL Foundations:
    2.2.5  Jaringan Saraf Tiruan dan Fungsi Aktivasi
    2.2.6  Backpropagation dan Optimisasi Gradient
    2.2.7  Regularisasi
    2.2.8  AdamW dan Learning Rate Scheduling
    2.2.9  Transfer Learning dan Fine-tuning

    Group 3 — Text Pipeline:
    2.2.10 Tokenisasi
    2.2.11 Transformer
    2.2.12 Mekanisme Attention
    2.2.13 BERT
    2.2.14 RoBERTa

    Group 4 — Visual Pipeline:
    2.2.15 Convolutional Neural Network (CNN)
    2.2.16 ResNet18
    2.2.17 Vision Transformer (ViT)
    2.2.18 Pix2Struct
    2.2.19 Kuantisasi Model
    2.2.20 Qwen2-VL (VLM)
    2.2.21 DePlot
    2.2.22 MATCHA

    Group 5 — Training & Evaluation:
    2.2.23 Multi-task Learning
    2.2.24 Scoring Head dan Arsitektur FC
    2.2.25 Uji Statistik (Paired t-test, Bonferroni)
    2.2.26 Quadratic Weighted Kappa (QWK)

2.3 Analisis Perbandingan Metode

2.4 Pertanyaan Tugas Akhir (RQ1–RQ6, numbered "1." style)
    Intro: states ≤7B VLM constraint
    RQ1–RQ6 as numbered list
```

## BAB III — Metodologi (t.re803sjptjxa)

> STATUS: ✅ chapter-3.tex fully updated as of 2026-05-02 (session 2 of rewrite).
> LaTeX is the source of truth. Google Docs tab may be outdated.

```
3.1 Alat dan Bahan ✅
    3.1.1 Alat (RTX 3060 6GB local + Kaggle P100 16GB; MATCHA added 2026-05-02)
    3.1.2 Bahan: Dataset EssayJudge (1054 essays, 10 traits, score 0–5)
           Table row 5: ResNet50 dan ResNet152 (updated 2026-05-02)

3.2 Metode yang Digunakan ✅ (v2 REVISIONS COMPLETE 2026-05-02)
    3.2.1 Pra-pemrosesan Data ✅ (v2)
          - URL download step added (requests+PIL, convert to RGB PNG)
          - tab:preprocessing: \hline between every row; URL download row added

    3.2.2 Ekstraksi Fitur ✅ (v2)
          - Neutral opening, no Pendekatan A/B differentiation
          - tab:feature-dims: 6 rows, no Pendekatan column, no duplicates
            (ResNet18, ResNet50, ResNet152, dual ResNet, BERT, RoBERTa)

    3.2.3 Arsitektur Model ✅ (v2)
          - Pendekatan A: replaced 5-step narrative with tab:exp-pend-a
            (8 experiments, columns: Encoder Teks, Encoder Gambar, Fusion, Loss, QWK test)
          - Pendekatan B: brief intro + CrossAttn equations + tab:arsitektur-crossattn
            (per-exp details moved to 3.2.4; cross-refs to subsec:metode-pelatihan and
            subsec:pipeline-captioning added)
          - fig:arsitektur-a kept intact

    3.2.4 Metode Pelatihan ✅ (v2, renamed from "Pelatihan Multi-task")
          - \label{subsec:metode-pelatihan} added
          - Multi-task vs per-trait paradigm explanation with WHY multi-task chosen
          - tab:exp-pend-b added: 7 experiments (158-164), columns: Query Strategy,
            Caption Set, N samples, QWK test
          - Existing equations (MSE/CE) and tab:hyperparameters kept

    3.2.5 Pipeline Captioning ✅ (v2)
          - \label{subsec:pipeline-captioning} added
          - tab:pipeline-captioning restructured: rows = Exp IDs (081/093, 103, 158/159/160,
            161, 162, 163, 164); columns = Qwen2-VL-7B | DePlot+Qwen2-VL-7B | MATCHA

    3.2.6 Evaluasi dan Uji Statistik ✅ (v2)
          - Split into two numbered subsubsections:
            3.2.6.1 Quadratic Weighted Kappa (QWK)
            3.2.6.2 Uji Paired T-Test

3.3 Alur Tugas Akhir ✅ (minor fixes 2026-05-02)
    - "keenam" → "kelima" (RQ6 removed in previous session)
    - ResNet18 → ResNet50 in 3.3.1 description
    - ResNet18 → ResNet50 in 3.4 batasan table row 5
    - Tab:alur-eksperimen 11 steps intact (historical accuracy preserved)
```

---

## Pending Work

| Task | Priority |
|------|----------|
| Run new paired t-test for Exp057 (Pend.A) and Exp161 (Pend.B) → add results to ch4 section 4.6 | HIGH — deferred by user |
| Update chapter 4 section 4.6 RQ5 question text and result tables when t-test is done | HIGH — blocked on above |
| Section 3.3.2 Alur Eksperimen: consider updating historical narrative to reflect new ablation order (Exp046-057 before T2T CrossAttn) | MEDIUM |
| Section 3.4 Batasan: verify all items still accurate after architecture updates | LOW |
| fig:arsitektur-a in ch3: should show ResNet50 not ResNet18 — diagram update deferred by user | LOW — user said "fix later" |
| hybrid_fusion.drawio → export as hybrid_fusion.pdf (user task, not Claude task) | DEFERRED |
