# Writing Style Guide: Section 3.3.2 Alur Eksperimen Utama
# Status: ACTIVE REFERENCE
# Created: 2026-05-03

---

## Scope

This guide documents the writing style for **section 3.3.2 Alur Eksperimen Utama** and
any similar narrative-flow sections in BAB III. It was developed iteratively through
the 2026-05-03 session.

---

## Core Principles

### 1. No QWK scores in prose — ever
Results belong exclusively in BAB IV. Section 3.3.2 describes what each experiment does,
not what it found. The summary table (tab:alur-eksperimen) carries the numbers.

### 2. Describe the experiment, not the outcome
Each step paragraph answers: **what is being tested, and why.** Not what happened.
The reader should understand the purpose and design of the experiment from the paragraph.

### 3. No heavy technical jargon in prose
Avoid deep implementation terms. The prose is for a reader who understands ML broadly
but does not need layer counts, hyperparameters, or loss function math.

**Banned terms in prose:**
- `backbone` → use "komponen pengolah gambar" or name it directly (ResNet18/50/152)
- `encoder` → use "model pemrosesan teks" or name it (BERT, RoBERTa)
- `MSE`, `CE`, `cross-entropy` → use "regression" / "classification"
- `gradient accumulation`, `weight decay`, `lr=2e-5` → not needed in 3.3.2
- `token [CLS]` alone → explain as "token ringkasan" when first introduced
- `logits`, `hidden states`, `batch size` → never in 3.3.2

### 4. Name specific models — always
Generic phrases like "model bahasa-visual" alone are not enough. Name the model
when it is the thing being varied or is key to the step.

**Always name:**
- Qwen2-VL-7B-Instruct (captioner for Approach B)
- BERT, RoBERTa (text models in Approach A)
- ResNet18, ResNet50, ResNet152 (visual components)
- DePlot, MATCHA (specialized captioners)

### 5. Use familiar English fusion/method terms
English terms are more recognizable than Indonesian translations for standard ML methods.
Use them as-is (italicized):

| Use this | Not this |
|----------|----------|
| *early fusion* | "penggabungan awal" |
| *intermediate fusion* | "penggabungan menengah" |
| *late fusion* | "penggabungan akhir" |
| *regression* | "regresi" |
| *classification* | "klasifikasi" (OK but less clear) |
| *CLS query* | "token ringkasan esai sebagai pertanyaan" |
| *sequential query* | "rata-rata urutan esai" |

### 6. Explain terms when first introduced in a step
If a technical term must appear, give a brief plain-language gloss the first time.

> *CLS query* yang menggunakan token ringkasan esai sebagai representasi pertanyaan

### 7. Follow the same pattern across all steps
Each step paragraph must:
1. State what is being compared / tested
2. Name the specific models or configurations involved
3. Note the experiment numbers (Exp~XXX)
4. Optionally note the fixed conditions (to isolate the variable)

---

## Examples: What Is Wrong vs What Is Correct

### WRONG — too result-forward (putting outcome in BAB III prose)

> ResNet50 menghasilkan QWK tertinggi dan dipilih sebagai \textit{backbone} visual standar.

> \textit{Cross-attention} menghasilkan QWK tertinggi dan dipilih sebagai strategi
> \textit{fusion} standar.

> Penggantian ini menghasilkan peningkatan performa yang signifikan dan menjadikannya
> hasil terbaik Pendekatan A.

> Hasilnya menunjukkan QWK 0,5802, nilai tertinggi yang dicapai dalam penelitian ini.

**Why wrong:** BAB III is methodology — it describes what you did, not what you found.
Results and conclusions go in BAB IV.

---

### WRONG — too technical (config dump, not description)

> Konfigurasi \textit{dual} ResNet (198 juta parameter) berpotensi \textit{overfit}
> pada 737 sampel pelatihan, sehingga dilakukan ablasi ke \textit{backbone} tunggal:
> ResNet18 (Exp~047, QWK 0,5070), ResNet50 (Exp~048, QWK 0,5134), dan ResNet152
> (Exp~049, QWK 0,5081).

> Konfigurasi pelatihan Exp~057 (CE 11-kelas, AdamW, \textit{lr}=$2 \times 10^{-5}$,
> \textit{batch} efektif 32, tanpa \textit{freeze}, \textit{seed}=42) selanjutnya
> diadopsi sebagai konfigurasi standar untuk Pendekatan B.

> fungsi kerugian \textit{cross-entropy} 11-kelas, optimisasi AdamW dengan
> \textit{learning rate} $2 \times 10^{-5}$ dan \textit{weight decay} $0{,}01$

**Why wrong:** Hyperparameter dumps belong in the per-experiment longtables (3.2.3,
3.2.4), not in the narrative flow section. The flow section is a high-level description
of the research journey.

---

### WRONG — too vague (no model names, no terms)

> Sebuah model bahasa-visual digunakan untuk menghasilkan deskripsi tekstual bagi
> setiap grafik, kemudian dua model teks independen mengolah deskripsi grafik dan esai
> secara paralel.

> Tiga cara berbeda bagi representasi esai untuk berinteraksi dengan deskripsi grafik
> diuji pada seluruh dataset.

**Why wrong:** The reader cannot understand what was actually done. Model names and
method names must appear so the step is traceable to the actual experiments.

---

### CORRECT

**Step 3 — comparing visual components:**
> Arsitektur BRCAF menggunakan dua komponen pengolah gambar secara bersamaan, yang
> berpotensi terlalu kompleks untuk jumlah data pelatihan yang tersedia. Langkah ini
> membandingkan konfigurasi tersebut dengan tiga alternatif pengolah gambar tunggal,
> yaitu ResNet18, ResNet50, dan ResNet152 (Exp~047, 048, 049), menggunakan seluruh
> konfigurasi pelatihan lain yang identik.

**Step 4 — regression vs classification:**
> Langkah ini membandingkan dua pendekatan prediksi skor: \textit{regression}, yang
> memperlakukan skor sebagai nilai kontinu, dan \textit{classification}, yang
> memperlakukan skor sebagai kategori diskrit (Exp~050). Seluruh komponen lain dijaga
> tetap sama untuk mengisolasi pengaruh pilihan pendekatan prediksi secara langsung.

**Step 5 — fusion strategies:**
> Dengan komponen pengolah gambar dan pendekatan prediksi yang telah dipilih, langkah
> ini membandingkan tiga strategi \textit{fusion}: \textit{early fusion} (Exp~055),
> \textit{intermediate fusion} (Exp~048), dan \textit{late fusion} (Exp~056). Ketiga
> strategi diuji pada konfigurasi yang sepenuhnya identik.

**Step 8 — query strategies with term explanation:**
> Fase pertama Pendekatan B membandingkan tiga strategi interaksi antara representasi
> esai dan deskripsi grafik (Exp~158, 159, 160): \textit{CLS query} yang menggunakan
> token ringkasan esai sebagai representasi pertanyaan, \textit{sequential query} yang
> menggunakan rata-rata seluruh token esai, dan \textit{CLS-cap-key} yang menggunakan
> token ringkasan deskripsi sebagai acuan kunci. Ketiga strategi diuji pada konfigurasi
> identik menggunakan deskripsi Qwen2-VL-7B pada seluruh 1.054 sampel.

**Step 11 — naming both captioners:**
> Fase kedua diakhiri dengan membandingkan dua \textit{captioner} khusus grafik
> \textit{bar} dan \textit{pie} pada seluruh 1.054 sampel: DePlot (Exp~162) dan MATCHA
> (Exp~164). Pada kedua eksperimen, \textit{caption} untuk jenis grafik lainnya tetap
> menggunakan Qwen2-VL-7B, sehingga perbedaan terletak semata pada pilihan
> \textit{captioner} untuk grafik \textit{bar} dan \textit{pie}.

---

## Paragraph Structure Template

```
\noindent\textbf{Langkah N, <Short Title>.}
<1 sentence: context / motivation for this step — why is this step needed?>
<1–2 sentences: what is being compared / tested, naming specific models/methods
 and experiment numbers.>
<Optional 1 sentence: what is held fixed, to isolate the variable being tested.>
```

Maximum 3–4 sentences per step. No results. No QWK. No hyperparameter lists.

---

## What Goes Where

| Content | Location |
|---------|----------|
| QWK scores | BAB IV only |
| Hyperparameters (lr, batch, dropout, seed) | Per-experiment longtable in 3.2.3 / 3.2.4 |
| Architecture details (layer counts, dims) | Per-experiment subsection in 3.2.3 / 3.2.4 |
| What was tested and why | 3.3.2 prose (this section) |
| Which model/variant won | BAB IV only |
| Summary of all steps with QWK | tab:alur-eksperimen (table) |
