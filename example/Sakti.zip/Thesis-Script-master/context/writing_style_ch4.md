# Writing Style Rules — Chapter 4 (Hasil dan Pembahasan)
Last updated: 2026-05-03

These rules apply **globally to the entire thesis** — not just the subsection where an example was first raised. When a rule is demonstrated with an example from 4.1.1, it must equally be applied to 4.1.2, 4.1.3, 4.2, 4.3, and all other sections. Do not treat a rule as scoped to the subsection where it was mentioned.

---

## 1. Table Captions

**Rule:** Keep captions minimal. Identify the experiment(s) only. Do not re-explain the architecture, models, or configuration in the caption — that belongs in the body text.

**Wrong:**
```
\caption{Hasil QWK per-\textit{trait} Eksperimen 046 (replikasi BRCAF: BERT,
         \textit{dual} ResNet152+ResNet50, \textit{cross-attention}).}
```

**Correct:**
```
\caption{Hasil QWK per-\textit{trait} Eksperimen 046.}
```

For comparison tables, listing experiment numbers is acceptable:
```
\caption{Perbandingan QWK per-\textit{trait}: ResNet18 (Exp~047), ResNet50
         (Exp~048), ResNet152 (Exp~049).}
```
Do NOT add "Nilai tertinggi per baris dicetak tebal" or similar formatting instructions in captions.

---

## 2. Bold in Tables

**Rule:** Only bold the **Avg QWK row value** in comparison tables. Do NOT bold individual highest scores per trait across columns.

**Wrong:**
```latex
\textit{Argument Clarity} & 0,317 & \textbf{0,353} & 0,348 \\
\textit{Coherence}        & 0,605 & \textbf{0,628} & 0,599 \\
...
\textbf{Avg QWK}          & 0,5070 & \textbf{0,5134} & 0,5081 \\
```

**Correct:**
```latex
\textit{Argument Clarity} & 0,317 & 0,353 & 0,348 \\
\textit{Coherence}        & 0,605 & 0,628 & 0,599 \\
...
\textbf{\textit{Avg} QWK} & 0,5070 & \textbf{0,5134} & 0,5081 \\
```

In the Avg QWK row, bold only the winning column value AND the row label. Other columns are not bolded.

---

## 3. "Avg" Formatting

**Rule:** The word "Avg" must always be italicized: `\textit{Avg}`. This applies in:
- Table row labels: `\textbf{\textit{Avg} QWK}`
- Table column headers: `\textbf{\textit{Avg} QWK}`
- Prose references: `\textit{Avg} QWK 0,5134`

**Wrong:**
```latex
\textbf{Avg QWK} & \textbf{0,5134} \\
```

**Correct:**
```latex
\textbf{\textit{Avg} QWK} & \textbf{0,5134} \\
```

---

## 4. Gap Notation (+xxx QWK) in Prose

**Rule:** Do not write gap notation (e.g., `$+0{,}030$`, `$+0{,}031$`) inline in prose paragraphs when comparing two models. If the gap is important, put it in a dedicated **Selisih** or **$\Delta$** column in the table.

**Wrong (in prose):**
```
Ketiga konfigurasi melampaui BRCAF dual (0,4839), dengan selisih terbesar pada ResNet50 ($+0{,}030$).
```

**Correct (in prose):**
```
Ketiga konfigurasi melampaui BRCAF dual (0,4839). ResNet50 menghasilkan \textit{Avg} QWK tertinggi (0,5134)...
```

**Correct (in table with Selisih column):**
```latex
\textbf{\textit{Avg} QWK} & \textbf{0,5134} & 0,4767 & $+0{,}037$ \\
```

Gap notation IS acceptable in progression tables (tab:rq1-progression style) where there is an explicit $\Delta$ column.

---

## 5. Section and Subsection Titles

**Rule:** Keep titles concise. Do not list every model variant in the title — that information is in the body text. List experiment numbers only.

**Wrong:**
```
\subsection{Perbandingan Komponen Pengolah Gambar: ResNet18, ResNet50, ResNet152
           (Eksperimen 047, 048, 049)}
```

**Correct:**
```
\subsection{Perbandingan Komponen Pengolah Gambar (Eksperimen 047, 048, 049)}
```

---

## 6. RQ Answer Format

**Rule:** Do NOT bold the RQ answer sentence. Do NOT use the format `Jawaban RQ1: \textbf{...}`. Instead, write it as a natural explanatory paragraph. Follow this template:

> Jawaban dari RQ[N], berdasarkan hasil di atas, adalah bahwa [finding in plain language], dengan [metric] [value] pada Eksperimen [XXX]. [Model/component] menjadi [role] yang digunakan pada eksperimen ini.

**Wrong:**
```latex
Jawaban RQ1: \textbf{\textit{cross-attention} menghasilkan QWK tertinggi di antara
ketiga strategi \textit{fusion} yang dievaluasi (Avg QWK 0,5134, Eksperimen 048),
melampaui \textit{late fusion} sebesar $+0{,}031$ dan \textit{early fusion}
sebesar $+0{,}042$.}
```

**Correct:**
```latex
Jawaban dari RQ1, berdasarkan hasil di atas, adalah bahwa strategi
\textit{intermediate fusion} dengan mekanisme \textit{cross-attention} menghasilkan
QWK tertinggi di antara strategi \textit{fusion} yang dievaluasi, dengan \textit{Avg}
QWK 0,5134 pada Eksperimen 048. BERT dan ResNet50 menjadi komponen teks dan gambar
yang digunakan pada eksperimen ini.
```

Key differences:
- No `\textbf{}` wrapping the answer
- No gap notation (`$+0{,}031$`) in the answer sentence
- Ends with a statement about which models were used
- Reads like a conclusion paragraph, not a formula

---

## 7. Architectural Context for Ablation Motivation

**Rule:** When noting that an architectural component is unsuitable for the current task, explain WHY it was designed that way originally and WHY that reasoning does not apply here. Do not just cite parameter count as the reason.

**Wrong:**
```
Kombinasi dua komponen pengolah gambar dengan total sekitar 198 juta parameter
berpotensi terlalu kompleks untuk 737 sampel pelatihan.
```

**Correct:**
```
Arsitektur \textit{dual} ResNet pada BRCAF awalnya dirancang untuk memisahkan
representasi objek (ResNet152 berbasis ImageNet) dan konteks latar belakang
(ResNet50 berbasis Places365) dalam sebuah gambar. Dalam konteks grafik IELTS
yang bersifat abstrak, pemisahan objek dan latar belakang tidak relevan, sehingga
konfigurasi \textit{dual} ini berpotensi terlalu kompleks untuk 737 sampel
pelatihan yang tersedia.
```

Explain the original design intent → why it does not apply here → consequence.

---

## 8. Parameter Count in Prose

**Rule:** Do not cite specific parameter counts (e.g., "198 juta parameter", "253 juta parameter") in prose analysis paragraphs unless the point being made is specifically about model size as a variable. Parameter counts belong in architecture description sections (Chapter 3) or in configuration tables, not in results analysis.

---

## 9. "Avg QWK" in Prose

**Rule:** In running prose, write `\textit{Avg} QWK` (italicized Avg), consistent with the table formatting.

**Wrong:** `Replikasi menghasilkan Avg QWK 0,4839`
**Correct:** `Replikasi menghasilkan \textit{Avg} QWK 0,4839`

---

## 10. No Re-Explaining Architecture in BAB IV

**Rule:** BAB IV is results and discussion — not an architecture description. Chapter 3 already covers all model architectures, training configurations, and component choices in full. Do NOT re-explain how a component works, why it was designed that way, or how it differs mechanically from another. In BAB IV, only name the component and cite the result.

This applies to: encoder descriptions, fusion mechanism internals, loss function formulations, pre-training details, component attribution logic ("because only X changed, the delta can be attributed to Y").

**Wrong:**
```
RoBERTa menggunakan \textit{dynamic masking} dan data pra-pelatihan yang jauh
lebih besar dibandingkan BERT \citep{liu2019roberta}, sehingga diharapkan
menghasilkan representasi yang lebih \textit{robust} untuk teks esai IELTS.
```
```
Perubahan satu-satunya adalah komponen \textit{text encoder}, sehingga selisih
hasil dapat secara langsung diatribusikan pada perbedaan representasi antara
kedua model.
```

**Correct:**
```
Eksperimen 057 mengganti BERT dengan RoBERTa pada arsitektur yang identik.
Hasil per-\textit{trait} disajikan pada Tabel~\ref{tab:exp057-results}.
```

In the analysis paragraph, stating which traits improved and by how much is sufficient. Do not re-state the mechanism behind why one encoder should theoretically outperform another — that belongs in BAB II or BAB III.
