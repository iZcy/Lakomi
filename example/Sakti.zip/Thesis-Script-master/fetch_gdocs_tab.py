"""Extract full text of section 2.2.2 from BAB II - Neo Draft child tab."""
import sys
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents.readonly']
SA_FILE = r'C:\Outpost\Skripsi\Research 4\primal-index-492509-s6-133bb47b7a74.json'
DOC_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
PARENT_TAB_ID = 't.nvd2oqk37t7s'

creds = service_account.Credentials.from_service_account_file(SA_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)
doc = service.documents().get(documentId=DOC_ID, includeTabsContent=True).execute()

# Navigate to the child tab
parent = next(t for t in doc['tabs'] if t['tabProperties']['tabId'] == PARENT_TAB_ID)
child = parent['childTabs'][0]  # BAB II - Neo Draft

body_content = child['documentTab']['body']['content']

def para_text(para):
    return ''.join(
        el.get('textRun', {}).get('content', '')
        for el in para.get('elements', [])
    )

# Collect all paragraphs as plain text
paras = []
for item in body_content:
    if 'paragraph' in item:
        text = para_text(item['paragraph'])
        paras.append(text)

# Find 2.2.2 section boundaries
start_idx = None
end_idx = None
for i, p in enumerate(paras):
    stripped = p.strip()
    if stripped.startswith('2.2.2') and 'Pemrosesan Multimoda' in stripped:
        start_idx = i
    elif start_idx is not None and stripped.startswith('2.2.3'):
        end_idx = i
        break

if start_idx is None:
    print("ERROR: 2.2.2 not found")
    sys.exit(1)

end_idx = end_idx or len(paras)
section = paras[start_idx:end_idx]

print(f"Section 2.2.2: paragraphs [{start_idx}:{end_idx}] ({len(section)} items)\n")
print("=" * 70)
for p in section:
    if p.strip():
        print(p)
        print("---")
