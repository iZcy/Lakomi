# Experiment Flow (Thesis Narrative)

Last updated: 2026-04-30

---

## Step 0: Baseline
Zero-shot Qwen2-VL-7B → avg QWK ~0.164

---

## Step 1: First Trained Model
**BERT + ResNet18 Intermediate Fusion**

| Exp | Dir | Test QWK | Status |
|-----|-----|----------|--------|
| 031 | Experiment/031_FusionCompare-BERT-Mid/ | 0.4799 | Done |

---

## Step 2: Find Best Fusion Strategy
**Early / Intermediate / Late Fusion (BERT + ResNet18)**

| Exp | Strategy | Test QWK | Status |
|-----|----------|----------|--------|
| 030 | Early fusion | 0.4777 | Done |
| 031 | Intermediate fusion | 0.4799 | Done |
| 032 | Late fusion | 0.4838 | Done — **Winner** |

---

## Step 3: Improve Text Encoder
**Swap BERT → RoBERTa (Late Fusion + ResNet18)**

| Exp | Config | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 00  | RoBERTa+ResNet18 per-trait (ref) | 0.5117 | 0.4237 | Done |
| 033 | RoBERTa+ResNet18 Late multi-task | 0.5283 | 0.5126 | Done — **Winner** |

### Ablation (Exp033 variants)

| Exp | Config | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 034 | ResNet50 | 0.5374 | 0.4926 | Done |
| 035 | ResNet152 | 0.5338 | 0.4947 | Done |
| 036 | lr=2e-5 | 0.5255 | 0.5089 | Done |
| 037 | lr=3e-4 | 0.5093 | 0.4941 | Done |
| 038 | dropout=0.1 | 0.5522 | 0.5332 | Done |
| 039 | dropout=0.5 | 0.5355 | 0.5351 | Done |
| 040 | per-trait, dropout=0.5 | — | 0.4833 | Done |
| 041 | rerun of 033 (variance check) | 0.5099 | 0.4896 | Done |

**Ablation findings:** ResNet18 best; lr=1e-4 best; dropout insensitive (0.1–0.5); multi-task >> per-trait (+0.052); run variance ~0.023

### Architecture Variants

| Exp | Config | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 016 | Siamese RoBERTa (He 2024), CE+MSE+NT-Xent | 0.4986 | 0.4582 | Done |
| 017 | Siamese + bidirectional cross-attention | 0.5022 | 0.4463 | Done |

### Freezing Ablation

| Exp | Strategy | Val QWK | Test QWK | Status |
|-----|----------|---------|----------|--------|
| 103 | Freeze embed+layers0-5 (baseline) | 0.5228 | 0.5026 | Done |
| 121 | Freeze embed+layers0-2 | 0.5058 | 0.4459 | Done |
| 122 | Freeze embed only | 0.3524 | 0.3396 | Done |
| 123 | No freeze (full fine-tune) | 0.3268 | 0.2898 | Done |
| 124 | Layerwise LR decay, no freeze | 0.5082 | 0.4642 | Done |

---

## Step 4: Move to T2T — 7B Captioner
**Qwen2-VL-7B-Instruct captions + Dual RoBERTa**

| Exp | Config | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 08  | Qwen7B, full 1054 | 0.5067 | 0.4579 | Done |
| 081 | Exp08 seeded | — | 0.4796 | Done |

---

## Step 5: Caption Quality Analysis
100-sample manual review (bar+pie only):

| Captioner | bar_error | pie_error |
|-----------|-----------|-----------|
| Qwen-7B | 54% | 67% |
| DePlot+Qwen7B | 23% | 67% |
| MATCHA | 100% | 100% |

**Finding:** caption accuracy != AES score; RoBERTa learns from essay text primarily

---

## Step 6: Find Best Chart Captioner
**DePlot vs MATCHA vs PaliGemma (bar+pie only, 7B handles rest)**

| Exp | Captioner | Val QWK | Test QWK | Status |
|-----|-----------|---------|----------|--------|
| 103 | DePlot+Qwen7B bar+pie | 0.5228 | 0.5026 | Done — **Selected** |
| 104 | DePlot+Qwen7B bar+pie, dropout=0.5 | 0.5445 | 0.4924 | Done |
| 020 | MATCHA bar+pie | — | 0.5213 | Dropped — 100% error rate |
| 021 | PaliGemma bar+pie | — | N/A | Dropped — caption gen failed |
| 112 | DePlot+Llama3.2 bar+pie, Qwen7B rest | 0.5272 | 0.4690 | Done |

**Winner:** DePlot — only reliable specialized captioner

---

## Step 7: Apply Best Captioner — Optimize Chart Type Coverage
**Qwen7B with chart type filtering**

| Exp | Strategy | Val QWK | Test QWK | Status |
|-----|----------|---------|----------|--------|
| 09  | Excl pie+bar+composite | 0.5654 | 0.4919 | Done |
| 092 | Exp09 seeded | — | 0.4941 | Done |
| 091 | Excl pie+bar (keep composite) | 0.5532 | 0.4945 | Done |
| **093** | **Exp091 seeded** | — | **0.5778** | Done — **BEST OVERALL** |
| 10  | DePlot+7B pie/bar/composite, 7B rest | 0.5432 | 0.4822 | Done |
| 102 | Exp10 seeded | — | 0.4660 | Done |
| 101 | DePlot+7B bar+pie only, 7B composite+rest | 0.5228 | 0.4555 | Done |

---

## Step 8: Try Stronger VLM as Captioner
**InternVL2-8B / Llama3.2-11B**

| Exp | Caption Model | Val QWK | Test QWK | Status |
|-----|---------------|---------|----------|--------|
| 12  | InternVL2-8B, full 1054, seeded | 0.5049 | 0.5017 | Done |
| 13  | Llama3.2-11B, full 1054, seeded | 0.5150 | 0.4701 | Done |

**Finding:** Larger caption model alone not the bottleneck (on par with Exp103 DePlot+Qwen7B)

---

## Step 9: Refine Approach A — BRCAF Architecture Ablation (Exp046–057)
**New training regime: CE loss (11-class weighted), lr=2e-5, AdamW, wd=0.01, batch=4 accum=8, no freeze, seed=42**

### Replication
| Exp | Config | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 046 | BRCAF full replication (BERT + dual ResNet152+ResNet50/Places365 + CrossAttn) | 0.5432 | 0.4839 | Done |

### Backbone Ablation (BERT + single ResNet + CrossAttn + CE)
| Exp | Backbone | Val QWK | Test QWK | Status |
|-----|----------|---------|----------|--------|
| 047 | ResNet18 | 0.5404 | 0.5070 | Done |
| **048** | **ResNet50** | **0.5240** | **0.5134** | **Done — Winner** |
| 049 | ResNet152 | 0.5351 | 0.5081 | Done |

**Finding:** ResNet50 best; larger backbones overfit 737 samples.

### Loss Function Ablation (BERT + ResNet50 + CrossAttn)
| Exp | Loss | Val QWK | Test QWK | Status |
|-----|------|---------|----------|--------|
| 050 | MSE (avg 2 runs) | ~0.523 | ~0.490 | Done — Dropped |
| 048 | CE weighted (11 class) | 0.5240 | 0.5134 | Done — **Winner** |

**Finding:** CE classification > MSE regression.

### Fusion Strategy Ablation (BERT + ResNet50 + CE)
| Exp | Fusion | Val QWK | Test QWK | Status |
|-----|--------|---------|----------|--------|
| 055 | Early fusion | 0.5218 | 0.4716 | Done |
| **048** | **Cross-attention** | **0.5240** | **0.5134** | **Done — Winner** |
| 056 | Late fusion (avg 2 runs) | ~0.519 | ~0.480 | Done |

**Finding:** Cross-attention wins (+0.033 over late, +0.042 over early).

### Encoder Ablation (ResNet50 + CrossAttn + CE)
| Exp | Text Encoder | Val QWK | Test QWK | Status |
|-----|-------------|---------|----------|--------|
| 048 | BERT-base | 0.5240 | 0.5134 | Done |
| **057** | **RoBERTa-base** | **0.5486** | **0.5270** | **Done — Approach A Best** |

**Approach A final best: Exp057 (RoBERTa + ResNet50 + CrossAttn + CE) = 0.5270**

---

## Step 10: Transfer Best Config to Approach B — CrossAttn T2T (Exp158–164)
**Architecture: DualRobertaCrossAttnCls — CLS essay query attends to caption tokens**
**Same config as Exp057: CE, lr=2e-5, AdamW, wd=0.01, batch=4 accum=8, no freeze, seed=42**

### Phase 1: Query Strategy Ablation (full Qwen7B, 1054 samples)
| Exp | Query Strategy | Val QWK | Test QWK | Epoch | Status |
|-----|---------------|---------|----------|-------|--------|
| **158** | **CLS [B,1,768]** | **0.5425** | **0.5041** | **11** | **Done — Winner** |
| 159 | Seq mean [B,n,768] | 0.5394 | 0.4962 | 22 | Done |
| 160 | CLS cap key [B,1,768] | 0.5241 | 0.4664 | 8 | Done |

**Finding:** CLS query best — fastest convergence, cleanest design, no query padding needed.

### Phase 2: Caption Set Comparison (CLS query)
| Exp | Caption Set | Val QWK | Test QWK | Status |
|-----|-------------|---------|----------|--------|
| 161 | Qwen7B excl bar+pie (772 samples) | 0.4910 | 0.5802 | Done — excluded subset, not full eval |
| **162** | **DePlot+Qwen7B full 1054** | **0.5402** | **0.5066** | **Done — BEST full-data T2T CrossAttn** |
| 163 | Qwen7B excl bar+pie+composite (665 samples) | 0.4604 | 0.5105 | Done — excluded subset |
| 164 | MATCHA+Qwen7B full 1054 | 0.5524 | 0.4702 | Done |

**Key findings:**
- Exp161/093/163 use excluded subsets — not directly comparable to full-dataset runs
- Best full-data T2T CrossAttn: Exp162 (DePlot+Qwen7B, 0.5066)
- DePlot (0.5066) > MATCHA (0.4702) — consistent finding; MATCHA overfits (high val, low test)
- New arch (no freeze, CE) consistently outperforms old arch for same caption sets (Exp081 0.4796 → Exp158 0.5041)

---

## Step 11: TBD
DeepSeek-VL-7B (RQ5 comparison vs Qwen2-VL-7B)

---

## Overall Best (full-dataset only — excluded-subset runs not ranked)

| Rank | Exp | Test QWK | Approach |
|------|-----|----------|----------|
| 1 | **057** | **0.5270** | Approach A, RoBERTa+ResNet50 CrossAttn CE, seed=42 |
| 2 | **033** | **0.5126** | Approach A, RoBERTa+ResNet18 Late Fusion MSE |
| 3 | **162** | **0.5066** | T2T CrossAttn CLS, DePlot+Qwen7B full 1054, seed=42 |
| 4 | 158 | 0.5041 | T2T CrossAttn CLS, Qwen7B full 1054, seed=42 |
| 5 | 103 | 0.5026 | T2T DualRoBERTa, DePlot+Qwen7B bar+pie, seed=42 |
| 6 | 164 | 0.4702 | T2T CrossAttn CLS, MATCHA+Qwen7B full 1054, seed=42 |

## Excluded-Subset Runs (not ranked against full-data runs)

| Exp | Test QWK | Subset | Note |
|-----|----------|--------|------|
| 161 | 0.5802 | 772 samples (excl bar+pie) | CrossAttn CLS, Qwen7B |
| 093 | 0.5778 | 772 samples (excl bar+pie) | Old arch DualRoBERTa |
| 163 | 0.5105 | 665 samples (excl bar+pie+comp) | CrossAttn CLS, Qwen7B |
