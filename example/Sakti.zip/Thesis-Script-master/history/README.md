# history/ — Session Log

> One file per session day: `YYYY-MM-DD.md`
> **Append only. Never overwrite or delete entries.**
> This is the highest-priority source of truth for what actually happened.

---

## Entry Format

```
[HH:MM] PROMPT: one-line summary of what the user asked
         RESULT: one-line summary of what was done or decided
```

---

## Rules

- Write in 24h time, local timezone (WIB, UTC+7).
- Keep entries terse — one line each for PROMPT and RESULT.
- If a decision was reversed later the same session, note it as a separate entry.
- Agents writing history entries must append, never overwrite.
