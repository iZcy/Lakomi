import re
from collections import defaultdict

files = {
    "BAB I":   r"C:/Outpost/Skripsi/Research 4/thesis-main/contents/chapter-1/chapter-1.tex",
    "BAB II":  r"C:/Outpost/Skripsi/Research 4/thesis-main/contents/chapter-2/chapter-2.tex",
    "BAB III": r"C:/Outpost/Skripsi/Research 4/thesis-main/contents/chapter-3/chapter-3.tex",
    "BAB IV":  r"C:/Outpost/Skripsi/Research 4/thesis-main/contents/chapter-4/chapter-4.tex",
}

old_keys = [
    "brown2020","liu2019roberta","devlin2019","loshchilov2019","baltrusaitis2019",
    "vaswani2017","ruder2017","he2016","sennrich2016","hendrycks2016","goodfellow2016",
    "lecun2015","kingma2015","bahdanau2015","srivastava2014","shermis2013",
    "krizhevsky2012","ngiam2011","yannakoudakis2011","pan2010","burstein2003",
    "lecun1998","landauer1998","caruana1997","rumelhart1986","landiskoch1977",
    "cohen1968","cohen1988","page1966"
]

SECTION_PAT = re.compile(r"\\(?:sub)*section[*]?\{([^}]+)\}")

key_locations = defaultdict(list)

for bab, fpath in files.items():
    with open(fpath, encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    current_section = "intro"
    section_map = {}
    for i, line in enumerate(lines):
        m = SECTION_PAT.search(line)
        if m:
            current_section = m.group(1).strip()
        section_map[i] = current_section

    for i, line in enumerate(lines):
        for key in old_keys:
            if key in line and "cit" in line:
                loc = bab + " > " + section_map[i]
                if loc not in key_locations[key]:
                    key_locations[key].append(loc)

years = {
    "brown2020":2020,"liu2019roberta":2019,"devlin2019":2019,"loshchilov2019":2019,
    "baltrusaitis2019":2019,"vaswani2017":2017,"ruder2017":2017,"he2016":2016,
    "sennrich2016":2016,"hendrycks2016":2016,"goodfellow2016":2016,"lecun2015":2015,
    "kingma2015":2015,"bahdanau2015":2015,"srivastava2014":2014,"shermis2013":2013,
    "krizhevsky2012":2012,"ngiam2011":2011,"yannakoudakis2011":2011,"pan2010":2010,
    "burstein2003":2003,"lecun1998":1998,"landauer1998":1998,"caruana1997":1997,
    "rumelhart1986":1986,"landiskoch1977":1977,"cohen1968":1968,"cohen1988":1988,
    "page1966":1966
}

authors = {
    "brown2020":       "Brown et al. (GPT-3)",
    "liu2019roberta":  "Liu et al. (RoBERTa)",
    "devlin2019":      "Devlin et al. (BERT)",
    "loshchilov2019":  "Loshchilov & Hutter (AdamW)",
    "baltrusaitis2019":"Baltrusaitis et al. (Multimodal Survey)",
    "vaswani2017":     "Vaswani et al. (Transformer)",
    "ruder2017":       "Ruder (MTL Overview)",
    "he2016":          "He et al. (ResNet)",
    "sennrich2016":    "Sennrich et al. (BPE)",
    "hendrycks2016":   "Hendrycks & Gimpel (GELU)",
    "goodfellow2016":  "Goodfellow et al. (DL book)",
    "lecun2015":       "LeCun et al. (Deep Learning)",
    "kingma2015":      "Kingma & Ba (Adam)",
    "bahdanau2015":    "Bahdanau et al. (Attention)",
    "srivastava2014":  "Srivastava et al. (Dropout)",
    "shermis2013":     "Shermis & Burstein (book)",
    "krizhevsky2012":  "Krizhevsky et al. (AlexNet)",
    "ngiam2011":       "Ngiam et al. (Multimodal DL)",
    "yannakoudakis2011":"Yannakoudakis et al. (ESOL)",
    "pan2010":         "Pan & Yang (Transfer Learning)",
    "burstein2003":    "Burstein (E-rater)",
    "lecun1998":       "LeCun et al. (LeNet)",
    "landauer1998":    "Landauer et al. (LSA)",
    "caruana1997":     "Caruana (Multitask Learning)",
    "rumelhart1986":   "Rumelhart et al. (Backprop)",
    "landiskoch1977":  "Landis & Koch (Kappa interpretation)",
    "cohen1968":       "Cohen (Weighted Kappa)",
    "cohen1988":       "Cohen (Statistical Power book)",
    "page1966":        "Page (AES by computer)",
}

for key in sorted(old_keys, key=lambda k: -years[k]):
    locs = key_locations.get(key, ["NOT CITED"])
    print(f"[{years[key]}] {authors[key]}")
    for l in locs:
        print(f"         -> {l}")
    print()
