# Verification Log

Format: `- [x] LINE XX: <original> → <fix> [Rule X.X]`
Mark `[x]` when applied.

---

## Chapter 1 — BAB I Pendahuluan

### Rule 1.2 — Colon before single item

- [~~] LINE 107–129: `Objek penelitian:`, `Metode penelitian:`, `Waktu dan tempat penelitian:`, `Keterbatasan penelitian:` — **REVERTED. These are labeled list items inside `\enumerate`. The "label: value" colon pattern is exempt from rule 1.2.** Rule updated with explicit exception.

### Rule 1.3 — Italicization of English technical terms (2 violations)

- [x] LINE 13-14: `\textit{diagram} batang`, `\textit{diagram} garis`, `\textit{diagram} lingkaran` → `\textit{bar chart}`, `\textit{line chart}`, `\textit{pie chart}` (rule 1.3 mandates complete English compound term with italics) [Rule 1.3]
- [x] LINE 15: `\textit{flowchart}` → `\textit{flow chart}` (two words per rule 1.3 table) [Rule 1.3]
- [x] LINE 150: `\textit{early}, \textit{intermediate}, dan \textit{late fusion}` → `\textit{early fusion}, \textit{intermediate fusion}, dan \textit{late fusion}` (each compound term must be fully italicized, not just the first word) [Rule 1.3]

---

*Checked and clean:*
- *No em dashes*
- *No QWK scores in prose*
- *No "fungsi kerugian"*
- *No gap notation*
- *VLM ≤7B constraint stated correctly (line 131-133)*
- *"Pendekatan A / Pendekatan B" used correctly throughout*
- *"Bagi dunia akademik:" and "Bagi praktisi pendidikan:" (lines 147, 164) — colon before itemize list of ≥2 items, acceptable*

---

## Chapter 2 — BAB II

### Section 2.1 — Tinjauan Pustaka

**Rule 1.2 — Colon before single item (1 violation)**

- [x] LINE 19 (figure caption): `\citet{gold2025}: \textit{encoder} teks (BERT)...` → remove colon, restructure as participial: `\citet{gold2025}, menggunakan \textit{encoder} teks (BERT) dan dua \textit{encoder} gambar (ResNet152 dan ResNet50) yang digabungkan melalui mekanisme \textit{cross-attention} sebagai referensi \textit{intermediate fusion}` [Rule 1.2]

**Rule 1.3 — Missing/malformed italics (5 violations)**

- [x] LINE 8: `grafik komposit yang menggabungkan beberapa jenis sekaligus` → `grafik komposit (\textit{composite chart}) yang menggabungkan beberapa jenis sekaligus` (no English term given for composite chart) [Rule 1.3]
- [x] LINE 58 (table): `\textit{early} vs \textit{late fusion}` → `\textit{early fusion} vs \textit{late fusion}` (compound term must be fully italicized) [Rule 1.3]
- [x] LINE 60 (table): `multi-\textit{trait}` → `\textit{multi-trait}` [Rule 1.3]
- [x] LINE 60 (table): `multi-tugas` → `\textit{multi-task}` (English mandatory per rule 1.3 table) [Rule 1.3]
- [x] LINE 70: `penilaian multi-\textit{trait} esai` → `penilaian \textit{multi-trait} esai` [Rule 1.3]

*Checked and clean: no em dash, no QWK from this thesis, no experiment numbers, no "fungsi kerugian", VLM ≤7B constraint consistent, "dimana" usage correct throughout.*

### Section 2.2 — Dasar Teori

**Rule 1.3 — Malformed italics: `multi-\textit{trait}` pattern (3 violations)**

- [x] LINE 948: `penilaian multi-\textit{trait} AES` → `penilaian \textit{multi-trait} AES` [Rule 1.3]
- [x] LINE 965: `AES multi-\textit{trait} berbasis` → `AES \textit{multi-trait} berbasis` [Rule 1.3]
- [x] LINE 1004: `AES multi-\textit{trait}, QWK` → `AES \textit{multi-trait}, QWK` [Rule 1.3]

**Rule 1.6 — `fungsi \textit{loss}` must be `\textit{loss function}` (2 violations)**

- [x] LINE 319: `ke fungsi \textit{loss}, mendorong bobot` → `ke \textit{loss function}, mendorong bobot` [Rule 1.6]
- [x] LINE 965: `Fungsi \textit{loss} yang digunakan adalah` → `\textit{Loss function} yang digunakan adalah` [Rule 1.6]

*Checked and clean: no em dash, no QWK from this thesis, no experiment numbers, "dimana" used correctly throughout, no "fungsi kerugian".*

---

### Section 2.3 — Analisis Perbandingan Metode

**Rule 1.1 — Em dash as parenthetical (1 violation)**

- [x] LINE 1025: `\textit{cross-attention} — antara token \texttt{[CLS]} esai dan representasi sekuensial esai penuh —` → `\textit{cross-attention}, yaitu antara token \texttt{[CLS]} esai dan representasi sekuensial esai penuh,` [Rule 1.1]

**Rule 1.3 — Malformed `multi-\textit{trait}` (2 violations)**

- [x] LINE 1025: `penilaian multi-\textit{trait} esai IELTS` → `penilaian \textit{multi-trait} esai IELTS` [Rule 1.3]
- [x] LINE 1044 (table): `penilaian esai multi-\textit{trait}` → `penilaian esai \textit{multi-trait}` [Rule 1.3]

*Checked and clean: no QWK from this thesis, no experiment numbers, no "fungsi kerugian", no colon violations.*

---

### Section 2.4 — Pertanyaan Tugas Akhir

*No violations found. Colon-after-label pattern in RQ enumerate items is exempt (Rule 1.2 exception).*

---

## Chapter 3 — BAB III Metodologi

### Section 3.1 — Alat dan Bahan

**Rule 1.3 — Italics violations (2 violations)**

- [x] LINE 22: `RoBERTa-\textit{base}` → `RoBERTa-base` (proper model variant name, no partial italics) [Rule 1.3]
- [x] LINE 92: `grafik komposit (107 sampel)` → `\textit{composite chart} (107 sampel)` (all other chart types in same sentence use English term) [Rule 1.3]

*Checked and clean: no em dash, no colon violations, no QWK, no "fungsi kerugian", "dimana" correct.*

### Section 3.2 — Metode yang Digunakan

**Rule 1.3 — Partial model name italics (10 violations)**

- [x] LINE 216: `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 240 (fig caption): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 308: `BERT-\textit{base-uncased}` → `BERT-base-uncased` [Rule 1.3]
- [x] LINE 310: `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 340 (table): `BERT-\textit{base-uncased}` → `BERT-base-uncased` [Rule 1.3]
- [x] LINE 342 (table): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 384 (table): `RoBERTa-\textit{base}` ×2 → `RoBERTa-base` [Rule 1.3]
- [x] LINE 890: `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 943 (table): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 945 (table): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]

**Rule 1.6 — Fungsi kerugian (4 violations)**

- [x] LINE 646 (subsubsection title): `Fungsi Kerugian Regresi MSE` → `\textit{Loss Function} Regresi MSE` [Rule 1.6]
- [x] LINE 665 (table caption): `Fungsi Kerugian Regresi MSE` → `\textit{Loss Function} Regresi MSE` [Rule 1.6]
- [x] LINE 957 (table cell): `Fungsi kerugian` → `\textit{Loss function}` [Rule 1.6]
- [x] LINE 1502 (table cell): `Fungsi kerugian` → `\textit{Loss function}` [Rule 1.6]

**Rule 2.1/5.1 — QWK scores in BAB III prose (15 violations)**

- [x] LINE 474-476: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,5070 pada data uji, lebih tinggi dari Eksperimen 046, yang mengindikasikan bahwa \textit{encoder} gambar tunggal sudah memadai untuk tugas ini.` [Rule 2.1]
- [x] LINE 534-535: remove sentence `Eksperimen ini memperoleh QWK sebesar 0,5134 pada data uji, melampaui Eksperimen 047 dan menjadi konfigurasi \textit{encoder} gambar tunggal terbaik di antara ketiga varian yang diuji.` [Rule 2.1]
- [x] LINE 593-595: remove sentence `Eksperimen ini memperoleh QWK sebesar 0,5081 pada data uji, sedikit di bawah ResNet50, mengindikasikan bahwa kedalaman \textit{encoder} gambar tambahan tidak selalu meningkatkan kinerja.` [Rule 2.1]
- [x] LINE 653-655: remove sentence `Hasil eksperimen menunjukkan QWK sebesar $\approx 0{,}490$ pada data uji, lebih rendah dari Eksperimen 048, sehingga formulasi klasifikasi dipertahankan pada eksperimen selanjutnya.` [Rule 2.1]
- [x] LINE 713-716: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,4716 pada data uji, dibawah \textit{cross-attention}, yang mengonfirmasi bahwa mekanisme \textit{attention} membantu model memilih fitur visual yang relevan terhadap konten esai.` [Rule 2.1]
- [x] LINE 774-776: remove sentence `Hasil eksperimen menunjukkan QWK sebesar $\approx 0{,}480$ pada data uji, lebih rendah dari \textit{cross-attention}, menunjukkan bahwa interaksi antar-modalitas sebelum prediksi memberikan manfaat yang signifikan.` [Rule 2.1]
- [x] LINE 834-836: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,5270 pada data uji, tertinggi di antara seluruh eksperimen Pendekatan A, sehingga konfigurasi ini dipilih sebagai konfigurasi final Pendekatan A.` [Rule 2.1]
- [x] LINE 973-975: remove sentence `Eksperimen ini memperoleh QWK sebesar 0,5041 pada data uji, melampaui konfigurasi lama Exp~081 (0,4796), dan menjadi basis ablasi strategi \textit{query} pada dua eksperimen berikutnya.` [Rule 2.1]
- [x] LINE 1038-1039: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,4962 pada data uji, lebih rendah dari strategi CLS, mengindikasikan bahwa representasi CLS sudah cukup untuk mewakili konteks esai dalam mekanisme ini.` [Rule 2.1]
- [x] LINE 1102-1104: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,4664 pada data uji, terendah di antara ketiga varian, menunjukkan bahwa urutan token \textit{caption} penuh lebih informatif dibandingkan representasi CLS tunggal.` [Rule 2.1]
- [x] LINE 1168-1170: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,5802 pada data uji, merupakan hasil terbaik dari seluruh eksperimen dalam penelitian ini.` [Rule 2.1]
- [x] LINE 1231-1234: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,5105 pada data uji, lebih rendah dari Eksperimen 161, mengonfirmasi bahwa menghapus grafik komposit justru merugikan karena mengurangi data pelatihan yang masih berguna.` [Rule 2.1]
- [x] LINE 1297-1299: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,4702 pada data uji, lebih rendah dari Qwen2-VL-7B penuh (Eksperimen 158, 0,5041), mengindikasikan bahwa MATCHA mengalami \textit{overfitting} atau menghasilkan \textit{caption} yang kurang sesuai untuk tugas ini.` [Rule 2.1]
- [x] LINE 1362-1363: remove sentence `Hasil eksperimen menunjukkan QWK sebesar 0,5066 pada data uji, tertinggi di antara seluruh eksperimen Pendekatan B pada data penuh.` [Rule 2.1]
- [x] LINE 1557-1564: remove QWK prose block after tab:exp-pend-b (entire result-discussion paragraph) [Rule 2.1]

### Section 3.3 — Alur Tugas Akhir

**Rule 1.6 — Fungsi kerugian (1 violation)**

- [x] LINE 1857 (table cell): `Ablasi Fungsi Kerugian` → `Ablasi \textit{Loss Function}` [Rule 1.6]

*Checked and clean: no em dash, no colon violations, no `multi-\textit{trait}`, no model name partial italics outside 3.2.*

---

## Chapter 4 — BAB IV Hasil dan Analisis

**Rule 1.3 — Partial model name italics / incomplete English compound term (6 violations)**

- [x] LINE 320 (subsection title): `BERT-\textit{base}` → `BERT-base` [Rule 1.3]
- [x] LINE 329 (subsection title): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 429 (prose): `BERT-\textit{base}` and `RoBERTa-\textit{base}` → `BERT-base` and `RoBERTa-base` [Rule 1.3]
- [x] LINE 457 (prose): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 475 (table): `RoBERTa-\textit{base}` → `RoBERTa-base` [Rule 1.3]
- [x] LINE 560 (table): `\textit{Composite}` → `\textit{Composite chart}` (incomplete compound term; all other chart types in same table use full "chart" suffix) [Rule 1.3]

*Checked and clean: no em dash, no colon violations, no "fungsi kerugian", no `multi-\textit{trait}`, QWK in prose is correct (BAB IV, not BAB III).*

## Chapter 5 — BAB V Kesimpulan

*No violations found. Checked: no em dash, no colon violations, no partial model name italics, no "fungsi kerugian", no `multi-\textit{trait}`, English terms properly italicized throughout.*
