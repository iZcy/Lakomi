# References

All references used in the thesis. Grouped by year (newest first).
Links marked ⚠️ were not in the bib file and need manual verification.

---

## 2025

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `su2025` | Su, Jiamin et al. | EssayJudge: A Multi-Granular Benchmark for Assessing AES Capabilities of MLLMs | ACL 2025 Findings | https://aclanthology.org/2025.findings-acl.329/ |
| `gold2025` | Gold, Ronen G. | A BERT-ResNet Cross-Attention Fusion Network and Modality Utilization Assessment for Multimodal Sentiment Classification | RIT M.S. Thesis 2025 | https://repository.rit.edu/theses/12090/ · PDF: C:\Outpost\Skripsi\Research 3\Papers\A BERT-ResNet Cross-Attention Fusion Network and Modality Utiliza.pdf |

---

## 2024

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `wang2024qwen2vl` | Wang, Peng et al. | Qwen2-VL: Enhancing Vision-Language Model's Perception of the World at Any Resolution | arXiv | https://arxiv.org/abs/2409.12191 |
| `bursztyn2024` | Bursztyn, Victor et al. | Representing Charts as Text for Language Models: An In-Depth Study of Question Answering for Bar Charts | IEEE VIS 2024 | https://doi.org/10.1109/VIS55277.2024.00061 · PDF: C:\Outpost\Skripsi\Research 3\Papers\Representing_Charts_as_Text_for_Language_Models_An_In-Depth_Study_of_Question_Answering_for_Bar_Charts.pdf |
| `sun2024` | Sun, Kun & Wang, Rong | Automatic Essay Multi-dimensional Scoring with Fine-tuning and Multiple Regression | arXiv | https://arxiv.org/abs/2406.01198 |
| `zhou2024` | Zhou, Pan et al. | Towards Understanding Convergence and Generalization of AdamW | IEEE TPAMI 2024, Vol.46(9), pp.6486–6493 | https://doi.org/10.1109/TPAMI.2024.3382294 |

---

## 2023

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `openai2023` | OpenAI | GPT-4 Technical Report | arXiv | https://arxiv.org/abs/2303.08774 |
| `bai2023qwen` | Bai, Jinze et al. | Qwen Technical Report | arXiv | https://arxiv.org/abs/2309.16609 |
| `liu2023deplot` | Liu, Fangyu et al. | DePlot: One-shot Visual Language Reasoning by Plot-to-Table Translation | ACL 2023 Findings | https://aclanthology.org/2023.findings-acl.660/ |
| `liu2023matcha` | Liu, Fangyu et al. | MatCha: Enhancing Visual Language Pretraining with Math Reasoning and Chart Derendering | ACL 2023 | https://aclanthology.org/2023.acl-long.201/ |
| `lee2023` | Lee, Kenton et al. | Pix2Struct: Screenshot Parsing as Pretraining for Visual Language Understanding | ICML 2023 | https://arxiv.org/abs/2210.03347 |
| `dettmers2023` | Dettmers, Tim et al. | QLoRA: Efficient Finetuning of Quantized LLMs | NeurIPS 2023 | https://arxiv.org/abs/2305.14314 |
| `akhila2023` | Akhila, N et al. | Comparative Study of Bert Models and Roberta in Transformer based Question Answering | IEEE CONIT 2023 | https://doi.org/10.1109/CONIT59222.2023.10205622 · PDF: C:\Outpost\Skripsi\Research 3\Papers\Comparative_Study_of_Bert_Models_and_Roberta_in_Transformer_based_Question_Answering.pdf |
| `do2023` | Do, Heejin et al. | Prompt- and Trait Relation-aware Cross-prompt Essay Trait Scoring (ProTACT) | ACL Findings 2023, pp. 1538–1551 | https://aclanthology.org/2023.findings-acl.98/ |
| `pereira2023` | Pereira, Luis Manuel et al. | A Comparative Analysis of Early and Late Fusion for the Multimodal Two-Class Problem | IEEE Access 2023 | https://doi.org/10.1109/ACCESS.2023.3296098 · PDF: C:\Outpost\Skripsi\Research 3\Papers\Paper_1_A_Comparative_Analysis_of_Early_and_Late_Fusion_for_the_Multimodal_Two-Class_Problem.pdf |

---

## 2022

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `hu2022` | Hu, Edward J. et al. | LoRA: Low-Rank Adaptation of Large Language Models | ICLR 2022 | https://arxiv.org/abs/2106.09685 |
| `zhai2022` | Zhai, Xiaohua et al. | Scaling Vision Transformers | CVPR 2022 | https://arxiv.org/abs/2106.04560 |

---

## 2021

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `dosovitskiy2021` | Dosovitskiy, Alexey et al. | An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale (ViT) | ICLR 2021 | https://arxiv.org/abs/2010.11929 |
| `wang2021celft` | Wang, Yifan et al. | CELFT: Combine Early and Late Fusion Together for Image-Text Matching | IEEE ICME 2021 | https://doi.org/10.1109/ICME51207.2021.9428201 · PDF: C:\Outpost\Skripsi\Research 3\Papers\Paper_2_Combine_Early_and_Late_Fusion_Together_A_Hybrid_Fusion_Framework_for_Image-Text_Matching.pdf |
| `kumar2021` | Kumar, Puneet et al. | Hybrid Fusion Based Approach for Multimodal Emotion Recognition with Insufficient Labeled Data | IEEE ICIP 2021 | https://doi.org/10.1109/ICIP42928.2021.9506714 · PDF: C:\Outpost\Skripsi\Research 3\Papers\Paper_4_Hybrid_Fusion_Based_Approach_for_Multimodal_Emotion_Recognition_with_Insufficient_Labeled_Data.pdf |

---

## 2020

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `brown2020` | Brown, Tom et al. | Language Models are Few-Shot Learners (GPT-3) | NeurIPS 2020 | https://arxiv.org/abs/2005.14165 |

---

## 2019

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `liu2019roberta` | Liu, Yinhan et al. | RoBERTa: A Robustly Optimized BERT Pretraining Approach | arXiv | https://arxiv.org/abs/1907.11692 |
| `devlin2019` | Devlin, Jacob et al. | BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding | NAACL 2019 | https://aclanthology.org/N19-1423/ |

---

## 2017

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `vaswani2017` | Vaswani, Ashish et al. | Attention Is All You Need (Transformer) | NeurIPS 2017 | https://arxiv.org/abs/1706.03762 |
| `ruder2017` | Ruder, Sebastian | An Overview of Multi-Task Learning in Deep Neural Networks | arXiv | https://arxiv.org/abs/1706.05098 |

---

## 2016

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `he2016` | He, Kaiming et al. | Deep Residual Learning for Image Recognition (ResNet) | CVPR 2016 | https://arxiv.org/abs/1512.03385 |
| `sennrich2016` | Sennrich, Rico et al. | Neural Machine Translation of Rare Words with Subword Units (BPE) | ACL 2016 | https://aclanthology.org/P16-1162/ |
| `hendrycks2016` | Hendrycks, Dan & Gimpel, Kevin | Gaussian Error Linear Units (GELUs) | arXiv | https://arxiv.org/abs/1606.08415 |
| `goodfellow2016` | Goodfellow, Ian et al. | Deep Learning (book) | MIT Press | https://www.deeplearningbook.org/ |

---

## 2015

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `lecun2015` | LeCun, Yann et al. | Deep Learning | Nature 2015 | https://doi.org/10.1038/nature14539 |
| `kingma2015` | Kingma, Diederik P. & Ba, Jimmy | Adam: A Method for Stochastic Optimization | ICLR 2015 | https://arxiv.org/abs/1412.6980 |
| `bahdanau2015` | Bahdanau, Dzmitry et al. | Neural Machine Translation by Jointly Learning to Align and Translate | ICLR 2015 | https://arxiv.org/abs/1409.0473 |

---

## 2014

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `srivastava2014` | Srivastava, Nitish et al. | Dropout: A Simple Way to Prevent Neural Networks from Overfitting | JMLR 2014 | https://jmlr.org/papers/v15/srivastava14a.html |

---

## 2013

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `shermis2013` | Shermis, Mark D. & Burstein, Jill | Handbook of Automated Essay Evaluation (book) | Routledge | ⚠️ Book — no URL |

---

## 2012

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `krizhevsky2012` | Krizhevsky, Alex et al. | ImageNet Classification with Deep CNNs (AlexNet) | NeurIPS 2012 | https://papers.nips.cc/paper_files/paper/2012/hash/c399862d3b9d6b76c8436e924a68c45b-Abstract.html |

---

## 2011

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `ngiam2011` | Ngiam, Jiquan et al. | Multimodal Deep Learning | ICML 2011 | https://icml.cc/2011/papers/399_icmlpaper.pdf |
| `yannakoudakis2011` | Yannakoudakis, Helen et al. | A New Dataset and Method for Automatically Grading ESOL Texts | ACL 2011 | https://aclanthology.org/P11-1019/ |

---

## 2010

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `pan2010` | Pan, Sinno Jialin & Yang, Qiang | A Survey on Transfer Learning | IEEE TKDE 2010 | https://doi.org/10.1109/TKDE.2009.191 |

---

## 2003

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `burstein2003` | Burstein, Jill | The E-rater Scoring Engine: Automated Essay Scoring with NLP | Book chapter | ⚠️ Book chapter — no URL |

---

## 1998

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `lecun1998` | LeCun, Yann et al. | Gradient-Based Learning Applied to Document Recognition (LeNet) | Proceedings of IEEE | https://doi.org/10.1109/5.726791 |
| `landauer1998` | Landauer, Thomas K. et al. | An Introduction to Latent Semantic Analysis | Discourse Processes | https://doi.org/10.1080/01638539809545028 |

---

## 1997

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `caruana1997` | Caruana, Rich | Multitask Learning | Machine Learning | https://doi.org/10.1023/A:1007379606734 |

---

## 1988

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `cohen1988` | Cohen, Jacob | Statistical Power Analysis for the Behavioral Sciences (book) | Lawrence Erlbaum | ⚠️ Book — no URL |

---

## 1986

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `rumelhart1986` | Rumelhart, David E. et al. | Learning Representations by Back-propagating Errors | Nature 1986 | https://doi.org/10.1038/323533a0 |

---

## 1977

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `landiskoch1977` | Landis, J. Richard & Koch, Gary G. | The Measurement of Observer Agreement for Categorical Data (Kappa) | Biometrics | https://doi.org/10.2307/2529310 |

---

## 1968

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `cohen1968` | Cohen, Jacob | Weighted Kappa: Nominal Scale Agreement Provision for Scaled Disagreement | Psychological Bulletin | https://doi.org/10.1037/h0026256 |

---

## 1966

| Key | Authors | Title | Venue | Link |
|-----|---------|-------|-------|------|
| `page1966` | Page, Ellis Batten | The Imminence of Grading Essays by Computer | Phi Delta Kappan | ⚠️ Old journal — no direct URL |

---

## Entries Needing Manual URL Verification

| Key | Title |
|-----|-------|
| `page1966` | The Imminence of Grading Essays by Computer |
