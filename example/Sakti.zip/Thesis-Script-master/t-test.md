# RQ6 — Significance Test Results (Paired T-Test)

**Test:** Paired t-test per trait — is the difference between predictions and ground truth statistically significant?  
**α Bonferroni** = 0.05 / 10 traits = **0.005**  
**n_test** = 159 samples (seeded 70/15/15 split, seed=42)  
**Interpretation:** Not significant = predictions statistically consistent with ground truth (good). Significant = systematic bias detected (bad).

---

## Exp033 — RoBERTa + ResNet18 Late Fusion (Pendekatan A best)

| Trait | Code | QWK | Mean diff | t-stat | p-value | Significance |
|---|---|---|---|---|---|---|
| argument_clarity | AC | 0.271 | +0.0791 | 1.864 | 6.42e-02 | Not significant |
| justifying_persuasiveness | JP | 0.463 | +0.1264 | 3.425 | 7.83e-04 | **Significant** |
| organizational_structure | OS | 0.622 | +0.1582 | 4.288 | 3.12e-05 | **Significant** |
| coherence | CH | 0.579 | +0.1682 | 4.741 | 4.72e-06 | **Significant** |
| essay_length | EL | 0.443 | +0.1044 | 2.194 | 2.97e-02 | Not significant |
| grammatical_accuracy | GA | 0.591 | +0.1148 | 2.533 | 1.23e-02 | Not significant |
| grammatical_diversity | GD | 0.586 | +0.1000 | 2.497 | 1.35e-02 | Not significant |
| lexical_accuracy | LA | 0.581 | +0.1104 | 2.655 | 8.75e-03 | Not significant |
| lexical_diversity | LD | 0.542 | +0.0873 | 2.428 | 1.63e-02 | Not significant |
| punctuation_accuracy | PA | 0.446 | +0.0971 | 1.920 | 5.67e-02 | Not significant |
| **Average** | | **0.513** | | | | **7/10 not significant** |

**Significant bias detected:** JP, OS, CH (systematic overestimation).

---

## Exp103 — DePlot+Qwen7B bar+pie, Dual RoBERTa (Pendekatan B, T2T)

| Trait | Code | QWK | Mean diff | t-stat | p-value | Significance |
|---|---|---|---|---|---|---|
| argument_clarity | AC | 0.276 | +0.0420 | 1.051 | 2.95e-01 | Not significant |
| justifying_persuasiveness | JP | 0.493 | +0.1274 | 3.523 | 5.58e-04 | **Significant** |
| organizational_structure | OS | 0.542 | +0.0748 | 1.883 | 6.16e-02 | Not significant |
| coherence | CH | 0.560 | +0.1184 | 3.163 | 1.87e-03 | **Significant** |
| essay_length | EL | 0.486 | +0.0123 | 0.254 | 8.00e-01 | Not significant |
| grammatical_accuracy | GA | 0.576 | +0.0664 | 1.419 | 1.58e-01 | Not significant |
| grammatical_diversity | GD | 0.573 | +0.0463 | 1.128 | 2.61e-01 | Not significant |
| lexical_accuracy | LA | 0.562 | +0.0684 | 1.684 | 9.41e-02 | Not significant |
| lexical_diversity | LD | 0.520 | +0.0848 | 2.223 | 2.77e-02 | Not significant |
| punctuation_accuracy | PA | 0.439 | +0.1142 | 2.232 | 2.70e-02 | Not significant |
| **Average** | | **0.503** | | | | **8/10 not significant** |

**Significant bias detected:** JP, CH (systematic overestimation).

---

## Side-by-Side Comparison

| Trait | Code | Exp033 QWK | Exp033 | Exp103 QWK | Exp103 |
|---|---|---|---|---|---|
| argument_clarity | AC | 0.271 | Not sig. | 0.276 | Not sig. |
| justifying_persuasiveness | JP | 0.463 | **Sig.** | 0.493 | **Sig.** |
| organizational_structure | OS | 0.622 | **Sig.** | 0.542 | Not sig. |
| coherence | CH | 0.579 | **Sig.** | 0.560 | **Sig.** |
| essay_length | EL | 0.443 | Not sig. | 0.486 | Not sig. |
| grammatical_accuracy | GA | 0.591 | Not sig. | 0.576 | Not sig. |
| grammatical_diversity | GD | 0.586 | Not sig. | 0.573 | Not sig. |
| lexical_accuracy | LA | 0.581 | Not sig. | 0.562 | Not sig. |
| lexical_diversity | LD | 0.542 | Not sig. | 0.520 | Not sig. |
| punctuation_accuracy | PA | 0.446 | Not sig. | 0.439 | Not sig. |
| **Average** | | **0.513** | 3 sig. | **0.503** | 2 sig. |

---

## Key Observations

- All mean diffs are **positive** — both models consistently **overestimate** scores across all traits.
- **JP and CH** are significant in both models — persistent systematic bias regardless of architecture, likely because subjective content-based traits are harder to calibrate.
- **OS** is significant only in Exp033 (fusion) but not Exp103 (T2T) — T2T reduces bias on organizational structure.
- **8 traits in Exp103** and **7 traits in Exp033** show no significant difference from ground truth after Bonferroni correction — predictions are statistically consistent with human annotations for most traits.
- Exp103 (T2T) has fewer significant biases (2/10) vs Exp033 (fusion, 3/10) — T2T pipeline is slightly less biased overall.
