"""Generate fusion architecture diagrams for chapter-2."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import to_rgba
import os

OUT = os.path.dirname(os.path.abspath(__file__))

EC = '#666666'
FC = '#F5F5F5'
LW = 0.8
FS = 9.5
BH = 1.1


def make_fig(w, h, xr, yr):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, xr)
    ax.set_ylim(0, yr)
    ax.axis('off')
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    return fig, ax


def bx(ax, cx, cy, bw, bh, txt, alpha=1.0):
    fc = to_rgba(FC, alpha)
    p = FancyBboxPatch((cx - bw / 2, cy - bh / 2), bw, bh,
                       boxstyle="round,pad=0.08",
                       fc=fc, ec=EC, lw=LW, zorder=2)
    ax.add_patch(p)
    ax.text(cx, cy, txt, ha='center', va='center', fontsize=FS,
            fontweight='bold', fontfamily='Times New Roman',
            multialignment='center', linespacing=1.4, zorder=3)


def ar(ax, x1, y1, x2, y2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=EC, lw=LW,
                                shrinkA=0, shrinkB=0),
                zorder=4)


def merge_v(ax, lx, ly, rx, ry, tx, ty):
    """Orthogonal V-merge: two sources → shared horizontal bus → arrow to target."""
    mid_y = (min(ly, ry) + ty) / 2
    ax.plot([lx, lx], [ly, mid_y], '-', color=EC, lw=LW, zorder=4)
    ax.plot([rx, rx], [ry, mid_y], '-', color=EC, lw=LW, zorder=4)
    ax.plot([lx, tx], [mid_y, mid_y], '-', color=EC, lw=LW, zorder=4)
    ax.plot([rx, tx], [mid_y, mid_y], '-', color=EC, lw=LW, zorder=4)
    ar(ax, tx, mid_y, tx, ty)


def three_merge_v(ax, lx, ly, cx, cy, rx, ry, tx, ty):
    """Three sources → shared horizontal bus → arrow to target."""
    mid_y = (min(ly, cy, ry) + ty) / 2
    for sx, sy in [(lx, ly), (cx, cy), (rx, ry)]:
        ax.plot([sx, sx], [sy, mid_y], '-', color=EC, lw=LW, zorder=4)
    ax.plot([lx, rx], [mid_y, mid_y], '-', color=EC, lw=LW, zorder=4)
    ar(ax, tx, mid_y, tx, ty)


def cap(ax, cx, cy, txt):
    ax.text(cx, cy, txt, ha='center', va='center', fontsize=8,
            fontstyle='italic', fontfamily='Times New Roman')


# ── 1. EARLY FUSION ──────────────────────────────────────────────────────────
def make_early():
    fig, ax = make_fig(5.5, 7.5, 11.0, 13.0)
    LX, RX, MX = 2.8, 8.2, 5.5
    y = [11.5, 9.0, 6.5, 4.0, 1.5]

    bx(ax, LX, y[0], 4.0, BH, "Masukan 1\n(Teks)")
    bx(ax, RX, y[0], 4.0, BH, "Masukan 2\n(Gambar)")
    merge_v(ax, LX, y[0] - BH / 2, RX, y[0] - BH / 2, MX, y[1] + BH / 2)
    bx(ax, MX, y[1], 5.5, BH, "Penggabungan Awal\n(Concat Input)")
    ar(ax, MX, y[1] - BH / 2, MX, y[2] + BH / 2)
    bx(ax, MX, y[2], 4.5, BH, "Encoder Bersama")
    ar(ax, MX, y[2] - BH / 2, MX, y[3] + BH / 2)
    bx(ax, MX, y[3], 4.5, BH, "Scoring Head\n(Output)")
    cap(ax, MX, y[4], "10 Skor Trait  (skala 0–5)")

    fig.savefig(f"{OUT}/ch2_early_fusion.png", dpi=150,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print("Early done")


# ── 2. INTERMEDIATE FUSION ───────────────────────────────────────────────────
def make_intermediate():
    fig, ax = make_fig(5.5, 7.5, 11.0, 13.0)
    LX, RX, MX = 2.8, 8.2, 5.5
    y = [11.5, 9.0, 6.5, 4.0, 1.5]

    bx(ax, LX, y[0], 4.0, BH, "Masukan 1\n(Teks)")
    bx(ax, RX, y[0], 4.0, BH, "Masukan 2\n(Gambar)")
    ar(ax, LX, y[0] - BH / 2, LX, y[1] + BH / 2)
    ar(ax, RX, y[0] - BH / 2, RX, y[1] + BH / 2)
    bx(ax, LX, y[1], 4.0, BH, "Encoder 1")
    bx(ax, RX, y[1], 4.0, BH, "Encoder 2")
    merge_v(ax, LX, y[1] - BH / 2, RX, y[1] - BH / 2, MX, y[2] + BH / 2)
    bx(ax, MX, y[2], 5.5, BH, "Mekanisme Fusion\n(Cross-Attention)")
    ar(ax, MX, y[2] - BH / 2, MX, y[3] + BH / 2)
    bx(ax, MX, y[3], 4.5, BH, "Scoring Head\n(Output)")
    cap(ax, MX, y[4], "10 Skor Trait  (skala 0–5)")

    fig.savefig(f"{OUT}/ch2_intermediate_fusion.png", dpi=150,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print("Intermediate done")


# ── 3. LATE FUSION ───────────────────────────────────────────────────────────
def make_late():
    fig, ax = make_fig(5.5, 9.0, 11.0, 16.5)
    LX, RX, MX = 2.8, 8.2, 5.5
    y = [15.0, 12.0, 9.0, 6.0, 3.0, 0.8]

    bx(ax, LX, y[0], 4.0, BH, "Masukan 1\n(Teks)")
    bx(ax, RX, y[0], 4.0, BH, "Masukan 2\n(Gambar)")
    ar(ax, LX, y[0] - BH / 2, LX, y[1] + BH / 2)
    ar(ax, RX, y[0] - BH / 2, RX, y[1] + BH / 2)
    bx(ax, LX, y[1], 4.0, BH, "Encoder 1")
    bx(ax, RX, y[1], 4.0, BH, "Encoder 2")
    ar(ax, LX, y[1] - BH / 2, LX, y[2] + BH / 2)
    ar(ax, RX, y[1] - BH / 2, RX, y[2] + BH / 2)
    bx(ax, LX, y[2], 4.0, BH, "Representasi 1", alpha=0.6)
    bx(ax, RX, y[2], 4.0, BH, "Representasi 2", alpha=0.6)
    merge_v(ax, LX, y[2] - BH / 2, RX, y[2] - BH / 2, MX, y[3] + BH / 2)
    bx(ax, MX, y[3], 5.5, BH, "Concat (Gabungan Akhir)")
    ar(ax, MX, y[3] - BH / 2, MX, y[4] + BH / 2)
    bx(ax, MX, y[4], 4.5, BH, "Scoring Head\n(Output)")
    cap(ax, MX, y[5], "10 Skor Trait  (skala 0–5)")

    fig.savefig(f"{OUT}/ch2_late_fusion.png", dpi=150,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print("Late done")


# ── 4. HYBRID FUSION ─────────────────────────────────────────────────────────
def make_hybrid():
    fig, ax = make_fig(7.0, 10.0, 14.0, 18.5)
    # Three encoder columns; inputs positioned above left/right encoders
    LX, CX, RX, MX = 2.0, 7.0, 12.0, 7.0
    ILX, IRX = 3.5, 10.5  # input box centers

    y = [17.0, 13.5, 10.5, 7.5, 4.5, 2.0, 0.4]

    # Inputs
    bx(ax, ILX, y[0], 4.5, BH, "Masukan 1\n(Teks)")
    bx(ax, IRX, y[0], 4.5, BH, "Masukan 2\n(Gambar)")

    # Late path: outer arrows from input sides to outer encoders
    ar(ax, ILX - 0.8, y[0] - BH / 2, LX, y[1] + BH / 2)
    ar(ax, IRX + 0.8, y[0] - BH / 2, RX, y[1] + BH / 2)

    # Early path: inner lines from input inner edges → horizontal bus → center encoder
    mid_y_e = (y[0] - BH / 2 + y[1] + BH / 2) / 2
    ax.plot([ILX + 0.8, ILX + 0.8], [y[0] - BH / 2, mid_y_e], '-', color=EC, lw=LW, zorder=4)
    ax.plot([IRX - 0.8, IRX - 0.8], [y[0] - BH / 2, mid_y_e], '-', color=EC, lw=LW, zorder=4)
    ax.plot([ILX + 0.8, CX], [mid_y_e, mid_y_e], '-', color=EC, lw=LW, zorder=4)
    ax.plot([IRX - 0.8, CX], [mid_y_e, mid_y_e], '-', color=EC, lw=LW, zorder=4)
    ar(ax, CX, mid_y_e, CX, y[1] + BH / 2)

    # Encoders
    bx(ax, LX, y[1], 3.2, BH, "Encoder 1\n(Jalur Late)")
    bx(ax, CX, y[1], 3.8, BH, "Encoder Bersama\n(Jalur Early)")
    bx(ax, RX, y[1], 3.2, BH, "Encoder 2\n(Jalur Late)")

    ar(ax, LX, y[1] - BH / 2, LX, y[2] + BH / 2)
    ar(ax, CX, y[1] - BH / 2, CX, y[2] + BH / 2)
    ar(ax, RX, y[1] - BH / 2, RX, y[2] + BH / 2)

    # Representations
    bx(ax, LX, y[2], 3.2, BH, "Repr. 1", alpha=0.6)
    bx(ax, CX, y[2], 3.8, BH, "Repr. Early", alpha=0.6)
    bx(ax, RX, y[2], 3.2, BH, "Repr. 2", alpha=0.6)

    # Three-to-one merge → Hybrid combine box
    three_merge_v(ax, LX, y[2] - BH / 2, CX, y[2] - BH / 2, RX, y[2] - BH / 2,
                  MX, y[3] + BH / 2)

    bx(ax, MX, y[3], 6.5, BH, "Gabung Akhir (Hybrid)")
    ar(ax, MX, y[3] - BH / 2, MX, y[4] + BH / 2)
    bx(ax, MX, y[4], 5.0, BH, "Scoring Head\n(Output)")
    cap(ax, MX, y[5], "10 Skor Trait  (skala 0–5)")

    fig.savefig(f"{OUT}/ch2_hybrid_fusion.png", dpi=150,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print("Hybrid done")


make_early()
make_intermediate()
make_late()
make_hybrid()
print("All diagrams generated.")
