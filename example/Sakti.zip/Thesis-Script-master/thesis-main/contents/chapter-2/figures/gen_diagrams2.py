"""Additional diagrams for chapter-2 sections 2.2.5, 2.2.12-17, 2.2.27."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Circle
from matplotlib.colors import to_rgba
import os

OUT = os.path.dirname(os.path.abspath(__file__))
EC = '#666666'
FC = '#F5F5F5'
LW = 0.8
FS = 9.5
FA = 'Times New Roman'
BH = 1.05


def make_fig(w, h, xr, yr):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, xr)
    ax.set_ylim(0, yr)
    ax.axis('off')
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    return fig, ax


def bx(ax, cx, cy, bw, bh, txt, alpha=1.0, fs=None, lw=None):
    fc = to_rgba(FC, alpha)
    p = FancyBboxPatch((cx - bw / 2, cy - bh / 2), bw, bh,
                       boxstyle="round,pad=0.08", fc=fc, ec=EC,
                       lw=lw if lw is not None else LW, zorder=2)
    ax.add_patch(p)
    ax.text(cx, cy, txt, ha='center', va='center', fontsize=fs or FS,
            fontweight='bold', fontfamily=FA,
            multialignment='center', linespacing=1.4, zorder=3)


def ar(ax, x1, y1, x2, y2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=EC, lw=LW,
                                shrinkA=0, shrinkB=0), zorder=4)


def ln(ax, x1, y1, x2, y2, lw=None):
    ax.plot([x1, x2], [y1, y2], '-', color=EC, lw=lw or LW, zorder=4)


def plus_circle(ax, cx, cy, r=0.22):
    c = Circle((cx, cy), r, fc='white', ec=EC, lw=LW, zorder=5)
    ax.add_patch(c)
    ax.text(cx, cy, '+', ha='center', va='center', fontsize=9,
            fontfamily=FA, fontweight='bold', zorder=6)


# -- 1. JST (2.2.5): feedforward neural network --------------------------------
def make_jst():
    fig, ax = make_fig(5.2, 5.5, 10.4, 10.0)
    r = 0.30

    ix, hx, ox = 1.5, 5.2, 8.9
    iy = [8.0, 6.0, 4.0]
    hy = [8.5, 7.0, 5.5, 4.0]
    oy = [7.3, 5.0]

    # Connections (thin)
    for y1 in iy:
        for y2 in hy:
            ax.plot([ix + r, hx - r], [y1, y2], '-', color='#cccccc', lw=0.45, zorder=1)
    for y1 in hy:
        for y2 in oy:
            ax.plot([hx + r, ox - r], [y1, y2], '-', color='#cccccc', lw=0.45, zorder=1)

    # Nodes
    for y in iy:
        ax.add_patch(Circle((ix, y), r, fc=FC, ec=EC, lw=LW, zorder=3))
        ax.text(ix, y, r'$x$', ha='center', va='center', fontsize=9,
                fontfamily='serif', fontstyle='italic', zorder=4)
    for y in hy:
        ax.add_patch(Circle((hx, y), r, fc=to_rgba(FC, 0.7), ec=EC, lw=LW, zorder=3))
        ax.text(hx, y, r'$h$', ha='center', va='center', fontsize=9,
                fontfamily='serif', fontstyle='italic', zorder=4)
    for y in oy:
        ax.add_patch(Circle((ox, y), r, fc=FC, ec=EC, lw=LW, zorder=3))
        ax.text(ox, y, r'$y$', ha='center', va='center', fontsize=9,
                fontfamily='serif', fontstyle='italic', zorder=4)

    # Column labels
    for x, lbl in [(ix, "Lapisan Input"), (hx, "Lapisan Tersembunyi"), (ox, "Lapisan Keluaran")]:
        ax.text(x, 9.5, lbl, ha='center', va='center', fontsize=9,
                fontweight='bold', fontfamily=FA)

    # Activation labels
    ax.text(hx, 3.2, "Aktivasi: ReLU / GELU", ha='center', va='center',
            fontsize=8, fontstyle='italic', fontfamily=FA, color='#555555')
    ax.text(ox, 4.1, "Aktivasi: Sigmoid", ha='center', va='center',
            fontsize=8, fontstyle='italic', fontfamily=FA, color='#555555')

    # Flow arrows between column labels
    ar(ax, ix + 0.5, 9.5, hx - 0.8, 9.5)
    ar(ax, hx + 0.6, 9.5, ox - 0.6, 9.5)

    fig.savefig(f"{OUT}/ch2_jst.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("JST done")


# -- 2. Transformer Encoder (2.2.12) -------------------------------------------
def make_transformer():
    fig, ax = make_fig(4.5, 9.5, 9.0, 19.0)
    cx = 4.5

    bx(ax, cx, 17.8, 8.0, BH, "Masukan + Positional Encoding")
    ar(ax, cx, 17.8 - BH / 2, cx, 16.5 + BH / 2)

    enc_rect = FancyBboxPatch((0.4, 5.2), 8.2, 11.5,
                              boxstyle="round,pad=0.1",
                              fc='none', ec='#999999', lw=0.8,
                              linestyle='dashed', zorder=1)
    ax.add_patch(enc_rect)
    ax.text(8.8, 11.5, 'xN', ha='center', va='center', fontsize=10,
            fontweight='bold', fontfamily=FA, color='#444444')

    bx(ax, cx, 16.5, 8.0, BH, "Multi-Head Self-Attention")

    RBP = 8.0
    ln(ax, cx + 4.0, 17.3, RBP, 17.3)
    ln(ax, RBP, 17.3, RBP, 14.8)
    ar(ax, RBP, 14.8, cx + 3.8, 14.8)

    ar(ax, cx, 16.5 - BH / 2, cx, 15.5 + BH / 2)
    plus_circle(ax, cx, 15.1)
    ar(ax, cx, 14.9, cx, 14.3 + BH / 2)
    bx(ax, cx, 14.0, 6.0, 0.85, "Add & Norm", fs=9)

    ar(ax, cx, 14.0 - 0.43, cx, 12.8 + BH / 2)
    bx(ax, cx, 12.8, 8.0, BH, "Feed-Forward Network")

    ln(ax, cx + 3.0, 13.8, RBP, 13.8)
    ln(ax, RBP, 13.8, RBP, 11.3)
    ar(ax, RBP, 11.3, cx + 3.8, 11.3)

    ar(ax, cx, 12.8 - BH / 2, cx, 11.7 + BH / 2)
    plus_circle(ax, cx, 11.3)
    ar(ax, cx, 11.1, cx, 10.5 + BH / 2)
    bx(ax, cx, 10.2, 6.0, 0.85, "Add & Norm", fs=9)

    ar(ax, cx, 10.2 - 0.43, cx, 9.3 + BH / 2)
    bx(ax, cx, 8.8, 6.5, BH, "Lapisan Berikutnya / Output")

    fig.savefig(f"{OUT}/ch2_transformer.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("Transformer done")


# -- 3. Attention Mechanism (2.2.13) -------------------------------------------
def make_attention():
    fig, ax = make_fig(4.5, 7.0, 9.0, 14.0)

    QX, KX, VX = 2.0, 4.5, 7.0
    MX = 4.5

    for x, lbl in [(QX, 'Q (Query)'), (KX, 'K (Key)'), (VX, 'V (Value)')]:
        bx(ax, x, 12.8, 2.5, 0.9, lbl, fs=9)

    ar(ax, QX, 12.8 - 0.45, QX, 11.3 + 0.45)
    ar(ax, KX, 12.8 - 0.45, KX, 11.3 + 0.45)

    bx(ax, (QX + KX) / 2, 11.3, 4.8, 0.9, "Q x K^T  (MatMul)", fs=9)

    ar(ax, (QX + KX) / 2, 11.3 - 0.45, MX, 9.8 + 0.45)
    bx(ax, MX, 9.8, 5.0, 0.9, "Skala  / sqrt(dk)", fs=9)

    ar(ax, MX, 9.8 - 0.45, MX, 8.3 + 0.45)
    bx(ax, MX, 8.3, 5.0, 0.9, "Softmax (Bobot Attention)", fs=9)

    ln(ax, VX, 12.35, VX, 6.8)
    ar(ax, VX, 6.8, MX + 2.8, 6.8)

    ar(ax, MX, 8.3 - 0.45, MX, 7.3 + 0.45)
    bx(ax, MX, 6.8, 5.0, 0.9, "Bobot x V  (MatMul)", fs=9)

    ar(ax, MX, 6.8 - 0.45, MX, 5.3 + 0.45)
    bx(ax, MX, 5.3, 5.0, 0.9, "Output Attention", fs=9)

    ax.text(MX, 4.0,
            r"$\mathrm{Attention}(Q,K,V)=\mathrm{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}}\right)V$",
            ha='center', va='center', fontsize=9, fontfamily=FA, zorder=3)

    fig.savefig(f"{OUT}/ch2_attention.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("Attention done")


# -- 4. BERT Architecture (2.2.14) ---------------------------------------------
def make_bert():
    fig, ax = make_fig(5.0, 7.0, 10.0, 14.5)
    cx = 5.0

    # Input tokens row -- tw=0.9, gap=0.45 so gap > 2*pad=0.16
    tokens = ['[CLS]', 'w1', 'w2', '...', 'wn', '[SEP]']
    tw, th, gap = 0.9, 0.75, 0.45
    n = len(tokens)
    total_w = n * tw + (n - 1) * gap
    x0 = cx - total_w / 2 + tw / 2
    for i, tok in enumerate(tokens):
        tx = x0 + i * (tw + gap)
        bx(ax, tx, 13.3, tw, th, tok, fs=8)
        if i < len(tokens) - 1:
            ar(ax, tx + tw / 2, 13.3, tx + tw / 2 + gap, 13.3)

    ar(ax, cx, 13.3 - th / 2, cx, 12.2 + BH / 2)
    bx(ax, cx, 12.2, 9.0, BH, "Token Embedding + Positional Encoding")

    ar(ax, cx, 12.2 - BH / 2, cx, 10.7 + BH * 1.1 / 2)
    bx(ax, cx, 10.7, 9.0, 1.3, "BERT Encoder\n(12 lapisan Transformer)", fs=9)

    ar(ax, cx, 10.7 - 1.3 / 2, cx, 9.0 + BH / 2)
    bx(ax, cx, 9.0, 7.0, BH, "Representasi [CLS]  (768-dim)", fs=9, alpha=0.7)

    ar(ax, cx, 9.0 - BH / 2, cx, 7.5 + BH / 2)
    bx(ax, cx, 7.5, 6.0, BH, "Scoring Head (FC)", fs=9)

    ar(ax, cx, 7.5 - BH / 2, cx, 6.0 + BH / 2)
    bx(ax, cx, 6.0, 6.5, BH, "10 Skor Trait  (Sigmoid x 5)")

    ax.text(9.5, 10.7, "Pre-training:\nMLM + NSP", ha='center', va='center',
            fontsize=7.5, fontfamily=FA, fontstyle='italic', color='#555555',
            multialignment='center', linespacing=1.4)

    fig.savefig(f"{OUT}/ch2_bert.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("BERT done")


# -- 5. RoBERTa vs BERT pretraining (2.2.15) -----------------------------------
def make_roberta():
    fig, ax = make_fig(6.5, 5.5, 13.0, 10.0)

    LX, RX = 3.25, 9.75
    bw = 5.5

    bx(ax, LX, 9.2, bw, 0.8, "BERT (Devlin et al., 2019)", fs=8.5)
    bx(ax, RX, 9.2, bw, 0.8, "RoBERTa (Liu et al., 2019)", fs=8.5)

    bert_items = "Objektif: MLM + NSP\nMasking: Statis\nData: 16 GB\nBatch: 256"
    rob_items  = "Objektif: MLM saja\nMasking: Dinamis\nData: 160 GB\nBatch: 8.000"
    bx(ax, LX, 7.0, bw, 3.2, bert_items, alpha=0.7, fs=8.5)
    bx(ax, RX, 7.0, bw, 3.2, rob_items, alpha=0.7, fs=8.5)

    ar(ax, LX, 7.0 - 1.6, 6.5 - 0.1, 4.7 + BH / 2)
    ar(ax, RX, 7.0 - 1.6, 6.5 + 0.1, 4.7 + BH / 2)

    bx(ax, 6.5, 4.7, 9.0, BH, "Fine-tuning pada Dataset EssayJudge (738 sampel)")

    ar(ax, 6.5, 4.7 - BH / 2, 6.5, 3.2 + BH / 2)
    bx(ax, 6.5, 3.2, 7.0, BH, "Prediksi 10 Skor Trait  (QWK)")

    fig.savefig(f"{OUT}/ch2_roberta.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("RoBERTa done")


# -- 6. CNN Pipeline (2.2.16) --------------------------------------------------
def make_cnn():
    fig, ax = make_fig(7.5, 3.5, 15.0, 7.0)

    stages = [
        (1.0, 4.5, 1.5, "Gambar\nInput"),
        (3.2, 3.8, 1.5, "Conv +\nReLU"),
        (5.2, 3.0, 1.3, "Max\nPooling"),
        (7.1, 2.5, 1.3, "Conv +\nReLU"),
        (9.0, 2.0, 1.3, "Max\nPooling"),
        (11.0, 1.5, 1.3, "Global\nAvg Pool"),
        (13.2, 1.0, 1.0, "Vektor\nFitur"),
    ]

    for i, (x, bh, bw, lbl) in enumerate(stages):
        bx(ax, x, 3.8, bw, bh, lbl, fs=8.5)
        if i < len(stages) - 1:
            nx = stages[i + 1][0]
            ar(ax, x + bw / 2, 3.8, nx - stages[i + 1][2] / 2, 3.8)

    dims = ['HxWx3', '56x56x64', '28x28x64', '14x14x128', '7x7x128', '512', '512d']
    for (x, _, bw, _), d in zip(stages, dims):
        ax.text(x, 2.4, d, ha='center', va='top', fontsize=7.5,
                fontfamily=FA, fontstyle='italic', color='#555555')

    fig.savefig(f"{OUT}/ch2_cnn.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("CNN done")


# -- 7. ResNet Residual Block (2.2.17) -----------------------------------------
def make_resnet():
    fig, ax = make_fig(4.0, 7.0, 8.0, 14.0)
    cx = 4.5

    bx(ax, cx, 13.0, 5.5, BH, "Masukan  x")

    ar(ax, cx, 13.0 - BH / 2, cx, 11.5 + BH / 2)
    bx(ax, cx, 11.5, 5.5, BH, "Conv 3x3 + BN + ReLU", alpha=0.7)

    ar(ax, cx, 11.5 - BH / 2, cx, 10.0 + BH / 2)
    bx(ax, cx, 10.0, 5.5, BH, "Conv 3x3 + BN", alpha=0.7)

    LBP = 1.0
    ln(ax, cx - 2.75, 12.5, LBP, 12.5)
    ln(ax, LBP, 12.5, LBP, 8.85)
    ar(ax, LBP, 8.85, cx - 1.5, 8.85)

    plus_circle(ax, cx, 8.85)
    ar(ax, cx, 8.63, cx, 7.7 + BH / 2)
    bx(ax, cx, 7.7, 5.5, BH, "ReLU")

    ar(ax, cx, 7.7 - BH / 2, cx, 6.2 + BH / 2)
    bx(ax, cx, 6.2, 5.5, BH, "Keluaran  H(x) = F(x) + x")

    ax.text(LBP - 0.3, 10.7, "Skip\nconn.", ha='right', va='center',
            fontsize=7.5, fontstyle='italic', fontfamily=FA, color='#555555',
            multialignment='center', linespacing=1.3)

    ax.text(cx, 5.0, r"$H(\mathbf{x}) = \mathcal{F}(\mathbf{x}) + \mathbf{x}$",
            ha='center', va='center', fontsize=9, fontfamily=FA, zorder=3)

    fig.savefig(f"{OUT}/ch2_resnet.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("ResNet done")


# -- 8. Scoring Head (2.2.27) --------------------------------------------------
def make_scoring_head():
    fig, ax = make_fig(4.5, 7.5, 9.0, 15.0)
    cx = 4.5

    bx(ax, cx, 13.8, 8.0, BH, "Representasi Gabungan  (d-dim)")

    ar(ax, cx, 13.8 - BH / 2, cx, 12.3 + BH / 2)
    bx(ax, cx, 12.3, 7.5, BH, "FC (768, ReLU) + Dropout")

    ar(ax, cx, 12.3 - BH / 2, cx, 10.8 + BH / 2)
    bx(ax, cx, 10.8, 7.5, BH, "FC (256, ReLU) + Dropout")

    ar(ax, cx, 10.8 - BH / 2, cx, 9.3 + BH / 2)
    bx(ax, cx, 9.3, 7.5, BH, "FC (N, Sigmoid x 5.0)")

    ar(ax, cx, 9.3 - BH / 2, cx, 7.8 + BH / 2)
    bx(ax, cx, 7.8, 7.5, BH, "s1, s2, ..., sN  (N Skor Trait)")

    dims = [
        (13.8, "d = 1280 (Pend.A)\nd = 1536 (Pend.B)"),
        (12.3, "768-dim"),
        (10.8, "256-dim"),
        (9.3,  "N-dim (N=10)"),
        (7.8,  "N skor dalam [0, 5]"),
    ]
    for y, txt in dims:
        ax.text(8.7, y, txt, ha='left', va='center', fontsize=7.5,
                fontstyle='italic', fontfamily=FA, color='#555555',
                multialignment='left', linespacing=1.3)

    fig.savefig(f"{OUT}/ch2_scoring_head.png", dpi=150, bbox_inches='tight', facecolor='white')
    plt.close()
    print("Scoring head done")


make_jst()
make_transformer()
make_attention()
make_bert()
make_roberta()
make_cnn()
make_resnet()
make_scoring_head()
print("All done.")
