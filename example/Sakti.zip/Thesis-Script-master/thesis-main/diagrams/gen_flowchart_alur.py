import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

# Color scheme from CLAUDE.md rule 10
C_GRAY   = ('#f5f5f5', '#666666')   # input / neutral
C_BLUE   = ('#dae8fc', '#6c8ebf')   # method / encoder
C_ORANGE = ('#ffe6cc', '#d79b00')   # process / intermediate
C_GREEN  = ('#d5e8d4', '#82b366')   # fusion / merge
C_RED    = ('#f8cecc', '#b85450')   # output / conclusion

FONT = 'Times New Roman'
FS_LABEL = 8.5
FS_SMALL = 7.5

fig, ax = plt.subplots(figsize=(7.5, 13))
ax.set_xlim(0, 10)
ax.set_ylim(0, 18)
ax.axis('off')

def oval(ax, cx, cy, w, h, label, fc, ec, fs=FS_LABEL, bold=False):
    ellipse = mpatches.Ellipse((cx, cy), w, h,
                                facecolor=fc, edgecolor=ec, linewidth=1.2, zorder=3)
    ax.add_patch(ellipse)
    weight = 'bold' if bold else 'normal'
    ax.text(cx, cy, label, ha='center', va='center',
            fontfamily=FONT, fontsize=fs, fontweight=weight, zorder=4)

def box(ax, cx, cy, w, h, lines, fc, ec, fs=FS_LABEL):
    x0, y0 = cx - w/2, cy - h/2
    rect = FancyBboxPatch((x0, y0), w, h,
                           boxstyle='round,pad=0.04',
                           facecolor=fc, edgecolor=ec, linewidth=1.0, zorder=3)
    ax.add_patch(rect)
    text = '\n'.join(lines)
    ax.text(cx, cy, text, ha='center', va='center',
            fontfamily=FONT, fontsize=fs, multialignment='center', zorder=4)

def arrow(ax, x1, y1, x2, y2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color='#444444',
                                lw=1.1, connectionstyle='arc3,rad=0.0'),
                zorder=2)

def dashed_box(ax, x0, y0, x1, y1, label):
    w, h = x1 - x0, y1 - y0
    rect = mpatches.FancyBboxPatch((x0, y0), w, h,
                                    boxstyle='round,pad=0.05',
                                    facecolor='none', edgecolor='#6c8ebf',
                                    linewidth=0.9, linestyle='dashed', zorder=1)
    ax.add_patch(rect)
    ax.text(x0 + w/2, y1 - 0.12, label, ha='center', va='top',
            fontfamily=FONT, fontsize=FS_SMALL, style='italic',
            color='#6c8ebf', zorder=4)

# ── row y positions (top to bottom) ──────────────────────────
Y = [17.2, 15.9, 14.6, 13.3,   # MULAI, Identifikasi, Tinjauan, Persiapan
     11.6, 10.4,                 # parallel top rows (Pend A left / Pend B right)
      9.2,  8.0,                 # parallel mid rows
      6.8,                       # Pend B extra row
      5.5,                       # merge row
      4.3,  3.2, 2.1]            # Uji Stat, Kesimpulan, SELESAI

# ── MULAI ───────────────────────────────────────────────────
oval(ax, 5, Y[0], 2.0, 0.7, 'MULAI', *C_GREEN, bold=True)

# ── Sequential steps ────────────────────────────────────────
box(ax, 5, Y[1], 5.5, 0.75, ['Identifikasi Masalah'], *C_GRAY)
box(ax, 5, Y[2], 5.5, 0.75, ['Tinjauan Pustaka'], *C_GRAY)
box(ax, 5, Y[3], 5.5, 0.75, ['Persiapan Dataset EssayJudge'], *C_ORANGE)

# arrows sequential
arrow(ax, 5, Y[0]-0.35, 5, Y[1]+0.375)
arrow(ax, 5, Y[1]-0.375, 5, Y[2]+0.375)
arrow(ax, 5, Y[2]-0.375, 5, Y[3]+0.375)

# ── Split line from Persiapan ────────────────────────────────
# branch left at x=2.5, right at x=7.5
ax.annotate('', xy=(2.5, Y[3]-0.375-0.55), xytext=(5, Y[3]-0.375),
            arrowprops=dict(arrowstyle='->', color='#444444', lw=1.1), zorder=2)
ax.annotate('', xy=(7.5, Y[3]-0.375-0.55), xytext=(5, Y[3]-0.375),
            arrowprops=dict(arrowstyle='->', color='#444444', lw=1.1), zorder=2)
# horizontal connector
ax.plot([2.5, 7.5], [Y[3]-0.375, Y[3]-0.375], color='#444444', lw=1.1, zorder=2)

# ── Pendekatan A (left, cx=2.5) ──────────────────────────────
bw, bh = 4.2, 0.85
box(ax, 2.5, Y[4], bw, bh,
    ['Desain Arsitektur Fusion', '(Pendekatan A)'], *C_BLUE)
box(ax, 2.5, Y[5], bw, bh,
    ['Ablasi & Pelatihan', 'Fusion (Exp 046–057)'], *C_BLUE)

arrow(ax, 2.5, Y[4]-bh/2, 2.5, Y[5]+bh/2)

# ── Pendekatan B (right, cx=7.5) ─────────────────────────────
box(ax, 7.5, Y[4], bw, bh,
    ['Desain Pipeline T2T', '(Pendekatan B)'], *C_BLUE)
box(ax, 7.5, Y[5], bw, bh,
    ['Pembuatan Caption', '(Qwen2-VL-7B / DePlot / MATCHA)'], *C_BLUE)
box(ax, 7.5, Y[6], bw, bh,
    ['Ablasi & Pelatihan', 'T2T (Exp 158–164)'], *C_BLUE)
box(ax, 7.5, Y[7], bw, bh,
    ['Analisis Kualitas Caption', '(100-sampel manual)'], *C_ORANGE)

arrow(ax, 7.5, Y[4]-bh/2, 7.5, Y[5]+bh/2)
arrow(ax, 7.5, Y[5]-bh/2, 7.5, Y[6]+bh/2)
arrow(ax, 7.5, Y[6]-bh/2, 7.5, Y[7]+bh/2)

# ── Dashed background boxes ───────────────────────────────────
dashed_box(ax, 0.2, Y[7]-0.55, 4.85, Y[4]+0.55, 'Pendekatan A')
dashed_box(ax, 5.15, Y[7]-0.55, 9.8, Y[4]+0.55, 'Pendekatan B')

# ── Merge arrows → Pemilihan Sistem Terbaik ───────────────────
merge_y = Y[8]  # 5.5
ax.plot([2.5, 2.5], [Y[5]-bh/2, merge_y+0.425], color='#444444', lw=1.1, zorder=2)
ax.plot([7.5, 7.5], [Y[7]-bh/2, merge_y+0.425], color='#444444', lw=1.1, zorder=2)
ax.plot([2.5, 7.5], [merge_y+0.425, merge_y+0.425], color='#444444', lw=1.1, zorder=2)
ax.annotate('', xy=(5, merge_y+0.425), xytext=(5, merge_y+0.425),
            zorder=2)
arrow(ax, 5, merge_y+0.425, 5, merge_y+0.35)

box(ax, 5, merge_y, 5.5, 0.85, ['Pemilihan Sistem Terbaik'], *C_GREEN)

# ── Final sequential ─────────────────────────────────────────
box(ax, 5, Y[9], 5.5, 0.85,
    ['Uji Statistik', '(Paired t-test, Bonferroni)'], *C_ORANGE)
box(ax, 5, Y[10], 5.5, 0.75, ['Penarikan Kesimpulan'], *C_GRAY)
oval(ax, 5, Y[11], 2.0, 0.7, 'SELESAI', *C_RED, bold=True)

arrow(ax, 5, merge_y-0.425, 5, Y[9]+0.425)
arrow(ax, 5, Y[9]-0.425, 5, Y[10]+0.375)
arrow(ax, 5, Y[10]-0.375, 5, Y[11]+0.35)

plt.tight_layout(pad=0.2)
out = r'C:\Outpost\Skripsi\Research 4\thesis-main\contents\chapter-3\figures\flowchart_alur.png'
fig.savefig(out, dpi=200, bbox_inches='tight', facecolor='white')
print('Saved:', out)
