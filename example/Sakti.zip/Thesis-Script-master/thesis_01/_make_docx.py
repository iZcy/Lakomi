from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

for sname in ['Normal', 'Heading 1', 'Heading 2', 'List Number', 'List Bullet']:
    s = doc.styles[sname]
    s.font.name = 'Times New Roman'
    s.font.size = Pt(12)

doc.styles['Heading 1'].font.size = Pt(14)
doc.styles['Heading 1'].font.bold = True
doc.styles['Heading 2'].font.bold = True


def add_heading(level, text):
    p = doc.add_heading(text, level=level)
    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for run in p.runs:
        run.font.name = 'Times New Roman'
        run.font.size = Pt(14 if level == 1 else 12)
        run.font.bold = True
        run.font.color.rgb = None
    return p


def add_para(text, indent=True):
    p = doc.add_paragraph(text)
    p.style = doc.styles['Normal']
    fmt = p.paragraph_format
    fmt.space_after = Pt(0)
    fmt.space_before = Pt(6)
    if indent:
        fmt.first_line_indent = Inches(0.5)
    return p


def add_numbered(items):
    for text in items:
        p = doc.add_paragraph(style='List Number')
        run = p.add_run(text)
        run.font.name = 'Times New Roman'
        run.font.size = Pt(12)


def add_bullets(items, indent_level=0):
    for text in items:
        p = doc.add_paragraph(style='List Bullet')
        run = p.add_run(text)
        run.font.name = 'Times New Roman'
        run.font.size = Pt(12)
        if indent_level > 0:
            p.paragraph_format.left_indent = Inches(0.5 * indent_level)


def add_bold_inline(label, rest):
    p = doc.add_paragraph()
    p.style = doc.styles['Normal']
    r1 = p.add_run(label)
    r1.bold = True
    r1.font.name = 'Times New Roman'
    r1.font.size = Pt(12)
    r2 = p.add_run(rest)
    r2.font.name = 'Times New Roman'
    r2.font.size = Pt(12)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    return p


# ════════════════════════════════════════════════════════════════════════════
# BAB I
# ════════════════════════════════════════════════════════════════════════════
add_heading(1, 'BAB I  PENDAHULUAN')

# ── 1.1 Latar Belakang ───────────────────────────────────────────────────────
add_heading(2, '1.1  Latar Belakang')

paras_lb = [
    # P1 — IELTS Task 1 multimodal context
    (
        "Penilaian esai merupakan komponen penting dalam ujian kemampuan berbahasa, "
        "salah satunya IELTS (International English Language Testing System). Pada "
        "IELTS Academic Writing Task 1, peserta ujian diminta untuk mendeskripsikan "
        "atau menganalisis informasi yang disajikan dalam bentuk visual seperti "
        "diagram batang, diagram garis, diagram lingkaran, tabel, peta, dan "
        "flowchart. Penilaian esai pada konteks ini tidak hanya bergantung pada "
        "kualitas teks yang ditulis, tetapi juga pada seberapa akurat dan relevan "
        "isi esai dalam merespons konten visual yang diberikan. Hal ini menjadikan "
        "penilaian IELTS Task 1 sebagai tugas multimodal, yaitu sebuah tugas yang "
        "memerlukan pemahaman simultan terhadap dua modalitas: gambar dan teks."
    ),
    # P2 — AES problem, traditional approaches ignore image
    (
        "Proses penilaian esai secara manual memerlukan waktu yang cukup lama dan "
        "memiliki potensi inkonsistensi antar penilai. Penelitian di bidang "
        "Automated Essay Scoring (AES) telah lama berupaya mengotomasi proses ini. "
        "Namun, sebagian besar pendekatan AES tradisional hanya mempertimbangkan "
        "teks esai saja, tanpa memperhitungkan konteks visual yang menjadi dasar "
        "penulisan esai tersebut (Su et al., 2025). Pada kasus IELTS Task 1, "
        "mengabaikan gambar berarti mengabaikan informasi yang fundamental dalam "
        "menilai apakah esai benar-benar membahas konten visual yang dimaksud."
    ),
    # P3 — EssayJudge paper and zero-shot 7B result
    (
        "Su et al. (2025) memperkenalkan EssayJudge, sebuah benchmark pertama yang "
        "secara eksplisit mengevaluasi kemampuan Multimodal Large Language Models "
        "(MLLM) dalam menilai esai IELTS Task 1 secara multi-granular. EssayJudge "
        "menggunakan 1.054 esai dengan 10 rubrik penilaian yang mencakup aspek "
        "leksikal, sintaksis, dan wacana. Hasil evaluasi pada EssayJudge menunjukkan "
        "bahwa bahkan salah satu model MLLM open-source terbaik yang tersedia saat "
        "ini, yaitu Qwen2-VL-7B dengan 7 miliar parameter, hanya mampu mencapai "
        "rata-rata QWK (Quadratic Weighted Kappa) sekitar 0,16 dalam skenario "
        "zero-shot, tanpa pelatihan khusus pada data esai berlabel. Hal ini "
        "memperlihatkan bahwa inferensi langsung dari MLLM, meskipun secara teknis "
        "memahami gambar, masih jauh dari cukup untuk tugas penilaian esai yang "
        "terstruktur."
    ),
    # P4 — Multimodal fusion approach
    (
        "Salah satu pendekatan yang lebih klasik dalam pemrosesan multimodal adalah "
        "fusion, yaitu penggabungan representasi dari dua modalitas yang berbeda "
        "ke dalam satu model terpadu. Terdapat tiga strategi fusion yang umum "
        "digunakan: early fusion yang menggabungkan fitur pada level input, "
        "intermediate fusion yang menggabungkan pada level representasi, dan late "
        "fusion yang menggabungkan pada level prediksi. Dalam konteks AES berbasis "
        "gambar dan teks, pendekatan ini dapat diwujudkan dengan menggunakan "
        "ResNet18 sebagai ekstraktor fitur gambar dan BERT sebagai ekstraktor fitur "
        "teks esai. Penelitian ini menginvestigasi ketiga strategi fusion tersebut "
        "untuk menentukan pendekatan yang paling efektif, kemudian mengeksplorasi "
        "penggantian BERT dengan RoBERTa yang terbukti lebih unggul dalam tugas "
        "pemahaman bahasa (Liu et al., 2019)."
    ),
    # P5 — T2T approach
    (
        "Sebagai alternatif terhadap pendekatan fusion, pendekatan Text-to-Text "
        "(T2T) mengusulkan untuk terlebih dahulu mengkonversi gambar menjadi "
        "deskripsi teks menggunakan model vision-language (VLM), kemudian "
        "menggunakan representasi teks tersebut bersama dengan esai dalam sebuah "
        "model berbasis teks. Dengan demikian, seluruh alur penilaian beroperasi "
        "dalam ruang teks dan tidak diperlukan encoder gambar dalam proses pelatihan "
        "akhir. Penelitian ini menggunakan Qwen2-VL-7B-Instruct sebagai model "
        "captioner untuk menghasilkan deskripsi seluruh 1.054 gambar. Namun, "
        "analisis manual terhadap 100 sampel acak menunjukkan bahwa sekitar 22% "
        "caption untuk gambar jenis bar chart dan line chart mengandung kesalahan "
        "ekstraksi data, seperti nilai yang terbalik atau puncak yang salah "
        "teridentifikasi. Hal ini memotivasi penggunaan DePlot, yaitu model "
        "khusus yang dirancang untuk mengekstraksi data tabular dari grafik, "
        "sebagai captioner alternatif untuk jenis gambar tersebut."
    ),
    # P6 — Research question
    (
        "Penelitian ini secara sistematis menginvestigasi dua paradigma utama dalam "
        "AES multimodal: pendekatan fusion yang menggunakan fitur visual secara "
        "langsung, dan pendekatan T2T yang mengkonversi gambar menjadi teks terlebih "
        "dahulu. Dalam paradigma fusion, penelitian ini membandingkan tiga strategi "
        "penggabungan fitur dan dua arsitektur encoder teks. Dalam paradigma T2T, "
        "penelitian ini membandingkan kualitas caption dari berbagai model VLM "
        "generalis maupun spesialis grafik. Pertanyaan mendasar yang ingin dijawab "
        "adalah: apakah pendekatan T2T dengan caption yang dioptimasi dapat "
        "mengungguli pendekatan fusion terbaik dalam konteks AES multimodal "
        "berbasis dataset EssayJudge?"
    ),
    # P7 — Dataset and evaluation
    (
        "Penelitian ini menggunakan dataset EssayJudge secara keseluruhan (1.054 "
        "esai) dengan pembagian data train/validasi/test sebesar 70%/15%/15%. "
        "Evaluasi dilakukan menggunakan metrik QWK pada 10 trait penilaian yang "
        "mencakup Argument Clarity (AC), Justifying Persuasiveness (JP), "
        "Organizational Structure (OS), Coherence (CH), Essay Length (EL), "
        "Grammatical Accuracy (GA), Grammatical Diversity (GD), Lexical Accuracy "
        "(LA), Lexical Diversity (LD), dan Punctuation Accuracy (PA)."
    ),
]

for text in paras_lb:
    add_para(text)

# ── 1.2 Rumusan Masalah ──────────────────────────────────────────────────────
add_heading(2, '1.2  Rumusan Masalah')
add_para(
    "Berdasarkan latar belakang yang telah diuraikan, penelitian ini merumuskan "
    "masalah sebagai berikut:",
    indent=False
)
add_numbered([
    "Strategi fusion manakah (early, intermediate, atau late fusion) yang "
    "menghasilkan performa terbaik dalam penilaian esai IELTS Task 1 secara "
    "otomatis menggunakan model BERT dan ResNet18 pada dataset EssayJudge?",

    "Apakah penggantian encoder teks dari BERT menjadi RoBERTa pada arsitektur "
    "late fusion dapat meningkatkan performa penilaian esai otomatis?",

    "Apakah pendekatan Text-to-Text (T2T) menggunakan caption dari "
    "Qwen2-VL-7B-Instruct dan model Dual RoBERTa dapat mengungguli pendekatan "
    "fusion terbaik dalam penilaian esai IELTS Task 1 pada dataset EssayJudge?",

    "Apakah penggunaan DePlot sebagai captioner khusus untuk gambar jenis bar "
    "chart dan pie chart dalam pipeline T2T dapat meningkatkan performa penilaian "
    "esai otomatis dibandingkan dengan penggunaan VLM generalis secara penuh?",
])

# ── 1.3 Tujuan Penelitian ────────────────────────────────────────────────────
add_heading(2, '1.3  Tujuan Penelitian')
add_para(
    "Berdasarkan rumusan masalah di atas, tujuan penelitian ini adalah:",
    indent=False
)
add_numbered([
    "Membandingkan performa strategi early, intermediate, dan late fusion "
    "menggunakan BERT dan ResNet18 untuk mengidentifikasi strategi fusion terbaik "
    "dalam konteks AES multimodal pada dataset EssayJudge.",

    "Mengevaluasi pengaruh penggantian encoder teks dari BERT menjadi RoBERTa "
    "pada arsitektur late fusion terhadap performa penilaian esai IELTS Task 1.",

    "Mengimplementasikan dan mengevaluasi pendekatan T2T menggunakan caption "
    "Qwen2-VL-7B-Instruct dan arsitektur Dual RoBERTa, serta membandingkannya "
    "dengan pendekatan fusion terbaik.",

    "Mengevaluasi efektivitas DePlot sebagai captioner khusus grafik dalam "
    "pipeline T2T hybrid untuk meningkatkan akurasi penilaian esai pada gambar "
    "jenis bar chart dan pie chart.",
])

# ── 1.4 Batasan Penelitian ───────────────────────────────────────────────────
add_heading(2, '1.4  Batasan Penelitian')
add_para(
    "Agar penelitian ini terfokus dan dapat diselesaikan dalam ruang lingkup yang "
    "terukur, ditetapkan batasan-batasan sebagai berikut:",
    indent=False
)
add_numbered([
    "Dataset yang digunakan adalah EssayJudge (Su et al., 2025), terdiri dari "
    "1.054 esai IELTS Academic Writing Task 1 dengan anotasi skor pada 10 trait "
    "(skala 0 s.d. 5, langkah 0,5).",

    "Penelitian ini hanya mencakup IELTS Academic Writing Task 1, bukan Task 2 "
    "(esai argumentatif tanpa gambar).",

    "Model yang digunakan dalam penelitian ini adalah:",

    "Evaluasi menggunakan metrik Quadratic Weighted Kappa (QWK) dengan skala "
    "11 level (0 hingga 5 dengan selisih step 0,5).",

    "Pelatihan pada eksperimen fusion dilakukan secara terpisah untuk masing-masing "
    "trait (per-trait training). Pelatihan pada eksperimen T2T dilakukan secara "
    "multi-task (satu model untuk seluruh 10 trait sekaligus).",

    "Penelitian ini tidak melakukan fine-tuning pada model VLM maupun DePlot; "
    "seluruh caption dihasilkan sekali dan digunakan secara statis pada seluruh "
    "proses pelatihan.",
])

# Sub-bullets for item 3 (model list)
add_bullets([
    "Pendekatan Fusion: BERT-base-uncased dan RoBERTa-base sebagai encoder teks; "
    "ResNet18 sebagai ekstraktor fitur gambar (dibekukan).",

    "Pendekatan T2T: Qwen2-VL-7B-Instruct sebagai model captioner generalis; "
    "DePlot (google/deplot) sebagai captioner khusus grafik; "
    "dua instansi RoBERTa-base terpisah sebagai encoder caption dan encoder esai.",
], indent_level=1)

# ── 1.5 Manfaat Penelitian ───────────────────────────────────────────────────
add_heading(2, '1.5  Manfaat Penelitian')
add_para(
    "Penelitian ini diharapkan memberikan manfaat sebagai berikut:",
    indent=False
)

add_bold_inline("Bagi dunia akademik:", "")
add_bullets([
    "Memberikan bukti empiris perbandingan langsung antara strategi early, "
    "intermediate, dan late fusion dalam konteks AES multimodal berbasis dataset nyata.",

    "Menunjukkan bahwa pendekatan berbasis pelatihan supervised dengan data "
    "berlabel dapat secara signifikan mengungguli inferensi zero-shot dari MLLM "
    "berukuran besar pada tugas penilaian esai terstruktur.",

    "Mengidentifikasi peran kualitas caption dalam pipeline T2T dan menunjukkan "
    "efektivitas model captioner khusus grafik (DePlot) dibandingkan VLM generalis.",

    "Mengidentifikasi trait penilaian yang secara konsisten sulit diprediksi oleh "
    "model berbasis teks maupun fusion, sebagai arahan untuk penelitian lanjutan.",
])

add_bold_inline("Bagi praktisi pendidikan:", "")
add_bullets([
    "Menyediakan dasar implementasi sistem AES yang dapat membantu pengajar atau "
    "institusi dalam memberikan umpan balik awal yang konsisten dan cepat terhadap "
    "esai IELTS Task 1.",

    "Memperkuat wawasan mengenai aspek penulisan esai mana yang dapat diotomasi "
    "dan mana yang masih membutuhkan penilaian manusia.",
])

# ── 1.6 Sistematika Penulisan ────────────────────────────────────────────────
add_heading(2, '1.6  Sistematika Penulisan')
add_para(
    "Penulisan skripsi ini disusun dengan sistematika sebagai berikut:",
    indent=False
)

sistematika = [
    ("Bab I",
     " membahas pendahuluan yang mencakup latar belakang penelitian, rumusan "
     "masalah, tujuan penelitian, batasan penelitian, manfaat penelitian, dan "
     "sistematika penulisan."),
    ("Bab II",
     " membahas tinjauan pustaka yang meliputi penelitian-penelitian terdahulu "
     "di bidang AES berbasis deep learning dan multimodal, serta dasar teori "
     "yang mencakup strategi fusion multimodal, arsitektur BERT dan RoBERTa, "
     "ResNet18, model vision-language Qwen2-VL, DePlot, dan metrik QWK."),
    ("Bab III",
     " membahas metodologi penelitian yang mencakup deskripsi dataset EssayJudge, "
     "desain arsitektur seluruh pendekatan (fusion dan T2T), konfigurasi pelatihan, "
     "serta alur eksperimen secara keseluruhan."),
    ("Bab IV",
     " membahas hasil dan analisis eksperimen secara berurutan: perbandingan "
     "strategi fusion, pengaruh upgrade encoder, perbandingan T2T vs fusion, "
     "analisis kualitas caption, dan efektivitas DePlot sebagai captioner khusus."),
    ("Bab V",
     " menyajikan kesimpulan yang menjawab seluruh rumusan masalah berdasarkan "
     "hasil penelitian, serta saran untuk penelitian selanjutnya."),
]

for bab, isi in sistematika:
    add_bold_inline(bab, isi)

# ── save ─────────────────────────────────────────────────────────────────────
out = "C:/outpost/skripsi/research 4/thesis_01/chapter-1.docx"
doc.save(out)
print("Saved:", out)
