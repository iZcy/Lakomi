import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# Get current end index
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child: return child
    return None

tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1
insert_at = end_index - 1  # insert before final newline
print(f'Inserting at index: {insert_at}')

# ── New segments to append ────────────────────────────────────────────────────
segments = [
    ("section", "2.4 Pertanyaan Tugas Akhir"),

    ("body", "Berdasarkan tinjauan pustaka, dasar teori, dan analisis perbandingan metode "
             "yang telah dipaparkan, dirumuskan enam pertanyaan tugas akhir (Research "
             "Question) yang masing-masing memiliki keterkaitan langsung dengan tujuan "
             "penelitian yang telah ditetapkan pada Bab I."),

    ("numbered",
     "RQ1 (Strategi Fusion): Strategi fusion mana -- early fusion, intermediate fusion, "
     "atau late fusion -- yang menghasilkan skor QWK tertinggi pada tugas automated essay "
     "scoring multimoda IELTS Task 1 dengan arsitektur BERT + ResNet18?"),

    ("numbered",
     "RQ2 (Text Encoder): Apakah penggantian text encoder dari BERT ke RoBERTa "
     "meningkatkan performa penilaian esai multimoda pada arsitektur late fusion "
     "dibandingkan menggunakan BERT dengan konfigurasi pelatihan yang identik?"),

    ("numbered",
     "RQ3 (Track A vs. Track B): Apakah pendekatan text-to-text berbasis caption VLM "
     "menghasilkan skor QWK yang lebih tinggi dibandingkan pendekatan fusi multimoda "
     "langsung (ResNet18 + RoBERTa late fusion) untuk penilaian esai IELTS Task 1?"),

    ("numbered",
     "RQ4 (Pemilihan Captioner): Di antara DePlot, MATCHA, dan PaliGemma, model mana "
     "yang menghasilkan caption paling andal untuk bar chart dan pie chart serta "
     "memberikan kontribusi terbaik terhadap performa scoring pada dataset EssayJudge?"),

    ("numbered",
     "RQ5 (Skala VLM): Apakah penggunaan VLM berkapasitas lebih besar (InternVL2-8B) "
     "sebagai captioner menghasilkan peningkatan performa yang signifikan dibandingkan "
     "Qwen2-VL-7B-Instruct dalam pipeline text-to-text?"),

    ("numbered",
     "RQ6 (Signifikansi Statistik): Apakah perbedaan performa antara sistem terbaik "
     "yang diusulkan dan baseline (Track A terbaik serta zero-shot Qwen2-VL-7B) secara "
     "statistik signifikan berdasarkan bootstrap resampling test pada metrik QWK?"),
]

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'text-to-text', r'multi-task', r'per-trait',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'encoder', r'text encoder', r'image encoder',
    r'bootstrap resampling',
    r'research question',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line  is not None: ps['indentFirstLine'] = {'magnitude': first_line,  'unit': 'PT'}
    if indent_start is not None: ps['indentStart']    = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above  is not None: ps['spaceAbove']     = {'magnitude': space_above,  'unit': 'PT'}
    if space_below  is not None: ps['spaceBelow']     = {'magnitude': space_below,  'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12,
                   font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build text block ───────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    # offset from insert_at position
    start = insert_at + len(full_text) + 1
    full_text += text + '\n'
    end = insert_at + len(full_text)
    seg_positions.append((start, end, seg_type))

print(f'Characters to append: {len(full_text)} | Segments: {len(segments)}')

# Italic search over appended text only
italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((insert_at + ms + 1, insert_at + me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
requests = []

# Insert text in reverse segment order at insert_at
for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', insert_at, TAB_ID))

# Apply styles
for start, end, seg_type in seg_positions:
    if seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))
    elif seg_type == 'numbered':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=0,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
