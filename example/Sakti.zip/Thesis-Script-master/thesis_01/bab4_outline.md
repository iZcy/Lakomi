# BAB IV — HASIL DAN PEMBAHASAN
## Outline Draft v5 (target: 30+ halaman)
### Last Updated: 2026-04-20

---

## PRINSIP PENULISAN BAB IV
- Setiap subbab menjawab tepat satu RQ, kecuali 4.3 (T2T discovery narrative, fondasi RQ3–RQ5).
- **Pola tiap subbab RQ**: X.X.1 = konteks teori + hipotesis dari paper → X.X.2–N = satu sub-subbab per varian eksperimen → X.X.N+1 = perbandingan + jawaban RQ (konfirmasi/sanggahan paper).
- Numbering maksimal 3 level (X.X.X). Tidak ada X.X.X.X. Jika eksperimen dalam satu sub-subbab lebih dari satu, bedakan dengan **bold header** di dalam paragraf.
- Sub-subbab terakhir di setiap subbab = ringkasan perbandingan + jawaban RQ.
- Tabel per-trait QWK wajib ada di setiap sub-subbab eksperimen.

---

## STRUKTUR BAB IV

### Intro BAB IV (~0.5 hal)
Overview dua jalur (Track A dan Track B), urutan pembahasan mengikuti 6 RQ,
konfirmasi eksperimen yang sudah selesai dan yang masih pending (RQ5 dan RQ6).

---

### 4.1 RQ1 — Perbandingan Strategi Fusion pada Track A (~5.5 hal)

**RQ1:** Strategi fusion mana (early/intermediate/late) yang menghasilkan QWK
tertinggi pada arsitektur BERT + ResNet18?

**4.1.1 Dasar Teori: Strategi Fusion Multimodal (Baltrusaitis et al., 2019)**
- Jelaskan taksonomi tiga strategi fusion dari Baltrusaitis et al. (2019):
  - *Early fusion*: menggabungkan sinyal mentah/representasi awal sebelum encoder utama
    → sederhana tapi memaksa satu model memproses dua ruang representasi sangat berbeda
  - *Intermediate fusion*: tiap modalitas diproses penuh oleh encoder masing-masing,
    digabungkan di tengah (misalnya cross-attention) sebelum FC head
    → lebih fleksibel, tapi menambah parameter fusion yang perlu dilatih
  - *Late fusion*: tiap modalitas diproses penuh, representasi akhir digabungkan
    (biasanya concatenation) baru masuk ke decision head
    → encoder tiap modalitas bebas dioptimalkan, fusion sederhana
- Prediksi Baltrusaitis et al.: late fusion cenderung lebih baik ketika distribusi
  dua modalitas sangat berbeda (teks vs gambar), karena encoder bisa dioptimalkan
  secara independen tanpa trade-off ruang representasi.
- Hipotesis RQ1: late fusion diperkirakan menghasilkan QWK tertinggi pada
  arsitektur BERT + ResNet18 dengan dataset esai IELTS Task 1.

**4.1.2 Early Fusion (Eksperimen 030)**
- Arsitektur: ResNet18 menghasilkan feature map yang di-flatten, digabungkan dengan
  BERT token embeddings sebelum encoder utama. Kedua modalitas diproses bersama FC head.
- Setup: lr=1e-4, dropout=0.3, batch=16, seed=42, multi-task MSE, 737/158/159 split
- Hasil: Test QWK = 0.4777
  Tabel per-trait: AC=0.161, JP=0.464, OS=0.486, CH=0.525, EL=0.419,
  GA=0.542, GD=0.541, LA=0.582, LD=0.536, PA=0.407
- Analisis: encoder dipaksa memproses ruang representasi yang sangat berbeda
  (pixel vs token) secara bersamaan → representasi teks terdegradasi.
  AC terendah (0.161) — argumen holistik paling terdampak oleh noise visual awal.

**4.1.3 Intermediate Fusion (Eksperimen 031)**
- Arsitektur: BERT memproses teks penuh → [CLS] 768d. ResNet18 memproses gambar penuh
  → feature map 512d. Cross-attention: essay [CLS] sebagai query, image features sebagai
  key/value. Output cross-attention di-concat dengan [CLS], masuk FC head.
- Setup: identik dengan Eksperimen 030
- Hasil: Test QWK = 0.4799
  Tabel per-trait: AC=0.241, JP=0.390, OS=0.540, CH=0.552, EL=0.415,
  GA=0.535, GD=0.599, LA=0.602, LD=0.511, PA=0.414
- Analisis: peningkatan kecil vs early (+0.002). Cross-attention sedikit membantu
  GD (0.599) dan LA (0.602) — keragaman linguistik berkorelasi dengan konten visual.
  AC membaik (0.241 vs 0.161) karena encoder teks bebas berjalan penuh.
  Namun parameter fusion baru membutuhkan lebih banyak data untuk dilatih efektif.

**4.1.4 Late Fusion (Eksperimen 032)**
- Arsitektur: BERT → [CLS] 768d dan ResNet18 → global average pooling 512d,
  keduanya independen penuh. Concatenation 1.280d → FC 1280→768→256→10, sigmoid×5.
- Setup: identik dengan Eksperimen 030
- Hasil: Test QWK = 0.4838
  Tabel per-trait: AC=0.318, JP=0.421, OS=0.502, CH=0.596, EL=0.427,
  GA=0.527, GD=0.578, LA=0.587, LD=0.493, PA=0.388
- Analisis: tertinggi (+0.004 vs intermediate, +0.006 vs early). AC naik signifikan
  (0.318) — encoder teks bebas dioptimalkan penuh untuk bahasa tanpa gangguan modalitas lain.
  CH (0.596) terbaik di seluruh Track A — koherensi murni didominasi sinyal teks.

**4.1.5 Perbandingan Antar Strategi dan Jawaban RQ1**
- Tabel ringkasan:
  | Strategi | Test QWK | AC | OS | CH | GA |
  |----------|----------|----|----|----|----|
  | Early (Exp030) | 0.4777 | 0.161 | 0.486 | 0.525 | 0.542 |
  | Intermediate (Exp031) | 0.4799 | 0.241 | 0.540 | 0.552 | 0.535 |
  | Late (Exp032) | **0.4838** | **0.318** | 0.502 | **0.596** | 0.527 |
- Jawaban RQ1: **Late fusion adalah strategi optimal**, konsisten dengan prediksi
  Baltrusaitis et al. (2019). Ketika dua modalitas memiliki distribusi sangat berbeda
  (teks esai mahasiswa vs gambar IELTS profesional), memisahkan optimasi encoder
  lebih efektif daripada menggabungkan representasi di awal atau tengah.
  Intermediate sedikit unggul di OS — cross-attention menangkap relasi visual-struktural,
  tetapi gain ini tidak cukup untuk mengkompensasi biaya parameter fusion tambahan.

---

### 4.2 RQ2 — Pengaruh Pilihan Text Encoder: BERT vs RoBERTa (~4.5 hal)

**RQ2:** Apakah penggantian text encoder dari BERT ke RoBERTa meningkatkan performa
pada arsitektur late fusion dengan konfigurasi pelatihan identik?

**4.2.1 Dasar Teori: RoBERTa sebagai Optimasi Pre-training BERT (Liu et al., 2019)**
- Liu et al. (2019) mengidentifikasi bahwa BERT under-trained: training lebih singkat,
  batch lebih kecil, dan penggunaan NSP (Next Sentence Prediction) yang tidak selalu
  menguntungkan downstream tasks.
- RoBERTa menghapus NSP, menggunakan *dynamic masking* (mask berbeda tiap epoch),
  batch lebih besar, dan data pre-training 10× lebih banyak (160GB vs 16GB).
- Liu et al. menunjukkan RoBERTa mengungguli BERT-base di GLUE, SQuAD, dan RACE
  dengan margin konsisten.
- Hipotesis RQ2: RoBERTa-base diperkirakan menghasilkan QWK lebih tinggi dari BERT-base
  pada arsitektur late fusion yang sama, terutama untuk trait yang bergantung pada
  pemahaman kosakata dan struktur wacana (GA, LA, LD, OS).

**4.2.2 BERT-base pada Arsitektur Late Fusion (Eksperimen 032)**
- Arsitektur: BERT-base-uncased (WordPiece tokenizer, 12 layer, 768d) + ResNet18,
  late fusion concat 1.280d. Freeze: embed + layer 0-5 (6/12 layer).
- Pre-training BERT: MLM + NSP pada Wikipedia+BookCorpus (16GB).
  NSP mendorong model memahami relasi antar-kalimat.
- Hasil: Test QWK = 0.4838 (direferensikan dari 4.1.4)

**4.2.3 RoBERTa-base pada Arsitektur Late Fusion (Eksperimen 033)**
- Arsitektur: RoBERTa-base (GPT-2 BPE tokenizer, 12 layer, 768d) + ResNet18,
  late fusion concat 1.280d. Konfigurasi identik dengan Eksperimen 032.
- Pre-training RoBERTa: tanpa NSP, dynamic masking, batch lebih besar, 160GB data.
- Hasil: Test QWK = 0.5126
  Tabel per-trait: AC=0.271, JP=0.463, OS=0.622, CH=0.579, EL=0.443,
  GA=0.591, GD=0.586, LA=0.581, LD=0.542, PA=0.446
- Analisis: peningkatan signifikan (+0.029 overall). RoBERTa unggul di 8 dari 10 trait.
  OS naik drastis (0.622 vs 0.502, +0.120) — representasi RoBERTa lebih kaya untuk
  struktur wacana. GA (0.591), LA (0.581) juga naik, konsisten dengan hipotesis.
  BERT sedikit unggul di AC (0.318 vs 0.271) dan CH (0.596 vs 0.579) —
  NSP mungkin membantu kohesi argumen lintas-kalimat untuk dua trait ini.

**4.2.4 Analisis: Dynamic Masking, NSP, dan Relevansinya untuk AES**
- RoBERTa lebih baik untuk trait linguistik per-kalimat (GA, GD, LA, LD, PA):
  dynamic masking + data lebih besar → representasi kata lebih robust dan beragam.
- BERT sedikit lebih baik di AC dan CH (koherensi lintas-kalimat):
  NSP kemungkinan membantu encoder memahami relasi argumen antar-kalimat,
  relevan untuk penilaian holistik kejelasan argumen IELTS.
- Implikasi: untuk dataset AES di mana kebanyakan trait bersifat per-kalimat,
  RoBERTa adalah pilihan yang lebih tepat.

**4.2.5 Jawaban RQ2**
- Jawaban RQ2: **RoBERTa-base mengungguli BERT-base** (+0.029 QWK) dengan konfigurasi
  identik, mengkonfirmasi temuan Liu et al. (2019) pada domain AES multimodal.
- RoBERTa menjadi text encoder pilihan untuk seluruh eksperimen Track B berikutnya.
- Catatan: jika AC menjadi fokus utama, BERT mungkin lebih sesuai — penelitian lanjutan
  dapat menguji ensemble atau task-specific encoder per trait.

---

### 4.3 Pendekatan Text-to-Text: Motivasi, Baseline, Analisis, dan Jawaban RQ3 (~7 hal)

*(Bukan RQ tersendiri — section ini membangun fondasi untuk RQ4 dan RQ5
dengan menceritakan perjalanan: motivasi T2T → baseline → temuan kualitas caption →
bukti empiris → kesimpulan masalah VLM pada grafik terstruktur → perbandingan Track A vs B)*

**4.3.1 Dasar Teori: Mengapa Text-to-Text Berpotensi Lebih Baik?**
- Bursztyn et al. (2024): model berbasis teks (T5, GPT) mencapai akurasi 99% pada
  chart question answering ketika diberi representasi teks dari grafik, vs hanya 63%
  ketika model menerima gambar langsung. Representasi teks grafik secara inheren
  lebih informatif bagi language model daripada raw image features.
- Zhao et al. (2025) pada EDU-CIRCUIT-HW: pipeline VLM → caption → LLM untuk penilaian
  esai gambar mencapai peningkatan signifikan vs model yang menerima gambar langsung.
  Mengkonfirmasi bahwa intermediary text representation adalah bottleneck yang produktif
  untuk educational assessment berbasis gambar.
- Motivasi langsung: pada dataset EssayJudge, essay berisi deskripsi verbal grafik
  IELTS — jika caption VLM dapat merepresentasikan grafik secara akurat dalam teks,
  maka RoBERTa dapat membandingkan essay vs caption secara semantik penuh,
  memanfaatkan pre-training bahasa tanpa batasan yang dimiliki image encoder.
- Hipotesis: pipeline T2T (Qwen2-VL-7B → caption → Dual RoBERTa) diperkirakan
  melampaui Track A setelah kualitas caption dioptimalkan.

**4.3.2 T2T Baseline: Qwen2-VL-7B-Instruct, Full 1.054 Sampel (Eksperimen 081)**
- Arsitektur: Dual RoBERTa-base independen. Caption encoder → [CLS] 768d.
  Essay encoder → [CLS] 768d. Concat 1.536d → FC 1536→768→256→10, sigmoid×5.
  Freeze: embed + layer 0-5 (6/12). Optimizer: AdamW lr=1e-4, ReduceLROnPlateau. Seed=42.
- Captions: Qwen2-VL-7B-Instruct (4-bit NF4, Kaggle P100) untuk semua 1.054 sampel —
  termasuk bar chart dan pie chart tanpa perlakuan khusus.
- Hasil: Test QWK = 0.4796
  Per-trait: AC=0.227, JP=0.450, OS=0.532, CH=0.550, EL=0.467,
  GA=0.548, GD=0.571, LA=0.540, LD=0.482, PA=0.429
- Analisis: T2T baseline melampaui Track A early (0.4777) dan intermediate (0.4799),
  tapi masih di bawah Track A terbaik yaitu RoBERTa late fusion (Exp033 = 0.5126).
  Gap ini mengindikasikan bahwa potensi T2T belum terealisasi sepenuhnya —
  kemungkinan disebabkan oleh noise pada caption jenis grafik tertentu.
  Pertanyaan: di mana dan seberapa besar error caption terjadi?

**4.3.3 Distribusi Jenis Grafik pada Dataset EssayJudge**
- Tabel distribusi:
  | Jenis Grafik | Jumlah Sampel | Persentase | Gambar Unik |
  |-------------|--------------|------------|-------------|
  | flow_chart | 305 | 28.9% | 32 |
  | bar_chart | 211 | 20.0% | 30 |
  | table | 153 | 14.5% | 17 |
  | line_chart | 145 | 13.8% | 15 |
  | composite_chart | 107 | 10.2% | 13 |
  | pie_chart | 71 | 6.7% | 10 |
  | map | 62 | 5.9% | 8 |
  | **Total** | **1.054** | **100%** | **125** |
- Hanya 125 gambar unik dari 1.054 baris — satu gambar digunakan oleh banyak esai.
  Captioning dilakukan pada 125 gambar unik, hasilnya diperluas ke 1.054 baris
  via URL mapping. Bar chart + pie chart = 282 sampel (26.7% dari total).

**4.3.4 Evaluasi Kualitas Caption Qwen2-VL-7B per Jenis Grafik**
- Review manual 100 sampel, dikategorikan: Akurat / Parsial / Salah.
  Definisi "salah": nilai numerik tidak sesuai, kategori tertukar, atau deskripsi
  tidak relevan dengan konten grafik.
- Hasil error rate per jenis:
  | Jenis | Error Rate | Masalah Utama |
  |-------|-----------|---------------|
  | pie_chart | ~67% | Nilai persentase salah, kategori tertukar |
  | bar_chart | ~54% | Nilai batang tidak akurat, skala salah baca |
  | composite_chart | ~18% | Sebagian komponen grafik gabungan terbaca |
  | flow_chart | <10% | Qwen efektif mendeskripsikan alur proses |
  | table | <10% | Struktur tabel terbaca dengan baik |
  | line_chart | <10% | Tren naik/turun dideskripsikan dengan baik |
  | map | <10% | Lokasi dan label geografis terbaca |
- Error rate keseluruhan pada 100 sampel review: ~22% (sesuai dengan proporsi
  bar+pie ~27% dalam dataset dikali rata-rata error rate bar+pie ~60%).
- Temuan: Qwen2-VL-7B efektif untuk grafik berbasis proses dan teks (flow, table, map,
  line), tetapi tidak andal untuk grafik berbasis angka presisi (bar, pie).
  Nilai numerik pada grafik terstruktur sulit dibaca secara akurat oleh VLM generalis.

**4.3.5 Bukti Empiris: Eksklusi Bar+Pie Meningkatkan QWK**
- Untuk membuktikan bahwa caption noisy bar+pie adalah penyebab gap performa
  (bukan faktor lain), dilakukan eksperimen eksklusi: training HANYA pada sampel
  yang caption-nya andal (non-bar, non-pie).

- **Eksperimen 092 — Eksklusi Bar+Pie+Composite:**
  Hapus bar_chart (211) + pie_chart (71) + composite_chart (107) = 389 sampel.
  Sisa: 665 sampel → split 465/99/101.
  Hasil: Test QWK = 0.4941 (+0.015 vs Exp081)
  Per-trait: AC=0.181, JP=0.494, OS=0.418, CH=0.558, EL=0.446,
  GA=0.642, GD=0.530, LA=0.519, LD=0.601, PA=0.552
  Catatan: membuang composite (18% error) terlalu agresif — OS turun drastis (0.418)
  karena composite chart memiliki sinyal visual-struktural yang berguna.

- **Eksperimen 093 — Eksklusi Bar+Pie Saja, Composite Dipertahankan:**
  Hapus bar_chart (211) + pie_chart (71) = 282 sampel. Sisa: 772 sampel → split 540/115/117.
  Hasil: Test QWK = **0.5778** ← TERBAIK KESELURUHAN
  Per-trait: AC=0.330, JP=0.572, OS=0.589, CH=0.606, EL=0.503,
  GA=0.688, GD=0.653, LA=0.658, LD=0.610, PA=0.570
  Catatan: seed=42 memastikan distribusi tipe grafik merata di train/val/test —
  gain dari seeding vs non-seeded (Exp091) = +0.083, gain terbesar sepanjang penelitian.
  Semua 10 trait mencapai QWK tertinggi masing-masing dibandingkan seluruh varian T2T.

- Kesimpulan eksklusi: menghapus hanya bar+pie (+0.098 vs Exp081) jauh lebih efektif
  dari menghapus bar+pie+composite (+0.015). Composite dengan 18% error masih
  memberikan sinyal berguna — keputusan eksklusi harus proporsional dengan error rate.

**4.3.6 Kesimpulan: Qwen2-VL-7B Tidak Andal pada Bar Chart dan Pie Chart**
- Dua bentuk bukti mengkonfirmasi masalah yang sama:
  1. Kualitatif: review manual menunjukkan ~54-67% error pada bar+pie
     (nilai tidak akurat, kategori tertukar)
  2. Kuantitatif: eksklusi bar+pie dari training meningkatkan QWK dari 0.4796 ke 0.5778
     (+0.098) — gain terbesar sepanjang penelitian ini.
- Implikasi: masalah bukan pada arsitektur T2T, melainkan pada kemampuan VLM generalis
  dalam menginterpretasikan grafik terstruktur berbasis angka presisi.
- Dua arah solusi yang akan dieksplorasi:
  (a) Captioner khusus grafik terstruktur (DePlot, MATCHA) → RQ4
  (b) VLM alternatif dengan kemampuan chart understanding lebih baik → RQ5

**4.3.7 Jawaban RQ3 — Track A (Fusion) vs Track B (Text-to-Text)**
- Track A terbaik: Eksperimen 033 (RoBERTa late fusion, 4.2.3) = 0.5126
- Track B terbaik: Eksperimen 093 (T2T excl bar+pie, seeded, 4.3.5) = 0.5778
- Perbandingan per-trait:
  | Trait | Track A (Exp033) | Track B (Exp093) | Δ |
  |-------|-----------------|-----------------|---|
  | AC | 0.271 | **0.330** | +0.059 |
  | JP | 0.463 | **0.572** | +0.109 |
  | OS | **0.622** | 0.589 | -0.033 |
  | CH | 0.579 | **0.606** | +0.027 |
  | EL | 0.443 | **0.503** | +0.060 |
  | GA | 0.591 | **0.688** | +0.097 |
  | GD | 0.586 | **0.653** | +0.067 |
  | LA | 0.581 | **0.658** | +0.077 |
  | LD | 0.542 | **0.610** | +0.068 |
  | PA | 0.446 | **0.570** | +0.124 |
  | **Overall** | 0.5126 | **0.5778** | **+0.065** |
- Track B unggul di 9 dari 10 trait. Track A unggul HANYA di OS:
  ResNet18 menangkap aspek visual layout (kepadatan teks, panjang visual esai)
  yang tidak tersampaikan secara eksplisit dalam caption teks.
- Jawaban RQ3: **Track B (T2T) secara keseluruhan lebih baik** (+0.065 QWK),
  mengkonfirmasi Bursztyn et al. (2024) dan Zhao et al. (2025).
  T2T mengonversi masalah multimodal → teks murni → RoBERTa memanfaatkan
  pre-training bahasa penuh untuk semua trait linguistik.
  Pengecualian: OS — fitur visual ResNet18 masih relevan untuk struktur tata letak.

---

### 4.4 RQ4 — Perbandingan Captioner untuk Bar Chart dan Pie Chart (~4.5 hal)

**RQ4:** Di antara DePlot dan MATCHA, captioner mana yang menghasilkan caption lebih andal
dan memberikan kontribusi terbaik terhadap performa scoring pada dataset EssayJudge?

**4.4.1 Dasar Teori: DePlot dan MATCHA sebagai Captioner Grafik Terstruktur**
- DePlot (Liu et al., 2023): Pix2Struct-based, dilatih khusus untuk mengekstraksi
  tabel terstruktur dari grafik (plot-to-table). Output: tabel markdown.
  Kekuatan: nilai numerik terekstraksi akurat secara struktural.
  Keterbatasan: output mentah bukan narasi — perlu VLM kedua, pipeline dua langkah.
- MATCHA (Liu et al., 2023): Pix2Struct-based, dilatih pada chart2text-statista,
  langsung menghasilkan narasi deskriptif dari grafik. Pipeline satu langkah.
  Kekuatan: narasi natural, tanpa tahap ekstraksi terpisah, lebih ringan komputasi.
  Keterbatasan: akurasi nilai numerik tidak dijamin, bergantung pada visual parsing VLM.
- Hipotesis RQ4: DePlot+Qwen7B diperkirakan unggul karena grounding numerik struktural
  menghasilkan caption lebih faktual, meskipun MATCHA lebih efisien. Kualitas caption
  (akurasi) lebih penting dari naturalness untuk tugas AES scoring.

**4.4.2 DePlot+Qwen7B sebagai Captioner Bar+Pie (Eksperimen 103)**
- Pipeline dua langkah: DePlot mengekstraksi tabel markdown dari gambar →
  Qwen7B menerima gambar + tabel sebagai konteks → narasi akurat secara faktual.
- Setup: identik dengan Eksperimen 093 (konfigurasi, seed=42, freeze), kecuali
  bar+pie (282 sampel) menggunakan DePlot+Qwen7B sebagai captioner,
  sisanya tetap Qwen7B langsung. Split: 737/158/159.
- Hasil: Test QWK = 0.5026. Baseline untuk RQ4.
  Per-trait: AC=0.276, JP=0.493, OS=0.542, CH=0.560, EL=0.486,
  GA=0.576, GD=0.573, LA=0.562, LD=0.520, PA=0.439
- DePlot grounding meningkatkan akurasi deskripsi nilai numerik bar+pie →
  JP naik (persuasiveness didukung data akurat), GA dan LA kompetitif.

**4.4.3 MATCHA sebagai Captioner Bar+Pie (Eksperimen 020)**
- Pipeline satu langkah: MATCHA (282M, Pix2Struct, chart2text-statista) langsung
  menghasilkan narasi dari gambar tanpa ekstraksi tabel.
- Setup training: identik dengan Eksperimen 103 (konfigurasi, split, seed=42).
- Hasil: Test QWK = 0.5213
  Per-trait: [akan diisi jika tersedia per-trait breakdown]
- Catatan kritis: meskipun QWK MATCHA (0.5213) lebih tinggi dari DePlot+Qwen7B (0.5026),
  review manual 100 sampel caption MATCHA menunjukkan error rate tinggi pada bar+pie —
  nilai tidak akurat, kategori tertukar, namun narasi tetap terdengar koheren.
  Fenomena ini menyebabkan caption memiliki fluency tinggi tapi factual accuracy rendah:
  RoBERTa mungkin menilai fluency bukan factual accuracy ketika menghitung skor essay.
- Keputusan: MATCHA TIDAK dipilih meskipun QWK lebih tinggi.
  Sistem dengan caption tidak akurat tidak dapat diandalkan sebagai AES scorer yang valid.

**4.4.4 Evaluasi Kualitas Caption: DePlot vs MATCHA**
- Review manual 100 sampel caption bar+pie untuk setiap captioner, kategori:
  Akurat (nilai numerik dan kategori benar) / Parsial / Salah.
  | Captioner | Bar Chart Error | Pie Chart Error |
  |-----------|----------------|----------------|
  | Qwen7B (baseline, dari 4.3.4) | 54% | 67% |
  | DePlot+Qwen7B | **23%** | 67% |
  | MATCHA | **100%** | **100%** |
- Analisis DePlot+Qwen7B:
  - Bar chart: error turun drastis dari 54% → 23% (-31 pp). DePlot berhasil
    mengekstraksi nilai batang secara struktural dari tabel markdown, Qwen7B
    kemudian menggunakan tabel tersebut sebagai grounding numerik.
  - Pie chart: error tetap 67% — DePlot tidak memiliki keunggulan untuk pie chart
    karena proporsi pie sulit dikonversi ke tabel terstruktur secara akurat.
- Analisis MATCHA:
  - Error rate 100% pada KEDUANYA — setiap caption mengandung nilai yang salah
    atau kategori yang tertukar. Narasi tetap koheren secara linguistik
    (kalimat terbentuk baik) meskipun konten faktualnya sepenuhnya salah.
  - Ini menjelaskan mengapa MATCHA memiliki QWK lebih tinggi (0.5213 vs 0.5026):
    RoBERTa merespons kualitas bahasa (fluency), bukan akurasi konten grafik.
    QWK tinggi MATCHA adalah artefak koherensi linguistik, bukan pemahaman grafik.
- Kesimpulan: DePlot+Qwen7B jelas lebih andal dari MATCHA meski QWK-nya lebih rendah.

**4.4.5 Mengapa DePlot Dipilih Meskipun QWK-nya Lebih Rendah**
- QWK tidak selalu merefleksikan keandalan sistem: MATCHA mendapat QWK lebih tinggi
  dari caption yang secara faktual salah tapi linguistik koheren — artinya
  RoBERTa mengalami "shortcut" pada fitur bahasa superfisial, bukan konten grafik.
- Prinsip yang digunakan: akurasi faktual caption adalah prasyarat, bukan opsional,
  untuk sistem AES yang dapat dipertanggungjawabkan.
- DePlot dengan nilai numerik terstruktur menghasilkan caption yang dapat diverifikasi
  dan terpercaya — lebih cocok sebagai komponen dalam sistem penilaian akademik.
- PaliGemma (kandidat ketiga): DROPPED — caption generation gagal sepenuhnya
  pada lingkungan Kaggle P100 (Eksperimen 021).

**4.4.6 Captioner Alternatif: Llama3.2-11B (Eksperimen 13 dan 112)**
- Eksperimen 13: Llama3.2-11B captions, full 1.054 sampel, seeded.
  Hasil: Test QWK = 0.4701 vs Qwen7B full (Exp081 = 0.4796) → -0.010.
  Per-trait: AC=0.235, JP=0.429, OS=0.540, CH=0.513, EL=0.431,
  GA=0.554, GD=0.556, LA=0.524, LD=0.504, PA=0.416

- Eksperimen 112: DePlot+Llama3.2-11B untuk bar+pie, Qwen7B untuk composite+rest.
  Hasil: Test QWK = 0.4690 vs DePlot+Qwen7B (Exp103 = 0.5026) → -0.034.
  Per-trait: AC=0.256, JP=0.389, OS=0.532, CH=0.528, EL=0.430,
  GA=0.532, GD=0.558, LA=0.582, LD=0.476, PA=0.408

- Analisis: Llama3.2-11B menghasilkan caption lebih verbose tapi kurang terkalibrasi
  untuk format IELTS chart description. Ukuran model (11B > 7B) bukan faktor utama —
  spesialisasi domain jauh lebih menentukan kualitas caption untuk AES.

**4.4.7 Jawaban RQ4**
- Jawaban RQ4: **DePlot+Qwen7B dipilih** sebagai captioner untuk bar+pie chart
  meskipun MATCHA memiliki QWK lebih tinggi (0.5213 vs 0.5026).
- Alasan: review manual mengkonfirmasi caption MATCHA tidak akurat secara faktual;
  QWK tinggi MATCHA adalah artefak dari koherensi linguistik, bukan pemahaman grafik.
- Temuan penting: metrik QWK saja tidak cukup sebagai kriteria pemilihan captioner —
  evaluasi kualitas caption manual diperlukan untuk sistem AES yang dapat diandalkan.
- Tambahan: ukuran model bukan faktor penentu (Llama3.2-11B < Qwen7B < DePlot+Qwen7B).

---

### 4.5 RQ5 — Perbandingan VLM 7B: Qwen2-VL-7B-Instruct vs DeepSeek-VL-7B (~3.5 hal)

**RQ5:** Apakah terdapat perbedaan performa yang signifikan antara Qwen2-VL-7B-Instruct
dan DeepSeek-VL-7B sebagai captioner dalam pipeline T2T, dalam batasan ≤7B parameter?

**4.5.1 Konteks: Baseline Zero-Shot VLM pada EssayJudge (Singh et al., 2024)**
- Singh et al. (2024) melaporkan hasil zero-shot MLLM pada EssayJudge (Tabel 2):
  DeepSeek-VL-7B: avg QWK ~0.11; Qwen2-VL-7B-Instruct: avg QWK ~0.14.
  Dalam zero-shot setting, Qwen2-VL-7B unggul +0.03 atas DeepSeek-VL-7B.
- Hipotesis RQ5: dalam pipeline T2T (supervised), perbedaan ini mungkin diperkuat atau
  justru hilang tergantung seberapa baik tiap VLM menghasilkan caption yang dapat
  dimanfaatkan oleh RoBERTa scorer. Kemampuan zero-shot tidak selalu berkorelasi
  dengan kualitas caption untuk downstream scoring.

**4.5.2 Qwen2-VL-7B-Instruct sebagai Baseline (Eksperimen 093)**
- Caption: 772 sampel non-bar/non-pie (83 gambar unik) diproses oleh
  Qwen2-VL-7B-Instruct (4-bit NF4, Kaggle P100).
- Hasil: Test QWK = 0.5778 (direferensikan dari 4.3.5).
- Perbandingan dengan zero-shot: 0.5778 vs ~0.14 zero-shot → supervised T2T
  memberikan 4× peningkatan; fine-tuning scorer pada caption Qwen jauh lebih efektif
  dari zero-shot inference langsung.

**4.5.3 DeepSeek-VL-7B sebagai Captioner Alternatif**
[DATA PENDING — captioning belum dijalankan]
- Model: DeepSeek-VL-7B, parameter identik dengan Qwen2-VL-7B, arsitektur berbeda.
- Rencana: generate captions untuk konfigurasi Eksperimen 093 (772 non-bar/pie sampel).
  Training: identik dengan Eksperimen 093 (split, seed, freeze, hyperparameter).
- Tabel hasil akan diisi setelah eksperimen selesai.

**4.5.4 Konteks Tambahan: InternVL2-8B (Eksperimen 12, di luar scope ≤7B)**
- InternVL2-8B (8B, sedikit di luar scope ≤7B) diuji sebagai referensi upper bound:
  Test QWK = 0.5017 (full 1.054 sampel, seeded)
  Per-trait: AC=0.300, JP=0.453, OS=0.577, CH=0.580, EL=0.484,
  GA=0.532, GD=0.558, LA=0.576, LD=0.507, PA=0.452
- Hampir identik dengan Eksperimen 103 DePlot+Qwen7B (0.5017 vs 0.5026, selisih 0.001).
- Implikasi: menambah 1B parameter tidak memberikan gain signifikan →
  bottleneck bukan di kapasitas VLM tetapi di strategi captioning dan penanganan
  jenis grafik bermasalah.

**4.5.5 Jawaban RQ5**
[Akan dilengkapi setelah eksperimen DeepSeek selesai]
- Hipotesis berdasarkan zero-shot: Qwen2-VL-7B unggul atas DeepSeek-VL-7B.
- Jika terkonfirmasi: pemilihan VLM 7B berpengaruh pada kualitas AES;
  Qwen2-VL lebih sesuai untuk caption grafik IELTS.
- Jika DeepSeek setara: arsitektur VLM 7B yang berbeda dapat menghasilkan
  performa comparable di pipeline T2T, dan faktor lain (strategi sampling,
  prompt engineering) lebih menentukan.

---

### 4.6 RQ6 — Signifikansi Statistik (~4 hal)

**RQ6:** Apakah perbedaan performa antara sistem terbaik dan baseline secara statistik
signifikan? Apakah prediksi sistem terbaik tidak berbeda signifikan dari anotasi manusia?

**4.6.1 Metodologi Uji Statistik**
- Uji yang digunakan: paired t-test per trait (Bonferroni α=0.005).
  Menguji apakah prediksi sistem terbaik secara sistematis berbeda dari anotasi manusia
  per trait. Bonferroni correction untuk 10 trait: α = 0.05/10 = 0.005.
- Setup: test set 158 sampel dari Eksperimen 093.
- Referensi: metode dari Yannakoudakis et al. (2011) dan Zhao et al. (2025)
  untuk evaluasi statistik sistem AES.

**4.6.2 Paired T-Test per Trait**
[DATA PENDING — memerlukan prediksi per-sampel dari Eksperimen 093]
- H0: mean(prediksi Exp093) = mean(ground_truth) untuk setiap trait.
- Bonferroni: α = 0.005 (0.05/10 traits).
- Harapan:
  - p > 0.005 (gagal tolak H0): prediksi tidak berbeda signifikan dari manusia
    → diharapkan untuk GA (0.688), GD (0.653), LA (0.658), LD (0.610), CH (0.606)
  - p < 0.005 (tolak H0): ada systematic bias
    → kemungkinan untuk AC (0.330) — model underpredict kejelasan argumen

**4.6.3 Interpretasi dan Diskusi**
- Trait dengan QWK tinggi (GA=0.688, LA=0.658) → prediksi mendekati anotasi manusia;
  sistem dapat diandalkan untuk trait linguistik terukur.
- AC (0.330) adalah outlier — menilai kejelasan argumen holistik memerlukan pemahaman
  tema esai secara keseluruhan, sesuatu yang sulit ditangkap fitur linguistik lokal RoBERTa.
- Implikasi praktis: sistem dapat digunakan dengan kepercayaan tinggi untuk trait linguistik
  (GA, GD, LA, LD, PA), namun masih perlu evaluasi manusia untuk AC dan sebagian JP.

---

### 4.7 Perbandingan dengan Penelitian Terdahulu dan Keterbatasan (~3.5 hal)

**4.7.1 Perbandingan vs Baseline Zero-Shot MLLM (EssayJudge Paper)**
- Tabel perbandingan:
  | Model | Tipe | Avg QWK |
  |-------|------|---------|
  | Yi-VL 6B | Open-source, zero-shot | ~0.07 |
  | DeepSeek-VL 7B | Open-source, zero-shot | ~0.11 |
  | LLaMA-3.2-Vision 11B | Open-source, zero-shot | ~0.13 |
  | Qwen2-VL 7B | Open-source, zero-shot | ~0.14 |
  | MiniCPM-LLaMA3-V2.5 8B | Open-source, zero-shot | ~0.21 |
  | GPT-4o | Closed-source, zero-shot | ~0.54 |
  | **Exp033 (Track A, ours)** | Fine-tuned, supervised | **0.5126** |
  | **Exp093 (Track B, ours)** | Fine-tuned, supervised | **0.5778** |
- Eksperimen 093 melampaui semua MLLM open-source zero-shot dengan selisih >0.35.
- Eksperimen 093 melampaui GPT-4o zero-shot (+0.04) — meski tidak sepenuhnya
  apple-to-apple karena metrik EssayJudge menggunakan MTS (average-then-QWK).
- Supervised fine-tuning dengan 737 sampel berlabel jauh lebih efektif dari
  zero-shot inference model besar manapun pada tugas ini.

**4.7.2 Konfirmasi Temuan Literatur**
- Tabel konfirmasi:
  | Klaim Literatur | Sumber | Terkonfirmasi? |
  |----------------|--------|----------------|
  | Late fusion > early/intermediate untuk modalitas berbeda | Baltrusaitis et al. (2019) | ✓ Exp030–032 |
  | RoBERTa > BERT pada downstream tasks | Liu et al. (2019) | ✓ Exp032–033 (+0.029) |
  | Teks > fitur visual untuk chart reasoning | Bursztyn et al. (2024) | ✓ Track B > Track A |
  | DePlot meningkatkan akurasi reasoning grafik terstruktur | Liu et al. (2023) | ✓ Exp103 vs Exp081 |
  | VLM pipeline meningkatkan penilaian akademik | Zhao et al. (2025) | ✓ Track B best overall |

**4.7.3 Keterbatasan Penelitian**
- Dataset kecil: 158 test samples → estimasi QWK memiliki variance tinggi;
  hasil mungkin tidak stabil pada re-split berbeda.
- Batasan VLM ≤7B: model lebih besar (>13B) tidak dievaluasi akibat keterbatasan GPU.
  InternVL2-8B (Eksperimen 12) menunjukkan tidak ada gain dari penambahan 1B parameter,
  namun belum tentu berlaku untuk model jauh lebih besar.
- RQ5 masih pending: DeepSeek-VL-7B belum selesai; kesimpulan RQ5 bersifat sementara.
- RQ6 masih pending: prediksi per-sampel Exp093 dan Exp033 belum diekstraksi.
- AC (Argument Clarity) konsisten sulit diprediksi (best=0.330): memerlukan pemahaman
  holistik argumen yang melampaui fitur linguistik lokal RoBERTa.
- Tidak ada evaluasi lintas-dataset: generalisasi ke ASAP, ASAP++ belum diverifikasi.
- Caption dihasilkan sekali (frozen inference) — fine-tuning VLM pada domain IELTS
  berpotensi meningkatkan kualitas caption secara substansial.

---

## RINGKASAN STRUKTUR FINAL

| Subbab | Konten | Sub-subbab | Est. Halaman |
|--------|--------|-----------|-------------|
| Intro | Overview 2 jalur + 6 RQ | — | 0.5 |
| 4.1 RQ1 | Fusion strategies (teori + 3 exp + jawaban) | 4.1.1–4.1.5 | 5.5 |
| 4.2 RQ2 | BERT vs RoBERTa (teori + 2 exp + analisis + jawaban) | 4.2.1–4.2.5 | 4.5 |
| 4.3 T2T + RQ3 | Motivasi + baseline + distribusi + error rate + proof eksklusi + kesimpulan + jawaban RQ3 | 4.3.1–4.3.7 | 7 |
| 4.4 RQ4 | DePlot vs MATCHA + QA review + mengapa DePlot dipilih + Llama + jawaban | 4.4.1–4.4.7 | 4.5 |
| 4.5 RQ5 | Konteks zero-shot + Qwen baseline + DeepSeek + InternVL konteks + jawaban | 4.5.1–4.5.5 | 3.5 |
| 4.6 RQ6 | Metodologi + paired t-test per trait + interpretasi | 4.6.1–4.6.3 | 3 |
| 4.7 Literatur | Zero-shot compare + konfirmasi + keterbatasan | 4.7.1–4.7.3 | 3.5 |
| **TOTAL** | | | **~33 hal** |

---

## CATATAN PERBAIKAN v5 (dari v4)
1. **4.4 (RQ3) dihapus sebagai section tersendiri**: seluruh konten exploration dihapus
   (Siamese Exp016/017, freeze ablation Exp121–125, DePlot variants Exp101/102).
2. **RQ3 jawaban dipindah ke 4.3.7**: secara natural melanjutkan narasi T2T discovery —
   setelah membuktikan Track B best = 0.5778, langsung dibandingkan dengan Track A best = 0.5126.
3. **Renumbering**: 4.5→4.4 (RQ4), 4.6→4.5 (RQ5), 4.7→4.6 (RQ6), 4.8→4.7 (Literatur).
4. **4.4.4 ditambah** (baru): QA review DePlot vs MATCHA, sama seperti 4.3.4 untuk Qwen.
5. **Cross-references diupdate**: 4.4.2 referensikan Exp093 ke "4.3.5", bukan "4.4.3" lama.
6. **Tabel konfirmasi literatur diupdate**: hapus baris freeze/Howard & Ruder (eksperimen dihapus).

---

## DATA YANG MASIH DIBUTUHKAN

1. **DeepSeek-VL-7B captioning + training** → RQ5 (4.5.3)
2. **Per-sample predictions Exp093** (.json results) → RQ6 paired t-test per trait
4. **MATCHA per-trait QWK breakdown** (Exp020) → 4.4.3 jika tersedia
5. **DePlot vs MATCHA manual caption review** → 4.4.4 (data error rate)

## PENDING SCRIPTS

- `run_statistical_tests.py` — paired t-test + bootstrap resampling
- `write_bab4.py` — Google Docs writer untuk BAB IV tab (buat tab manual dulu)

## STATUS SEMUA EKSPERIMEN (untuk referensi)
| Eksperimen | Hasil | Status di Outline |
|-----------|-------|------------------|
| Exp030 early fusion | 0.4777 | 4.1.2 |
| Exp031 mid fusion | 0.4799 | 4.1.3 |
| Exp032 late fusion | 0.4838 | 4.1.4 |
| Exp033 RoBERTa late | 0.5126 | 4.2.3 + 4.3.7 |
| Exp081 T2T full 1054 | 0.4796 | 4.3.2 |
| Exp092 excl 3 types | 0.4941 | 4.3.5 |
| Exp093 excl bar+pie | **0.5778** | 4.3.5 + 4.3.7 |
| Exp103 DePlot seeded | 0.5026 | 4.4.2 |
| Exp020 MATCHA | 0.5213 | 4.4.3 (DROPPED) |
| Exp021 PaliGemma | N/A | 4.4.5 (DROPPED) |
| Exp13 Llama3.2-11B | 0.4701 | 4.4.6 |
| Exp112 DePlot+Llama | 0.4690 | 4.4.6 |
| Exp12 InternVL2-8B | 0.5017 | 4.5.4 |
| DeepSeek-VL-7B | PENDING | 4.5.3 |
