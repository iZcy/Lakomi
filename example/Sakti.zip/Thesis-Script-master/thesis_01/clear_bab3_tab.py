import sys, json
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TARGET_TAB_ID = 't.re803sjptjxa'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()

def find_tab(tabs, target_id):
    for t in tabs:
        tp = t.get('tabProperties', {})
        if tp.get('tabId') == target_id:
            return t
        child = find_tab(t.get('childTabs', []), target_id)
        if child:
            return child
    return None

def print_tabs(tabs, indent=0):
    for t in tabs:
        tp = t.get('tabProperties', {})
        body = t.get('documentTab', {}).get('body', {})
        content = body.get('content', [])
        end = content[-1].get('endIndex', 0) if content else 0
        print(' ' * indent + f"tabId={tp.get('tabId')} title={tp.get('title')} endIndex={end}")
        print_tabs(t.get('childTabs', []), indent + 4)

print_tabs(doc.get('tabs', []))

tab = find_tab(doc.get('tabs', []), TARGET_TAB_ID)
if tab:
    body = tab.get('documentTab', {}).get('body', {})
    content = body.get('content', [])
    end = content[-1].get('endIndex', 0) if content else 0
    print(f'\nFound target tab: endIndex={end}')
    if end > 2:
        print(f'Deleting content range 1 to {end - 1}...')
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': [{
                'deleteContentRange': {
                    'range': {'startIndex': 1, 'endIndex': end - 1, 'tabId': TARGET_TAB_ID}
                }
            }]}
        ).execute()
        print('Cleared.')
    else:
        print('Tab already empty.')
else:
    print(f'\nTarget tab {TARGET_TAB_ID} not found in any level.')
