import sys
sys.stdout.reconfigure(encoding='utf-8')
import json
import requests as req
from google.oauth2 import service_account
from google.auth.transport.requests import Request as GoogleRequest

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
THESIS_DRAFT_TAB_ID = 't.l6y1yzoye6yt'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
creds.refresh(GoogleRequest())

token = creds.token
headers = {
    'Authorization': f'Bearer {token}',
    'Content-Type': 'application/json'
}
url = f'https://docs.googleapis.com/v1/documents/{DOCUMENT_ID}:batchUpdate'

def create_tab(title):
    body = {
        "requests": [{
            "createTab": {
                "tab": {
                    "tabProperties": {
                        "title": title,
                        "parentTabId": THESIS_DRAFT_TAB_ID
                    }
                }
            }
        }]
    }
    resp = req.post(url, headers=headers, json=body)
    print(f"Create '{title}': HTTP {resp.status_code}")
    data = resp.json()
    for reply in data.get('replies', []):
        ct = reply.get('createTab', {})
        tab_props = ct.get('tab', {}).get('tabProperties', {})
        tab_id = tab_props.get('tabId', '')
        if tab_id:
            print(f"  New tab ID: {tab_id}")
    if resp.status_code != 200:
        print(json.dumps(data, indent=2))
    return data

create_tab("BAB II - Draft")
create_tab("BAB III - Draft")
