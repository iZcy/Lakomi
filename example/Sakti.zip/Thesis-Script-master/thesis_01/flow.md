# Thesis Narrative Flow — Discussion Notes

Last updated: 2026-04-20 (Exp020/021 dropped; DePlot selected; caption error rates added)

---

## Overview

The thesis tells a progressive story:
zero-shot MLLM → trained fusion models → T2T captioning → better captioners → stronger VLM

---

## Full Flow

```
[Starting Point]
EssayJudge Qwen2-VL-7B zero-shot → avg QWK ~0.164
  "Even a 7B MLLM scores poorly without training"
         │
         ▼
[Step 1: First Trained Model]
BERT + ResNet18 Intermediate Fusion
  → Motivated by: BERT-ResNet Cross-Attention paper (Gold, 2025)
  → Experiment: Exp 031 | Dir: Experiment/031_FusionCompare-BERT-Mid/
  → Result: avg QWK 0.4799 (val 0.5380, epoch 8, 12.5 min)
         │
         ▼
[Step 2: Find Best Fusion Strategy]
Compare Early / Intermediate / Late Fusion
  → Motivated by: Paper_1, Paper_2, Paper_3 (fusion comparison papers)
  → All use BERT + ResNet18, same training config (lr=1e-4, seed=42, batch=16)
  → Experiments:
       Exp 030 Early  | Dir: Experiment/030_FusionCompare-BERT-Early/ | QWK 0.4777
       Exp 031 Mid    | Dir: Experiment/031_FusionCompare-BERT-Mid/   | QWK 0.4799
       Exp 032 Late   | Dir: Experiment/032_FusionCompare-BERT-Late/  | QWK 0.4838
  → Result: Late fusion wins (0.4838 > 0.4799 > 0.4777)
         │
         ▼
[Step 3: Improve the Text Encoder]
Swap BERT → RoBERTa (keep Late Fusion + ResNet18)
  → Motivated by: Automatic Essay Multi-dimensional Scoring paper
  → Experiment: Exp 033 | Dir: Experiment/033_FusionCompare-RoBERTa-Late/
  → Result: avg QWK 0.5126 (val 0.5283, epoch 22, 30.6 min)
  → RoBERTa Late (0.5126) > BERT Late (0.4838): +0.029 gain from encoder upgrade
  → Narrative confirmed: Late fusion wins -> RoBERTa beats BERT -> move to T2T
         │
         ▼
[Step 4: Move to T2T — 7B Captioner]
Qwen2-VL-7B-Instruct captions, full 1054 + Dual RoBERTa (Exp 08)
  → No image encoder needed in training loop
  → Motivated by: EDU-CIRCUIT-HW (2025) — validates image-to-text for educational assessment
  → Experiment: Exp 08  | Dir: Experiment/08_T2T-7B-MultiTask-Full1054/           | QWK 0.4579
  → Seeded:    Exp 081  | Dir: Experiment/081_T2T-7B-MultiTask-Full1054-Seeded/    | QWK 0.4796
  → Validation: Exp 093 | Dir: Experiment/093_T2T-7B-MultiTask-ExclBarPie-Seeded/  | QWK 0.5778 (BEST)
    — confirms T2T direction is correct; optimized T2T far exceeds initial result
    — T2T gap vs Fusion (0.4579 < 0.5126) is closed and surpassed by caption optimization
         │
         ▼
[Step 5: Caption Quality Analysis]
100-sample manual review of captions (same 100-sample index across all captioners)
  → Qwen-7B baseline error rates:  bar=54%  pie=67%
  → DePlot+Qwen7B error rates:     bar=23%  pie=67%   (bar improved, pie unchanged)
  → MATCHA error rates:            bar=100% pie=100%  (completely unreliable)
  → Key finding: caption factual accuracy != downstream AES performance
    (MATCHA QWK 0.5213 > DePlot 0.5026 despite 100% error rate — model learns
     from essay text primarily; bar+pie is only 282/1054 = 27% of samples)
  → Decision: select DePlot — lower raw QWK but factually reliable captions
         │
         ▼
[Step 6: Find Best Chart Captioner — 3 Candidates Evaluated]
DePlot  vs  MATCHA  vs  PaliGemma
  → Applied to bar + pie charts specifically; 7B handles the rest
  → Motivated by: DePlot paper, MATCHA paper, Multimodal Chart Retrieval paper
  → Experiments:
       Exp 103 DePlot+Qwen7B  | Dir: Experiment/103_T2T-DePlot-BarPie-7BComposite-Seeded/ | QWK 0.5026 | SELECTED
       Exp 020 MATCHA         | Dir: Experiment/020_T2T-MATCHA-BarPie/                    | QWK 0.5213 | DROPPED — 100-sample manual review showed high error rate in bar+pie captions
       Exp 021 PaliGemma      | DROPPED — bar+pie caption generation failed entirely
  → Winner: DePlot — only reliable specialized captioner after caption quality review
  → Caption error rate summary (100-sample manual review, bar+pie only):
       Captioner       bar_error  pie_error
       Qwen-7B          54%        67%   (baseline)
       DePlot+Qwen7B    23%        67%   (bar much better, pie unchanged)
       MATCHA          100%       100%   (completely unreliable)
  → Note: MATCHA QWK (0.5213) > DePlot (0.5026) despite 100% error rate
    → caption accuracy != AES score; RoBERTa learns from essay text primarily
    → DePlot selected for thesis narrative (reliable, interpretable captions)
         │
         ▼
[Step 7: Apply Best Captioner — Hybrid Pipeline]
DePlot for bar/pie + Qwen2-VL-7B for rest
  → Experiment: Exp 091/093 | Dir: Experiment/091_T2T-7B-MultiTask-ExclBarPie/
                               Seeded: Experiment/093_T2T-7B-MultiTask-ExclBarPie-Seeded/
  → Result: Exp 091 = 0.4945 | Exp 093 (seeded) = 0.5778 (BEST OVERALL)
         │
         ▼
[Step 8: Try Stronger VLM as Captioner]
InternVL2-8B captions + Dual RoBERTa (Exp 12)
  → Does a larger, more capable VLM caption better than hybrid?
  → Experiment: Exp 12 | Dir: Experiment/12_T2T-InternVL2-Full1054/
  → Result: avg QWK 0.5017 (on par with Exp 103 DePlot+Qwen7B = 0.5026)
  → Finding: Larger caption model alone not the bottleneck
         │
         ▼
[Step 9: TBD]
InternVL2.5 / MiniCPM — to be decided later
```

---

## Chapter Mapping

| Chapter | Content |
|---------|---------|
| Bab I | Pendahuluan — problem, rumusan masalah, tujuan, batasan |
| Bab II | Tinjauan Pustaka & Dasar Teori — AES, fusion types, VLMs, RoBERTa, ResNet, DePlot, QWK |
| Bab III | Metode Penelitian — dataset, architectures, training config, experiment flow |
| Bab IV | Hasil & Pembahasan — follows Steps 1–8 above |
| Bab V | Kesimpulan & Saran |

---

## Pending Experiments

| Step | What | Dir | Priority |
|------|------|-----|----------|
| Step 3 | ~~Exp 033 RoBERTa + ResNet18 Late Fusion~~ | Experiment/033_FusionCompare-RoBERTa-Late/ | DONE (0.5126) |
| Step 6 | ~~Exp 020 MATCHA~~ | Experiment/020_T2T-MATCHA-BarPie/ | DROPPED — high error rate in bar+pie captions (100-sample review) |
| Step 6 | ~~Exp 021 PaliGemma~~ | Experiment/021_T2T-DePlot-PaliGemma-BarPie/ | DROPPED — caption generation failed |
| Step 9 | Exp 022 InternVL2.5 / MiniCPM | Experiment/022_T2T-InternVL25-Full1054/ | Defer |

---

## Key Result Table (so far)

| Step | Exp | Approach | Dir | Avg Test QWK | Done |
|------|-----|----------|-----|-------------|------|
| Baseline | - | Zero-shot Qwen2-VL-7B | EssayJudge/code/Open_source/ | ~0.164 | Yes |
| Step 1 | Exp 031 | BERT+ResNet18 Mid Fusion | Experiment/031_FusionCompare-BERT-Mid/ | 0.4799 | Yes |
| Step 2 | Exp 030 | BERT+ResNet18 Early Fusion | Experiment/030_FusionCompare-BERT-Early/ | 0.4777 | Yes |
| Step 2 | Exp 031 | BERT+ResNet18 Mid Fusion | Experiment/031_FusionCompare-BERT-Mid/ | 0.4799 | Yes |
| Step 2 | Exp 032 | BERT+ResNet18 Late Fusion | Experiment/032_FusionCompare-BERT-Late/ | 0.4838 | Yes |
| Step 3 | Exp 00 | RoBERTa+ResNet18 per-trait (ref) | Experiment/00_baseline/ | 0.4237 | Yes |
| Step 3 | Exp 033 | RoBERTa+ResNet18 Late multi-task | Experiment/033_FusionCompare-RoBERTa-Late/ | 0.5126 | Yes |
| Step 4 | Exp 08 | T2T Qwen2-VL-7B full 1054 | Experiment/08_T2T-7B-MultiTask-Full1054/ | 0.4579 | Yes |
| Step 4 | Exp 081 | T2T Qwen2-VL-7B seeded | Experiment/081_T2T-7B-MultiTask-Full1054-Seeded/ | 0.4796 | Yes |
| Step 6 | Exp 103 | T2T DePlot+Qwen7B bar+pie | Experiment/103_T2T-DePlot-BarPie-7BComposite-Seeded/ | 0.5026 | Yes |
| Step 6 | Exp 020 | T2T MATCHA bar+pie | Experiment/020_T2T-MATCHA-BarPie/ | 0.5213 | DROPPED (high caption error rate) |
| Step 6 | Exp 021 | T2T PaliGemma bar+pie | Experiment/021_T2T-DePlot-PaliGemma-BarPie/ | N/A | DROPPED (caption gen failed) |
| Step 7 | Exp 091 | T2T Qwen7B excl bar+pie | Experiment/091_T2T-7B-MultiTask-ExclBarPie/ | 0.4945 | Yes |
| Step 7 | Exp 093 | T2T Qwen7B excl bar+pie seeded | Experiment/093_T2T-7B-MultiTask-ExclBarPie-Seeded/ | 0.5778 | Yes (BEST) |
| Step 8 | Exp 12 | T2T InternVL2-8B full 1054 | Experiment/12_T2T-InternVL2-Full1054/ | 0.5017 | Yes |

---

## Open Issues

1. **Steps 2 & 3 DONE.** Late fusion wins (0.4838 > 0.4799 > 0.4777). RoBERTa Late (0.5126)
   beats BERT Late (0.4838) under identical config — loophole closed. Narrative fully supported:
   Early -> Mid -> Late -> RoBERTa upgrade -> T2T.

2. **Exp 052 (2B T2T) is scrapped from the narrative flow** but the results still exist.
   It can appear in the appendix or as a footnote in the dasar teori section.

3. **AC trait** consistently near-zero across all experiments — worth a dedicated discussion
   paragraph in Bab IV explaining why (semantic alignment between opening paragraph and image).

4. **Exp 07 (Back Translation)** has suspicious results (0.5724 avg) — NOT included in the
   flow since the score tensor bug makes it unverifiable. Can mention in Saran as future work.
