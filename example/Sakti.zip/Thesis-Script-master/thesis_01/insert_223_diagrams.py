"""
Insert 4 fusion diagrams into Docs tab t.v7l3rd9jsdie.
Files must already be uploaded to the Drive folder by the user (service accounts
have no storage quota and cannot own files in personal Drive).
Script: lists folder, makes files public, inserts into Docs.
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = [
    'https://www.googleapis.com/auth/documents',
    'https://www.googleapis.com/auth/drive',
]
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'
FIGURES_DIR = 'C:/Outpost/Skripsi/Research 4/thesis_latex/contents/chapter-2/figures'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
docs_service = build('docs', 'v1', credentials=creds)
drive_service = build('drive', 'v3', credentials=creds)

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        docs_service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()

DRIVE_FOLDER_ID = '1__lw4kKA_Vnzwpw3ZNPycuVKA7zDTqCd'

def get_or_make_public(filename):
    """Find file by name in the Drive folder, make public, return direct URL."""
    results = drive_service.files().list(
        q=f"name='{filename}' and '{DRIVE_FOLDER_ID}' in parents and trashed=false",
        fields='files(id,name)',
    ).execute()
    files = results.get('files', [])
    if not files:
        raise FileNotFoundError(
            f"'{filename}' not found in Drive folder {DRIVE_FOLDER_ID}. "
            "Please upload it manually to the folder first."
        )
    file_id = files[0]['id']
    # Make public (idempotent — safe to call even if already public)
    try:
        drive_service.permissions().create(
            fileId=file_id,
            body={'type': 'anyone', 'role': 'reader'},
        ).execute()
    except Exception:
        pass  # already public or no permission needed
    url = f'https://drive.google.com/uc?export=download&id={file_id}'
    print(f'Found {filename} (id={file_id}) -> {url}')
    return url

# ── Diagrams: (filename, caption, insert_after_text) ──────────────────────────
# Insert each diagram at the END of each subsubsection's last body paragraph,
# i.e., just before the next subsubsection heading.
# We identify the insertion point by finding the next subsubsection heading
# and inserting BEFORE it (so image appears at end of current subsubsection).

DIAGRAMS = [
    (
        'fusion_early.png',
        'Gambar 2.1. Arsitektur Early Fusion: penggabungan dilakukan di level input sebelum encoder bersama.',
        '2.2.3.2 Intermediate Fusion',   # insert before this heading
    ),
    (
        'fusion_intermediate.png',
        'Gambar 2.2. Arsitektur Intermediate Fusion: penggabungan via cross-attention di level representasi tersembunyi.',
        '2.2.3.3 Late Fusion',
    ),
    (
        'fusion_late.png',
        'Gambar 2.3. Arsitektur Late Fusion: encoder bekerja sepenuhnya independen, penggabungan di level output.',
        '2.2.3.4 Hybrid Fusion',
    ),
    (
        'fusion_hybrid.png',
        'Gambar 2.4. Arsitektur Hybrid Fusion: menggabungkan path early fusion dan late fusion secara bersamaan.',
        '2.2.4 Penilaian Esai Multimoda',  # insert before 2.2.4
    ),
]

# ── Step 1: Locate images in Drive folder (must be pre-uploaded by user) ──────
urls = {}
for fname, caption, _ in DIAGRAMS:
    url = get_or_make_public(fname)
    urls[fname] = url
    time.sleep(0.3)

print('All images located in Drive folder.')

# ── Step 2: Insert images + captions into Docs ────────────────────────────────
# Do in reverse order so earlier insertions don't shift indices of later ones.
for fname, caption, next_heading in reversed(DIAGRAMS):
    url = urls[fname]

    # Fetch fresh doc
    doc = docs_service.documents().get(
        documentId=DOCUMENT_ID, includeTabsContent=True
    ).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    # Find the next heading paragraph to insert before it
    insert_at = None
    for el in body_content:
        if 'paragraph' in el:
            text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in el['paragraph'].get('elements', [])
            ).strip()
            if text == next_heading:
                insert_at = el.get('startIndex')
                break

    if insert_at is None:
        print(f'ERROR: Could not find heading "{next_heading}". Skipping {fname}.')
        continue

    print(f'Inserting {fname} before "{next_heading}" at index {insert_at}.')

    # Insert caption text FIRST (will be pushed down after image insert)
    # Then insert image above it.
    # Strategy: insert caption at insert_at, then image at insert_at (above caption).

    # 1. Insert caption paragraph
    batch_update([{
        'insertText': {
            'text': caption + '\n',
            'location': {'index': insert_at, 'tabId': TAB_ID},
        }
    }])

    # 2. Style caption: centered, italic, 11pt
    batch_update([
        {
            'updateParagraphStyle': {
                'range': {
                    'startIndex': insert_at,
                    'endIndex': insert_at + len(caption) + 1,
                    'tabId': TAB_ID,
                },
                'paragraphStyle': {
                    'alignment': 'CENTER',
                    'spaceAbove': {'magnitude': 3, 'unit': 'PT'},
                    'spaceBelow': {'magnitude': 12, 'unit': 'PT'},
                    'lineSpacing': 120,
                },
                'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
            }
        },
        {
            'updateTextStyle': {
                'range': {
                    'startIndex': insert_at,
                    'endIndex': insert_at + len(caption),
                    'tabId': TAB_ID,
                },
                'textStyle': {
                    'italic': True,
                    'fontSize': {'magnitude': 10, 'unit': 'PT'},
                    'weightedFontFamily': {'fontFamily': 'Times New Roman'},
                },
                'fields': 'italic,fontSize,weightedFontFamily',
            }
        }
    ])

    # 3. Insert image before caption
    batch_update([{
        'insertInlineImage': {
            'uri': url,
            'location': {'index': insert_at, 'tabId': TAB_ID},
            'objectSize': {
                'width':  {'magnitude': 380, 'unit': 'PT'},
                'height': {'magnitude': 285, 'unit': 'PT'},
            },
        }
    }])

    # 4. Center the image paragraph
    # Image is inserted at insert_at, pushing caption down by 1 char (the image char)
    batch_update([{
        'updateParagraphStyle': {
            'range': {
                'startIndex': insert_at,
                'endIndex': insert_at + 1,
                'tabId': TAB_ID,
            },
            'paragraphStyle': {
                'alignment': 'CENTER',
                'spaceAbove': {'magnitude': 12, 'unit': 'PT'},
                'spaceBelow': {'magnitude': 3, 'unit': 'PT'},
            },
            'fields': 'alignment,spaceAbove,spaceBelow',
        }
    }])

    print(f'Done: {fname}')
    time.sleep(1)

print('\nAll diagrams inserted.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
