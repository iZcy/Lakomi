import sys, json
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=False).execute()
print("Top-level keys:", list(doc.keys()))
tabs = doc.get('tabs', [])
print(f"Tabs found: {len(tabs)}")
for tab in tabs:
    print(json.dumps(tab.get('tabProperties', {}), indent=2))
