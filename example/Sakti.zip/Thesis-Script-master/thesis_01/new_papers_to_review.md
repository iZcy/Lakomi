# New Papers to Review
Found via web search 2026-04-13

## Supporting T2T Approach

1. **Representing Charts as Text for Language Models: An In-Depth Study of Question Answering for Bar Charts**
   - Adobe Research, IEEE VIS 2024
   - Key: Text-only > vision-based GPT-4 for chart reasoning (99% vs 63%)
   - URL: https://ieeexplore.ieee.org/document/10771151/

2. **DePlot: One-shot visual language reasoning by plot-to-table translation**
   - Liu et al., ACL Findings 2023, arXiv:2212.10505
   - Key: Chart→text decomposition for downstream LLM reasoning
   - URL: https://arxiv.org/abs/2212.10505

3. **VisText: A Benchmark for Semantically Rich Chart Captioning**
   - Tang et al., ACL 2023 Outstanding Paper, arXiv:2307.05356
   - Key: Rich chart captions enable better downstream NLP performance
   - URL: https://arxiv.org/abs/2307.05356

4. **EDU-CIRCUIT-HW: Evaluating MLLMs on Real-World University-Level STEM Student Handwritten Solutions**
   - arXiv:2602.00095, 2025
   - Key: Image→text interpretation for educational assessment
   - Already in Papers folder

## Related Work on EssayJudge (Competitor Papers)

5. **Decision-Level Ordinal Modeling for Multimodal Essay Scoring with Large Language Models**
   - Zhang et al., arXiv:2603.14891, March 2026
   - Key: Works on EssayJudge, DLOM-GF with gated LLM fusion
   - URL: https://arxiv.org/abs/2603.14891

6. **CAFES: A Collaborative Multi-Agent Framework for Multi-Granular Multimodal Essay Scoring**
   - arXiv:2505.13965, May 2025
   - Key: Multi-agent MLLM on EssayJudge, 21% relative QWK improvement
   - URL: https://arxiv.org/abs/2505.13965
