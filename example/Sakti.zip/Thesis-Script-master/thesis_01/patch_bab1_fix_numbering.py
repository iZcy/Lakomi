import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.prr0oo8xt561'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child: return child
    return None

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
content = tab.get('documentTab', {}).get('body', {}).get('content', [])

# Find point 7
p7_start = p7_end = None
for element in content:
    para = element.get('paragraph', {})
    txt = ''.join(pe.get('textRun', {}).get('content', '') for pe in para.get('elements', []))
    if txt.startswith('Perbandingan VLM dalam jalur T2T'):
        p7_start = element.get('startIndex')
        p7_end = element.get('endIndex')
        break

if p7_start is None:
    print('ERROR: Point 7 not found.')
    sys.exit(1)

print(f'Point 7 found at [{p7_start}-{p7_end}]')

requests = [
    # Remove existing bullet
    {
        'deleteParagraphBullets': {
            'range': {'startIndex': p7_start, 'endIndex': p7_end, 'tabId': TAB_ID}
        }
    },
    # Reapply with correct "1." style
    {
        'createParagraphBullets': {
            'range': {'startIndex': p7_start, 'endIndex': p7_end, 'tabId': TAB_ID},
            'bulletPreset': 'NUMBERED_DECIMAL_ALPHA_ROMAN'
        }
    },
]

service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()
print('Done. Numbering style fixed to "1." format.')
