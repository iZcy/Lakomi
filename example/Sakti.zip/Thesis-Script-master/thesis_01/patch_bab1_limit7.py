import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.prr0oo8xt561'  # BAB I

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

INSERT_AT = 5401  # right before blank line after point 6

TEXT = ("Perbandingan VLM dalam jalur T2T dibatasi pada model open-source berukuran "
        "7 miliar parameter, yaitu Qwen2-VL-7B-Instruct dan DeepSeek-VL-7B, akibat "
        "keterbatasan memori GPU yang tersedia pada lingkungan komputasi. Model VLM "
        "berukuran lebih besar tidak dievaluasi dalam penelitian ini.")

requests = [
    # Insert text
    {
        'insertText': {
            'text': TEXT + '\n',
            'location': {'index': INSERT_AT, 'tabId': TAB_ID}
        }
    },
    # Paragraph style: JUSTIFIED, no first-line indent
    {
        'updateParagraphStyle': {
            'range': {'startIndex': INSERT_AT, 'endIndex': INSERT_AT + len(TEXT) + 1, 'tabId': TAB_ID},
            'paragraphStyle': {
                'namedStyleType': 'NORMAL_TEXT',
                'alignment': 'JUSTIFIED',
                'indentFirstLine': {'magnitude': 0, 'unit': 'PT'},
                'spaceAbove': {'magnitude': 0, 'unit': 'PT'},
                'spaceBelow': {'magnitude': 0, 'unit': 'PT'},
            },
            'fields': 'namedStyleType,alignment,indentFirstLine,spaceAbove,spaceBelow'
        }
    },
    # Text style: TNR 12
    {
        'updateTextStyle': {
            'range': {'startIndex': INSERT_AT, 'endIndex': INSERT_AT + len(TEXT) + 1, 'tabId': TAB_ID},
            'textStyle': {
                'bold': False, 'italic': False,
                'fontSize': {'magnitude': 12, 'unit': 'PT'},
                'weightedFontFamily': {'fontFamily': 'Times New Roman'},
            },
            'fields': 'bold,italic,fontSize,weightedFontFamily'
        }
    },
    # Apply numbered list (same preset as other points)
    {
        'createParagraphBullets': {
            'range': {'startIndex': INSERT_AT, 'endIndex': INSERT_AT + len(TEXT) + 1, 'tabId': TAB_ID},
            'bulletPreset': 'NUMBERED_DECIMAL_ALPHA_ROMAN_PARENS'
        }
    },
]

service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()
print('Done. Point 7 added to section 1.4.')
