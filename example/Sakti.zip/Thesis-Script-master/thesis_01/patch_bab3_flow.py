import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

replacements = [
    # Fix step count in intro
    (
        'delapan langkah eksperimen yang bersifat',
        'sepuluh langkah eksperimen yang bersifat'
    ),
    # Fix step 7: was captioner eval, should be exclusion experiments
    (
        '7. Evaluasi Captioner Khusus (Exp 103, Exp 020, Exp 021). Tiga kandidat '
        'captioner dievaluasi untuk bar chart dan pie chart: DePlot+Qwen7B (Exp 103) '
        'menghasilkan QWK 0,5026 dan dipilih; MATCHA (Exp 020) menghasilkan QWK 0,5213 '
        'namun ditolak berdasarkan tinjauan kualitas caption yang mengkonfirmasi '
        'tingkat kesalahan tinggi; PaliGemma (Exp 021) ditolak karena proses caption '
        'generation gagal sepenuhnya pada lingkungan Kaggle P100.',
        '7. Eksperimen Eksklusi Jenis Grafik (Exp 092, Exp 093). Berdasarkan temuan '
        'tinjauan kualitas caption pada langkah 6, model dilatih hanya pada sampel dengan '
        'caption andal. Eksperimen 092 mengeksklusi bar chart, pie chart, dan composite '
        'chart menghasilkan QWK 0,4941. Eksperimen 093 mengeksklusi hanya bar chart dan '
        'pie chart dengan mempertahankan composite chart, menggunakan seed=42, dan '
        'menghasilkan QWK 0,5778. Hasil ini melampaui Track A dengan margin +0,065 dan '
        'menjadi hasil terbaik keseluruhan. Gain seeding sebesar +0,083 merupakan '
        'peningkatan terbesar sepanjang penelitian ini.'
    ),
    # Fix step 8: was wrong Exp093 description, now captioner comparison
    (
        '8. Pipeline Hybrid Terbaik (Exp 091, Exp 093). DePlot+Qwen7B untuk bar chart '
        'dan pie chart dikombinasikan dengan Qwen7B langsung untuk semua jenis grafik '
        'lainnya tanpa pengecualian sampel. Exp 091 (tanpa seed) menghasilkan QWK '
        '0,4945 dan Exp 093 (seeded, seed=42) menghasilkan QWK 0,5778, melampaui Track '
        'A (0,5126) dengan margin +0,065 dan menjadi hasil terbaik keseluruhan.',
        '8. Evaluasi Captioner Khusus untuk Bar Chart dan Pie Chart (Exp 103, Exp 020). '
        'DePlot+Qwen7B dan MATCHA dievaluasi sebagai captioner alternatif untuk bar chart '
        'dan pie chart. DePlot+Qwen7B (Exp 103) menghasilkan QWK 0,5026 dengan error '
        'rate bar chart turun dari 54% menjadi 23%. MATCHA (Exp 020) menghasilkan QWK '
        'lebih tinggi (0,5213) namun error rate 100% pada kedua jenis grafik berdasarkan '
        'tinjauan manual; DePlot+Qwen7B dipilih karena akurasi faktual lebih penting '
        'dari fluency semata. PaliGemma (Exp 021) tidak dapat digunakan karena caption '
        'generation gagal sepenuhnya pada lingkungan Kaggle P100.'
    ),
    # Fix step 9: update VLM comparison to mention DeepSeek pending
    (
        '9. Evaluasi VLM Lebih Kuat (Exp 12). InternVL2-8B digunakan sebagai pengganti '
        'Qwen2-VL-7B untuk seluruh 1.054 sampel dengan arsitektur Dual RoBERTa yang '
        'identik. Hasil test QWK 0,5017 setara dengan Exp 103 DePlot+Qwen7B (0,5026), '
        'mengonfirmasi bahwa skala model VLM yang lebih besar tidak secara otomatis '
        'meningkatkan performa; spesialisasi captioner per jenis grafik lebih '
        'menentukan.',
        '9. Perbandingan VLM dalam Batasan 7B Parameter (Exp 093, Exp 12, pending). '
        'Qwen2-VL-7B-Instruct (Exp 093) digunakan sebagai baseline VLM dengan batasan '
        '<=7B parameter. InternVL2-8B (Exp 12) diuji sebagai referensi konteks meskipun '
        'sedikit di luar batasan, menghasilkan QWK 0,5017 yang setara dengan '
        'DePlot+Qwen7B (0,5026), mengkonfirmasi bahwa skala VLM bukan faktor penentu '
        'utama. DeepSeek-VL-7B direncanakan sebagai pembanding utama Qwen2-VL-7B namun '
        'eksperimen belum selesai dijalankan.'
    ),
]

requests = []
for old, new in replacements:
    requests.append({
        'replaceAllText': {
            'containsText': {'text': old, 'matchCase': True},
            'replaceText': new,
        }
    })

result = service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

for i, reply in enumerate(result.get('replies', [])):
    count = reply.get('replaceAllText', {}).get('occurrencesChanged', 0)
    print(f'  Replacement {i+1}: {count} occurrence(s) changed')

print('Done.')
