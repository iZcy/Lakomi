import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.re803sjptjxa'  # BAB III - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# Find the anchor text (end of step 9) and insert step 10 after it
ANCHOR = ('eksperimen belum selesai dijalankan.')
STEP10 = ('10. Uji Signifikansi Statistik (pending). Paired t-test per trait dengan '
          'koreksi Bonferroni (alpha=0,005) akan dijalankan pada prediksi per-sampel '
          'Eksperimen 093 untuk mengkonfirmasi apakah sistem terbaik menghasilkan '
          'prediksi yang tidak berbeda signifikan dari anotasi manusia pada setiap trait.')

# Replace anchor with anchor + newline + step 10
requests = [{
    'replaceAllText': {
        'containsText': {'text': ANCHOR, 'matchCase': True},
        'replaceText': ANCHOR + '\n' + STEP10,
    }
}]

result = service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

count = result['replies'][0].get('replaceAllText', {}).get('occurrencesChanged', 0)
print(f'Step 10 inserted: {count} occurrence(s) changed')

# Now apply body style to the new paragraph
# We need to find the position — easier to just do a second replaceAllText to style
# Actually we can't set paragraph style via replaceAllText.
# The paragraph will inherit the style of the previous paragraph, which is fine.
print('Done. Note: step 10 inherits style from step 9 (body/justified). Manual style check recommended.')
