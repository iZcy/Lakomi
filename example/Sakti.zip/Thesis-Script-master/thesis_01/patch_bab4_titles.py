import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# Each (old, new) pair — order matters (longer matches first)
replacements = [
    # Section RQ labels (with em dash)
    (' RQ1 \u2014 ', ' '),
    (' RQ2 \u2014 ', ' '),
    (' RQ4 \u2014 ', ' '),
    (' RQ5 \u2014 ', ' '),
    (' RQ6 \u2014 ', ' '),
    # 4.3 section title cleanup
    (', dan Jawaban RQ3', ''),
    # 4.3.7 subsection cleanup
    ('Jawaban RQ3 \u2014 ', ''),
    # Subsection experiment code numbers (parenthesized, only appear in titles)
    (' (Eksperimen 030)', ''),
    (' (Eksperimen 031)', ''),
    (' (Eksperimen 032)', ''),
    (' (Eksperimen 033)', ''),
    (' (Eksperimen 081)', ''),
    (' (Eksperimen 103)', ''),
    (' (Eksperimen 020)', ''),
    (' (Eksperimen 13 dan 112)', ''),
    (' (Eksperimen 093)', ''),
    (' (Eksperimen 12, di Luar Scope)', ''),
]

requests = []
for old, new in replacements:
    requests.append({
        'replaceAllText': {
            'containsText': {'text': old, 'matchCase': True},
            'replaceText': new,
        }
    })

result = service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

for i, reply in enumerate(result.get('replies', [])):
    count = reply.get('replaceAllText', {}).get('occurrencesChanged', 0)
    old, new = replacements[i]
    print(f'  "{old}" -> "{new}" : {count} replaced')

print('Done.')
