import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# Fix: Gold (2025) was incorrectly described as studying educational AES.
# Actual: MS thesis on multimodal sentiment classification (social media).
# The fusion finding (cross-attention > early fusion) still applies, just reframe domain.

OLD = (
    'Gold et al. (2025) meneliti strategi fusion untuk penilaian esai multimoda berbasis '
    'BERT dan ResNet dan menunjukkan bahwa intermediate fusion dengan mekanisme '
    'cross-attention dapat melampaui early fusion pada beberapa konfigurasi.'
)

NEW = (
    'Gold (2025) dalam penelitian tentang klasifikasi sentimen multimoda menunjukkan '
    'bahwa intermediate fusion dengan mekanisme cross-attention antara BERT dan ResNet '
    'dapat melampaui early fusion pada beberapa konfigurasi tugas klasifikasi teks-gambar.'
)

service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': [{
        'replaceAllText': {
            'containsText': {'text': OLD, 'matchCase': True},
            'replaceText': NEW,
            'tabsCriteria': {'tabIds': [TAB_ID]},
        }
    }]}
).execute()

print('Patched Gold citation in 2.2.3.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
