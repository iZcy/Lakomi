import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

OLD = ("RQ5 (Skala VLM): Apakah penggunaan VLM berkapasitas lebih besar (InternVL2-8B) "
       "sebagai captioner menghasilkan peningkatan performa yang signifikan dibandingkan "
       "Qwen2-VL-7B-Instruct dalam pipeline text-to-text?")

NEW = ("RQ5 (Pemilihan VLM): Apakah terdapat perbedaan performa yang signifikan antara "
       "Qwen2-VL-7B-Instruct dan DeepSeek-VL-7B sebagai captioner dalam pipeline "
       "text-to-text, mengingat penelitian ini membatasi penggunaan VLM pada model "
       "open-source berukuran 7 miliar parameter?")

requests = [{
    'replaceAllText': {
        'containsText': {'text': OLD, 'matchCase': True},
        'replaceText': NEW,
        'tabsCriteria': {'tabIds': [TAB_ID]}
    }
}]

result = service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

replies = result.get('replies', [])
count = replies[0].get('replaceAllText', {}).get('occurrencesChanged', 0) if replies else 0
print(f'Occurrences replaced: {count}')
print('Done.')
