import sys
sys.stdout.reconfigure(encoding='utf-8')
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child: return child
    return None

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
content = tab.get('documentTab', {}).get('body', {}).get('content', [])

# Find all RQ paragraphs
rq_ranges = []
for element in content:
    para = element.get('paragraph', {})
    full_text = ''.join(
        pe.get('textRun', {}).get('content', '')
        for pe in para.get('elements', [])
    )
    if full_text.startswith('RQ') and '(' in full_text:
        si = element.get('startIndex')
        ei = element.get('endIndex')
        rq_ranges.append((si, ei, full_text[:40]))

print(f'Found {len(rq_ranges)} RQ paragraphs:')
for si, ei, txt in rq_ranges:
    print(f'  [{si}-{ei}] {txt}...')

if not rq_ranges:
    print('ERROR: No RQ paragraphs found.')
    sys.exit(1)

# Apply numbered list to each RQ paragraph
requests = []
for si, ei, _ in rq_ranges:
    requests.append({
        'createParagraphBullets': {
            'range': {'startIndex': si, 'endIndex': ei, 'tabId': TAB_ID},
            'bulletPreset': 'NUMBERED_DECIMAL_ALPHA_ROMAN_PARENS'
        }
    })

print(f'Sending {len(requests)} requests...')
service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()
print('Done.')
