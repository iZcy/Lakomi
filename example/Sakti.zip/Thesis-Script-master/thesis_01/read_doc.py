import json
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

doc = service.documents().get(
    documentId=DOCUMENT_ID,
    includeTabsContent=True
).execute()

print("Document title:", doc.get('title'))
print()

tabs = doc.get('tabs', [])
print(f"Total tabs: {len(tabs)}")
print()

for tab in tabs:
    props = tab.get('tabProperties', {})
    tab_id = props.get('tabId', '')
    title = props.get('title', '')
    index = props.get('index', '')
    print(f"  [{index}] '{title}' — ID: {tab_id}")

print()
print("--- Looking for BAB I Pendahuluan content ---")
for tab in tabs:
    props = tab.get('tabProperties', {})
    title = props.get('title', '')
    if 'Pendahuluan' in title or 'BAB I' in title:
        print(f"\nTab: '{title}'")
        doc_tab = tab.get('documentTab', {})
        body = doc_tab.get('body', {})
        content = body.get('content', [])
        for element in content[:40]:
            para = element.get('paragraph')
            if para:
                text = ''
                for pe in para.get('elements', []):
                    tr = pe.get('textRun')
                    if tr:
                        text += tr.get('content', '')
                if text.strip():
                    style = para.get('paragraphStyle', {}).get('namedStyleType', '')
                    print(f"  [{style}] {text.strip()[:120]}")
