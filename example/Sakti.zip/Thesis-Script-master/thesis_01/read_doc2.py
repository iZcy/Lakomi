import json
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

doc = service.documents().get(
    documentId=DOCUMENT_ID,
    includeTabsContent=True
).execute()

def print_tabs(tabs, depth=0):
    for tab in tabs:
        props = tab.get('tabProperties', {})
        tab_id = props.get('tabId', '')
        title = props.get('title', '').encode('ascii', 'replace').decode()
        index = props.get('index', '')
        print(f"{'  '*depth}[{index}] '{title}' -- ID: {tab_id}")
        child_tabs = tab.get('childTabs', [])
        if child_tabs:
            print_tabs(child_tabs, depth+1)

print("All tabs (including nested):")
print_tabs(doc.get('tabs', []))

print()
print("--- Reading all tabs for content preview ---")

def read_tab_content(tabs, depth=0):
    for tab in tabs:
        props = tab.get('tabProperties', {})
        tab_id = props.get('tabId', '')
        title = props.get('title', '').encode('ascii', 'replace').decode()

        doc_tab = tab.get('documentTab', {})
        body = doc_tab.get('body', {})
        content = body.get('content', [])

        texts = []
        for element in content[:10]:
            para = element.get('paragraph')
            if para:
                text = ''
                for pe in para.get('elements', []):
                    tr = pe.get('textRun')
                    if tr:
                        text += tr.get('content', '')
                if text.strip():
                    texts.append(text.strip()[:80])

        if texts:
            print(f"\n[Tab: '{title}' | ID: {tab_id}]")
            for t in texts[:5]:
                print(f"  > {t}")

        child_tabs = tab.get('childTabs', [])
        if child_tabs:
            read_tab_content(child_tabs, depth+1)

read_tab_content(doc.get('tabs', []))
