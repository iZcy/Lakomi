import sys
sys.stdout.reconfigure(encoding='utf-8')

from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
BAB1_PENDAHULUAN_TAB = 't.f1ettg15e6rw'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

doc = service.documents().get(
    documentId=DOCUMENT_ID,
    includeTabsContent=True
).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        props = tab.get('tabProperties', {})
        if props.get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), BAB1_PENDAHULUAN_TAB)
if not tab:
    print("Tab not found")
else:
    doc_tab = tab.get('documentTab', {})
    body = doc_tab.get('body', {})
    content = body.get('content', [])
    print(f"Elements in BAB I Pendahuluan: {len(content)}")
    print()
    for i, element in enumerate(content):
        para = element.get('paragraph')
        if para:
            text = ''
            bold_runs = []
            for pe in para.get('elements', []):
                tr = pe.get('textRun')
                if tr:
                    t = tr.get('content', '')
                    text += t
                    ts = tr.get('textStyle', {})
                    if ts.get('bold'):
                        bold_runs.append(t.strip()[:30])
            style = para.get('paragraphStyle', {}).get('namedStyleType', 'NORMAL')
            if text.strip():
                bold_info = f" [BOLD: {bold_runs}]" if bold_runs else ""
                print(f"[{i:03d}] [{style}]{bold_info}")
                print(f"       {text.strip()[:150]}")
                print()
