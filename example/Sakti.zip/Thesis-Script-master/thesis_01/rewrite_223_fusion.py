import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps, 'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()

# ── Step 1: Find and delete the old 2.2.3 block ───────────────────────────────
# Old 2.2.3 starts with "2.2.3 Strategi Multimodal Fusion"
# and ends just before "2.2.4 Penilaian Esai Multimoda"

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

old_223_start = None
old_224_start = None

for el in body_content:
    if 'paragraph' in el:
        text = ''.join(
            pe.get('textRun', {}).get('content', '')
            for pe in el['paragraph'].get('elements', [])
        ).strip()
        if text == '2.2.3 Strategi Multimodal Fusion' and old_223_start is None:
            old_223_start = el.get('startIndex')
        if text == '2.2.4 Penilaian Esai Multimoda' and old_224_start is None:
            old_224_start = el.get('startIndex')

if old_223_start is None or old_224_start is None:
    print(f'ERROR: Could not find markers. 2.2.3 start={old_223_start}, 2.2.4 start={old_224_start}')
    exit(1)

print(f'Old 2.2.3 block: index {old_223_start} to {old_224_start}')

# Delete old 2.2.3 block
batch_update([{'deleteContentRange': {'range': {
    'startIndex': old_223_start,
    'endIndex': old_224_start,
    'tabId': TAB_ID,
}}}])
print('Old 2.2.3 deleted.')
time.sleep(1)

# ── Step 2: Get insertion point (now where 2.2.4 moved to) ────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

insert_at = None
for el in body_content:
    if 'paragraph' in el:
        text = ''.join(
            pe.get('textRun', {}).get('content', '')
            for pe in el['paragraph'].get('elements', [])
        ).strip()
        if text == '2.2.4 Penilaian Esai Multimoda':
            insert_at = el.get('startIndex')
            break

if insert_at is None:
    print('ERROR: Could not find 2.2.4 after deletion.')
    exit(1)

print(f'Inserting new 2.2.3 at index {insert_at}.')

# ── Step 3: New 2.2.3 content ─────────────────────────────────────────────────

TABLE_223_CAPTION = 'Tabel 2.3. Perbandingan Strategi Multimodal Fusion'
TABLE_223_PH = '<<TABEL_2_3_NEW>>'
TABLE_223_DATA = [
    ['Strategi', 'Titik Penggabungan', 'Kelebihan', 'Kekurangan'],
    ['Early Fusion',
     'Level input: fitur mentah dari semua modalitas digabungkan sebelum diproses encoder bersama',
     'Interaksi lintas modalitas sejak awal; satu encoder bersama',
     'Membutuhkan keselarasan dimensi; rentan terhadap modalitas yang hilang'],
    ['Intermediate Fusion',
     'Level representasi: output encoder masing-masing modalitas digabungkan via cross-attention atau concatenation',
     'Encoder per modalitas dapat dioptimalkan secara mandiri; representasi lebih kaya',
     'Desain mekanisme penggabungan menambah kompleksitas arsitektur'],
    ['Late Fusion',
     'Level output: prediksi atau representasi akhir masing-masing modalitas digabungkan',
     'Modular; encoder dapat diganti independen; efektif pada dataset kecil',
     'Interaksi lintas modalitas terbatas; informasi kontekstual antar modalitas tidak terbagi'],
    ['Hybrid Fusion',
     'Gabungan dua atau lebih tahap: early+late, intermediate+late, dsb.',
     'Menggabungkan keunggulan beberapa strategi; fleksibel',
     'Kompleksitas tinggi; lebih banyak hyperparameter; sulit dilatih pada dataset kecil'],
]

segments = [
    # ── 2.2.3 subsection heading ──────────────────────────────────────────────
    ('subsection', '2.2.3 Strategi Multimodal Fusion'),

    ('body',
     'Multimodal fusion adalah proses menggabungkan representasi atau informasi dari '
     'beberapa modalitas menjadi satu representasi terintegrasi yang digunakan untuk '
     'prediksi atau klasifikasi. Baltrusaitis et al. (2019) mengklasifikasikan strategi '
     'fusion berdasarkan titik dalam pipeline pemrosesan di mana penggabungan dilakukan, '
     'menghasilkan tiga kategori utama: early fusion, intermediate fusion, dan late fusion. '
     'Wang et al. (2021) menambahkan kategori keempat yaitu hybrid fusion yang '
     'menggabungkan dua atau lebih strategi tersebut secara bersamaan. '
     'Tabel 2.3 merangkum perbandingan keempat strategi berdasarkan titik penggabungan, '
     'kelebihan, dan kekurangannya.'),

    ('caption', TABLE_223_CAPTION),
    ('placeholder', TABLE_223_PH),

    # ── 2.2.3.1 Early Fusion ──────────────────────────────────────────────────
    ('subsubsection', '2.2.3.1 Early Fusion'),

    ('body',
     'Early fusion menggabungkan representasi mentah dari semua modalitas di level '
     'input sebelum diproses oleh satu encoder bersama. Dalam konteks teks dan gambar, '
     'ini berarti fitur-fitur dari kedua modalitas dikonkatenasi atau dijumlahkan terlebih '
     'dahulu sebelum masuk ke dalam jaringan pemrosesan utama. Keunggulan utama pendekatan '
     'ini adalah kemampuan encoder bersama untuk mempelajari interaksi lintas modalitas '
     'sejak tahap paling awal, sehingga representasi yang dihasilkan mengintegrasikan '
     'informasi dari kedua modalitas secara mendalam. Pereira-Gonzalez et al. (2023) '
     'menunjukkan secara matematis bahwa early fusion mencapai error Bayes teoritis yang '
     'lebih rendah ketika model memiliki pengetahuan penuh tentang distribusi data, karena '
     'representasi gabungan mengandung lebih banyak informasi daripada prediksi individual.'),

    ('body',
     'Namun, early fusion memiliki keterbatasan fundamental: ia mensyaratkan keselarasan '
     'dimensi dan skala antara fitur dari modalitas yang sangat berbeda. Teks dalam bentuk '
     'embedding token dan gambar dalam bentuk matriks piksel atau feature map CNN memiliki '
     'sifat dan distribusi yang sangat berbeda, sehingga penggabungan langsung di level '
     'input membutuhkan proyeksi ke ruang dimensi yang sama. Selain itu, early fusion '
     'sangat rentan terhadap hilangnya satu modalitas pada saat inferensi karena encoder '
     'bersama telah terlatih mengasumsikan kehadiran semua modalitas. Pada dataset yang '
     'kecil seperti EssayJudge dengan 738 sampel pelatihan, kurva pembelajaran encoder '
     'bersama yang kompleks juga dapat menjadi masalah karena data yang tersedia tidak '
     'cukup untuk melatih parameter yang jauh lebih banyak daripada encoder per modalitas.'),

    ('body',
     'Dalam konteks penelitian ini, early fusion diuji sebagai salah satu dari tiga '
     'strategi pada Pendekatan A menggunakan encoder teks BERT dan encoder gambar ResNet18, '
     'dengan representasi kedua modalitas dikonkatenasi sebelum dimasukkan ke dalam '
     'scoring head. Hasil eksperimen menunjukkan bahwa early fusion menghasilkan QWK '
     'terendah di antara ketiga strategi yang diuji, konsisten dengan prediksi teoretis '
     'Pereira-Gonzalez et al. (2023) bahwa early fusion kurang optimal pada ukuran '
     'dataset yang terbatas dibandingkan late fusion.'),

    # ── 2.2.3.2 Intermediate Fusion ───────────────────────────────────────────
    ('subsubsection', '2.2.3.2 Intermediate Fusion'),

    ('body',
     'Intermediate fusion memproses setiap modalitas secara mandiri menggunakan encoder '
     'yang sesuai dengan sifatnya, kemudian menggabungkan representasi tersembunyi yang '
     'dihasilkan di tengah pipeline pemrosesan. Mekanisme penggabungan yang umum '
     'mencakup concatenation vektor representasi, cross-attention antar modalitas, '
     'bottleneck fusion, dan gated fusion. Gold (2025) mengimplementasikan '
     'cross-attention fusion antara BERT dan ResNet di mana representasi teks dan gambar '
     'saling menjadi query dan key satu sama lain, memungkinkan setiap modalitas '
     'untuk menyerap informasi kontekstual dari modalitas lain sebelum representasi '
     'akhir terbentuk.'),

    ('body',
     'Keunggulan intermediate fusion terletak pada fleksibilitasnya: setiap encoder '
     'dapat dioptimalkan secara mandiri sesuai dengan karakteristik modalitasnya, '
     'sementara mekanisme fusion tetap menangkap interaksi lintas modalitas yang '
     'lebih kaya daripada late fusion. Pada tugas yang membutuhkan pemahaman hubungan '
     'antara elemen visual dan tekstual yang spesifik, seperti visual question '
     'answering dan image-text matching, intermediate fusion dengan cross-attention '
     'sering mengungguli kedua strategi lainnya. Wang et al. (2021) menunjukkan dalam '
     'framework CELFT bahwa intermediate fusion berhasil menangkap hubungan intra-modal '
     'yang tidak dapat ditangkap oleh late fusion, sehingga menjadi komponen penting '
     'dalam arsitektur hybrid yang mereka usulkan.'),

    ('body',
     'Dalam penelitian ini, intermediate fusion diuji pada Pendekatan A dengan '
     'mekanisme cross-attention antara representasi BERT dan ResNet18. Meskipun '
     'secara teoritis lebih ekspresif daripada late fusion, hasil eksperimen '
     'menunjukkan bahwa intermediate fusion hanya memberikan peningkatan marginal '
     'dibandingkan early fusion dan tidak melampaui late fusion pada dataset '
     'EssayJudge. Hal ini konsisten dengan temuan Pereira-Gonzalez et al. (2023) '
     'bahwa pada dataset kecil, kompleksitas mekanisme fusion tambahan tidak '
     'selalu menghasilkan peningkatan kinerja yang signifikan.'),

    # ── 2.2.3.3 Late Fusion ───────────────────────────────────────────────────
    ('subsubsection', '2.2.3.3 Late Fusion'),

    ('body',
     'Late fusion mempertahankan pipeline pemrosesan yang sepenuhnya terpisah untuk '
     'setiap modalitas hingga tahap akhir, di mana prediksi atau representasi akhir '
     'dari masing-masing encoder digabungkan melalui operasi seperti concatenation, '
     'rata-rata tertimbang, atau stacking. Pendekatan ini merupakan yang paling '
     'modular: encoder untuk setiap modalitas dapat dilatih, diganti, atau diperbarui '
     'secara independen tanpa mempengaruhi pipeline modalitas lain. Baltrusaitis et al. '
     '(2019) mencatat bahwa late fusion sangat cocok ketika modalitas yang digabungkan '
     'memiliki sifat yang sangat berbeda dan diproses oleh arsitektur yang tidak '
     'kompatibel satu sama lain, seperti Transformer untuk teks dan CNN untuk gambar.'),

    ('body',
     'Pereira-Gonzalez et al. (2023) menunjukkan bahwa pada ukuran training set yang '
     'terbatas, late fusion justru dapat melampaui early fusion karena masing-masing '
     'encoder dapat fokus pada modalitasnya tanpa terganggu oleh kompleksitas '
     'penggabungan di level rendah. Dengan dataset berukuran 738 sampel, melatih '
     'dua encoder yang relatif independen dan menggabungkan representasinya di level '
     'akhir lebih stabil dan lebih mudah dioptimalkan daripada melatih encoder bersama '
     'dengan ruang fitur gabungan yang jauh lebih besar. Properti ini menjadikan '
     'late fusion sebagai pilihan yang pragmatis dan terbukti efektif untuk skenario '
     'dataset kecil pada tugas multimodal.'),

    ('body',
     'Dalam penelitian ini, late fusion diimplementasikan pada Pendekatan A dengan '
     'mengonkatenasi representasi [CLS] dari RoBERTa dan feature vector dari ResNet18 '
     'setelah masing-masing encoder memproses modalitasnya secara independen, kemudian '
     'menyerahkan representasi gabungan ke scoring head. Late fusion terbukti '
     'menghasilkan kinerja terbaik di antara ketiga strategi yang diuji pada '
     'Pendekatan A, mendukung hipotesis dari Baltrusaitis et al. (2019) dan '
     'Pereira-Gonzalez et al. (2023) bahwa late fusion lebih sesuai untuk dataset '
     'kecil dengan modalitas yang heterogen.'),

    # ── 2.2.3.4 Hybrid Fusion ─────────────────────────────────────────────────
    ('subsubsection', '2.2.3.4 Hybrid Fusion'),

    ('body',
     'Hybrid fusion mengombinasikan dua atau lebih strategi fusion yang berbeda '
     'secara bersamaan dalam satu arsitektur, memanfaatkan keunggulan komplementer '
     'dari masing-masing strategi. Wang et al. (2021) mengusulkan CELFT (Combine '
     'Early and Late Fusion Together), sebuah framework hybrid universal untuk '
     'image-text matching yang menggabungkan early fusion untuk menangkap hubungan '
     'intra-modal dan late fusion untuk menangkap hubungan inter-modal secara '
     'bersamaan. Hasil eksperimen CELFT menunjukkan bahwa kombinasi ini secara '
     'konsisten mengungguli penggunaan masing-masing strategi secara terpisah '
     'pada beberapa benchmark image-text matching, karena kedua strategi '
     'menangkap aspek informasi yang berbeda dan saling melengkapi.'),

    ('body',
     'Kumar et al. (2021) mengusulkan hybrid fusion yang menggabungkan intermediate '
     'fusion dan late fusion untuk pengenalan emosi multimodal dari teks, gambar, '
     'dan ucapan pada kondisi data berlabel terbatas. Arsitektur mereka memproses '
     'pasangan modalitas melalui intermediate fusion untuk menangkap interaksi '
     'antara modalitas yang saling berkaitan, kemudian menggabungkan hasilnya '
     'dengan representasi modalitas individual melalui late fusion menggunakan '
     'rata-rata tertimbang yang dapat dipelajari. Pada kondisi data berlabel '
     'terbatas yang serupa dengan situasi dataset EssayJudge, hybrid fusion '
     'terbukti lebih stabil daripada intermediate fusion saja karena komponen '
     'late fusion memberikan jalur gradien alternatif yang lebih sederhana.'),

    ('body',
     'Dalam penelitian ini, hybrid fusion tidak diimplementasikan secara eksplisit '
     'pada Pendekatan A karena ukuran dataset yang sangat terbatas (738 sampel) '
     'membuat optimasi arsitektur yang lebih kompleks berisiko tinggi terhadap '
     'overfitting. Namun, Pendekatan B secara konseptual dapat dipandang sebagai '
     'bentuk hybrid fusion: konversi gambar menjadi teks oleh VLM merupakan '
     'tahap fusion di level semantik (image-to-text translation), sedangkan '
     'penggabungan representasi caption dan esai oleh Dual RoBERTa melalui '
     'concatenation merupakan late fusion. Kombinasi kedua tahap ini '
     'menghasilkan sistem yang mengungguli Pendekatan A murni, mendukung '
     'argumen bahwa integrasi strategi yang berbeda pada level abstraksi '
     'yang berbeda dapat meningkatkan kinerja secara signifikan.'),
]

# ── Build text and positions ───────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'multimodal fusion', r'Multimodal Fusion',
    r'early fusion', r'Early Fusion',
    r'intermediate fusion', r'Intermediate Fusion',
    r'late fusion', r'Late Fusion',
    r'hybrid fusion', r'Hybrid Fusion',
    r'cross-attention',
    r'bottleneck fusion', r'gated fusion',
    r'concatenation',
    r'stacking',
    r'pipeline',
    r'encoder', r'decoder',
    r'feature map', r'feature maps',
    r'feature vector',
    r'embedding',
    r'scoring head',
    r'deep learning',
    r'overfitting',
    r'benchmark',
    r'image-text matching',
    r'visual question answering',
    r'image-to-text',
    r'\bCELFT\b',
    r'intra-modal',
    r'inter-modal',
]

italic_ranges = []
covered = set()

for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption', 'subsubsection', 'subsection'):
        continue
    seg_start = full_text.find(text)
    if seg_start == -1:
        continue
    for term in ITALIC_TERMS:
        for m in re.compile(term, re.IGNORECASE).finditer(text):
            ms, me = seg_start + m.start(), seg_start + m.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
offset = insert_at - 1
requests_list = []

for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', insert_at, TAB_ID))

for start, end, seg_type, text in seg_positions:
    s, e = start + offset, end + offset
    if seg_type == 'subsection':
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'subsubsection':
        # 12pt bold, left-aligned, same as subsection (DTETI defines subsubsection identically)
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=6, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'caption':
        requests_list.append(req_para_style(s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID,
                                        italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted and styled.')
time.sleep(1)

# ── Insert table ───────────────────────────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

ph_start = None
for el in body_content:
    if 'paragraph' in el:
        para_text = ''.join(
            pe.get('textRun', {}).get('content', '')
            for pe in el['paragraph'].get('elements', [])
        )
        if TABLE_223_PH in para_text:
            ph_start = el.get('startIndex', 0)
            break

if ph_start is None:
    print('ERROR: Table placeholder not found.')
else:
    print(f'Placeholder at {ph_start}.')
    batch_update([{'deleteContentRange': {'range': {
        'startIndex': ph_start, 'endIndex': ph_start + len(TABLE_223_PH), 'tabId': TAB_ID
    }}}])
    batch_update([{'insertTable': {
        'rows': 5, 'columns': 4,
        'location': {'index': ph_start, 'tabId': TAB_ID},
    }}])
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = next((el for el in body_content
                     if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)

    if table_el:
        rows = table_el['table'].get('tableRows', [])
        cell_inserts = []
        for ri, row in enumerate(rows):
            for ci, cell in enumerate(row.get('tableCells', [])):
                paras = cell.get('content', [])
                if paras and 'paragraph' in paras[0]:
                    cell_inserts.append((paras[0].get('startIndex', 0),
                                         TABLE_223_DATA[ri][ci], ri))
        cell_inserts.sort(key=lambda x: x[0], reverse=True)
        batch_update([req_insert(t, s, TAB_ID) for s, t, _ in cell_inserts])
        print(f'Filled {len(cell_inserts)} cells.')
        time.sleep(1)

        doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
        tab = find_tab(doc.get('tabs', []), TAB_ID)
        body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
        table_el = next((el for el in body_content
                         if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)

        fmt_reqs = []
        if table_el:
            for ri, row in enumerate(table_el['table'].get('tableRows', [])):
                is_header = (ri == 0)
                for ci, cell in enumerate(row.get('tableCells', [])):
                    for para in cell.get('content', []):
                        if 'paragraph' in para:
                            ps, pe = para.get('startIndex'), para.get('endIndex')
                            fmt_reqs.append(req_text_style(ps, pe, TAB_ID,
                                                           bold=is_header, size_pt=11))
                            fmt_reqs.append({'updateParagraphStyle': {
                                'range': {'startIndex': ps, 'endIndex': pe, 'tabId': TAB_ID},
                                'paragraphStyle': {
                                    'alignment': 'CENTER' if is_header else 'START',
                                    'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                    'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                    'lineSpacing': 120,
                                },
                                'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                            }})
            batch_update(fmt_reqs)
            print(f'Table formatted ({len(fmt_reqs)} reqs).')

print('\nDone.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
