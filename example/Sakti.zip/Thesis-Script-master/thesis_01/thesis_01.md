# Thesis Discussion Notes — Exp 00 (Intermediate Fusion) vs Exp 052 (T2T Qwen2-VL-2B)

---

## 1. Reference Point: EssayJudge's Qwen2-VL-7B Zero-Shot

The EssayJudge paper evaluates Qwen2-VL-7B as a direct end-to-end scorer
(image + question + essay → score 0–5). Zero-shot, no training, no fine-tuning.
This is the state-of-the-art zero-shot MLLM result on this dataset.

Results from Table 2 of Su et al. (2025), full 1,054-sample dataset:

| Trait | QWK   |
|-------|-------|
| AC    | 0.17  |
| JP    | 0.10  |
| OS    | 0.14  |
| CH    | 0.13  |
| EL    | 0.15  |
| GA    | 0.21  |
| GD    | 0.16  |
| LA    | 0.20  |
| LD    | 0.26  |
| PA    | 0.12  |
| **Avg** | **~0.164** |

---

## 2. Our Approach A: Intermediate Fusion (Exp 00)

Baseline trained model. Directly fuses image and text features.

**Pipeline:**
```
Image → ResNet18 (frozen) → 512-dim
                                    ↘  Concat 1280-dim → FC → Score
Essay → RoBERTa-base → [CLS] 768-dim ↗
```

- FC: 1280 → 512 → 128 → 1, Sigmoid × 5.0
- ResNet18 fully frozen; RoBERTa embeddings + first 6 layers frozen, last 6 trainable
- Per-trait: 10 separate models trained independently
- Full dataset: 738 train / 158 val / 158 test (seed=42)

**Results — Exp 00:**

| Trait | Val QWK | Test QWK |
|-------|---------|---------|
| AC    | —       | 0.1606  |
| JP    | —       | 0.2994  |
| OS    | —       | 0.4800  |
| CH    | —       | 0.4770  |
| EL    | —       | 0.3948  |
| GA    | —       | 0.4583  |
| GD    | —       | 0.5407  |
| LA    | —       | 0.4434  |
| LD    | —       | 0.5445  |
| PA    | —       | 0.4384  |
| **Avg** |       | **0.4237** |

---

## 3. Our Approach B: Text-to-Text with Qwen2-VL-2B (Exp 052)

Image is first converted to a text caption by Qwen2-VL-2B-Instruct.
Caption and essay are then encoded separately by two RoBERTa instances
and concatenated — no image encoder in the training loop.

**Caption generation:**
- Model: Qwen2-VL-2B-Instruct (8-bit quantized, ~6GB VRAM)
- Prompt: describes chart type, data, main trends, specific numbers, label clarity
- Length: min 100 / max 200 new tokens (~120–150 words per caption)
- Generated once, stored statically in `qwen_captions_corrected.json`
- Token stats on RoBERTa tokenizer: max 410, avg 247, none > 512

**Pipeline:**
```
Image → Qwen2-VL-2B-Instruct → Caption (text, static)
Caption → RoBERTa-base (encoder A) → [CLS] 768-dim ↘
                                                      Concat 1536-dim → FC → Score
Essay   → RoBERTa-base (encoder B) → [CLS] 768-dim ↗
```

- FC: 1536 → 512 → 128 → 1, Sigmoid × 5.0
- Two separate RoBERTa encoders (not shared weights)
- Same training config as Exp 00 (lr=1e-4, dropout=0.3, batch=16, patience=10)
- Per-trait: 10 separate models

**Results — Exp 052:**

| Trait | Best Val QWK | Test QWK | Train time |
|-------|-------------|---------|-----------|
| AC    | 0.0789      | 0.0200  | 348s      |
| JP    | 0.4057      | 0.3108  | 590s      |
| OS    | 0.4211      | 0.3436  | 536s      |
| CH    | 0.5257      | 0.5706  | 648s      |
| EL    | 0.4982      | 0.4787  | 643s      |
| GA    | 0.5328      | 0.5927  | 631s      |
| GD    | 0.5830      | 0.5868  | 631s      |
| LA    | 0.6279      | 0.6021  | 478s      |
| LD    | 0.6238      | 0.5431  | 651s      |
| PA    | 0.5795      | 0.3305  | 455s      |
| **Avg** |           | **0.4359** | ~1.6h  |

---

## 4. Head-to-Head: Exp 00 vs Exp 052 vs Zero-Shot 7B

| Trait | Zero-Shot 7B | Exp 00 (Fusion) | Exp 052 (T2T 2B) | Winner (trained) |
|-------|-------------|----------------|-----------------|-----------------|
| AC    | 0.17        | 0.1606         | 0.0200          | Exp 00          |
| JP    | 0.10        | 0.2994         | 0.3108          | Exp 052         |
| OS    | 0.14        | **0.4800**     | 0.3436          | Exp 00          |
| CH    | 0.13        | 0.4770         | **0.5706**      | Exp 052         |
| EL    | 0.15        | 0.3948         | **0.4787**      | Exp 052         |
| GA    | 0.21        | 0.4583         | **0.5927**      | Exp 052         |
| GD    | 0.16        | 0.5407         | **0.5868**      | Exp 052         |
| LA    | 0.20        | 0.4434         | **0.6021**      | Exp 052         |
| LD    | 0.26        | **0.5445**     | 0.5431          | ~Equal          |
| PA    | 0.12        | **0.4384**     | 0.3305          | Exp 00          |
| **Avg** | **0.164** | **0.4237**     | **0.4359**      | Exp 052 (+0.012) |

**Takeaway:** Both trained models massively outperform zero-shot 7B (~2.6×).
T2T-2B narrowly wins overall (+0.012 avg), but the split is trait-dependent:
- Exp 052 wins: JP, CH, EL, GA, GD, LA (grammar, lexical, coherence traits)
- Exp 00 wins: AC, OS, PA (structural and argument traits)
- ~Equal: LD

---

## 5. Key Findings

### 5.1 T2T Helps Grammar and Lexical Traits Most
GA (+0.13), LA (+0.16), CH (+0.09), EL (+0.09), GD (+0.05) all improve with T2T.
These traits are fundamentally about how text is written — once the image content is
described in words, RoBERTa can compare the essay's language quality against the
caption's description of what should be addressed.

### 5.2 Intermediate Fusion Is Better for Structure and Argument
OS (0.48 vs 0.34) and PA (0.44 vs 0.33) favour Exp 00.
For OS, direct image features likely capture layout and visual structure cues that
a text-only Qwen-2B caption summarises poorly. For PA, punctuation might correlate
with visual scanning of the essay rather than cross-modal reasoning.

### 5.3 Argument Clarity (AC) Fails in Both
AC = 0.1606 (Exp 00) and 0.0200 (Exp 052). Both are near-zero.
This trait asks whether the essay's opening paragraph correctly maps to the image task.
Neither ResNet18 features nor Qwen-2B captions capture this semantic alignment.
Exp 053 (Claude-3.5-Sonnet captions) achieves AC = 0.1262, suggesting richer captions
help slightly but the trait remains fundamentally hard at 738 training samples.

### 5.4 Caption Prompt Matters
Exp 05 (wrong prompt: "student-drawn graph") vs Exp 052 (corrected prompt): avg QWK
is similar (~0.443 vs 0.436) but individual traits differ. The corrected prompt
produces cleaner, more factual captions — the headline numbers don't fully capture
the qualitative improvement in caption content.

### 5.5 Both Approaches Massively Beat Zero-Shot
Trained models (0.42–0.44) vs zero-shot 7B (0.164) — a 2.5× improvement.
Key insight for thesis: the bottleneck is not the VLM's vision capability,
it is the lack of task-specific training on labeled data.

---

## 6. Caption Quality Reference: Exp 053 (Claude-3.5-Sonnet)

| Trait | Exp 052 (Qwen-2B) | Exp 053 (Claude-3.5) | Delta     |
|-------|------------------|---------------------|-----------|
| AC    | 0.0200           | 0.1262              | +0.106    |
| JP    | 0.3108           | 0.3739              | +0.063    |
| OS    | 0.3436           | 0.3579              | +0.014    |
| CH    | 0.5706           | 0.4752              | −0.096    |
| EL    | 0.4787           | 0.4885              | +0.010    |
| GA    | 0.5927           | 0.5722              | −0.021    |
| GD    | 0.5868           | 0.5509              | −0.036    |
| LA    | 0.6021           | 0.5449              | −0.057    |
| LD    | 0.5431           | 0.4840              | −0.059    |
| PA    | 0.3305           | 0.4487              | +0.118    |
| **Avg** | **0.4359**     | **0.4422**          | **+0.006** |

Claude captions help AC (+0.106) and PA (+0.118) noticeably but lose on LA, LD, CH.
Suggests caption verbosity and style interact differently with different traits —
richer, more nuanced descriptions help argument-level traits but may hurt
surface-level trait prediction by introducing vocabulary noise.

---

## 7. Numbers to Use in Thesis

| Claim | Supporting data |
|-------|----------------|
| Supervised training >> zero-shot MLLM | Exp 00: 0.4237, Exp 052: 0.4359 vs Zero-shot 7B: 0.164 |
| T2T slightly outperforms fusion overall | 0.4359 vs 0.4237 (+0.012 avg) |
| T2T best for grammar/lexical traits | GA: 0.59, LA: 0.60, GD: 0.59 |
| Fusion best for structural traits | OS: 0.48, PA: 0.44 |
| AC is the hardest trait | AC: 0.02 (T2T), 0.16 (Fusion), 0.13 (Claude T2T) |
| Caption quality has bounded effect | Qwen-2B avg 0.4359, Claude avg 0.4422 (+0.006) |

---

## 8. Open Questions for the Thesis

- Why does intermediate fusion outperform T2T on OS? Is it the ResNet18 spatial features
  or the training dynamics? (ablation: train Exp 00 with image features zeroed out)
- Can AC be fixed at all with 738 training samples, or is it a data-size problem?
- What is the right caption length/detail level? Claude's richer captions help some
  traits but hurt others — is there an optimal verbosity?
- Exp 07 (Back Translation, avg ~0.57) is the current best but needs a clean rerun
  after fixing the score tensor bug. If confirmed, what explains the gain?
