"""
Write BAB II Group 3: 2.2.10-2.2.14 (Text Processing Pipeline)
  2.2.10 Tokenisasi
  2.2.11 Transformer
  2.2.12 Mekanisme Attention
  2.2.13 BERT
  2.2.14 RoBERTa
Pure theory — no research-specific context.
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)


def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None


def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}


def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps, 'fields': fields,
    }}


def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}


def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()


# Get append index
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
content = tab.get('documentTab', {}).get('body', {}).get('content', [])
append_at = content[-1].get('startIndex', 1) if content else 1
print(f'Appending after index {append_at}.')

# ── Table data ─────────────────────────────────────────────────────────────────

# Tabel 2.9 — BPE tokenization example
TABLE_2210_CAPTION = 'Tabel 2.9. Contoh Tokenisasi BPE pada Kalimat Bahasa Inggris'
TABLE_2210_PH = '<<TABEL_2_9>>'
TABLE_2210_DATA = [
    ['Tipe Segmentasi', 'Input', 'Hasil Token'],
    ['Word-level',
     '"internationalization"',
     '"internationalization" (1 token; OOV jika tidak ada di kamus)'],
    ['Character-level',
     '"internationalization"',
     '"i", "n", "t", "e", "r", ... (21 karakter terpisah)'],
    ['BPE (subword)',
     '"internationalization"',
     '"international", "ization" (2 token; menggabungkan pasangan frekuensi tinggi)'],
    ['WordPiece (BERT)',
     '"internationalization"',
     '"international", "##ization" (prefix ## menandai subword lanjutan)'],
]

# Tabel 2.10 — Transformer encoder components
TABLE_2211_CAPTION = 'Tabel 2.10. Komponen Utama Encoder Transformer dan Fungsinya'
TABLE_2211_PH = '<<TABEL_2_10>>'
TABLE_2211_DATA = [
    ['Komponen', 'Fungsi', 'Keterangan Teknis'],
    ['Input Embedding',
     'Mengonversi token ID menjadi vektor kontinu',
     'Dimensi d_model (misal 512 atau 768)'],
    ['Positional Encoding',
     'Menambahkan informasi posisi token dalam urutan',
     'Sinusoidal tetap (Vaswani et al.) atau dipelajari (BERT)'],
    ['Multi-Head Self-Attention',
     'Menghitung ketergantungan antar semua pasangan token secara paralel',
     'h kepala paralel; dimensi per kepala d_k = d_model / h'],
    ['Feed-Forward Network',
     'Transformasi nonlinier per posisi secara independen',
     '2 lapisan linier dengan aktivasi GELU; dimensi dalam 4 x d_model'],
    ['Residual + Layer Norm',
     'Memastikan gradien mengalir stabil; menormalkan aktivasi per lapisan',
     'Add & Norm diterapkan setelah setiap sub-lapisan'],
]

# Tabel 2.11 — Attention types comparison
TABLE_2212_CAPTION = 'Tabel 2.11. Perbandingan Jenis Mekanisme Attention'
TABLE_2212_PH = '<<TABEL_2_11>>'
TABLE_2212_DATA = [
    ['Jenis Attention', 'Sumber Q', 'Sumber K dan V', 'Penggunaan Utama'],
    ['Self-Attention',
     'Urutan yang sama',
     'Urutan yang sama',
     'Encoder Transformer; menangkap ketergantungan intra-urutan'],
    ['Cross-Attention',
     'Decoder (target)',
     'Encoder (source)',
     'Decoder Transformer; menyelaraskan output dengan input'],
    ['Multi-Head Attention',
     'Bergantung pada konteks (self atau cross)',
     'Bergantung pada konteks',
     'Semua varian Transformer; h kepala menangkap aspek berbeda'],
    ['Causal (Masked) Attention',
     'Urutan yang sama',
     'Token sebelumnya saja (masking kanan)',
     'Decoder autoregresif (GPT); mencegah melihat token masa depan'],
]

# Tabel 2.12 — BERT-base vs BERT-large
TABLE_2213_CAPTION = 'Tabel 2.12. Perbandingan Arsitektur BERT-base dan BERT-large'
TABLE_2213_PH = '<<TABEL_2_12>>'
TABLE_2213_DATA = [
    ['Parameter Arsitektur', 'BERT-base', 'BERT-large'],
    ['Jumlah lapisan (L)', '12', '24'],
    ['Dimensi hidden (H)', '768', '1024'],
    ['Jumlah attention heads (A)', '12', '16'],
    ['Jumlah parameter total', '110 juta', '340 juta'],
    ['GLUE benchmark score', '79.6', '82.1'],
]

# Tabel 2.13 — BERT vs RoBERTa training differences
TABLE_2214_CAPTION = 'Tabel 2.13. Perbedaan Pelatihan BERT dan RoBERTa'
TABLE_2214_PH = '<<TABEL_2_13>>'
TABLE_2214_DATA = [
    ['Aspek Pelatihan', 'BERT (Devlin et al., 2019)', 'RoBERTa (Liu et al., 2019)'],
    ['Tujuan pre-training',
     'MLM + NSP (Next Sentence Prediction)',
     'MLM saja (NSP dihapus setelah terbukti tidak membantu)'],
    ['Strategi masking',
     'Static masking (pola mask tetap sepanjang pelatihan)',
     'Dynamic masking (pola mask diregenerasi setiap epoch)'],
    ['Ukuran batch',
     '256 urutan per langkah',
     '8.000 urutan per langkah (32x lebih besar)'],
    ['Data pelatihan',
     '16 GB (BooksCorpus + English Wikipedia)',
     '160 GB (+ CC-News, OpenWebText, Stories)'],
    ['Ukuran vocabulary',
     '30.000 token (WordPiece)',
     '50.265 token (BPE berbasis byte)'],
    ['Skor GLUE',
     '79.6 (BERT-base)',
     '88.5 (RoBERTa-large)'],
]

# ── Segments ───────────────────────────────────────────────────────────────────
segments = [

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.10 Tokenisasi
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.10 Tokenisasi'),

    ('body',
     'Tokenisasi adalah proses mengonversi teks mentah menjadi satuan-satuan '
     'diskret yang dapat diproses oleh model bahasa. Satuan-satuan ini disebut '
     'token, yang bergantung pada strategi yang digunakan dapat berupa karakter '
     'tunggal, kata utuh, atau potongan subkata. Pada era awal pemrosesan bahasa '
     'alami berbasis statistik, tokenisasi dilakukan pada level kata dengan '
     'memisahkan teks berdasarkan spasi dan tanda baca, sehingga setiap kata '
     'mendapat satu entri dalam kosakata model. Pendekatan berbasis kata '
     'menghadapi dua masalah fundamental: kosakata yang sangat besar untuk '
     'bahasa dengan morfologi kaya, dan ketidakmampuan menangani kata-kata yang '
     'tidak pernah muncul dalam data pelatihan (out-of-vocabulary). Sebaliknya, '
     'tokenisasi berbasis karakter menghasilkan urutan yang sangat panjang '
     'sehingga menyulitkan model menangkap makna semantik pada level yang lebih '
     'tinggi.'),

    ('body',
     'Sennrich et al. (2016) memperkenalkan Byte Pair Encoding (BPE) sebagai '
     'solusi subword tokenization yang kini menjadi fondasi hampir seluruh model '
     'bahasa besar modern. BPE bekerja dengan algoritma iteratif: dimulai dari '
     'kosakata karakter, pasangan simbol yang paling sering muncul berdampingan '
     'dalam korpus digabungkan menjadi satu simbol baru, dan proses ini diulang '
     'sebanyak jumlah operasi merge yang ditentukan. Hasilnya adalah kosakata '
     'subword yang secara alami menempatkan kata-kata umum sebagai token tunggal '
     'dan memecah kata-kata langka menjadi subunit yang lebih kecil namun tetap '
     'bermakna secara morfologis. Dengan cara ini, BPE mengatasi trade-off antara '
     'ukuran kosakata dan kemampuan menangani kata-kata baru secara elegan: '
     'kata yang tidak pernah dilihat selama pelatihan tetap dapat direpresentasikan '
     'sebagai urutan subword yang dikenal.'),

    ('body',
     'Model BERT dan variannya menggunakan WordPiece, sebuah varian BPE yang '
     'mengoptimalkan pemilihan merge berdasarkan kemungkinan (likelihood) korpus '
     'pelatihan bahasa alami daripada frekuensi mentah pasangan. Devlin et al. '
     '(2019) menggunakan kosakata WordPiece berukuran 30.000 token untuk BERT, '
     'sedangkan Liu et al. (2019) memperluas kosakata BPE berbasis byte RoBERTa '
     'menjadi 50.265 token untuk mencakup lebih banyak subword bahasa Inggris '
     'tanpa token unknown. Selain subword itu sendiri, model Transformer '
     'menambahkan token khusus seperti [CLS] yang diletakkan di awal urutan '
     'sebagai representasi agregat kalimat untuk tugas klasifikasi, dan [SEP] '
     'yang memisahkan dua segmen kalimat. Tabel 2.9 membandingkan hasil tokenisasi '
     'dari beberapa strategi pada contoh kata yang sama untuk memperlihatkan '
     'perbedaan granularitas dan penanganan kata langka.'),

    ('caption', TABLE_2210_CAPTION),
    ('placeholder', TABLE_2210_PH),

    ('body',
     'Berdasarkan Tabel 2.9, strategi subword seperti BPE dan WordPiece memberikan '
     'keseimbangan terbaik antara ukuran kosakata yang terbatas dan kemampuan '
     'merepresentasikan kata-kata baru tanpa token unknown. Perbedaan utama antara '
     'BPE dan WordPiece terletak pada kriteria merge: BPE menggunakan frekuensi, '
     'sedangkan WordPiece menggunakan peningkatan likelihood. Kedua metode '
     'menggunakan prefiks khusus (## pada WordPiece) untuk menandai subword yang '
     'bukan awal kata, sehingga model dapat merekonstruksi bentuk kata asli dari '
     'urutan token jika diperlukan.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.11 Transformer
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.11 Transformer'),

    ('body',
     'Transformer adalah arsitektur jaringan saraf tiruan yang diperkenalkan oleh '
     'Vaswani et al. (2017) dalam makalah "Attention Is All You Need" sebagai '
     'alternatif terhadap model sekuensial berbasis Recurrent Neural Network '
     'yang dominan sebelumnya. Keunggulan mendasar Transformer adalah kemampuannya '
     'memproses seluruh urutan input secara paralel melalui mekanisme self-attention, '
     'berbeda dengan RNN yang harus memproses token satu per satu secara sekuensial. '
     'Paralelisasi ini memungkinkan pelatihan yang jauh lebih efisien pada perangkat '
     'keras modern (GPU/TPU) dan memungkinkan model mempelajari ketergantungan '
     'jarak jauh antar token tanpa degradasi informasi yang terjadi pada RNN '
     'ketika urutan menjadi sangat panjang.'),

    ('body',
     'Arsitektur Transformer asli terdiri dari encoder dan decoder yang masing-masing '
     'tersusun dari lapisan-lapisan identik. Setiap lapisan encoder mengandung '
     'dua sub-lapisan utama: multi-head self-attention dan feed-forward network '
     'yang diterapkan per posisi secara independen. Setelah setiap sub-lapisan, '
     'diterapkan koneksi residual yang menjumlahkan input dengan output sub-lapisan, '
     'diikuti oleh layer normalization untuk menstabilkan distribusi aktivasi. '
     'Karena self-attention tidak memiliki pemahaman bawaan tentang urutan, '
     'Transformer menambahkan positional encoding pada input embedding untuk '
     'menyuntikkan informasi posisi token. Vaswani et al. (2017) menggunakan '
     'encoding sinusoidal dengan frekuensi berbeda untuk setiap dimensi, '
     'sementara model-model selanjutnya seperti BERT menggunakan positional '
     'embedding yang dapat dipelajari (learnable).'),

    ('body',
     'Untuk tugas pemahaman bahasa seperti klasifikasi kalimat dan regresi, '
     'hanya bagian encoder yang digunakan. Arsitektur encoder-only ini '
     'memproses seluruh kalimat secara dua arah (bidirectional), artinya '
     'representasi setiap token dipengaruhi oleh semua token lain di kiri '
     'maupun kanan. Ini berbeda dengan arsitektur decoder-only (seperti GPT) '
     'yang hanya dapat memperhatikan token-token sebelumnya karena dirancang '
     'untuk generasi teks autoregresif. Tabel 2.10 merangkum komponen utama '
     'lapisan encoder Transformer beserta fungsi dan keterangan teknis masing-masing.'),

    ('caption', TABLE_2211_CAPTION),
    ('placeholder', TABLE_2211_PH),

    ('body',
     'Berdasarkan Tabel 2.10, setiap komponen dalam lapisan encoder Transformer '
     'memiliki peran yang saling melengkapi: positional encoding memberikan '
     'konteks posisi yang tidak tersedia dari embedding saja, self-attention '
     'memungkinkan token mana pun berinteraksi langsung dengan token mana pun '
     'tanpa dibatasi jarak, feed-forward network menambahkan kapasitas representasi '
     'nonlinier per posisi, dan kombinasi residual serta layer normalization '
     'memastikan gradien mengalir secara stabil selama pelatihan jaringan yang dalam.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.12 Mekanisme Attention
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.12 Mekanisme Attention'),

    ('body',
     'Mekanisme attention pertama kali diperkenalkan dalam konteks neural machine '
     'translation oleh Bahdanau et al. (2015), yang mengamati bahwa model '
     'encoder-decoder berbasis RNN mengalami bottleneck informasi: seluruh '
     'makna kalimat sumber harus dikompres ke dalam satu vektor berdimensi tetap '
     'sebelum decoder mulai menghasilkan terjemahan. Bahdanau et al. (2015) '
     'mengusulkan mekanisme soft attention yang memungkinkan decoder secara '
     'dinamis memilih bagian-bagian relevan dari urutan encoder untuk setiap '
     'langkah generasi, dengan bobot perhatian yang dipelajari secara bersama '
     'dengan seluruh model. Pendekatan ini secara dramatis meningkatkan '
     'kualitas terjemahan, khususnya untuk kalimat-kalimat panjang yang '
     'sebelumnya sangat sulit ditangani oleh model berbasis RNN.'),

    ('body',
     'Vaswani et al. (2017) menyederhanakan dan mengefisienkan mekanisme ini '
     'menjadi scaled dot-product attention yang dapat diparalelkan sepenuhnya. '
     'Dalam formulasi ini, setiap posisi dalam urutan direpresentasikan sebagai '
     'tiga proyeksi: Query (Q), Key (K), dan Value (V). Relevansi antara satu '
     'posisi dengan posisi lain dihitung sebagai dot product antara Q dan K, '
     'kemudian dibagi dengan akar dimensi kunci (sqrt(d_k)) untuk mencegah '
     'nilai dot product yang terlalu besar yang dapat menyebabkan gradien '
     'softmax menjadi sangat kecil. Hasilnya dinormalisasi dengan softmax '
     'menghasilkan bobot attention, dan akhirnya digunakan untuk menimbang '
     'nilai V. Secara matematis: Attention(Q, K, V) = softmax(Q K^T / sqrt(d_k)) V.'),

    ('body',
     'Multi-head attention memperluas scaled dot-product attention dengan '
     'menjalankan h instansi attention secara paralel, masing-masing menggunakan '
     'proyeksi Q, K, V yang berbeda. Keluaran dari semua kepala digabungkan '
     '(concatenated) dan diproyeksikan kembali ke dimensi model. Manfaat '
     'utamanya adalah setiap kepala dapat berspesialisasi menangkap aspek '
     'yang berbeda dari ketergantungan antar token: satu kepala dapat '
     'menangkap hubungan sintaksis, kepala lain hubungan semantik, dan '
     'kepala lainnya lagi hubungan koreferencialis. Tabel 2.11 merangkum '
     'perbedaan antara jenis-jenis attention yang digunakan dalam berbagai '
     'varian arsitektur Transformer.'),

    ('caption', TABLE_2212_CAPTION),
    ('placeholder', TABLE_2212_PH),

    ('body',
     'Berdasarkan Tabel 2.11, perbedaan mendasar antar jenis attention terletak '
     'pada sumber Query, Key, dan Value yang digunakan. Self-attention '
     'memungkinkan setiap token dalam satu urutan memperhatikan token lain '
     'dalam urutan yang sama, sehingga model dapat membangun representasi '
     'kontekstual yang kaya. Cross-attention menghubungkan dua urutan berbeda '
     'dan menjadi mekanisme utama dalam arsitektur encoder-decoder. Causal '
     'attention menambahkan masking untuk memastikan model generatif tidak '
     'mengakses informasi dari posisi masa depan selama pelatihan.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.13 BERT
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.13 BERT'),

    ('body',
     'BERT (Bidirectional Encoder Representations from Transformers) adalah '
     'model bahasa berbasis encoder Transformer yang diperkenalkan oleh Devlin '
     'et al. (2019) dan menjadi titik balik dalam perkembangan natural language '
     'processing modern. Kontribusi utama BERT adalah pre-training dua arah '
     '(bidirectional) yang memungkinkan representasi setiap token dipengaruhi '
     'oleh seluruh konteks di kiri maupun kanannya secara bersamaan, berbeda '
     'dengan model bahasa autoregresif sebelumnya yang hanya dapat memproses '
     'teks dari kiri ke kanan. Kemampuan bidirectional ini sangat penting '
     'untuk tugas pemahaman bahasa karena makna sebuah kata sering ditentukan '
     'oleh konteks di kedua sisinya secara simultan.'),

    ('body',
     'BERT dilatih dengan dua tujuan secara bersamaan pada korpus teks '
     'tidak berlabel berukuran 16 GB. Pertama, Masked Language Modeling (MLM) '
     'secara acak menutup 15 persen token dalam setiap urutan dan melatih '
     'model untuk memprediksi token yang tertutup berdasarkan konteks di '
     'kanan dan kirinya. Kedua, Next Sentence Prediction (NSP) melatih model '
     'untuk memprediksi apakah dua kalimat yang diberikan berdekatan dalam '
     'teks asli atau dipilih secara acak. Token khusus [CLS] diletakkan di '
     'awal setiap urutan dan representasi tersembunyinya pada lapisan terakhir '
     'digunakan sebagai representasi agregat urutan untuk tugas-tugas '
     'klasifikasi dan regresi tingkat kalimat. Token [SEP] memisahkan '
     'dua segmen kalimat dan juga digunakan sebagai penanda akhir urutan.'),

    ('body',
     'Setelah pre-training, BERT dapat di-fine-tune pada berbagai tugas '
     'downstream dengan menambahkan lapisan head yang sesuai di atas '
     'representasi [CLS] atau representasi per-token. Devlin et al. (2019) '
     'menunjukkan bahwa fine-tuning BERT-base pada sebelas tugas benchmark '
     'NLP menghasilkan performa state-of-the-art di semua tugas tersebut '
     'dengan hanya sedikit perubahan arsitektur per tugas. Fleksibilitas ini, '
     'dikombinasikan dengan ketersediaan bobot pretrained secara publik, '
     'menjadikan BERT fondasi dari ratusan model turunan yang dikembangkan '
     'dalam beberapa tahun setelah publikasinya. Tabel 2.12 membandingkan '
     'konfigurasi arsitektur BERT-base dan BERT-large beserta skor benchmark '
     'yang dilaporkan dalam makalah aslinya.'),

    ('caption', TABLE_2213_CAPTION),
    ('placeholder', TABLE_2213_PH),

    ('body',
     'Berdasarkan Tabel 2.12, BERT-large memiliki kapasitas representasi yang '
     'lebih besar dengan 340 juta parameter dibandingkan 110 juta parameter '
     'BERT-base, dengan peningkatan skor GLUE dari 79.6 menjadi 82.1. Namun '
     'kapasitas yang lebih besar juga berarti kebutuhan komputasi yang lebih '
     'tinggi selama fine-tuning. Dalam praktiknya, BERT-base sering dipilih '
     'untuk tugas-tugas dengan dataset pelatihan berukuran kecil karena '
     'ukurannya yang lebih efisien dan risiko overfitting yang lebih rendah.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.14 RoBERTa
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.14 RoBERTa'),

    ('body',
     'RoBERTa (Robustly Optimized BERT Pretraining Approach) adalah varian '
     'BERT yang diperkenalkan oleh Liu et al. (2019) melalui studi sistematis '
     'tentang dampak berbagai pilihan pelatihan BERT. Liu et al. (2019) '
     'menemukan bahwa BERT asli mengalami undertraining secara signifikan: '
     'dengan memperpanjang jadwal pelatihan, menghapus tujuan NSP yang '
     'terbukti tidak memberikan manfaat konsisten, menggunakan ukuran batch '
     'yang jauh lebih besar, dan melatih pada data yang sepuluh kali lebih '
     'banyak, performa pada benchmark NLP dapat ditingkatkan secara substansial '
     'tanpa perubahan arsitektur apapun. Temuan ini mengindikasikan bahwa '
     'perbedaan performa antara model-model berbasis Transformer sering lebih '
     'dipengaruhi oleh keputusan pelatihan daripada inovasi arsitektur.'),

    ('body',
     'Empat perubahan utama RoBERTa dibandingkan BERT mencakup penghapusan '
     'NSP (karena ablation study menunjukkan NSP tidak memperbaiki dan '
     'kadang memperburuk performa pada tugas downstream), penggunaan dynamic '
     'masking yang meregenerasi pola mask di setiap epoch sehingga model '
     'melihat data yang lebih beragam selama pelatihan, peningkatan ukuran '
     'batch dari 256 menjadi 8.000 urutan per langkah yang memungkinkan '
     'penggunaan learning rate yang lebih tinggi dan konvergensi lebih cepat, '
     'serta perluasan data pelatihan dari 16 GB menjadi 160 GB dengan '
     'menambahkan CC-News, OpenWebText, dan Stories. Selain itu, RoBERTa '
     'menggunakan encoding BPE berbasis byte dengan kosakata 50.265 token '
     'yang tidak memerlukan pre-tokenization atau normalisasi Unicode khusus, '
     'sehingga lebih robust terhadap input teks yang beragam.'),

    ('body',
     'RoBERTa secara konsisten mengungguli BERT pada semua benchmark utama '
     'dan menjadi baseline standar dalam penelitian NLP selama periode '
     '2019 hingga 2021 sebelum model yang lebih besar seperti DeBERTa '
     'dan GPT-4 mengambil alih posisi teratas. Liu et al. (2019) melaporkan '
     'skor GLUE 88.5 untuk RoBERTa-large, dibandingkan 82.1 untuk BERT-large '
     'asli. RoBERTa-base (12 lapisan, 768 dimensi, 125 juta parameter) '
     'mempertahankan arsitektur yang identik dengan BERT-base namun '
     'mencapai performa yang secara konsisten lebih baik pada berbagai '
     'tugas klasifikasi dan regresi teks. Tabel 2.13 merangkum perbedaan '
     'kunci dalam strategi pelatihan antara BERT dan RoBERTa.'),

    ('caption', TABLE_2214_CAPTION),
    ('placeholder', TABLE_2214_PH),

    ('body',
     'Berdasarkan Tabel 2.13, perbedaan terbesar antara BERT dan RoBERTa '
     'terletak pada skala pelatihan dan strategi masking. Penghapusan NSP '
     'menyederhanakan tujuan pre-training tanpa mengorbankan kualitas '
     'representasi, sementara dynamic masking memastikan model tidak '
     'menghapal pola mask yang tetap. Kombinasi batch yang jauh lebih '
     'besar dan data yang sepuluh kali lipat lebih banyak menjadikan '
     'RoBERTa sebagai encoder teks yang lebih kuat untuk tugas-tugas '
     'yang membutuhkan pemahaman semantik mendalam seperti penilaian '
     'kualitas teks.'),
]

# ── Build text block ───────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'\bBPE\b', r'Byte Pair Encoding',
    r'WordPiece',
    r'subword', r'subword tokenization',
    r'out-of-vocabulary', r'\bOOV\b',
    r'token', r'tokenisasi', r'tokenization',
    r'encoder', r'decoder',
    r'encoder-decoder', r'encoder-only', r'decoder-only',
    r'self-attention', r'cross-attention',
    r'multi-head attention', r'multi-head self-attention',
    r'scaled dot-product attention',
    r'attention',
    r'positional encoding', r'positional embedding',
    r'feed-forward', r'feed-forward network',
    r'layer normalization',
    r'residual',
    r'embedding',
    r'pipeline',
    r'fine-tuning', r'fine-tune', r'fine-tuned', r'di-fine-tune',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream',
    r'Masked Language Modeling', r'\bMLM\b',
    r'Next Sentence Prediction', r'\bNSP\b',
    r'dynamic masking', r'static masking',
    r'learning rate',
    r'batch size',
    r'deep learning',
    r'machine learning',
    r'natural language processing', r'\bNLP\b',
    r'benchmark',
    r'overfitting',
    r'autoregressive', r'autoregresif',
    r'bidirectional',
    r'Transformer',
    r'Query', r'Key', r'Value',
    r'\bRNN\b', r'\bLSTM\b', r'\bGPT\b',
    r'softmax',
    r'dropout',
    r'weight decay',
    r'state-of-the-art',
    r'ablation study',
    r'sigmoid', r'Sigmoid',
    r'\bGELU\b', r'\bReLU\b',
    r'activation function',
    r'bottleneck',
    r'concatenat',
    r'mask', r'masking',
]

italic_ranges = []
covered = set()

for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start = full_text.find(text)
    if seg_start == -1:
        continue
    for term in ITALIC_TERMS:
        for match in re.compile(term, re.IGNORECASE).finditer(text):
            ms = seg_start + match.start()
            me = seg_start + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Phase 1: Insert text ───────────────────────────────────────────────────────
offset = append_at - 1
requests_list = []

for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', append_at, TAB_ID))

for start, end, seg_type, text in seg_positions:
    s, e = start + offset, end + offset
    if seg_type == 'subsection':
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'caption':
        requests_list.append(req_para_style(s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID,
                                        italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted and styled.')

# ── Phase 2: Insert tables ─────────────────────────────────────────────────────
time.sleep(1)

TABLES = [
    (TABLE_2210_PH, TABLE_2210_DATA, 5, 3),
    (TABLE_2211_PH, TABLE_2211_DATA, 6, 3),
    (TABLE_2212_PH, TABLE_2212_DATA, 5, 4),
    (TABLE_2213_PH, TABLE_2213_DATA, 6, 2),
    (TABLE_2214_PH, TABLE_2214_DATA, 7, 3),
]

for ph_text, table_data, nrows, ncols in TABLES:
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    ph_start = None
    for element in body_content:
        if 'paragraph' in element:
            para_text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in element['paragraph'].get('elements', [])
            )
            if ph_text in para_text:
                ph_start = element.get('startIndex', 0)
                break

    if ph_start is None:
        print(f'ERROR: Placeholder {ph_text} not found. Skipping.')
        continue

    print(f'{ph_text} at index {ph_start}.')

    batch_update([{
        'deleteContentRange': {
            'range': {'startIndex': ph_start, 'endIndex': ph_start + len(ph_text), 'tabId': TAB_ID}
        }
    }])

    batch_update([{
        'insertTable': {
            'rows': nrows, 'columns': ncols,
            'location': {'index': ph_start, 'tabId': TAB_ID},
        }
    }])
    print(f'Table {ph_text} inserted ({nrows}x{ncols}). Filling...')
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    if table_el is None:
        print(f'ERROR: Table element not found for {ph_text}.')
        continue

    rows = table_el['table'].get('tableRows', [])
    cell_inserts = []
    for row_idx, row in enumerate(rows):
        for col_idx, cell in enumerate(row.get('tableCells', [])):
            cell_paras = cell.get('content', [])
            if cell_paras and 'paragraph' in cell_paras[0]:
                cell_start = cell_paras[0].get('startIndex', 0)
                cell_text = table_data[row_idx][col_idx]
                cell_inserts.append((cell_start, cell_text, row_idx))

    cell_inserts.sort(key=lambda x: x[0], reverse=True)
    fill_reqs = [req_insert(ct, cs, TAB_ID) for cs, ct, _ in cell_inserts]
    batch_update(fill_reqs)
    print(f'Filled {len(fill_reqs)} cells.')
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    fmt_reqs = []
    if table_el:
        for row_idx, row in enumerate(table_el['table'].get('tableRows', [])):
            is_header = (row_idx == 0)
            for cell in row.get('tableCells', []):
                for para in cell.get('content', []):
                    if 'paragraph' in para:
                        p_start = para.get('startIndex')
                        p_end = para.get('endIndex')
                        fmt_reqs.append(req_text_style(p_start, p_end, TAB_ID,
                                                       bold=is_header, size_pt=11))
                        fmt_reqs.append({
                            'updateParagraphStyle': {
                                'range': {'startIndex': p_start, 'endIndex': p_end, 'tabId': TAB_ID},
                                'paragraphStyle': {
                                    'alignment': 'CENTER' if is_header else 'START',
                                    'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                    'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                    'lineSpacing': 120,
                                },
                                'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                            }
                        })
        batch_update(fmt_reqs)
        print(f'Formatted {ph_text} ({len(fmt_reqs)} requests).')

print('\nDone. Group 3 written.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
