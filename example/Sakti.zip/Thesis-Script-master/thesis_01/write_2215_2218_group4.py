"""
Write BAB II Group 4: 2.2.15-2.2.18 (Visual Processing Pipeline Part 1)
  2.2.15 Convolutional Neural Network (CNN)
  2.2.16 ResNet18
  2.2.17 Vision Transformer (ViT)
  2.2.18 Pix2Struct
Pure theory — no research-specific context.
Papers confirmed:
  - LeCun et al. (1998) LeNet — Proc. IEEE 86(11):2278-2324
  - Krizhevsky et al. (2012) AlexNet — NeurIPS
  - He et al. (2016) ResNet — CVPR, DOI:10.1109/CVPR.2016.90
  - Dosovitskiy et al. (2021) ViT — ICLR, arXiv:2010.11929
  - Lee et al. (2023) Pix2Struct — ICML, arXiv:2210.03347
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)


def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps, 'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()


doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
content = tab.get('documentTab', {}).get('body', {}).get('content', [])
append_at = content[-1].get('startIndex', 1) if content else 1
print(f'Appending after index {append_at}.')

# ── Tables ─────────────────────────────────────────────────────────────────────

TABLE_2215_CAPTION = 'Tabel 2.14. Komponen Utama Arsitektur CNN dan Fungsinya'
TABLE_2215_PH = '<<TABEL_2_14>>'
TABLE_2215_DATA = [
    ['Komponen', 'Operasi', 'Fungsi dalam Hierarki Fitur'],
    ['Convolutional Layer',
     'Konvolusi kernel W dengan input X: (W * X)[i,j] = sum_m sum_n W[m,n] X[i+m, j+n]',
     'Mengekstraksi fitur lokal (tepi, tekstur, pola); bobot berbagi antar posisi'],
    ['Activation (ReLU)',
     'f(x) = max(0, x) diterapkan elemen per elemen',
     'Menambahkan nonlinieritas; mencegah vanishing gradient di lapisan dangkal'],
    ['Pooling Layer',
     'Max atau average pooling pada jendela s x s dengan stride s',
     'Mengurangi dimensi spasial; memberikan invarian terhadap translasi kecil'],
    ['Fully Connected Layer',
     'Transformasi linier: y = Wx + b setelah flatten feature map',
     'Mengintegrasikan fitur global untuk klasifikasi atau regresi akhir'],
]

TABLE_2216_CAPTION = 'Tabel 2.15. Perbandingan Varian Arsitektur ResNet'
TABLE_2216_PH = '<<TABEL_2_15>>'
TABLE_2216_DATA = [
    ['Varian', 'Jumlah Lapisan', 'Parameter', 'Dimensi Output (AvgPool)'],
    ['ResNet-18',  '18', '11,7 juta', '512-dim'],
    ['ResNet-34',  '34', '21,8 juta', '512-dim'],
    ['ResNet-50',  '50', '25,6 juta', '2.048-dim'],
    ['ResNet-101', '101', '44,5 juta', '2.048-dim'],
]

TABLE_2217_CAPTION = 'Tabel 2.16. Perbandingan Varian Arsitektur Vision Transformer (ViT)'
TABLE_2217_PH = '<<TABEL_2_16>>'
TABLE_2217_DATA = [
    ['Varian', 'Lapisan', 'Hidden Dim', 'Heads', 'Parameter', 'ImageNet Top-1'],
    ['ViT-Base/16',  '12', '768',  '12', '86 juta',  '81.8%'],
    ['ViT-Large/16', '24', '1024', '16', '307 juta', '82.6%'],
    ['ViT-Huge/14',  '32', '1280', '16', '632 juta', '83.6%'],
]

TABLE_2218_CAPTION = 'Tabel 2.17. Perbandingan Pix2Struct dengan Pendekatan Visual Language Model Sebelumnya'
TABLE_2218_PH = '<<TABEL_2_17>>'
TABLE_2218_DATA = [
    ['Aspek', 'OCR Tradisional + Parser', 'ViT + Language Model Umum', 'Pix2Struct'],
    ['Input',
     'Gambar; output OCR sebagai teks perantara',
     'Gambar diperkecil ke resolusi tetap',
     'Screenshot/gambar dengan resolusi variabel'],
    ['Pretraining',
     'Tidak ada; OCR dilatih terpisah',
     'Pretraining pada pasangan gambar-teks umum',
     'Masked patch prediction pada 80 juta screenshot web'],
    ['Kemampuan struktur visual',
     'Tergantung pada kualitas OCR; tidak memahami layout',
     'Terbatas; tidak dioptimalkan untuk dokumen',
     'Memahami tabel, grafik, dan elemen UI secara langsung'],
    ['Keluaran',
     'Teks terdeteksi tanpa pemahaman semantik',
     'Caption atau jawaban generik',
     'Teks terstruktur yang merepresentasikan konten visual'],
]

# ── Segments ───────────────────────────────────────────────────────────────────
segments = [

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.15 Convolutional Neural Network (CNN)
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.15 Convolutional Neural Network (CNN)'),

    ('body',
     'Convolutional Neural Network (CNN) adalah kelas arsitektur jaringan saraf '
     'tiruan yang dirancang khusus untuk memproses data yang memiliki struktur '
     'kisi (grid), seperti gambar piksel dua dimensi. LeCun et al. (1998) '
     'memperkenalkan LeNet, arsitektur CNN pertama yang berhasil diterapkan '
     'secara praktis untuk pengenalan tulisan tangan digit, dengan memanfaatkan '
     'tiga ide kunci yang menjadi fondasi CNN hingga saat ini: koneksi lokal '
     'antar neuron yang hanya memperhatikan area reseptif kecil, berbagi bobot '
     '(weight sharing) di mana kernel yang sama diterapkan di seluruh posisi '
     'spasial gambar, dan subsampling melalui pooling untuk mengurangi dimensi '
     'spasial secara bertahap. Berbagi bobot secara drastis mengurangi jumlah '
     'parameter dibandingkan jaringan fully connected pada gambar berdimensi '
     'tinggi, sekaligus membuat model invarian terhadap translasi objek dalam '
     'gambar.'),

    ('body',
     'Krizhevsky et al. (2012) mendemonstrasikan potensi penuh CNN modern '
     'melalui AlexNet yang memenangkan kompetisi ImageNet Large Scale Visual '
     'Recognition Challenge (ILSVRC) dengan margin yang sangat besar, '
     'menurunkan error rate dari 26,2 persen menjadi 15,3 persen. AlexNet '
     'memperkenalkan penggunaan GPU untuk pelatihan, fungsi aktivasi ReLU '
     'sebagai pengganti sigmoid untuk mengatasi vanishing gradient, dropout '
     'sebagai regularisasi, dan augmentasi data. Kesuksesan AlexNet memicu '
     'gelombang penelitian yang menghasilkan arsitektur CNN yang semakin '
     'dalam dan akurat: VGGNet (Simonyan & Zisserman, 2015) menunjukkan '
     'bahwa kedalaman dengan kernel 3x3 yang konsisten adalah kunci performa, '
     'GoogLeNet (Szegedy et al., 2015) memperkenalkan modul inception, dan '
     'ResNet (He et al., 2016) memecahkan masalah vanishing gradient pada '
     'jaringan yang sangat dalam melalui koneksi residual.'),

    ('body',
     'Secara hierarkis, lapisan-lapisan awal CNN mempelajari fitur primitif '
     'seperti tepi dan gradien orientasi, lapisan tengah mengkombinasikan '
     'fitur-fitur ini menjadi pola yang lebih kompleks seperti tekstur dan '
     'bagian objek, sedangkan lapisan akhir merepresentasikan objek secara '
     'keseluruhan dalam ruang fitur yang kompak. Representasi hierarkis ini '
     'sangat efektif untuk tugas-tugas visual karena mencerminkan bagaimana '
     'manusia juga memproses informasi visual secara bertahap dari detail '
     'lokal ke pemahaman global. Setelah seluruh blok konvolusional, '
     'global average pooling sering digunakan untuk menghasilkan vektor '
     'fitur berdimensi tetap yang merangkum konten semantik gambar secara '
     'keseluruhan, terlepas dari ukuran input aslinya. Tabel 2.14 merangkum '
     'komponen utama arsitektur CNN dan peran masing-masing dalam membangun '
     'representasi hierarkis fitur visual.'),

    ('caption', TABLE_2215_CAPTION),
    ('placeholder', TABLE_2215_PH),

    ('body',
     'Berdasarkan Tabel 2.14, setiap komponen CNN memiliki peran yang saling '
     'melengkapi dalam membangun representasi visual yang berguna: lapisan '
     'konvolusional mengekstraksi pola lokal dengan efisiensi parameter melalui '
     'berbagi bobot, aktivasi ReLU menambahkan kapasitas nonlinier, pooling '
     'membangun invarian spasial, dan lapisan fully connected mengintegrasikan '
     'semua fitur untuk keputusan akhir.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.16 ResNet18
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.16 ResNet18'),

    ('body',
     'ResNet (Residual Network) diperkenalkan oleh He et al. (2016) sebagai '
     'solusi terhadap masalah degradasi yang diamati pada CNN yang sangat dalam: '
     'bertambahnya kedalaman jaringan melampaui titik tertentu justru '
     'menyebabkan penurunan akurasi pelatihan, bukan hanya akurasi validasi. '
     'He et al. (2016) menunjukkan bahwa masalah ini bukan disebabkan oleh '
     'overfitting melainkan oleh kesulitan optimasi pada jaringan yang sangat '
     'dalam. Solusinya adalah residual learning: alih-alih melatih blok jaringan '
     'untuk mempelajari pemetaan H(x) secara langsung, blok tersebut dilatih '
     'untuk mempelajari residu F(x) = H(x) - x, sehingga H(x) = F(x) + x. '
     'Koneksi pintasan (skip connection) yang menjumlahkan input x langsung '
     'ke output blok memungkinkan gradien mengalir langsung dari lapisan akhir '
     'ke lapisan awal tanpa melalui transformasi nonlinier yang berulang.'),

    ('body',
     'Arsitektur ResNet-18 terdiri dari 18 lapisan berbobot yang diorganisasi '
     'dalam empat grup blok residual, masing-masing dengan dua lapisan '
     'konvolusional 3x3 diikuti oleh batch normalization dan aktivasi ReLU. '
     'Dimensi channel meningkat secara bertahap dari 64 di grup pertama hingga '
     '512 di grup keempat, sementara dimensi spasial berkurang melalui '
     'konvolusi dengan stride 2 di awal setiap grup. Pada akhir seluruh blok '
     'konvolusional, global average pooling menghasilkan vektor fitur '
     'berdimensi 512 yang meringkas seluruh konten semantik gambar input. '
     'Dengan total 11,7 juta parameter, ResNet-18 merupakan varian paling '
     'ringan dalam keluarga ResNet sehingga sering dipilih sebagai visual '
     'encoder dalam sistem yang memerlukan efisiensi komputasi atau '
     'menggabungkan beberapa encoder secara bersamaan.'),

    ('body',
     'He et al. (2016) mengevaluasi seluruh keluarga ResNet pada benchmark '
     'ImageNet dan menunjukkan bahwa skip connection secara konsisten '
     'meningkatkan akurasi seiring bertambahnya kedalaman, berbeda dengan '
     'jaringan tanpa residual yang mengalami degradasi setelah kedalaman '
     'tertentu. ResNet-152 mencapai top-5 error rate 3,57 persen pada '
     'ImageNet, mengalahkan performa manusia untuk pertama kalinya. '
     'Keluarga ResNet menjadi arsitektur backbone standar untuk berbagai '
     'tugas visi komputer termasuk deteksi objek, segmentasi semantik, '
     'dan ekstraksi fitur visual dalam sistem multimoda. Tabel 2.15 '
     'membandingkan konfigurasi dan kapasitas representasi dari empat '
     'varian arsitektur ResNet yang paling umum digunakan.'),

    ('caption', TABLE_2216_CAPTION),
    ('placeholder', TABLE_2216_PH),

    ('body',
     'Berdasarkan Tabel 2.15, ResNet-18 dan ResNet-34 menggunakan blok '
     'residual dasar dengan dua lapisan konvolusional 3x3, sehingga '
     'dimensi output setelah global average pooling adalah 512. ResNet-50 '
     'ke atas menggunakan bottleneck block dengan tiga lapisan (1x1, 3x3, '
     '1x1) yang lebih efisien secara komputasi untuk kedalaman yang lebih '
     'besar, menghasilkan dimensi output 2.048. Pemilihan varian bergantung '
     'pada keseimbangan antara kapasitas representasi yang dibutuhkan dan '
     'sumber daya komputasi yang tersedia.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.17 Vision Transformer (ViT)
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.17 Vision Transformer (ViT)'),

    ('body',
     'Vision Transformer (ViT) diperkenalkan oleh Dosovitskiy et al. (2021) '
     'dalam makalah "An Image is Worth 16x16 Words: Transformers for Image '
     'Recognition at Scale" sebagai bukti bahwa arsitektur Transformer murni, '
     'tanpa komponen konvolusional, dapat mencapai performa state-of-the-art '
     'pada tugas pengenalan gambar ketika dilatih pada dataset yang cukup besar. '
     'Ide utamanya sederhana: gambar dibagi menjadi patch-patch kecil berukuran '
     '16x16 piksel, setiap patch diratakan (flatten) dan diproyeksikan secara '
     'linier menjadi embedding berdimensi tetap, kemudian urutan embedding '
     'patch ini diperlakukan persis seperti urutan token dalam model bahasa '
     'Transformer. Sebuah token [CLS] khusus ditambahkan di awal urutan, '
     'dan representasinya pada lapisan terakhir digunakan sebagai representasi '
     'keseluruhan gambar untuk tugas klasifikasi.'),

    ('body',
     'Karena Transformer tidak memiliki pemahaman bawaan tentang posisi, '
     'ViT menambahkan positional embedding yang dapat dipelajari ke setiap '
     'patch embedding agar model dapat memanfaatkan informasi tata letak '
     'spasial gambar. Dosovitskiy et al. (2021) menemukan bahwa ViT yang '
     'dilatih pada dataset berukuran sedang seperti ImageNet (1,3 juta '
     'gambar) masih kalah dari CNN yang dioptimalkan, tetapi ketika '
     'dilatih pada dataset yang jauh lebih besar seperti JFT-300M (300 '
     'juta gambar), ViT secara konsisten mengungguli CNN terbaik dengan '
     'biaya komputasi pelatihan yang lebih rendah. Temuan ini mengindikasikan '
     'bahwa CNN memiliki induktif bias spasial yang menguntungkan pada data '
     'kecil, tetapi Transformer yang lebih fleksibel dapat melampaui CNN '
     'ketika diberikan data yang cukup untuk mempelajari bias tersebut '
     'secara empiris.'),

    ('body',
     'ViT menjadi fondasi arsitektur visual encoder dalam hampir semua '
     'vision-language model modern. Kemampuan self-attention untuk '
     'menangkap ketergantungan jarak jauh antar patch secara langsung, '
     'tanpa dibatasi oleh ukuran receptive field lokal seperti pada CNN, '
     'membuatnya sangat cocok untuk memahami hubungan global dalam gambar '
     'seperti tata letak halaman dokumen, struktur tabel, atau hubungan '
     'antar elemen grafik. Skalabilitas ViT yang baik memungkinkan '
     'pelatihan model visual yang jauh lebih besar dibandingkan CNN '
     'pada infrastruktur yang sama. Tabel 2.16 membandingkan konfigurasi '
     'tiga varian ViT utama beserta performa pada benchmark ImageNet-1k.'),

    ('caption', TABLE_2217_CAPTION),
    ('placeholder', TABLE_2217_PH),

    ('body',
     'Berdasarkan Tabel 2.16, peningkatan kapasitas dari ViT-Base ke '
     'ViT-Huge dicapai melalui penambahan kedalaman (jumlah lapisan), '
     'lebar (dimensi hidden), dan jumlah attention head secara bersamaan. '
     'Meskipun ViT-Huge memiliki parameter tujuh kali lebih banyak dari '
     'ViT-Base, peningkatan akurasi ImageNet relatif kecil (81,8 persen '
     'vs 83,6 persen), menunjukkan bahwa skala data pelatihan lebih '
     'menentukan daripada skala parameter untuk model berbasis Transformer.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.18 Pix2Struct
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.18 Pix2Struct'),

    ('body',
     'Pix2Struct adalah model image-to-text berbasis encoder-decoder yang '
     'diperkenalkan oleh Lee et al. (2023) dengan pendekatan pretraining '
     'yang dirancang khusus untuk memahami konten visual yang situasional, '
     'yaitu gambar yang maknanya bergantung pada struktur visual seperti '
     'tabel, grafik, antarmuka pengguna, dan dokumen ilmiah. Berbeda dari '
     'model visual umum yang dilatih pada pasangan gambar-caption dari '
     'internet, Pix2Struct dilatih melalui masked patch prediction pada '
     '80 juta screenshot halaman web: sebagian patch gambar ditutup dan '
     'model dilatih untuk menghasilkan teks HTML yang merepresentasikan '
     'bagian yang tertutup tersebut berdasarkan konteks visual yang tersisa. '
     'Pretraining ini memaksa model untuk benar-benar memahami struktur '
     'dan semantik visual, bukan sekadar mengenali objek.'),

    ('body',
     'Salah satu inovasi teknis utama Pix2Struct adalah penanganan resolusi '
     'variabel melalui strategi pembagian patch yang adaptif. Model ViT '
     'standar mengubah ukuran (resize) semua gambar menjadi resolusi tetap '
     '(misalnya 224x224 piksel) sebelum membaginya menjadi patch, yang '
     'menyebabkan distorsi pada dokumen berteks panjang atau grafik dengan '
     'detail numerik halus. Pix2Struct sebaliknya menentukan jumlah patch '
     'maksimum yang diizinkan dan membagi gambar menjadi patch-patch yang '
     'mempertahankan rasio aspek aslinya, sehingga gambar dengan resolusi '
     'lebih tinggi mendapat lebih banyak patch dan lebih banyak detail '
     'dipertahankan. Pendekatan ini sangat penting untuk akurasi pada '
     'grafik yang memuat angka-angka kecil atau tabel dengan banyak kolom.'),

    ('body',
     'Lee et al. (2023) mengevaluasi Pix2Struct pada delapan tugas pemahaman '
     'visual yang mencakup question answering pada grafik, tabel, antarmuka '
     'pengguna, dan dokumen ilmiah, serta pada tugas captioning grafik. '
     'Pix2Struct mencapai performa state-of-the-art pada enam dari delapan '
     'tugas tersebut, termasuk pada ChartQA dan FigureQA untuk pemahaman '
     'grafik. Pix2Struct kemudian menjadi fondasi untuk model-model '
     'khusus grafik yang lebih terfokus: DePlot yang di-fine-tune untuk '
     'mengonversi grafik menjadi tabel terstruktur, dan MATCHA yang '
     'di-fine-tune untuk penalaran matematika dan pemahaman grafik '
     'secara end-to-end. Tabel 2.17 membandingkan Pix2Struct dengan '
     'pendekatan sebelumnya untuk pemahaman konten visual terstruktur.'),

    ('caption', TABLE_2218_CAPTION),
    ('placeholder', TABLE_2218_PH),

    ('body',
     'Berdasarkan Tabel 2.17, keunggulan utama Pix2Struct terletak pada '
     'kombinasi pretraining yang berorientasi pada struktur visual dan '
     'kemampuan memproses resolusi variabel, dua aspek yang tidak '
     'dimiliki oleh pendekatan OCR tradisional maupun model ViT umum. '
     'Kemampuan mempertahankan resolusi asli gambar sangat krusial '
     'untuk konten seperti grafik ilmiah dan tabel data yang memuat '
     'informasi numerik detail yang mudah hilang ketika gambar diperkecil.'),
]

# ── Build text ─────────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []
for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Italic terms ───────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'\bCNN\b', r'Convolutional Neural Network',
    r'convolutional', r'convolution',
    r'kernel', r'filter',
    r'feature map', r'feature maps', r'feature vector',
    r'pooling', r'max pooling', r'average pooling', r'global average pooling',
    r'fully connected',
    r'weight sharing', r'berbagi bobot',
    r'receptive field',
    r'batch normalization',
    r'dropout',
    r'skip connection', r'shortcut connection', r'residual connection',
    r'residual learning', r'residual block',
    r'backbone',
    r'encoder', r'decoder', r'encoder-decoder',
    r'embedding', r'patch embedding', r'positional embedding',
    r'self-attention', r'cross-attention', r'multi-head',
    r'attention',
    r'Transformer',
    r'\bViT\b', r'Vision Transformer',
    r'patch',
    r'fine-tuning', r'fine-tune', r'fine-tuned',
    r'pre-training', r'pre-trained',
    r'pretraining',
    r'transfer learning',
    r'benchmark',
    r'state-of-the-art',
    r'deep learning',
    r'machine learning',
    r'overfitting',
    r'vanishing gradient', r'exploding gradient',
    r'stride',
    r'flatten',
    r'image-to-text',
    r'screenshot',
    r'masked patch prediction',
    r'question answering',
    r'captioning',
    r'end-to-end',
    r'pipeline',
    r'inference',
    r'\bReLU\b', r'\bGELU\b',
    r'activation',
    r'layer normalization',
    r'feed-forward',
    r'bottleneck',
    r'resize',
    r'visual encoder',
    r'vision-language model', r'\bVLM\b',
]

italic_ranges = []
covered = set()
for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start = full_text.find(text)
    if seg_start == -1:
        continue
    for term in ITALIC_TERMS:
        for match in re.compile(term, re.IGNORECASE).finditer(text):
            ms = seg_start + match.start()
            me = seg_start + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Phase 1: Insert text ───────────────────────────────────────────────────────
offset = append_at - 1
requests_list = []

for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', append_at, TAB_ID))

for start, end, seg_type, text in seg_positions:
    s, e = start + offset, end + offset
    if seg_type == 'subsection':
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'caption':
        requests_list.append(req_para_style(s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID,
                                        italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted.')

# ── Phase 2: Tables ────────────────────────────────────────────────────────────
time.sleep(1)

TABLES = [
    (TABLE_2215_PH, TABLE_2215_DATA, 5, 3),
    (TABLE_2216_PH, TABLE_2216_DATA, 5, 4),
    (TABLE_2217_PH, TABLE_2217_DATA, 4, 5),
    (TABLE_2218_PH, TABLE_2218_DATA, 5, 3),
]

for ph_text, table_data, nrows, ncols in TABLES:
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    ph_start = None
    for element in body_content:
        if 'paragraph' in element:
            para_text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in element['paragraph'].get('elements', [])
            )
            if ph_text in para_text:
                ph_start = element.get('startIndex', 0)
                break

    if ph_start is None:
        print(f'ERROR: {ph_text} not found.')
        continue

    print(f'{ph_text} at index {ph_start}.')
    batch_update([{'deleteContentRange': {
        'range': {'startIndex': ph_start, 'endIndex': ph_start + len(ph_text), 'tabId': TAB_ID}
    }}])
    batch_update([{'insertTable': {
        'rows': nrows, 'columns': ncols,
        'location': {'index': ph_start, 'tabId': TAB_ID},
    }}])
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
    table_el = next((el for el in body_content
                     if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)
    if not table_el:
        print(f'ERROR: table element not found for {ph_text}.')
        continue

    rows_data = table_el['table'].get('tableRows', [])
    cell_inserts = []
    for ri, row in enumerate(rows_data):
        for ci, cell in enumerate(row.get('tableCells', [])):
            paras = cell.get('content', [])
            if paras and 'paragraph' in paras[0]:
                cell_inserts.append((paras[0].get('startIndex', 0), table_data[ri][ci], ri))

    cell_inserts.sort(key=lambda x: x[0], reverse=True)
    batch_update([req_insert(ct, cs, TAB_ID) for cs, ct, _ in cell_inserts])
    print(f'Filled {len(cell_inserts)} cells.')
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
    table_el = next((el for el in body_content
                     if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)

    fmt_reqs = []
    if table_el:
        for ri, row in enumerate(table_el['table'].get('tableRows', [])):
            is_hdr = (ri == 0)
            for cell in row.get('tableCells', []):
                for para in cell.get('content', []):
                    if 'paragraph' in para:
                        ps, pe = para.get('startIndex'), para.get('endIndex')
                        fmt_reqs.append(req_text_style(ps, pe, TAB_ID, bold=is_hdr, size_pt=11))
                        fmt_reqs.append({'updateParagraphStyle': {
                            'range': {'startIndex': ps, 'endIndex': pe, 'tabId': TAB_ID},
                            'paragraphStyle': {
                                'alignment': 'CENTER' if is_hdr else 'START',
                                'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                'lineSpacing': 120,
                            },
                            'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                        }})
        batch_update(fmt_reqs)
        print(f'Formatted {ph_text}.')

print('\nDone. Group 4 (2.2.15-2.2.18) written.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
