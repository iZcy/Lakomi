"""
Write BAB II Group 5: 2.2.19-2.2.22 (Visual Processing Pipeline Part 2)
  2.2.19 Kuantisasi Model
  2.2.20 Qwen2-VL
  2.2.21 DePlot
  2.2.22 MATCHA
Pure theory — no research-specific context.
Papers confirmed:
  - Dettmers et al. (2023) QLoRA — NeurIPS, arXiv:2305.14314
  - Wang et al. (2024) Qwen2-VL — arXiv:2409.12191
  - Liu et al. (2023) DePlot — ACL Findings, DOI:10.18653/v1/2023.findings-acl.660
  - Liu et al. (2023) MATCHA — ACL Long, arXiv:2212.09662
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)


def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps, 'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()


doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
content = tab.get('documentTab', {}).get('body', {}).get('content', [])
append_at = content[-1].get('startIndex', 1) if content else 1
print(f'Appending after index {append_at}.')

# ── Tables ─────────────────────────────────────────────────────────────────────

TABLE_2219_CAPTION = 'Tabel 2.18. Perbandingan Format Presisi Numerik untuk Kuantisasi Model'
TABLE_2219_PH = '<<TABEL_2_18>>'
TABLE_2219_DATA = [
    ['Format', 'Bit', 'Ukuran per Parameter', 'Memori Model 7B', 'Karakteristik'],
    ['FP32', '32', '4 byte', '~28 GB', 'Presisi penuh; standar pelatihan'],
    ['FP16 / BF16', '16', '2 byte', '~14 GB', 'Presisi setengah; digunakan saat inferensi dan pelatihan mixed precision'],
    ['INT8', '8', '1 byte', '~7 GB', 'Integer 8-bit; dapat dikuantisasi pasca-pelatihan; sedikit penurunan akurasi'],
    ['NF4 (Normal Float 4)', '4', '0,5 byte', '~3,5 GB', 'Optimal secara teoritis untuk bobot berdistribusi normal; digunakan dalam QLoRA'],
]

TABLE_2220_CAPTION = 'Tabel 2.19. Perbandingan Varian Model Qwen2-VL'
TABLE_2220_PH = '<<TABEL_2_19>>'
TABLE_2220_DATA = [
    ['Varian', 'Parameter', 'Visual Encoder', 'DocVQA Score', 'ChartQA Score'],
    ['Qwen2-VL-2B', '2 miliar', 'ViT ~675 juta', '90,1', '73,5'],
    ['Qwen2-VL-7B', '7 miliar', 'ViT ~675 juta', '94,5', '83,0'],
    ['Qwen2-VL-72B', '72 miliar', 'ViT ~675 juta', '96,5', '88,3'],
]

TABLE_2221_CAPTION = 'Tabel 2.20. Tipe Grafik dan Kemampuan DePlot dalam Menghasilkan Tabel Terstruktur'
TABLE_2221_PH = '<<TABEL_2_20>>'
TABLE_2221_DATA = [
    ['Tipe Grafik', 'Contoh Output DePlot', 'Keandalan'],
    ['Bar chart', 'Year | Value\\n2010 | 45\\n2011 | 52 ...', 'Tinggi; nilai numerik terekstraksi akurat'],
    ['Pie chart', 'Category | Percentage\\nA | 35%\\nB | 25% ...', 'Sedang; nilai persentase kadang tidak tepat'],
    ['Line chart', 'X | Y\\n0 | 10\\n1 | 15 ...', 'Tinggi untuk tren; nilai titik data kadang approx.'],
    ['Flow chart / Map', '(output tidak terstruktur)', 'Tidak didukung; tidak ada data tabular untuk diekstraksi'],
]

TABLE_2222_CAPTION = 'Tabel 2.21. Perbandingan DePlot dan MATCHA'
TABLE_2222_PH = '<<TABEL_2_21>>'
TABLE_2222_DATA = [
    ['Aspek', 'DePlot (Liu et al., 2023)', 'MATCHA (Liu et al., 2023)'],
    ['Fondasi model', 'Pix2Struct (fine-tuned)', 'Pix2Struct (fine-tuned)'],
    ['Tujuan pretraining tambahan',
     'Chart-to-table translation (satu tugas)',
     'Chart derendering + math reasoning (dua tugas)'],
    ['Format keluaran',
     'Tabel terstruktur berformat teks (linearized markdown)',
     'Teks bahasa alami (caption atau jawaban)'],
    ['Pipeline penggunaan',
     'Dua langkah: DePlot menghasilkan tabel, LLM melakukan penalaran',
     'Satu langkah: end-to-end dari gambar langsung ke teks'],
    ['Kekuatan utama',
     'Keluaran terstruktur dan dapat diverifikasi secara faktual',
     'Kemampuan penalaran matematis; tidak memerlukan LLM tambahan'],
    ['Keterbatasan',
     'Memerlukan LLM terpisah untuk penalaran; hanya untuk grafik tabular',
     'Keluaran sulit diverifikasi; penalaran tersembunyi dalam model'],
]

# ── Segments ───────────────────────────────────────────────────────────────────
segments = [

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.19 Kuantisasi Model
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.19 Kuantisasi Model'),

    ('body',
     'Kuantisasi model adalah teknik kompresi yang mengurangi presisi numerik '
     'dari bobot dan/atau aktivasi jaringan saraf tiruan dari representasi '
     'floating-point 32-bit (FP32) yang standar menjadi format dengan bit lebih '
     'sedikit, seperti 16-bit (FP16), 8-bit (INT8), atau bahkan 4-bit. '
     'Motivasi utama kuantisasi adalah bahwa model bahasa besar modern memiliki '
     'miliaran parameter yang membutuhkan puluhan hingga ratusan gigabyte memori '
     'dalam format FP32, jauh melampaui kapasitas GPU konsumer maupun GPU kelas '
     'menengah. Sebagai contoh, model dengan 7 miliar parameter dalam FP32 '
     'membutuhkan sekitar 28 GB VRAM, sedangkan GPU dengan 16 GB VRAM hanya '
     'dapat menampungnya jika presisi dikurangi ke setidaknya FP16 (14 GB) '
     'atau lebih lanjut ke INT8 atau format 4-bit.'),

    ('body',
     'Dettmers et al. (2023) memperkenalkan QLoRA (Quantized Low-Rank Adaptation), '
     'sebuah metode yang menggabungkan kuantisasi 4-bit dengan teknik PEFT '
     'berbasis LoRA untuk memungkinkan fine-tuning model besar pada GPU dengan '
     'memori terbatas. Format kuantisasi yang diusulkan, NF4 (Normal Float 4-bit), '
     'adalah format 4-bit yang optimal secara informasi-teoritis untuk bobot '
     'jaringan saraf yang berdistribusi normal: NF4 menempatkan titik kuantisasi '
     'pada kuantil-kuantil distribusi normal sehingga meminimalkan error '
     'kuantisasi rata-rata untuk distribusi tersebut. Dettmers et al. (2023) '
     'menunjukkan bahwa fine-tuning dengan QLoRA pada model 65 miliar parameter '
     'hanya membutuhkan satu GPU 48 GB, sedangkan fine-tuning FP16 penuh '
     'membutuhkan lebih dari 780 GB VRAM, dengan penurunan performa yang '
     'minimal pada benchmark evaluasi.'),

    ('body',
     'Dalam konteks inferensi (bukan fine-tuning), kuantisasi pasca-pelatihan '
     '(post-training quantization) memungkinkan model yang sudah dilatih dalam '
     'FP32 untuk dimuat dalam presisi yang lebih rendah tanpa pelatihan ulang. '
     'Teknik double quantization yang diperkenalkan dalam QLoRA mengkuantisasi '
     'konstanta kuantisasi itu sendiri, menghasilkan penghematan memori '
     'tambahan sekitar 0,37 bit per parameter. Penting untuk dicatat bahwa '
     'kuantisasi memperkenalkan error aproksimasi yang dapat mengurangi '
     'akurasi model, tetapi untuk banyak tugas, error ini dapat diabaikan '
     'terutama ketika model memiliki kapasitas yang cukup besar. Tabel 2.18 '
     'merangkum karakteristik format presisi utama yang digunakan dalam '
     'ekosistem model bahasa besar modern.'),

    ('caption', TABLE_2219_CAPTION),
    ('placeholder', TABLE_2219_PH),

    ('body',
     'Berdasarkan Tabel 2.18, format NF4 menawarkan kompresi memori delapan '
     'kali dibandingkan FP32 sambil tetap mempertahankan kualitas representasi '
     'yang lebih baik dibandingkan INT8 untuk bobot berdistribusi normal. '
     'Pilihan format kuantisasi bergantung pada trade-off antara memori GPU '
     'yang tersedia, toleransi terhadap penurunan akurasi, dan apakah '
     'model akan digunakan untuk inferensi saja atau juga untuk fine-tuning.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.20 Qwen2-VL
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.20 Qwen2-VL'),

    ('body',
     'Qwen2-VL adalah vision-language model yang dikembangkan oleh Alibaba '
     'Cloud dan diperkenalkan oleh Wang et al. (2024) melalui makalah '
     '"Qwen2-VL: Enhancing Vision-Language Model\'s Perception of the World '
     'at Any Resolution". Model ini mengintegrasikan encoder visual berbasis '
     'ViT dengan decoder berbasis model bahasa Qwen2 untuk memproses dan '
     'menghasilkan teks berdasarkan input gambar, video, dan teks secara '
     'bersamaan. Arsitektur Qwen2-VL tersedia dalam tiga ukuran: 2B, 7B, '
     'dan 72B parameter, dengan encoder visual yang digunakan bersama '
     'oleh ketiga varian memiliki sekitar 675 juta parameter.'),

    ('body',
     'Inovasi arsitektur utama Qwen2-VL adalah mekanisme Naive Dynamic '
     'Resolution yang memungkinkan model memproses gambar pada resolusi '
     'aslinya tanpa perlu mengubah ukuran ke dimensi tetap. Gambar dengan '
     'resolusi berbeda menghasilkan jumlah visual token yang berbeda, '
     'sehingga gambar beresolusi tinggi mendapat representasi yang lebih '
     'kaya. Selain itu, Qwen2-VL memperkenalkan Multimodal Rotary Position '
     'Embedding (M-RoPE) yang menyatukan representasi posisi untuk teks, '
     'gambar, dan video dalam satu ruang posisi yang konsisten, '
     'memungkinkan model memahami hubungan temporal dan spasial antar '
     'modalitas secara lebih koheren. Wang et al. (2024) melaporkan bahwa '
     'Qwen2-VL-72B mencapai performa setara dengan GPT-4o dan Claude 3.5 '
     'Sonnet pada berbagai benchmark multimodal.'),

    ('body',
     'Untuk pemahaman dokumen dan grafik, Qwen2-VL dilatih dengan data '
     'yang mencakup OCR pada dokumen berbagai bahasa, pemahaman grafik '
     'ilmiah, tabel, dan diagram. Kemampuan ini membuatnya relevan sebagai '
     'model yang dapat menghasilkan deskripsi tekstual dari gambar grafik '
     'secara zero-shot maupun few-shot tanpa fine-tuning tambahan pada '
     'domain target. Dalam skenario di mana model digunakan hanya untuk '
     'inferensi tanpa fine-tuning, bobot Qwen2-VL dapat dimuat dalam '
     'format NF4 4-bit menggunakan QLoRA untuk mengurangi kebutuhan memori '
     'GPU secara signifikan. Tabel 2.19 membandingkan performa ketiga '
     'varian Qwen2-VL pada benchmark pemahaman dokumen dan grafik.'),

    ('caption', TABLE_2220_CAPTION),
    ('placeholder', TABLE_2220_PH),

    ('body',
     'Berdasarkan Tabel 2.19, Qwen2-VL-7B menawarkan keseimbangan antara '
     'kapasitas dan efisiensi: dengan 7 miliar parameter, model ini '
     'mencapai skor ChartQA 83,0 yang signifikan lebih tinggi dari varian '
     '2B (73,5) namun masih dapat dijalankan pada GPU dengan memori '
     '16 GB menggunakan kuantisasi 4-bit, tidak seperti varian 72B '
     'yang membutuhkan infrastruktur GPU yang jauh lebih besar.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.21 DePlot
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.21 DePlot'),

    ('body',
     'DePlot adalah model konversi grafik-ke-tabel yang diperkenalkan oleh '
     'Liu et al. (2023) dalam makalah "DePlot: One-shot visual language '
     'reasoning by plot-to-table translation". Model ini dibangun di atas '
     'fondasi Pix2Struct dengan cara melakukan fine-tuning pada pasangan '
     'data grafik dan tabel yang merepresentasikan data di balik grafik '
     'tersebut. Motivasi DePlot berangkat dari pengamatan bahwa model '
     'bahasa besar yang sangat canggih sekalipun mengalami kesulitan '
     'melakukan penalaran langsung pada gambar grafik karena informasi '
     'numerik dalam grafik tidak dapat diakses melalui representasi '
     'visual semata. Dengan mengonversi grafik menjadi tabel teks terlebih '
     'dahulu, penalaran matematis dan faktual dapat diserahkan sepenuhnya '
     'kepada model bahasa yang jauh lebih handal dalam memproses teks '
     'terstruktur.'),

    ('body',
     'Arsitektur DePlot menggunakan encoder visual berbasis Pix2Struct '
     'yang memproses gambar grafik dalam resolusi variabel, diikuti oleh '
     'decoder autoregresif yang menghasilkan tabel dalam format linearized '
     'markdown: baris pertama berisi header kolom yang dipisahkan oleh '
     'karakter pipe (|), dan setiap baris berikutnya berisi nilai-nilai '
     'data. Liu et al. (2023) mengevaluasi DePlot pada benchmark ChartQA '
     'menggunakan pendekatan one-shot: tabel yang dihasilkan DePlot '
     'diberikan bersama satu contoh pertanyaan-jawaban kepada model bahasa '
     'besar (LLM) untuk menjawab pertanyaan tentang grafik tersebut. '
     'Pendekatan ini mencapai peningkatan 29,4 persen dibandingkan '
     'model yang di-fine-tune secara penuh pada ribuan contoh, '
     'menunjukkan bahwa dekomposisi tugas menjadi konversi modalitas '
     'dan penalaran teks adalah strategi yang sangat efektif.'),

    ('body',
     'DePlot memiliki keterbatasan inheren yang berasal dari sifat tugas '
     'yang diselesaikannya: model ini hanya dapat mengonversi grafik yang '
     'memiliki representasi tabular yang jelas seperti bar chart, pie chart, '
     'dan line chart. Untuk jenis visual yang tidak memiliki struktur data '
     'tabular seperti flow chart, peta, dan diagram proses, DePlot tidak '
     'menghasilkan keluaran yang bermakna. Selain itu, akurasi ekstrasi '
     'nilai numerik bervariasi antar jenis grafik; bar chart umumnya '
     'menghasilkan tabel yang lebih akurat dibandingkan pie chart '
     'karena nilai sudut pada pie chart lebih sulit diestimasi secara '
     'presisi dari representasi piksel. Tabel 2.20 mengilustrasikan '
     'contoh format keluaran DePlot dan tingkat keandalan untuk '
     'berbagai tipe grafik.'),

    ('caption', TABLE_2221_CAPTION),
    ('placeholder', TABLE_2221_PH),

    ('body',
     'Berdasarkan Tabel 2.20, DePlot paling andal untuk bar chart dan '
     'line chart di mana nilai numerik dapat dibaca secara relatif '
     'akurat dari panjang batang atau posisi titik pada sumbu. '
     'Pie chart menghadirkan tantangan tambahan karena estimasi '
     'sudut memerlukan presisi geometris yang lebih tinggi. '
     'Keterbatasan pada flow chart dan peta bukan kegagalan model '
     'melainkan batasan desain yang mencerminkan domain spesifik '
     'data pelatihan DePlot.'),

    # ══════════════════════════════════════════════════════════════════════════
    # 2.2.22 MATCHA
    # ══════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.22 MATCHA'),

    ('body',
     'MATCHA (Math reasoning and CHArt derendering) adalah model visual '
     'language berbasis Pix2Struct yang diperkenalkan oleh Liu et al. '
     '(2023) dalam makalah "MatCha: Enhancing Visual Language Pretraining '
     'with Math Reasoning and Chart Derendering". MATCHA memperluas '
     'kemampuan Pix2Struct melalui dua tujuan pretraining tambahan yang '
     'dilakukan secara bersamaan: pertama, chart derendering yang melatih '
     'model untuk mengonversi gambar grafik menjadi tabel data yang '
     'mendasarinya (serupa dengan DePlot); kedua, math reasoning yang '
     'melatih model untuk memecahkan masalah matematika dari representasi '
     'visual menggunakan dataset seperti MATH dan DROP. Kombinasi kedua '
     'tugas pretraining ini dirancang untuk membangun model yang tidak '
     'hanya dapat membaca data dari grafik tetapi juga dapat melakukan '
     'penalaran kuantitatif atas data tersebut secara langsung.'),

    ('body',
     'Perbedaan mendasar antara MATCHA dan DePlot terletak pada paradigma '
     'penggunaan yang berbeda meskipun keduanya berbagi fondasi arsitektur '
     'yang sama. DePlot mengikuti paradigma dua langkah: konversi grafik '
     'ke tabel oleh DePlot, kemudian penalaran atas tabel oleh LLM '
     'terpisah yang lebih besar dan canggih. MATCHA sebaliknya mengikuti '
     'paradigma end-to-end: dari gambar grafik langsung ke jawaban atau '
     'caption dalam satu forward pass tanpa memerlukan LLM tambahan. '
     'Liu et al. (2023) menunjukkan bahwa MATCHA mencapai peningkatan '
     'hingga 20 persen dibandingkan model state-of-the-art sebelumnya '
     'pada benchmark PlotQA dan ChartQA, mengungguli pendekatan yang '
     'menggunakan OCR atau model visual umum.'),

    ('body',
     'Pilihan antara DePlot dan MATCHA bergantung pada kebutuhan aplikasi '
     'yang spesifik. DePlot menghasilkan representasi perantara berupa '
     'tabel yang dapat diinspeksi dan diverifikasi secara independen, '
     'sehingga lebih cocok untuk skenario yang membutuhkan transparansi '
     'dan kepercayaan pada keluaran. MATCHA menghasilkan teks langsung '
     'yang lebih alami dan tidak memerlukan komponen LLM tambahan, '
     'sehingga lebih efisien dalam pipeline yang sederhana. Kedua model '
     'dibatasi oleh kemampuan Pix2Struct yang mendasarinya: keduanya '
     'bekerja dengan baik untuk grafik dengan struktur tabular yang jelas '
     'namun tidak dirancang untuk jenis visual lain seperti diagram proses '
     'atau peta geografis. Tabel 2.21 merangkum perbandingan antara '
     'DePlot dan MATCHA dari beberapa dimensi kunci.'),

    ('caption', TABLE_2222_CAPTION),
    ('placeholder', TABLE_2222_PH),

    ('body',
     'Berdasarkan Tabel 2.21, DePlot dan MATCHA bukan merupakan pendekatan '
     'yang saling menggantikan melainkan saling melengkapi tergantung '
     'pada konteks penggunaan. DePlot lebih cocok ketika keluaran '
     'terstruktur dan dapat diverifikasi menjadi prioritas, sementara '
     'MATCHA lebih cocok ketika simplisitas pipeline dan kemampuan '
     'penalaran matematis bawaan menjadi kebutuhan utama.'),
]

# ── Build text ─────────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []
for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

ITALIC_TERMS = [
    r'kuantisasi', r'quantization', r'post-training quantization',
    r'\bFP32\b', r'\bFP16\b', r'\bBF16\b', r'\bINT8\b', r'\bNF4\b',
    r'Normal Float',
    r'floating-point',
    r'\bLoRA\b', r'\bQLoRA\b', r'\bPEFT\b',
    r'Low-Rank Adaptation',
    r'fine-tuning', r'fine-tune', r'fine-tuned',
    r'pre-training', r'pre-trained',
    r'mixed precision',
    r'double quantization',
    r'vision-language model', r'\bVLM\b',
    r'encoder', r'decoder',
    r'visual encoder',
    r'\bViT\b', r'Vision Transformer',
    r'Naive Dynamic Resolution',
    r'M-RoPE', r'Rotary Position Embedding',
    r'visual token', r'token',
    r'benchmark',
    r'zero-shot', r'few-shot', r'one-shot',
    r'inference', r'inferensi',
    r'forward pass',
    r'pipeline',
    r'end-to-end',
    r'autoregressive', r'autoregresif',
    r'fine-tuned',
    r'chart derendering',
    r'plot-to-table',
    r'linearized',
    r'markdown',
    r'math reasoning',
    r'deep learning',
    r'state-of-the-art',
    r'backbone',
    r'embedding',
    r'attention',
    r'self-attention',
    r'patch',
    r'screenshot',
    r'image-to-text',
    r'text-to-text',
    r'question answering',
    r'captioning',
    r'caption',
    r'multimodal',
    r'OCR',
]

italic_ranges = []
covered = set()
for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start = full_text.find(text)
    if seg_start == -1:
        continue
    for term in ITALIC_TERMS:
        for match in re.compile(term, re.IGNORECASE).finditer(text):
            ms = seg_start + match.start()
            me = seg_start + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

offset = append_at - 1
requests_list = []

for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', append_at, TAB_ID))

for start, end, seg_type, text in seg_positions:
    s, e = start + offset, end + offset
    if seg_type == 'subsection':
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'caption':
        requests_list.append(req_para_style(s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID,
                                        italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted.')
time.sleep(1)

TABLES = [
    (TABLE_2219_PH, TABLE_2219_DATA, 5, 5),
    (TABLE_2220_PH, TABLE_2220_DATA, 4, 5),
    (TABLE_2221_PH, TABLE_2221_DATA, 5, 3),
    (TABLE_2222_PH, TABLE_2222_DATA, 7, 3),
]

for ph_text, table_data, nrows, ncols in TABLES:
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    ph_start = None
    for element in body_content:
        if 'paragraph' in element:
            para_text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in element['paragraph'].get('elements', [])
            )
            if ph_text in para_text:
                ph_start = element.get('startIndex', 0)
                break

    if ph_start is None:
        print(f'ERROR: {ph_text} not found.')
        continue

    print(f'{ph_text} at index {ph_start}.')
    batch_update([{'deleteContentRange': {
        'range': {'startIndex': ph_start, 'endIndex': ph_start + len(ph_text), 'tabId': TAB_ID}
    }}])
    batch_update([{'insertTable': {
        'rows': nrows, 'columns': ncols,
        'location': {'index': ph_start, 'tabId': TAB_ID},
    }}])
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
    table_el = next((el for el in body_content
                     if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)
    if not table_el:
        print(f'ERROR: table not found for {ph_text}.')
        continue

    cell_inserts = []
    for ri, row in enumerate(table_el['table'].get('tableRows', [])):
        for ci, cell in enumerate(row.get('tableCells', [])):
            paras = cell.get('content', [])
            if paras and 'paragraph' in paras[0]:
                cell_inserts.append((paras[0].get('startIndex', 0), table_data[ri][ci], ri))

    cell_inserts.sort(key=lambda x: x[0], reverse=True)
    batch_update([req_insert(ct, cs, TAB_ID) for cs, ct, _ in cell_inserts])
    print(f'Filled {len(cell_inserts)} cells.')
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
    table_el = next((el for el in body_content
                     if 'table' in el and el.get('startIndex', 0) >= ph_start - 2), None)

    fmt_reqs = []
    if table_el:
        for ri, row in enumerate(table_el['table'].get('tableRows', [])):
            is_hdr = (ri == 0)
            for cell in row.get('tableCells', []):
                for para in cell.get('content', []):
                    if 'paragraph' in para:
                        ps, pe = para.get('startIndex'), para.get('endIndex')
                        fmt_reqs.append(req_text_style(ps, pe, TAB_ID, bold=is_hdr, size_pt=11))
                        fmt_reqs.append({'updateParagraphStyle': {
                            'range': {'startIndex': ps, 'endIndex': pe, 'tabId': TAB_ID},
                            'paragraphStyle': {
                                'alignment': 'CENTER' if is_hdr else 'START',
                                'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                'lineSpacing': 120,
                            },
                            'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                        }})
        batch_update(fmt_reqs)
        print(f'Formatted {ph_text}.')

print('\nDone. Group 5 (2.2.19-2.2.22) written.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
