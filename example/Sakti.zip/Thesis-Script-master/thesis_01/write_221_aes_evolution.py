import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Helpers ────────────────────────────────────────────────────────────────────
def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i + BATCH]}
        ).execute()

# ── Phase 1: Clear existing content ───────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1

if end_index > 2:
    batch_update([{
        'deleteContentRange': {
            'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': TAB_ID}
        }
    }])
    print(f'Cleared {end_index - 2} characters.')

# ── Phase 2: Content ───────────────────────────────────────────────────────────
# 2.2.1 Evolusi Automated Essay Scoring
# Rules: min 3 paragraphs, no em dash, italic English terms,
#        Pendekatan A/B (not Track A/B), media = Tabel 2.1, latest papers first.

TABLE_PLACEHOLDER = '<<TABEL_2_1>>'

# Table: 5 rows x 3 cols (header + 4 data rows)
TABLE_CAPTION = 'Tabel 2.1. Perbandingan Generasi Automated Essay Scoring'
TABLE_DATA = [
    ['Generasi', 'Pendekatan Utama', 'Referensi'],
    [
        'Berbasis Aturan (1960-an - 1990-an)',
        'Ekstraksi fitur permukaan teks; aturan linguistik terstruktur; tanpa pembelajaran data',
        'Page (1966) - PEG; Burstein et al. (2003) - e-rater',
    ],
    [
        'Statistik dan ML (2000-an - 2010-an)',
        'LSA, SVM, Naive Bayes; rekayasa fitur manual; regresi berbasis fitur linguistik',
        'Landauer et al. (1997) - LSA; Kompetisi ASAP (2012); Shermis & Burstein (2013)',
    ],
    [
        'Deep Learning (2018 - 2022)',
        'Encoder Transformer; BERT fine-tuning; representasi kontekstual tanpa rekayasa fitur',
        'Vaswani et al. (2017) - Transformer; Devlin et al. (2019) - BERT',
    ],
    [
        'Multimoda (2023 - kini)',
        'VLM untuk pemahaman grafik; multi-trait scoring; pipeline text-to-text berbasis caption',
        'Singh et al. (2024) - EssayJudge; Zhao et al. (2025) - EDU-CIRCUIT-HW',
    ],
]

segments = [
    # ── Subsection heading ────────────────────────────────────────────────────
    ('subsection', '2.2.1 Evolusi Automated Essay Scoring'),

    # ── Paragraph 1: era awal berbasis aturan ────────────────────────────────
    ('body',
     'Automated Essay Scoring (AES) adalah bidang penelitian yang bertujuan mengembangkan '
     'sistem komputasi untuk menilai kualitas esai secara otomatis tanpa keterlibatan penilai '
     'manusia secara langsung. Gagasan awal AES dirintis oleh Page (1966) melalui proyek '
     'Project Essay Grade (PEG), yang menggunakan sejumlah fitur permukaan teks seperti '
     'jumlah kata, panjang kalimat rata-rata, dan keragaman kosakata untuk memprediksi skor '
     'esai secara statistik. Era awal AES didominasi oleh pendekatan berbasis aturan, di mana '
     'sistem e-rater yang dikembangkan oleh Educational Testing Service (Burstein et al., 2003) '
     'menggunakan pipeline ekstraksi fitur linguistik terstruktur, mencakup analisis sintaksis, '
     'kohesi leksikal, dan struktur retorika, untuk menghasilkan skor yang konsisten dengan '
     'penilai manusia terlatih. Meskipun pendekatan ini memiliki interpretabilitas yang tinggi '
     'dan dapat diandalkan pada domain tertentu, proses rekayasa fitur yang dilakukan secara '
     'manual menjadi hambatan utama karena membutuhkan keahlian linguistik yang mendalam dan '
     'sulit digeneralisasi ke jenis esai atau bahasa yang berbeda dari yang digunakan '
     'saat pengembangan sistem.'),

    # ── Paragraph 2: era machine learning ────────────────────────────────────
    ('body',
     'Perkembangan metode machine learning pada akhir 1990-an hingga 2010-an membawa '
     'perubahan signifikan dalam pendekatan AES. Latent Semantic Analysis (LSA) yang '
     'dikembangkan oleh Landauer et al. (1997) memungkinkan sistem merepresentasikan makna '
     'semantik teks dalam ruang vektor berdimensi tinggi melalui dekomposisi matriks '
     'term-document, sehingga mampu menangkap kemiripan topik antara esai dan teks referensi '
     'tanpa pencocokan kata secara eksak. Support Vector Machine (SVM) dengan fitur linguistik '
     'yang dirancang secara manual kemudian menjadi pendekatan dominan pada kompetisi '
     'Automated Student Assessment Prize (ASAP) pada tahun 2012, yang menjadi benchmark '
     'utama komunitas AES selama bertahun-tahun. Shermis dan Burstein (2013) dalam tinjauan '
     'komprehensif sistem AES menyimpulkan bahwa pendekatan machine learning tradisional mampu '
     'mencapai tingkat kesepakatan yang cukup tinggi dengan penilai manusia pada domain '
     'tertentu, namun kualitas fitur yang direkayasa secara manual masih sangat bergantung '
     'pada keahlian domain dan tidak mudah ditransfer ke konteks penilaian yang baru. '
     'Keterbatasan inilah yang mendorong eksplorasi pendekatan yang dapat mempelajari '
     'representasi fitur secara otomatis dari data mentah tanpa intervensi manusia.'),

    # ── Paragraph 3: era deep learning hingga multimoda (terbaru dulu) ───────
    ('body',
     'Kemunculan arsitektur Transformer (Vaswani et al., 2017) dan model bahasa pre-trained '
     'seperti BERT (Devlin et al., 2019) membuka era baru AES dengan kemampuan representasi '
     'kontekstual yang melampaui seluruh pendekatan sebelumnya. Model berbasis encoder '
     'Transformer yang di-fine-tune pada dataset penilaian esai menunjukkan peningkatan '
     'signifikan tanpa rekayasa fitur manual, sekaligus lebih fleksibel dalam generalisasi '
     'lintas domain dan jenis esai. Pendekatan AES modern berkembang menuju penilaian '
     'multi-trait menggunakan multi-task learning (Caruana, 1997), di mana satu model dilatih '
     'secara bersamaan pada seluruh dimensi kualitas esai, memanfaatkan keterkaitan '
     'representasional antar trait untuk meningkatkan akurasi setiap dimensi. Perkembangan '
     'terbaru dan paling mutakhir dalam AES adalah integrasi pemahaman visual secara eksplisit '
     'pada esai yang merujuk gambar grafik. Singh et al. (2024) memperkenalkan benchmark '
     'EssayJudge untuk penilaian esai multimoda IELTS Task 1, sementara Zhao et al. (2025) '
     'menunjukkan bahwa pipeline image-to-text berbasis vision-language model dapat '
     'meningkatkan kinerja penilaian otomatis dalam konteks akademik dibandingkan pendekatan '
     'yang memproses gambar secara langsung, menandai babak baru dalam evolusi AES menuju '
     'sistem yang memahami kedua modalitas teks dan visual secara terintegrasi.'),

    # ── Lead-in to table ──────────────────────────────────────────────────────
    ('body',
     'Evolusi AES dari generasi ke generasi mencerminkan kemajuan dalam representasi fitur, '
     'keluasan generalisasi, dan kompleksitas input yang dapat diproses. Tabel 2.1 merangkum '
     'perbandingan antar generasi AES berdasarkan pendekatan utama yang digunakan beserta '
     'referensi sistem representatifnya.'),

    # ── Table caption (above table, per DTETI convention) ────────────────────
    ('caption', TABLE_CAPTION),

    # ── Table placeholder (replaced by actual table in Phase 4) ──────────────
    ('placeholder', TABLE_PLACEHOLDER),

    # ── Discussion paragraph after table ─────────────────────────────────────
    ('body',
     'Berdasarkan Tabel 2.1, setiap generasi AES menunjukkan kemajuan yang saling '
     'melengkapi: pendekatan berbasis aturan memberikan interpretabilitas namun terbatas '
     'pada domain sempit; pendekatan machine learning meningkatkan fleksibilitas melalui '
     'pembelajaran statistik namun bergantung pada rekayasa fitur manual; pendekatan '
     'deep learning menghilangkan ketergantungan pada rekayasa fitur melalui representasi '
     'kontekstual otomatis; dan pendekatan multimoda terkini mampu mengintegrasikan '
     'informasi visual secara eksplisit. Penelitian ini berfokus pada generasi AES '
     'multimoda dengan mengusulkan dua pendekatan: Pendekatan A berupa fusi multimoda '
     'terlatih menggunakan ResNet18 dan RoBERTa, serta Pendekatan B berupa pipeline '
     'text-to-text berbasis caption VLM yang mengonversi grafik menjadi representasi teks '
     'sebelum dinilai menggunakan Dual RoBERTa.'),
]

# ── Phase 3: Build text and positions ─────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Phase 3b: Italic term detection ──────────────────────────────────────────
ITALIC_TERMS = [
    r'Automated Essay Scoring', r'\bAES\b',
    r'automated essay scoring',
    r'vision-language model',
    r'image-to-text',
    r'text-to-text',
    r'multi-task learning', r'multi-task',
    r'multi-trait',
    r'machine learning',
    r'deep learning',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'pre-trained', r'pre-training', r'pre-train',
    r'benchmark',
    r'pipeline',
    r'\bcaption\b', r'\bcaptions\b',
    r'encoder', r'decoder',
    r'embedding',
    r'feature engineering',
    r'downstream',
    r'backbone',
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'dropout',
    r'overfitting',
    r'tokenizer',
    r'zero-shot',
    r'reasoning',
    r'output head',
    r'shared encoder',
    r'Latent Semantic Analysis', r'\bLSA\b',
    r'Support Vector Machine', r'\bSVM\b',
    r'Naive Bayes',
]

italic_ranges = []
covered = set()

# Only apply italics to non-placeholder, non-caption segments
skip_segs = {TABLE_PLACEHOLDER, TABLE_CAPTION}

for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start_in_full = full_text.find(text)
    if seg_start_in_full == -1:
        continue
    for term_pattern in ITALIC_TERMS:
        pattern = re.compile(term_pattern, re.IGNORECASE)
        for match in pattern.finditer(text):
            ms = seg_start_in_full + match.start()
            me = seg_start_in_full + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Phase 3c: Build API requests ──────────────────────────────────────────────
requests_list = []

# Insert segments in reverse at index 1
for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', 1, TAB_ID))

# Apply paragraph + text styles (forward pass)
for start, end, seg_type, text in seg_positions:
    if seg_type == 'subsection':
        # DTETI: 12pt bold, left-aligned, 12pt above (corrected from 6pt)
        requests_list.append(req_para_style(
            start, end, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'body':
        # DTETI: 12pt normal, justified, 1.25cm (35.43pt) first-line indent, 1.5x spacing
        requests_list.append(req_para_style(
            start, end, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(start, end, TAB_ID, bold=False, size_pt=12))

    elif seg_type == 'caption':
        # Table caption: centered, italic, 12pt, above table (DTETI convention)
        requests_list.append(req_para_style(
            start, end, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type == 'placeholder':
        # Placeholder: plain body style (will be replaced by table)
        requests_list.append(req_para_style(
            start, end, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(start, end, TAB_ID, bold=False, size_pt=12))

# Apply italic ranges
for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests for text + styles...')
batch_update(requests_list)
print('Text inserted and styled.')

# ── Phase 4: Replace placeholder with actual table ────────────────────────────
time.sleep(1)

doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

# Find placeholder paragraph
ph_start = None
for element in body_content:
    if 'paragraph' in element:
        para_text = ''.join(
            pe.get('textRun', {}).get('content', '')
            for pe in element['paragraph'].get('elements', [])
        )
        if TABLE_PLACEHOLDER in para_text:
            ph_start = element.get('startIndex', 0)
            break

if ph_start is None:
    print('ERROR: Placeholder paragraph not found. Aborting table insertion.')
else:
    print(f'Placeholder found at index {ph_start}.')

    # Delete placeholder text only (keep the trailing \n paragraph marker)
    batch_update([{
        'deleteContentRange': {
            'range': {
                'startIndex': ph_start,
                'endIndex': ph_start + len(TABLE_PLACEHOLDER),
                'tabId': TAB_ID,
            }
        }
    }])

    # Insert table before the now-empty placeholder paragraph
    batch_update([{
        'insertTable': {
            'rows': 5,
            'columns': 3,
            'location': {'index': ph_start, 'tabId': TAB_ID},
        }
    }])
    print('Table inserted. Fetching document to fill cells...')

    time.sleep(1)

    # ── Phase 5: Fill table cells ──────────────────────────────────────────────
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    # Find the table (first table element at or after ph_start)
    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    if table_el is None:
        print('ERROR: Table element not found after insertion.')
    else:
        table = table_el['table']
        rows = table.get('tableRows', [])

        # Collect (cell_index, text) in reverse document order to avoid index shifts
        cell_inserts = []
        for row_idx, row in enumerate(rows):
            for col_idx, cell in enumerate(row.get('tableCells', [])):
                cell_paras = cell.get('content', [])
                if cell_paras and 'paragraph' in cell_paras[0]:
                    cell_start = cell_paras[0].get('startIndex', 0)
                    cell_text = TABLE_DATA[row_idx][col_idx]
                    cell_inserts.append((cell_start, cell_text, row_idx))

        # Sort by descending index to preserve positions when inserting
        cell_inserts.sort(key=lambda x: x[0], reverse=True)

        fill_reqs = []
        for cell_start, cell_text, row_idx in cell_inserts:
            fill_reqs.append(req_insert(cell_text, cell_start, TAB_ID))

        batch_update(fill_reqs)
        print(f'Filled {len(fill_reqs)} cells.')

        time.sleep(1)

        # ── Phase 6: Apply table formatting ───────────────────────────────────
        doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
        tab = find_tab(doc.get('tabs', []), TAB_ID)
        body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

        table_el = None
        for element in body_content:
            if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
                table_el = element
                break

        fmt_reqs = []
        if table_el:
            table = table_el['table']
            for row_idx, row in enumerate(table.get('tableRows', [])):
                is_header = (row_idx == 0)
                for col_idx, cell in enumerate(row.get('tableCells', [])):
                    for para in cell.get('content', []):
                        if 'paragraph' in para:
                            p_start = para.get('startIndex')
                            p_end = para.get('endIndex')
                            # Font + bold header
                            fmt_reqs.append(req_text_style(
                                p_start, p_end, TAB_ID,
                                bold=is_header, size_pt=11))
                            # Alignment + spacing
                            fmt_reqs.append({
                                'updateParagraphStyle': {
                                    'range': {
                                        'startIndex': p_start,
                                        'endIndex': p_end,
                                        'tabId': TAB_ID,
                                    },
                                    'paragraphStyle': {
                                        'alignment': 'CENTER' if is_header else 'START',
                                        'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                        'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                        'lineSpacing': 120,
                                    },
                                    'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                                }
                            })
            batch_update(fmt_reqs)
            print(f'Applied table formatting ({len(fmt_reqs)} requests).')

print('\nDone.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
