import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Helpers ────────────────────────────────────────────────────────────────────
def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i + BATCH]}
        ).execute()

# ── Get current end index (append mode — do NOT clear) ────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
append_at = content[-1].get('startIndex', 1) if content else 1
print(f'Appending after index {append_at}.')

# ── Table data ─────────────────────────────────────────────────────────────────

# Tabel 2.2 — modality types
TABLE_222_CAPTION = 'Tabel 2.2. Contoh Modalitas dan Representasi dalam Sistem Multimoda'
TABLE_222_PH = '<<TABEL_2_2>>'
TABLE_222_DATA = [
    ['Modalitas', 'Bentuk Data', 'Contoh Representasi'],
    ['Teks', 'Urutan token karakter atau subkata', 'Embedding RoBERTa, vektor TF-IDF'],
    ['Gambar/Citra', 'Matriks piksel RGB atau grayscale', 'Feature map CNN, patch embedding ViT'],
    ['Audio', 'Sinyal gelombang waktu kontinu', 'Spektrogram mel, embedding Wav2Vec'],
    ['Video', 'Sekuens frame gambar + audio', 'Frame embedding + temporal pooling'],
]

# Tabel 2.3 — fusion strategy comparison
TABLE_223_CAPTION = 'Tabel 2.3. Perbandingan Strategi Multimodal Fusion'
TABLE_223_PH = '<<TABEL_2_3>>'
TABLE_223_DATA = [
    ['Strategi', 'Titik Penggabungan', 'Kelebihan', 'Kekurangan'],
    ['Early Fusion',
     'Level input: fitur mentah dari semua modalitas digabungkan sebelum encoder',
     'Interaksi lintas modalitas sejak awal; representasi bersama yang kaya',
     'Membutuhkan keselarasan dimensi input; sensitif terhadap modalitas yang hilang'],
    ['Intermediate Fusion',
     'Level representasi tersembunyi: fitur dari encoder masing-masing modalitas digabungkan',
     'Fleksibel; tiap modalitas diproses secara mandiri sesuai sifatnya',
     'Desain mekanisme penggabungan (cross-attention, gating) menambah kompleksitas'],
    ['Late Fusion',
     'Level output: prediksi atau representasi akhir dari tiap modalitas digabungkan',
     'Modular; encoder per modalitas dapat diganti tanpa mengubah modalitas lain',
     'Interaksi lintas modalitas terbatas; informasi yang bisa dikombinasikan lebih sedikit'],
]

# Tabel 2.4 — multimodal AES comparison
TABLE_224_CAPTION = 'Tabel 2.4. Karakteristik Penilaian Esai Unimodal vs Multimoda'
TABLE_224_PH = '<<TABEL_2_4>>'
TABLE_224_DATA = [
    ['Aspek', 'Unimodal (Teks Saja)', 'Multimoda (Teks + Grafik)'],
    ['Input sistem', 'Teks esai mahasiswa', 'Teks esai + gambar grafik (chart/tabel/peta)'],
    ['Informasi faktual', 'Hanya dari teks; tidak dapat diverifikasi terhadap stimulus',
     'Dapat dibandingkan dengan data asli pada grafik stimulus'],
    ['Tantangan utama', 'Pemahaman semantik dan kohesi teks',
     'Pemahaman visual grafik + pencocokan klaim teks dengan data grafik'],
    ['Contoh benchmark', 'ASAP (Shermis & Burstein, 2013)',
     'EssayJudge IELTS Task 1 (Singh et al., 2025)'],
]

# ── Segments ───────────────────────────────────────────────────────────────────
segments = [

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.2 Pemrosesan Multimoda
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.2 Pemrosesan Multimoda'),

    ('body',
     'Pemrosesan multimoda adalah bidang kecerdasan buatan yang mempelajari cara sistem '
     'komputasi mengintegrasikan dan memproses informasi yang berasal dari dua atau lebih '
     'modalitas berbeda secara bersamaan. Modalitas dalam konteks ini merujuk pada jenis '
     'atau kanal data yang berbeda secara fundamental dalam representasi dan karakteristik '
     'sinyalnya, seperti teks, gambar, audio, dan video. Ngiam et al. (2011) merupakan '
     'salah satu penelitian awal yang secara sistematis menunjukkan bahwa model deep learning '
     'yang dilatih secara bersama pada beberapa modalitas dapat mempelajari representasi '
     'yang lebih kaya dibandingkan model unimodal, melalui eksperimen pada data audio-video '
     'ucapan manusia. Gagasan inti pemrosesan multimoda adalah bahwa modalitas yang berbeda '
     'sering kali membawa informasi yang saling melengkapi, bukan sekadar redundan, sehingga '
     'penggabungan informasi lintas modalitas berpotensi meningkatkan kualitas representasi '
     'dan kinerja sistem.'),

    ('body',
     'Baltrusaitis et al. (2019) menyusun taksonomi komprehensif pertama untuk tantangan '
     'dalam pemrosesan multimoda, mengidentifikasi lima dimensi utama: representasi '
     'multimoda, penerjemahan antar-modalitas, penyelarasan modalitas, fusi multimoda, '
     'dan co-learning antar modalitas. Representasi multimoda berkaitan dengan cara '
     'mengkodekan data dari modalitas yang berbeda ke dalam ruang vektor yang dapat '
     'dibandingkan atau digabungkan. Penerjemahan antar-modalitas mencakup konversi '
     'informasi dari satu modalitas ke modalitas lain, misalnya mengubah gambar grafik '
     'menjadi deskripsi teks. Penyelarasan modalitas memastikan bahwa elemen-elemen dari '
     'modalitas berbeda yang merujuk pada konsep yang sama dapat dipasangkan secara tepat '
     'sebelum penggabungan dilakukan. Kelima dimensi ini membentuk kerangka kerja yang '
     'digunakan secara luas dalam pengembangan sistem multimoda modern, termasuk pada '
     'vision-language model yang menjadi bagian dari penelitian ini.'),

    ('body',
     'Dalam konteks penelitian ini, dua modalitas yang relevan adalah teks esai mahasiswa '
     'dan gambar grafik IELTS Task 1. Esai mahasiswa merupakan teks berbahasa Inggris '
     'yang mendeskripsikan tren atau informasi dari sebuah grafik, sedangkan grafik '
     'merupakan citra berformat JPEG yang memuat data kuantitatif dalam bentuk bar chart, '
     'pie chart, line chart, tabel, peta, atau diagram alir. Kedua modalitas ini bersifat '
     'saling melengkapi: gambar grafik menyediakan ground truth faktual, sementara teks '
     'esai mencerminkan pemahaman mahasiswa terhadap grafik tersebut. Sistem AES multimoda '
     'yang efektif harus mampu mengintegrasikan informasi dari kedua sumber ini untuk menilai '
     'sejauh mana esai mencerminkan data pada grafik secara akurat, kohesif, dan gramatikal. '
     'Tabel 2.2 merangkum contoh modalitas beserta bentuk data dan representasi komputasionalnya.'),

    ('caption', TABLE_222_CAPTION),
    ('placeholder', TABLE_222_PH),

    ('body',
     'Berdasarkan Tabel 2.2, setiap modalitas memiliki karakteristik representasi yang '
     'berbeda dan membutuhkan encoder yang disesuaikan. Teks direpresentasikan sebagai '
     'urutan token dan diproses oleh encoder berbasis Transformer, sedangkan gambar '
     'direpresentasikan sebagai matriks piksel dan diproses oleh encoder berbasis CNN '
     'atau Vision Transformer. Perbedaan mendasar ini memotivasi penggunaan encoder '
     'terpisah untuk setiap modalitas sebelum penggabungan representasi, yang menjadi '
     'landasan arsitektur pada Pendekatan A maupun Pendekatan B dalam penelitian ini.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.3 Strategi Multimodal Fusion
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.3 Strategi Multimodal Fusion'),

    ('body',
     'Multimodal fusion adalah proses menggabungkan representasi atau informasi dari '
     'beberapa modalitas menjadi satu representasi terintegrasi yang dapat digunakan '
     'untuk tugas prediksi atau klasifikasi. Baltrusaitis et al. (2019) mengklasifikasikan '
     'strategi fusion berdasarkan titik dalam pipeline pemrosesan di mana penggabungan '
     'dilakukan: early fusion yang terjadi di level input, intermediate fusion yang terjadi '
     'di level representasi tersembunyi, dan late fusion yang terjadi di level output atau '
     'prediksi akhir. Pemilihan strategi fusion yang tepat bergantung pada karakteristik '
     'modalitas yang digabungkan, ketersediaan data pelatihan, dan sifat tugas yang ingin '
     'diselesaikan, sehingga tidak ada satu strategi yang secara universal lebih baik dari '
     'yang lain.'),

    ('body',
     'Early fusion menggabungkan fitur mentah dari semua modalitas sebelum diproses oleh '
     'encoder bersama. Keuntungan pendekatan ini adalah memungkinkan model mempelajari '
     'interaksi lintas modalitas sejak tahap awal representasi, sehingga berpotensi '
     'menangkap korelasi yang lebih dalam. Namun, early fusion mensyaratkan keselarasan '
     'dimensi dan skala antara fitur dari modalitas berbeda, yang sulit dipenuhi ketika '
     'teks dan gambar memiliki ruang fitur yang sangat berbeda. Intermediate fusion, di sisi '
     'lain, memproses setiap modalitas secara mandiri menggunakan encoder yang sesuai, '
     'kemudian menggabungkan representasi tersembunyi yang dihasilkan. Mekanisme '
     'penggabungan yang umum pada intermediate fusion mencakup concatenation vektor, '
     'cross-attention antar modalitas, bottleneck fusion, dan gated fusion. Gold et al. '
     '(2025) meneliti strategi fusion untuk penilaian esai multimoda berbasis BERT dan '
     'ResNet dan menunjukkan bahwa intermediate fusion dengan mekanisme cross-attention '
     'dapat melampaui early fusion pada beberapa konfigurasi.'),

    ('body',
     'Late fusion mempertahankan pipeline pemrosesan yang sepenuhnya terpisah untuk '
     'setiap modalitas hingga tahap akhir, di mana prediksi atau representasi akhir '
     'dari masing-masing modalitas digabungkan melalui operasi seperti concatenation, '
     'rata-rata tertimbang, atau stacking. Keunggulan utama late fusion adalah '
     'modularitas: encoder untuk setiap modalitas dapat dilatih, diganti, atau '
     'diperbarui secara independen. Tabel 2.3 merangkum perbandingan ketiga strategi '
     'fusion berdasarkan titik penggabungan, kelebihan, dan kekurangannya. Dalam '
     'penelitian ini, Pendekatan A menggunakan late fusion dengan encoder teks RoBERTa '
     'dan encoder gambar ResNet18, di mana representasi dari kedua encoder '
     'digabungkan melalui concatenation sebelum diserahkan ke scoring head.'),

    ('caption', TABLE_223_CAPTION),
    ('placeholder', TABLE_223_PH),

    ('body',
     'Berdasarkan Tabel 2.3, pemilihan strategi fusion dalam penelitian ini dilandasi '
     'oleh pertimbangan berikut. Pertama, teks esai dan gambar grafik memiliki sifat '
     'representasi yang sangat berbeda sehingga early fusion tidak cocok. Kedua, '
     'arsitektur encoder yang berbeda (RoBERTa untuk teks, ResNet18 untuk gambar) '
     'membutuhkan pemrosesan mandiri yang paling alami diakomodasi oleh late fusion '
     'atau intermediate fusion. Ketiga, ukuran dataset yang relatif kecil (738 sampel '
     'pelatihan) membatasi kapasitas model untuk mempelajari mekanisme cross-attention '
     'yang kompleks secara efektif. Pertimbangan-pertimbangan ini memotivasi pengujian '
     'ketiga strategi fusion pada Pendekatan A untuk menemukan konfigurasi terbaik '
     'secara empiris.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.4 Penilaian Esai Multimoda
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.4 Penilaian Esai Multimoda'),

    ('body',
     'Penilaian esai multimoda adalah perluasan dari AES konvensional ke skenario di mana '
     'esai yang dinilai merujuk pada stimulus visual, sehingga sistem penilaian harus mampu '
     'memahami dan mengintegrasikan informasi dari gambar dan teks secara bersamaan. Konteks '
     'yang paling relevan untuk penelitian ini adalah IELTS Academic Writing Task 1, di mana '
     'peserta ujian diminta menulis esai yang mendeskripsikan dan menganalisis data dari sebuah '
     'grafik, tabel, peta, atau diagram. Kualitas esai IELTS Task 1 dinilai berdasarkan '
     'sepuluh dimensi yang mencakup kejelasan argumen, akurasi gramatikal, keragaman leksikal, '
     'serta koherensi dan organisasi teks. Singh et al. (2025) memperkenalkan benchmark '
     'EssayJudge sebagai dataset pertama yang dirancang khusus untuk evaluasi sistem AES '
     'multimoda pada domain ini, memuat 1.054 esai dengan skor dari sepuluh dimensi penilaian '
     'yang dianotasi oleh penilai terlatih.'),

    ('body',
     'Tantangan utama dalam penilaian esai multimoda terletak pada kebutuhan untuk '
     'menghubungkan klaim faktual dalam teks esai dengan data yang disajikan pada '
     'gambar grafik. Sebuah sistem AES unimodal yang hanya memproses teks tidak dapat '
     'memverifikasi apakah angka atau tren yang disebutkan dalam esai sesuai dengan '
     'data aktual pada grafik, sehingga dimensi penilaian seperti keakuratan argumen '
     'dan ketepatan deskripsi tidak dapat dinilai secara optimal. Bursztyn et al. (2024) '
     'menunjukkan bahwa representasi berbasis teks dari grafik secara signifikan '
     'mengungguli representasi berbasis gambar langsung untuk tugas question answering '
     'pada grafik, dengan akurasi 99% berbanding 63%, mengindikasikan bahwa konversi '
     'grafik menjadi teks terstruktur merupakan pendekatan yang lebih efektif untuk '
     'tugas yang membutuhkan reasoning atas data numerik.'),

    ('body',
     'Zhao et al. (2025) memperkuat arah ini melalui EDU-CIRCUIT-HW, sebuah benchmark '
     'untuk evaluasi VLM pada konten akademik tertulis tangan, yang menunjukkan bahwa '
     'pipeline image-to-text berbasis VLM dapat meningkatkan kinerja penilaian otomatis '
     'dalam konteks akademik. Temuan ini mendukung hipotesis bahwa mengonversi gambar '
     'grafik menjadi representasi teks terlebih dahulu, kemudian menyerahkan teks tersebut '
     'kepada model bahasa, lebih efektif daripada memproses gambar secara langsung dalam '
     'model multimoda end-to-end. Tabel 2.4 merangkum perbedaan antara sistem penilaian '
     'esai unimodal dan multimoda dari beberapa dimensi kunci, menggambarkan mengapa '
     'pendekatan multimoda diperlukan untuk penilaian esai IELTS Task 1 yang komprehensif.'),

    ('caption', TABLE_224_CAPTION),
    ('placeholder', TABLE_224_PH),

    ('body',
     'Berdasarkan Tabel 2.4, penilaian esai multimoda membawa tantangan tambahan yang '
     'tidak ditemui dalam sistem AES konvensional, terutama kebutuhan untuk memahami '
     'konten visual grafik secara akurat. Penelitian ini mengusulkan dua pendekatan '
     'untuk mengatasi tantangan tersebut: Pendekatan A yang mengintegrasikan encoder '
     'visual ResNet18 langsung dalam pipeline pelatihan, dan Pendekatan B yang '
     'mengonversi gambar grafik menjadi teks deskriptif menggunakan VLM sebelum '
     'penilaian dilakukan oleh Dual RoBERTa. Perbandingan empiris kedua pendekatan '
     'ini merupakan salah satu kontribusi utama penelitian ini terhadap pengembangan '
     'sistem AES multimoda.'),
]

# ── Build text block and positions ────────────────────────────────────────────
full_text = ''
seg_positions = []  # (abs_start, abs_end, type, text) relative to full_text base

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'Automated Essay Scoring', r'\bAES\b',
    r'automated essay scoring',
    r'multimodal fusion', r'Multimodal Fusion',
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'cross-attention',
    r'bottleneck fusion', r'gated fusion',
    r'vision-language model', r'\bVLM\b', r'\bVLMs\b',
    r'image-to-text',
    r'text-to-text',
    r'deep learning',
    r'machine learning',
    r'pipeline',
    r'fine-tuning', r'fine-tuned', r'fine-tune',
    r'pre-trained', r'pre-training',
    r'benchmark',
    r'encoder', r'decoder',
    r'embedding',
    r'feature map', r'feature maps',
    r'backbone',
    r'reasoning',
    r'zero-shot',
    r'end-to-end',
    r'co-learning',
    r'scoring head',
    r'concatenation',
    r'stacking',
    r'ground truth',
    r'Question Answering', r'question answering',
    r'Vision Transformer', r'\bViT\b',
    r'co-learning',
]

italic_ranges = []
covered = set()

for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start_in_full = full_text.find(text)
    if seg_start_in_full == -1:
        continue
    for term_pattern in ITALIC_TERMS:
        pattern = re.compile(term_pattern, re.IGNORECASE)
        for match in pattern.finditer(text):
            ms = seg_start_in_full + match.start()
            me = seg_start_in_full + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Phase 1: Insert text (append mode) ────────────────────────────────────────
# Offset all positions by append_at (existing content length)
offset = append_at - 1  # doc index where new content starts

requests_list = []

# Insert segments in reverse at append_at
for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', append_at, TAB_ID))

# Apply paragraph + text styles (forward pass, offset-adjusted)
for start, end, seg_type, text in seg_positions:
    s = start + offset
    e = end + offset

    if seg_type == 'subsection':
        requests_list.append(req_para_style(
            s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'body':
        requests_list.append(req_para_style(
            s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

    elif seg_type == 'caption':
        requests_list.append(req_para_style(
            s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(
            s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

# Apply italic ranges (offset-adjusted)
for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted and styled.')

# ── Phase 2: Insert tables ─────────────────────────────────────────────────────
time.sleep(1)

TABLES = [
    (TABLE_222_PH, TABLE_222_DATA, 5, 3),
    (TABLE_223_PH, TABLE_223_DATA, 4, 4),
    (TABLE_224_PH, TABLE_224_DATA, 5, 3),
]

for ph_text, table_data, nrows, ncols in TABLES:
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    # Find placeholder paragraph
    ph_start = None
    for element in body_content:
        if 'paragraph' in element:
            para_text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in element['paragraph'].get('elements', [])
            )
            if ph_text in para_text:
                ph_start = element.get('startIndex', 0)
                break

    if ph_start is None:
        print(f'ERROR: Placeholder {ph_text} not found. Skipping.')
        continue

    print(f'Placeholder {ph_text} found at index {ph_start}.')

    # Delete placeholder text
    batch_update([{
        'deleteContentRange': {
            'range': {
                'startIndex': ph_start,
                'endIndex': ph_start + len(ph_text),
                'tabId': TAB_ID,
            }
        }
    }])

    # Insert table
    batch_update([{
        'insertTable': {
            'rows': nrows,
            'columns': ncols,
            'location': {'index': ph_start, 'tabId': TAB_ID},
        }
    }])
    print(f'Table {ph_text} inserted ({nrows}x{ncols}). Filling cells...')
    time.sleep(1)

    # Fetch fresh doc to fill cells
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    if table_el is None:
        print(f'ERROR: Table element not found for {ph_text}.')
        continue

    table = table_el['table']
    rows = table.get('tableRows', [])

    cell_inserts = []
    for row_idx, row in enumerate(rows):
        for col_idx, cell in enumerate(row.get('tableCells', [])):
            cell_paras = cell.get('content', [])
            if cell_paras and 'paragraph' in cell_paras[0]:
                cell_start = cell_paras[0].get('startIndex', 0)
                cell_text = table_data[row_idx][col_idx]
                cell_inserts.append((cell_start, cell_text, row_idx))

    cell_inserts.sort(key=lambda x: x[0], reverse=True)

    fill_reqs = []
    for cell_start, cell_text, row_idx in cell_inserts:
        fill_reqs.append(req_insert(cell_text, cell_start, TAB_ID))

    batch_update(fill_reqs)
    print(f'Filled {len(fill_reqs)} cells.')
    time.sleep(1)

    # Format table cells
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    fmt_reqs = []
    if table_el:
        table = table_el['table']
        for row_idx, row in enumerate(table.get('tableRows', [])):
            is_header = (row_idx == 0)
            for col_idx, cell in enumerate(row.get('tableCells', [])):
                for para in cell.get('content', []):
                    if 'paragraph' in para:
                        p_start = para.get('startIndex')
                        p_end = para.get('endIndex')
                        fmt_reqs.append(req_text_style(
                            p_start, p_end, TAB_ID,
                            bold=is_header, size_pt=11))
                        fmt_reqs.append({
                            'updateParagraphStyle': {
                                'range': {
                                    'startIndex': p_start,
                                    'endIndex': p_end,
                                    'tabId': TAB_ID,
                                },
                                'paragraphStyle': {
                                    'alignment': 'CENTER' if is_header else 'START',
                                    'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                    'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                    'lineSpacing': 120,
                                },
                                'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                            }
                        })
        batch_update(fmt_reqs)
        print(f'Applied formatting ({len(fmt_reqs)} requests) for {ph_text}.')

print('\nDone.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
