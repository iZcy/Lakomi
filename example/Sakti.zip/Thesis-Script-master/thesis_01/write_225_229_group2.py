import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.v7l3rd9jsdie'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps, 'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i+BATCH]}
        ).execute()

# Get current end index (append mode)
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
append_at = content[-1].get('startIndex', 1) if content else 1
print(f'Appending after index {append_at}.')

# ── Table data ─────────────────────────────────────────────────────────────────

TABLE_225_CAPTION = 'Tabel 2.5. Perbandingan Fungsi Aktivasi yang Digunakan dalam Penelitian Ini'
TABLE_225_PH = '<<TABEL_2_5>>'
TABLE_225_DATA = [
    ['Fungsi Aktivasi', 'Formula', 'Range Output', 'Digunakan di'],
    ['ReLU', 'f(x) = max(0, x)', '[0, inf)', 'Layer tersembunyi CNN, scoring head'],
    ['GELU', 'f(x) = x * P(X <= x), X ~ N(0,1)', '(-0.17, inf)', 'Layer tersembunyi Transformer (RoBERTa, BERT)'],
    ['Sigmoid', 'f(x) = 1 / (1 + e^(-x))', '(0, 1)', 'Output layer scoring head; dikali 5.0 untuk rentang [0,5]'],
]

TABLE_227_CAPTION = 'Tabel 2.6. Teknik Regularisasi yang Digunakan dalam Penelitian Ini'
TABLE_227_PH = '<<TABEL_2_6>>'
TABLE_227_DATA = [
    ['Teknik', 'Mekanisme', 'Nilai dalam Penelitian Ini'],
    ['Dropout', 'Secara acak menonaktifkan sebagian unit jaringan selama pelatihan dengan probabilitas p', 'p = 0.3 pada scoring head'],
    ['Weight Decay (L2)', 'Menambahkan penalti L2 pada bobot ke fungsi loss: L_total = L_task + lambda * ||w||^2', 'Diimplementasikan via AdamW (default 0.01)'],
    ['Early Stopping', 'Menghentikan pelatihan ketika val QWK tidak membaik selama k epoch berturut-turut', 'patience = 10 epoch'],
]

TABLE_228_CAPTION = 'Tabel 2.7. Perbandingan Adam dan AdamW'
TABLE_228_PH = '<<TABEL_2_7>>'
TABLE_228_DATA = [
    ['Aspek', 'Adam (Kingma & Ba, 2015)', 'AdamW (Loshchilov & Hutter, 2019)'],
    ['Weight decay', 'Ditambahkan ke gradient sebelum update adaptif; terikat dengan learning rate',
     'Dipisahkan dari gradient update; diterapkan langsung ke bobot setelah update'],
    ['Efek regularisasi', 'L2 regularization dan weight decay tidak ekuivalen; perilaku tidak konsisten',
     'Weight decay murni; ekuivalen dengan L2 proximal; generalisasi lebih baik'],
    ['Rumus update', 'theta_t = theta_{t-1} - lr * m_t / (sqrt(v_t) + eps) - lr * lambda * theta_{t-1}',
     'theta_t = theta_{t-1} - lr * m_t / (sqrt(v_t) + eps); theta_t = theta_t - lr * lambda * theta_{t-1}'],
    ['Penggunaan default', 'Banyak digunakan sebelum 2019; masih relevan untuk beberapa arsitektur',
     'Default optimizer di HuggingFace Transformers; digunakan di seluruh eksperimen penelitian ini'],
]

TABLE_229_CAPTION = 'Tabel 2.8. Strategi Transfer Learning dan Contoh Penerapannya'
TABLE_229_PH = '<<TABEL_2_8>>'
TABLE_229_DATA = [
    ['Strategi', 'Deskripsi', 'Contoh Penerapan dalam Penelitian Ini'],
    ['Feature extraction', 'Bobot pretrained dibekukan; hanya head baru yang dilatih',
     'DePlot dan Qwen2-VL-7B-Instruct: bobot VLM tidak dilatih, hanya digunakan untuk inferensi'],
    ['Full fine-tuning', 'Semua bobot pretrained dilatih ulang bersama task-specific head',
     'RoBERTa: semua 12 lapisan dilatih pada dataset EssayJudge (Exp093)'],
    ['Partial fine-tuning', 'Sebagian lapisan pretrained dibekukan; lapisan atas dilatih',
     'Exp121: 3 lapisan pertama + embedding dibekukan; 9 lapisan atas dilatih'],
    ['PEFT (LoRA/QLoRA)', 'Low-rank adapter diinjeksikan ke lapisan Transformer; bobot asli dibekukan',
     'Qwen2-VL-7B-Instruct: dimuat dengan QLoRA (NF4) untuk inferensi efisien di P100'],
]

# ── Segments ───────────────────────────────────────────────────────────────────
segments = [

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.5 Jaringan Saraf Tiruan dan Fungsi Aktivasi
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.5 Jaringan Saraf Tiruan dan Fungsi Aktivasi'),

    ('body',
     'Jaringan saraf tiruan (JST) adalah kerangka komputasi terinspirasi dari struktur '
     'biologis neuron di otak manusia, di mana unit-unit komputasi sederhana yang disebut '
     'neuron buatan disusun dalam lapisan-lapisan yang saling terhubung untuk memproses '
     'informasi secara hierarkis. Setiap koneksi antar neuron memiliki bobot yang dipelajari '
     'dari data, dan setiap neuron menghitung kombinasi linier dari input yang diterimanya '
     'kemudian menerapkan fungsi aktivasi nonlinier untuk menghasilkan output. LeCun et al. '
     '(2015) dalam ulasan komprehensif tentang deep learning menjelaskan bahwa kemampuan '
     'jaringan berlapis-dalam (deep network) untuk mempelajari representasi hierarkis '
     'adalah kunci keunggulannya: lapisan awal mempelajari fitur primitif seperti tepi '
     'dan tekstur, lapisan tengah mempelajari pola yang lebih kompleks, dan lapisan akhir '
     'mengintegrasikan informasi untuk membentuk representasi tingkat tinggi yang berguna '
     'bagi tugas prediksi.'),

    ('body',
     'Fungsi aktivasi memainkan peran kritis dalam kemampuan JST untuk memodelkan '
     'hubungan nonlinier. Tanpa fungsi aktivasi nonlinier, susunan lapisan linier yang '
     'dalam hanya setara dengan satu lapisan linier tunggal, sehingga tidak ada '
     'keuntungan dari kedalaman jaringan. Rectified Linear Unit (ReLU), yang '
     'mendefinisikan f(x) = max(0, x), menjadi fungsi aktivasi paling dominan pada '
     'jaringan modern karena mengatasi masalah vanishing gradient yang dialami oleh '
     'fungsi sigmoid dan tanh pada jaringan yang dalam, sekaligus efisien secara '
     'komputasi. Gaussian Error Linear Unit (GELU), yang diperkenalkan oleh Hendrycks '
     'dan Gimpel (2016), mendekati perilaku dropout secara deterministik dengan '
     'membobot input berdasarkan probabilitas kumulatif distribusi normal, dan '
     'digunakan secara luas di dalam lapisan feed-forward arsitektur Transformer '
     'termasuk BERT dan RoBERTa yang menjadi komponen utama penelitian ini.'),

    ('body',
     'Fungsi Sigmoid, yang mendefinisikan f(x) = 1 / (1 + e^(-x)), menghasilkan '
     'output pada rentang (0, 1) sehingga cocok untuk lapisan output pada tugas '
     'regresi yang membutuhkan nilai yang dibatasi. Dalam penelitian ini, scoring '
     'head menggunakan Sigmoid pada lapisan output dan mengalikan hasilnya dengan '
     '5.0 untuk menghasilkan prediksi skor pada rentang [0, 5] yang sesuai dengan '
     'skala penilaian IELTS Task 1. Tabel 2.5 merangkum tiga fungsi aktivasi yang '
     'digunakan dalam penelitian ini beserta formula, rentang output, dan lokasi '
     'penggunaannya dalam arsitektur model.'),

    ('caption', TABLE_225_CAPTION),
    ('placeholder', TABLE_225_PH),

    ('body',
     'Berdasarkan Tabel 2.5, setiap fungsi aktivasi dipilih sesuai dengan peran '
     'arsitekturalnya: GELU digunakan di dalam encoder Transformer karena cocok '
     'untuk lapisan feed-forward yang memproses representasi semantik, ReLU '
     'digunakan di lapisan tersembunyi scoring head karena efisien dan efektif '
     'untuk regresi bertingkat, dan Sigmoid digunakan di lapisan output untuk '
     'memastikan prediksi skor berada dalam rentang yang valid.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.6 Backpropagation dan Optimisasi Gradient
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.6 Backpropagation dan Optimisasi Gradient'),

    ('body',
     'Backpropagation adalah algoritma untuk menghitung gradien fungsi loss terhadap '
     'setiap parameter jaringan saraf tiruan secara efisien menggunakan aturan rantai '
     'diferensial (chain rule). Rumelhart et al. (1986) mempopulerkan algoritma ini '
     'dalam konteks jaringan berlapis, menunjukkan bahwa gradien dapat dipropagasi '
     'dari lapisan output ke lapisan input secara berulang, memungkinkan pelatihan '
     'jaringan dengan banyak lapisan tersembunyi. Secara matematis, untuk setiap '
     'parameter w dalam jaringan, gradien dL/dw dihitung sebagai hasil kali partial '
     'derivative dari setiap transformasi dalam jalur komputasi antara w dan output '
     'loss L. Dalam implementasi modern menggunakan PyTorch, seluruh proses ini '
     'ditangani secara otomatis oleh mekanisme autograd, sehingga peneliti hanya '
     'perlu mendefinisikan forward pass dan memanggil loss.backward() untuk '
     'memperoleh semua gradien.'),

    ('body',
     'Gradient descent adalah prosedur optimasi yang memperbarui parameter jaringan '
     'berlawanan arah dengan gradien loss untuk meminimalkan loss secara iteratif. '
     'Pada stochastic gradient descent (SGD), gradien dihitung pada mini-batch kecil '
     'sampel (bukan seluruh dataset), menghasilkan pembaruan yang lebih cepat dengan '
     'noise yang bertindak sebagai regularizer implisit. Goodfellow et al. (2016) '
     'dalam buku teks Deep Learning menjelaskan bahwa landscape loss jaringan dalam '
     'sangat non-convex dengan banyak saddle point, sehingga optimizer berbasis '
     'momentum dan adaptive learning rate seperti Adam jauh lebih efektif daripada '
     'SGD standar untuk melatih model bahasa dan model multimoda. Pemilihan learning '
     'rate awal, jadwal penurunannya, dan ukuran batch secara langsung mempengaruhi '
     'kecepatan konvergensi dan kualitas solusi yang ditemukan.'),

    ('body',
     'Masalah vanishing gradient terjadi ketika gradien mengecil secara eksponensial '
     'saat dipropagasi ke lapisan-lapisan awal jaringan yang dalam, sehingga '
     'parameter di lapisan awal hampir tidak berubah selama pelatihan. Masalah '
     'sebaliknya, exploding gradient, dapat terjadi pada jaringan rekuren dan '
     'diatasi dengan gradient clipping. Arsitektur Transformer mengatasi vanishing '
     'gradient melalui koneksi residual dan layer normalization yang memastikan '
     'gradien mengalir secara stabil ke seluruh lapisan. Dalam penelitian ini, '
     'learning rate sebesar 1e-4 digunakan untuk melatih scoring head, sementara '
     'RoBERTa yang telah di-pre-train memiliki representasi awal yang sudah baik '
     'sehingga tidak memerlukan learning rate tinggi untuk fine-tuning yang '
     'efektif pada dataset berukuran 738 sampel.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.7 Regularisasi
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.7 Regularisasi'),

    ('body',
     'Regularisasi adalah kumpulan teknik yang dirancang untuk mengurangi '
     'overfitting pada model pembelajaran mesin dengan membatasi kompleksitas '
     'model atau menambahkan noise pada proses pelatihan. Overfitting terjadi '
     'ketika model mempelajari pola yang sangat spesifik pada data pelatihan '
     'sehingga tidak mampu menggeneralisasi ke data yang belum pernah dilihat. '
     'Pada penelitian ini, risiko overfitting cukup tinggi mengingat dataset '
     'EssayJudge hanya memiliki 738 sampel pelatihan namun model RoBERTa memiliki '
     '110 juta parameter, sehingga penerapan regularisasi yang tepat menjadi '
     'komponen kritis dalam pipeline pelatihan.'),

    ('body',
     'Dropout, yang diperkenalkan oleh Srivastava et al. (2014), adalah teknik '
     'regularisasi yang secara acak menonaktifkan sebagian unit jaringan dengan '
     'probabilitas p selama setiap iterasi pelatihan. Secara intuitif, dropout '
     'memaksa jaringan untuk tidak bergantung pada unit-unit tertentu dan '
     'sebaliknya mempelajari representasi yang terdistribusi dan redundan, '
     'sehingga lebih robust terhadap variasi dalam data uji. Srivastava et al. '
     '(2014) menunjukkan bahwa dropout dapat diinterpretasikan sebagai pelatihan '
     'ensemble dari eksponensial banyak jaringan yang berbagi bobot, di mana '
     'pada saat inferensi semua "sub-jaringan" digabungkan secara implisit '
     'melalui penskalaan bobot dengan faktor (1-p). Dalam penelitian ini, '
     'dropout dengan p = 0.3 diterapkan pada lapisan tersembunyi scoring head '
     'untuk mencegah koadaptasi antar unit.'),

    ('body',
     'Weight decay atau regularisasi L2 menambahkan penalti proporsional dengan '
     'kuadrat norma bobot ke fungsi loss, mendorong bobot menuju nilai yang kecil '
     'dan mencegah bobot tunggal mendominasi prediksi. Early stopping menghentikan '
     'pelatihan ketika metrik validasi tidak membaik selama sejumlah epoch tertentu, '
     'mencegah model terlalu lama belajar dari data pelatihan. Tabel 2.6 merangkum '
     'tiga teknik regularisasi yang digunakan dalam penelitian ini beserta mekanisme '
     'kerja dan nilai hyperparameter yang digunakan.'),

    ('caption', TABLE_227_CAPTION),
    ('placeholder', TABLE_227_PH),

    ('body',
     'Kombinasi dari ketiga teknik pada Tabel 2.6 diterapkan secara bersamaan '
     'dalam setiap eksperimen. Dropout melindungi scoring head dari overfitting '
     'terhadap pola permukaan data, weight decay via AdamW mencegah nilai bobot '
     'yang terlalu besar pada seluruh parameter model, dan early stopping '
     'memastikan pelatihan berhenti pada titik generalisasi terbaik berdasarkan '
     'performa pada data validasi.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.8 AdamW dan Learning Rate Scheduling
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.8 AdamW dan Learning Rate Scheduling'),

    ('body',
     'Adam (Adaptive Moment Estimation), yang diperkenalkan oleh Kingma dan Ba '
     '(2015), adalah optimizer berbasis gradient yang menggabungkan momentum '
     'orde pertama (rata-rata bergerak gradient) dan orde kedua (rata-rata '
     'bergerak kuadrat gradient) untuk mengadaptasi learning rate secara '
     'individual untuk setiap parameter. Dengan mempertahankan estimasi momen '
     'pertama m_t dan momen kedua v_t, Adam melakukan pembaruan parameter '
     'dengan besaran yang ternormalisasi oleh akar kuadrat v_t sehingga '
     'parameter yang jarang diperbarui (sparse gradient) mendapatkan pembaruan '
     'yang lebih besar, dan parameter yang sering diperbarui mendapatkan '
     'pembaruan yang lebih kecil secara proporsional. Properti ini membuat '
     'Adam sangat efektif untuk melatih model bahasa besar seperti RoBERTa '
     'yang memiliki distribusi gradient yang sangat tidak seragam.'),

    ('body',
     'Loshchilov dan Hutter (2019) mengidentifikasi kelemahan fundamental Adam '
     'dalam penerapan weight decay: pada optimizer adaptif seperti Adam, '
     'menambahkan L2 regularization ke gradient tidak ekuivalen dengan weight '
     'decay murni karena interaksi dengan faktor normalisasi adaptif. AdamW '
     'memperbaiki hal ini dengan memisahkan weight decay dari update gradient '
     'adaptif, menerapkannya langsung ke parameter setelah update Adam. '
     'Perbaikan ini terbukti meningkatkan generalisasi secara konsisten dan '
     'menjadikan AdamW sebagai optimizer default di library HuggingFace '
     'Transformers yang digunakan dalam seluruh eksperimen penelitian ini. '
     'Tabel 2.7 membandingkan Adam dan AdamW dari beberapa dimensi kunci.'),

    ('caption', TABLE_228_CAPTION),
    ('placeholder', TABLE_228_PH),

    ('body',
     'Learning rate scheduling melengkapi optimizer dengan menyesuaikan '
     'learning rate secara dinamis selama pelatihan. Strategi ReduceLROnPlateau '
     'yang digunakan dalam penelitian ini memantau metrik validasi dan '
     'mengurangi learning rate dengan faktor tertentu ketika tidak ada '
     'peningkatan selama sejumlah epoch (patience). Pendekatan ini adaptif '
     'terhadap karakteristik konvergensi tiap eksperimen: jika model sudah '
     'mendekati minimum lokal yang baik, learning rate dikecilkan untuk '
     'penyempurnaan yang lebih halus tanpa melompati solusi optimal. '
     'Dalam penelitian ini, learning rate awal 1e-4 dipilih berdasarkan '
     'praktik umum fine-tuning model Transformer pada dataset kecil.'),

    # ════════════════════════════════════════════════════════════════════════════
    # 2.2.9 Transfer Learning dan Fine-tuning
    # ════════════════════════════════════════════════════════════════════════════
    ('subsection', '2.2.9 Transfer Learning dan Fine-tuning'),

    ('body',
     'Transfer learning adalah paradigma pembelajaran mesin di mana pengetahuan '
     'yang diperoleh dari satu tugas atau domain (sumber) digunakan kembali untuk '
     'meningkatkan kinerja pada tugas atau domain lain (target). Pan dan Yang (2010) '
     'dalam survei komprehensif pertama tentang transfer learning mendefinisikan '
     'tiga dimensi transfer: domain, tugas, dan pengetahuan yang ditransfer. '
     'Dalam konteks deep learning modern, transfer learning biasanya berarti '
     'menggunakan bobot model yang telah dilatih pada dataset besar (pre-training) '
     'sebagai inisialisasi untuk pelatihan pada dataset yang lebih kecil '
     '(fine-tuning). Pendekatan ini sangat penting ketika dataset target terlalu '
     'kecil untuk melatih model besar dari awal, seperti yang terjadi dalam '
     'penelitian ini dengan 738 sampel pelatihan EssayJudge.'),

    ('body',
     'Pre-training pada korpus teks besar memungkinkan model bahasa seperti '
     'RoBERTa mempelajari representasi linguistik yang kaya meliputi sintaksis, '
     'semantik, dan pragmatik bahasa Inggris, yang kemudian dapat digunakan '
     'kembali untuk tugas penilaian esai dengan sedikit data berlabel. '
     'Hu et al. (2022) memperkenalkan LoRA (Low-Rank Adaptation), sebuah metode '
     'Parameter-Efficient Fine-Tuning (PEFT) yang menginjeksikan matriks '
     'low-rank trainable ke dalam lapisan Transformer tanpa mengubah bobot '
     'pretrained, sehingga jumlah parameter yang dilatih berkurang hingga '
     '10.000 kali dibandingkan full fine-tuning. Dalam penelitian ini, LoRA '
     'dalam varian QLoRA (4-bit NF4 quantization) diterapkan pada Qwen2-VL-7B '
     'untuk memungkinkan inferensi pada GPU P100 16GB tanpa fine-tuning '
     'model tersebut pada data EssayJudge.'),

    ('body',
     'Terdapat tiga strategi utama transfer learning yang relevan dengan '
     'penelitian ini: feature extraction di mana bobot pretrained dibekukan '
     'dan hanya head baru yang dilatih, full fine-tuning di mana semua bobot '
     'dilatih ulang bersama head baru, dan partial fine-tuning di mana sebagian '
     'lapisan dibekukan dan sebagian dilatih. Tabel 2.8 merangkum keempat '
     'strategi beserta penerapannya dalam penelitian ini. Pemilihan strategi '
     'optimal bergantung pada ukuran dataset target, kesamaan domain antara '
     'data pre-training dan target, serta kapasitas komputasi yang tersedia. '
     'Dalam penelitian ini, RoBERTa sebagai encoder teks menggunakan full '
     'fine-tuning karena domain bahasa Inggris akademik cukup berbeda dari '
     'korpus pre-training umum, sementara VLM dan DePlot menggunakan feature '
     'extraction karena tujuannya hanya menghasilkan representasi teks dari '
     'gambar grafik tanpa adaptasi lebih lanjut.'),

    ('caption', TABLE_229_CAPTION),
    ('placeholder', TABLE_229_PH),

    ('body',
     'Berdasarkan Tabel 2.8, kombinasi strategi transfer learning yang '
     'digunakan dalam penelitian ini mencerminkan trade-off antara efisiensi '
     'komputasi dan kebutuhan adaptasi domain. VLM dan DePlot digunakan sebagai '
     'feature extractor karena kemampuan pengenalan gambar yang sudah sangat '
     'baik tidak perlu diubah, sedangkan RoBERTa perlu disesuaikan dengan '
     'karakteristik esai IELTS Task 1 yang spesifik melalui fine-tuning '
     'penuh pada dataset EssayJudge.'),
]

# ── Build text and positions ───────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'deep learning', r'Deep Learning',
    r'machine learning',
    r'overfitting',
    r'underfitting',
    r'dropout',
    r'weight decay',
    r'early stopping',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'pre-training', r'pre-trained', r'pre-train',
    r'transfer learning',
    r'feature extraction',
    r'full fine-tuning',
    r'partial fine-tuning',
    r'\bPEFT\b',
    r'Parameter-Efficient Fine-Tuning',
    r'\bLoRA\b',
    r'\bQLoRA\b',
    r'Low-Rank Adaptation',
    r'low-rank',
    r'backpropagation', r'Backpropagation',
    r'gradient descent',
    r'stochastic gradient descent', r'\bSGD\b',
    r'vanishing gradient',
    r'exploding gradient',
    r'gradient clipping',
    r'learning rate',
    r'batch size',
    r'mini-batch',
    r'momentum',
    r'optimizer',
    r'autograd',
    r'forward pass',
    r'backward',
    r'layer normalization',
    r'feed-forward',
    r'residual',
    r'encoder',
    r'embedding',
    r'benchmark',
    r'pipeline',
    r'scoring head',
    r'inference',
    r'regularization', r'regularisasi',
    r'\bReLU\b',
    r'\bGELU\b',
    r'Sigmoid',
    r'activation function',
    r'chain rule',
    r'sparse gradient',
    r'adaptive',
]

italic_ranges = []
covered = set()

for seg_type, text in segments:
    if seg_type in ('placeholder', 'caption'):
        continue
    seg_start = full_text.find(text)
    if seg_start == -1:
        continue
    for term in ITALIC_TERMS:
        for match in re.compile(term, re.IGNORECASE).finditer(text):
            ms = seg_start + match.start()
            me = seg_start + match.end()
            if any(i in covered for i in range(ms, me)):
                continue
            covered.update(range(ms, me))
            italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
offset = append_at - 1
requests_list = []

for seg_type, text in reversed(segments):
    requests_list.append(req_insert(text + '\n', append_at, TAB_ID))

for start, end, seg_type, text in seg_positions:
    s, e = start + offset, end + offset
    if seg_type == 'subsection':
        requests_list.append(req_para_style(s, e, TAB_ID, 'START',
            space_above=12, space_below=6, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=35.43, space_above=0, space_below=0, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'caption':
        requests_list.append(req_para_style(s, e, TAB_ID, 'CENTER',
            space_above=12, space_below=3, line_spacing=150))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))
    elif seg_type == 'placeholder':
        requests_list.append(req_para_style(s, e, TAB_ID, 'JUSTIFIED',
            first_line=0, space_above=0, space_below=0))
        requests_list.append(req_text_style(s, e, TAB_ID, bold=False, size_pt=12))

for ms, me in italic_ranges:
    requests_list.append(req_text_style(ms + offset, me + offset, TAB_ID,
                                        italic=True, size_pt=12))

print(f'Sending {len(requests_list)} requests...')
batch_update(requests_list)
print('Text inserted and styled.')

# ── Insert tables ──────────────────────────────────────────────────────────────
time.sleep(1)

TABLES = [
    (TABLE_225_PH, TABLE_225_DATA, 4, 4),
    (TABLE_227_PH, TABLE_227_DATA, 4, 3),
    (TABLE_228_PH, TABLE_228_DATA, 5, 3),
    (TABLE_229_PH, TABLE_229_DATA, 5, 3),
]

for ph_text, table_data, nrows, ncols in TABLES:
    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    ph_start = None
    for element in body_content:
        if 'paragraph' in element:
            para_text = ''.join(
                pe.get('textRun', {}).get('content', '')
                for pe in element['paragraph'].get('elements', [])
            )
            if ph_text in para_text:
                ph_start = element.get('startIndex', 0)
                break

    if ph_start is None:
        print(f'ERROR: {ph_text} not found. Skipping.')
        continue

    print(f'{ph_text} at index {ph_start}.')

    batch_update([{'deleteContentRange': {'range': {
        'startIndex': ph_start, 'endIndex': ph_start + len(ph_text), 'tabId': TAB_ID
    }}}])

    batch_update([{'insertTable': {
        'rows': nrows, 'columns': ncols,
        'location': {'index': ph_start, 'tabId': TAB_ID},
    }}])
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    if not table_el:
        print(f'ERROR: table not found for {ph_text}.')
        continue

    rows = table_el['table'].get('tableRows', [])
    cell_inserts = []
    for ri, row in enumerate(rows):
        for ci, cell in enumerate(row.get('tableCells', [])):
            paras = cell.get('content', [])
            if paras and 'paragraph' in paras[0]:
                cell_inserts.append((paras[0].get('startIndex', 0),
                                     table_data[ri][ci], ri))

    cell_inserts.sort(key=lambda x: x[0], reverse=True)
    batch_update([req_insert(t, s, TAB_ID) for s, t, _ in cell_inserts])
    print(f'Filled {len(cell_inserts)} cells.')
    time.sleep(1)

    doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
    tab = find_tab(doc.get('tabs', []), TAB_ID)
    body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])

    table_el = None
    for element in body_content:
        if 'table' in element and element.get('startIndex', 0) >= ph_start - 2:
            table_el = element
            break

    fmt_reqs = []
    if table_el:
        for ri, row in enumerate(table_el['table'].get('tableRows', [])):
            is_header = (ri == 0)
            for ci, cell in enumerate(row.get('tableCells', [])):
                for para in cell.get('content', []):
                    if 'paragraph' in para:
                        ps, pe = para.get('startIndex'), para.get('endIndex')
                        fmt_reqs.append(req_text_style(ps, pe, TAB_ID,
                                                       bold=is_header, size_pt=11))
                        fmt_reqs.append({'updateParagraphStyle': {
                            'range': {'startIndex': ps, 'endIndex': pe, 'tabId': TAB_ID},
                            'paragraphStyle': {
                                'alignment': 'CENTER' if is_header else 'START',
                                'spaceAbove': {'magnitude': 2, 'unit': 'PT'},
                                'spaceBelow': {'magnitude': 2, 'unit': 'PT'},
                                'lineSpacing': 120,
                            },
                            'fields': 'alignment,spaceAbove,spaceBelow,lineSpacing',
                        }})
        batch_update(fmt_reqs)
        print(f'Formatted {ph_text} ({len(fmt_reqs)} reqs).')

print('\nDone.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
