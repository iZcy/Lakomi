import sys
sys.stdout.reconfigure(encoding='utf-8')

from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
DRAFT_TAB_ID = 't.prr0oo8xt561'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Content Definition ────────────────────────────────────────────────────────
# Each segment: (text, named_style, bold)
# bold=True applies bold to the ENTIRE segment text
# Use "\n" at end of each paragraph

segments = [

    # BAB I title
    ("BAB I  PENDAHULUAN\n", "HEADING_1", True),

    # ── 1.1 Latar Belakang ──────────────────────────────────────────────────
    ("1.1  Latar Belakang\n", "HEADING_2", True),

    (
        "Penilaian esai merupakan komponen penting dalam ujian kemampuan berbahasa, "
        "salah satunya IELTS (International English Language Testing System). Pada "
        "IELTS Academic Writing Task 1, peserta ujian diminta untuk mendeskripsikan "
        "atau menganalisis informasi yang disajikan dalam bentuk visual seperti "
        "diagram batang, diagram garis, diagram lingkaran, tabel, peta, dan "
        "flowchart. Penilaian esai pada konteks ini tidak hanya bergantung pada "
        "kualitas teks yang ditulis, tetapi juga pada seberapa akurat dan relevan "
        "isi esai dalam merespons konten visual yang diberikan. Hal ini menjadikan "
        "penilaian IELTS Task 1 sebagai tugas multimodal, yaitu sebuah tugas yang "
        "memerlukan pemahaman simultan terhadap dua modalitas: gambar dan teks.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Proses penilaian esai secara manual memerlukan waktu yang cukup lama dan "
        "memiliki potensi inkonsistensi antar penilai. Penelitian di bidang "
        "Automated Essay Scoring (AES) telah lama berupaya mengotomasi proses ini. "
        "Namun, sebagian besar pendekatan AES tradisional hanya mempertimbangkan "
        "teks esai saja, tanpa memperhitungkan konteks visual yang menjadi dasar "
        "penulisan esai tersebut (Su et al., 2025). Pada kasus IELTS Task 1, "
        "mengabaikan gambar berarti mengabaikan informasi yang fundamental dalam "
        "menilai apakah esai benar-benar membahas konten visual yang dimaksud.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Su et al. (2025) memperkenalkan EssayJudge, sebuah benchmark pertama yang "
        "secara eksplisit mengevaluasi kemampuan Multimodal Large Language Models "
        "(MLLM) dalam menilai esai IELTS Task 1 secara multi-granular. EssayJudge "
        "menggunakan 1.054 esai dengan 10 rubrik penilaian yang mencakup aspek "
        "leksikal, sintaksis, dan wacana. Hasil evaluasi menunjukkan bahwa model "
        "MLLM open-source Qwen2-VL-7B, dengan 7 miliar parameter, hanya mampu "
        "mencapai rata-rata QWK (Quadratic Weighted Kappa) sekitar 0,16 dalam "
        "skenario zero-shot tanpa pelatihan khusus pada data berlabel. Hal ini "
        "memperlihatkan bahwa inferensi langsung dari MLLM, meskipun secara teknis "
        "mampu memahami gambar, masih jauh dari cukup untuk tugas penilaian esai "
        "yang terstruktur. Temuan ini sejalan dengan Bucher dan Martini (2024) yang "
        "menunjukkan bahwa model berukuran kecil yang di-fine-tune dengan data "
        "berlabel secara konsisten mengungguli model besar dalam mode zero-shot pada "
        "berbagai tugas klasifikasi teks.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Penelitian ini mengusulkan dua pendekatan berbasis pembelajaran terawasi "
        "untuk mengatasi keterbatasan tersebut: pendekatan Multimodal Fusion dan "
        "pendekatan Text-to-Text (T2T). Kedua pendekatan diinvestigasi secara paralel "
        "dengan tujuan mengidentifikasi strategi yang paling efektif dalam konteks "
        "AES multimodal berbasis dataset EssayJudge.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Pendekatan Multimodal Fusion menggabungkan representasi dari dua modalitas "
        "secara langsung ke dalam satu model terpadu. Terdapat tiga strategi fusion "
        "yang umum digunakan: early fusion yang menggabungkan fitur pada level input, "
        "intermediate fusion yang menggabungkan pada level representasi, dan late "
        "fusion yang menggabungkan pada level prediksi (Pereira-Gonzalez et al., "
        "2023). Dalam penelitian ini, fitur gambar diekstraksi menggunakan ResNet18, "
        "sedangkan fitur teks esai direpresentasikan menggunakan encoder berbasis "
        "transformer. Penelitian ini menginvestigasi ketiga strategi fusion tersebut "
        "menggunakan dua arsitektur encoder teks, yaitu BERT (Devlin et al., 2019) "
        "dan RoBERTa (Liu et al., 2019), untuk mengidentifikasi konfigurasi yang "
        "paling efektif.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Pendekatan Text-to-Text (T2T) mengusulkan konversi gambar grafik menjadi "
        "deskripsi teks menggunakan model vision-language (VLM) sebelum dilakukan "
        "penilaian oleh model berbasis teks. Motivasi utama pendekatan ini "
        "berlandaskan pada temuan Liu et al. (2023) yang menunjukkan bahwa konversi "
        "grafik ke representasi teks memungkinkan model bahasa melakukan penalaran "
        "yang lebih efektif dibandingkan pemrosesan langsung dari piksel gambar. "
        "Hal ini diperkuat oleh Bursztyn et al. (2024) yang secara empiris "
        "membuktikan bahwa pendekatan berbasis teks mengungguli GPT-4 berbasis visi "
        "pada tugas pemahaman grafik dengan akurasi 99% berbanding 63%. Dalam "
        "penelitian ini, Qwen2-VL-7B-Instruct digunakan sebagai captioner untuk "
        "menghasilkan deskripsi seluruh 1.054 gambar. Namun, analisis manual "
        "terhadap 100 sampel acak menunjukkan bahwa sekitar 22% caption untuk gambar "
        "jenis bar chart dan pie chart mengandung kesalahan ekstraksi data, seperti "
        "nilai yang terbalik atau puncak yang salah teridentifikasi. Hal ini "
        "memotivasi penggunaan DePlot (Liu et al., 2023), yaitu model khusus yang "
        "mengekstraksi data tabular dari grafik, sebagai captioner untuk jenis "
        "gambar tersebut.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Secara keseluruhan, penelitian ini menginvestigasi dua paradigma dalam AES "
        "multimodal: pendekatan Fusion yang menggunakan fitur visual secara langsung "
        "dan pendekatan T2T yang mengkonversi gambar menjadi teks terlebih dahulu. "
        "Pertanyaan mendasar yang ingin dijawab adalah: paradigma manakah yang "
        "menghasilkan performa lebih baik, dan bagaimana optimasi pada masing-masing "
        "paradigma berkontribusi terhadap akurasi penilaian esai IELTS Task 1 secara "
        "otomatis?\n",
        "NORMAL_TEXT", False
    ),

    (
        "Penelitian ini menggunakan dataset EssayJudge secara keseluruhan (1.054 "
        "esai) dengan pembagian data train/validasi/test sebesar 70%/15%/15%. "
        "Evaluasi dilakukan menggunakan metrik QWK pada 10 trait penilaian yang "
        "mencakup Argument Clarity (AC), Justifying Persuasiveness (JP), "
        "Organizational Structure (OS), Coherence (CH), Essay Length (EL), "
        "Grammatical Accuracy (GA), Grammatical Diversity (GD), Lexical Accuracy "
        "(LA), Lexical Diversity (LD), dan Punctuation Accuracy (PA).\n",
        "NORMAL_TEXT", False
    ),

    # ── 1.2 Rumusan Masalah ─────────────────────────────────────────────────
    ("1.2  Rumusan Masalah\n", "HEADING_2", True),

    (
        "Berdasarkan latar belakang yang telah diuraikan, penelitian ini merumuskan "
        "masalah sebagai berikut:\n",
        "NORMAL_TEXT", False
    ),

    ("Pendekatan Multimodal Fusion:\n", "NORMAL_TEXT", True),

    (
        "1. Strategi fusion manakah (early, intermediate, atau late fusion) yang "
        "menghasilkan performa terbaik dalam penilaian esai IELTS Task 1 secara "
        "otomatis menggunakan BERT dan ResNet18 pada dataset EssayJudge?\n",
        "NORMAL_TEXT", False
    ),

    (
        "2. Apakah penggantian encoder teks dari BERT menjadi RoBERTa pada arsitektur "
        "late fusion dapat meningkatkan performa penilaian esai otomatis?\n",
        "NORMAL_TEXT", False
    ),

    ("Pendekatan Text-to-Text (T2T):\n", "NORMAL_TEXT", True),

    (
        "3. Apakah pendekatan Text-to-Text (T2T) menggunakan caption dari "
        "Qwen2-VL-7B-Instruct dan model Dual RoBERTa dapat mengungguli pendekatan "
        "Fusion terbaik dalam penilaian esai IELTS Task 1 pada dataset EssayJudge?\n",
        "NORMAL_TEXT", False
    ),

    (
        "4. Apakah penggunaan DePlot sebagai captioner khusus untuk gambar jenis bar "
        "chart dan pie chart dalam pipeline T2T dapat meningkatkan performa penilaian "
        "esai otomatis dibandingkan penggunaan VLM generalis secara penuh?\n",
        "NORMAL_TEXT", False
    ),

    # ── 1.3 Tujuan Penelitian ────────────────────────────────────────────────
    ("1.3  Tujuan Penelitian\n", "HEADING_2", True),

    (
        "Berdasarkan rumusan masalah di atas, tujuan penelitian ini adalah:\n",
        "NORMAL_TEXT", False
    ),

    (
        "1. Membandingkan performa strategi early, intermediate, dan late fusion "
        "menggunakan BERT dan ResNet18 untuk mengidentifikasi strategi fusion terbaik "
        "dalam konteks AES multimodal pada dataset EssayJudge.\n",
        "NORMAL_TEXT", False
    ),

    (
        "2. Mengevaluasi pengaruh penggantian encoder teks dari BERT menjadi RoBERTa "
        "pada arsitektur late fusion terhadap performa penilaian esai IELTS Task 1.\n",
        "NORMAL_TEXT", False
    ),

    (
        "3. Mengimplementasikan dan mengevaluasi pendekatan T2T menggunakan caption "
        "Qwen2-VL-7B-Instruct dan arsitektur Dual RoBERTa, serta membandingkannya "
        "dengan pendekatan Fusion terbaik.\n",
        "NORMAL_TEXT", False
    ),

    (
        "4. Mengevaluasi efektivitas DePlot sebagai captioner khusus grafik dalam "
        "pipeline T2T hybrid untuk meningkatkan akurasi penilaian esai pada gambar "
        "jenis bar chart dan pie chart.\n",
        "NORMAL_TEXT", False
    ),

    # ── 1.4 Batasan Penelitian ───────────────────────────────────────────────
    ("1.4  Batasan Penelitian\n", "HEADING_2", True),

    (
        "Agar penelitian ini terfokus dan dapat diselesaikan dalam ruang lingkup yang "
        "terukur, ditetapkan batasan-batasan sebagai berikut:\n",
        "NORMAL_TEXT", False
    ),

    (
        "1. Dataset yang digunakan adalah EssayJudge (Su et al., 2025), terdiri dari "
        "1.054 esai IELTS Academic Writing Task 1 dengan anotasi skor pada 10 trait "
        "(skala 0 s.d. 5, langkah 0,5).\n",
        "NORMAL_TEXT", False
    ),

    (
        "2. Penelitian ini hanya mencakup IELTS Academic Writing Task 1, bukan Task 2 "
        "(esai argumentatif tanpa gambar).\n",
        "NORMAL_TEXT", False
    ),

    (
        "3. Model yang digunakan dalam penelitian ini adalah:\n",
        "NORMAL_TEXT", False
    ),

    (
        "    a. Pendekatan Fusion: BERT-base-uncased dan RoBERTa-base sebagai encoder "
        "teks; ResNet18 sebagai ekstraktor fitur gambar (dibekukan).\n",
        "NORMAL_TEXT", False
    ),

    (
        "    b. Pendekatan T2T: Qwen2-VL-7B-Instruct sebagai model captioner "
        "generalis; DePlot (google/deplot) sebagai captioner khusus grafik; dua "
        "instansi RoBERTa-base terpisah sebagai encoder caption dan encoder esai.\n",
        "NORMAL_TEXT", False
    ),

    (
        "4. Evaluasi menggunakan metrik Quadratic Weighted Kappa (QWK) dengan skala "
        "11 level (0 hingga 5 dengan selisih 0,5).\n",
        "NORMAL_TEXT", False
    ),

    (
        "5. Pelatihan pada eksperimen Fusion dilakukan secara per-trait (10 model "
        "terpisah). Pelatihan pada eksperimen T2T dilakukan secara multi-task (satu "
        "model untuk seluruh 10 trait sekaligus).\n",
        "NORMAL_TEXT", False
    ),

    (
        "6. Penelitian ini tidak melakukan fine-tuning pada model VLM maupun DePlot; "
        "seluruh caption dihasilkan sekali dan digunakan secara statis pada seluruh "
        "proses pelatihan.\n",
        "NORMAL_TEXT", False
    ),

    # ── 1.5 Manfaat Penelitian ───────────────────────────────────────────────
    ("1.5  Manfaat Penelitian\n", "HEADING_2", True),

    (
        "Penelitian ini diharapkan memberikan manfaat sebagai berikut:\n",
        "NORMAL_TEXT", False
    ),

    ("Bagi dunia akademik:\n", "NORMAL_TEXT", True),

    (
        "1. Memberikan bukti empiris perbandingan langsung antara strategi early, "
        "intermediate, dan late fusion dalam konteks AES multimodal berbasis dataset "
        "nyata.\n",
        "NORMAL_TEXT", False
    ),

    (
        "2. Menunjukkan bahwa pendekatan berbasis pelatihan supervised dengan data "
        "berlabel dapat secara signifikan mengungguli inferensi zero-shot dari MLLM "
        "berukuran besar pada tugas penilaian esai terstruktur.\n",
        "NORMAL_TEXT", False
    ),

    (
        "3. Mengidentifikasi peran kualitas caption dalam pipeline T2T dan menunjukkan "
        "efektivitas model captioner khusus grafik (DePlot) dibandingkan VLM "
        "generalis.\n",
        "NORMAL_TEXT", False
    ),

    (
        "4. Mengidentifikasi trait penilaian yang secara konsisten sulit diprediksi "
        "oleh model berbasis teks maupun fusion, sebagai arahan untuk penelitian "
        "lanjutan.\n",
        "NORMAL_TEXT", False
    ),

    ("Bagi praktisi pendidikan:\n", "NORMAL_TEXT", True),

    (
        "1. Menyediakan dasar implementasi sistem AES yang dapat membantu pengajar "
        "atau institusi dalam memberikan umpan balik awal yang konsisten dan cepat "
        "terhadap esai IELTS Task 1.\n",
        "NORMAL_TEXT", False
    ),

    (
        "2. Memperkuat wawasan mengenai aspek penulisan esai mana yang dapat "
        "diotomasi dan mana yang masih membutuhkan penilaian manusia.\n",
        "NORMAL_TEXT", False
    ),

    # ── 1.6 Sistematika Penulisan ────────────────────────────────────────────
    ("1.6  Sistematika Penulisan\n", "HEADING_2", True),

    (
        "Penulisan skripsi ini disusun dengan sistematika sebagai berikut:\n",
        "NORMAL_TEXT", False
    ),

    (
        "Bab I membahas pendahuluan yang mencakup latar belakang penelitian, rumusan "
        "masalah, tujuan penelitian, batasan penelitian, manfaat penelitian, dan "
        "sistematika penulisan.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Bab II membahas tinjauan pustaka yang meliputi penelitian-penelitian "
        "terdahulu di bidang AES berbasis deep learning dan multimodal, serta dasar "
        "teori yang mencakup strategi fusion multimodal, arsitektur BERT dan RoBERTa, "
        "ResNet18, model vision-language Qwen2-VL, DePlot, dan metrik QWK.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Bab III membahas metodologi penelitian yang mencakup deskripsi dataset "
        "EssayJudge, desain arsitektur seluruh pendekatan (Fusion dan T2T), "
        "konfigurasi pelatihan, serta alur eksperimen secara keseluruhan.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Bab IV membahas hasil dan analisis eksperimen secara berurutan: perbandingan "
        "strategi fusion, pengaruh upgrade encoder teks, perbandingan T2T terhadap "
        "Fusion terbaik, analisis kualitas caption, dan efektivitas DePlot sebagai "
        "captioner khusus.\n",
        "NORMAL_TEXT", False
    ),

    (
        "Bab V menyajikan kesimpulan yang menjawab seluruh rumusan masalah "
        "berdasarkan hasil penelitian, serta saran untuk penelitian selanjutnya.\n",
        "NORMAL_TEXT", False
    ),
]

# ── Build full text and compute index positions ──────────────────────────────
full_text = ""
positions = []  # (start_idx, end_idx, style, bold)

for text, style, bold in segments:
    start = len(full_text) + 1  # doc body starts at index 1
    end = start + len(text)
    positions.append((start, end, style, bold))
    full_text += text

print(f"Total characters to insert: {len(full_text)}")
print(f"Total segments: {len(segments)}")

# ── Step 1: Read current tab to get end index ────────────────────────────────
doc = service.documents().get(
    documentId=DOCUMENT_ID,
    includeTabsContent=True
).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        props = tab.get('tabProperties', {})
        if props.get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), DRAFT_TAB_ID)
doc_tab = tab.get('documentTab', {})
body = doc_tab.get('body', {})
content = body.get('content', [])

# Get end index of current content
end_index = 1
for element in content:
    ei = element.get('endIndex', 0)
    if ei > end_index:
        end_index = ei

print(f"Current tab end index: {end_index}")

# ── Step 2: Delete existing content (if any, keeping at least index 1) ───────
requests = []

if end_index > 2:
    requests.append({
        'deleteContentRange': {
            'range': {
                'startIndex': 1,
                'endIndex': end_index - 1,
                'tabId': DRAFT_TAB_ID
            }
        }
    })
    print(f"Deleting existing content from 1 to {end_index - 1}")

# ── Step 3: Insert full text at index 1 ─────────────────────────────────────
requests.append({
    'insertText': {
        'location': {
            'index': 1,
            'tabId': DRAFT_TAB_ID
        },
        'text': full_text
    }
})

# ── Step 4: Apply paragraph styles ──────────────────────────────────────────
for start, end, style, bold in positions:
    requests.append({
        'updateParagraphStyle': {
            'range': {
                'startIndex': start,
                'endIndex': end,
                'tabId': DRAFT_TAB_ID
            },
            'paragraphStyle': {
                'namedStyleType': style
            },
            'fields': 'namedStyleType'
        }
    })

# ── Step 5: Apply bold text styles ──────────────────────────────────────────
for start, end, style, bold in positions:
    if bold:
        requests.append({
            'updateTextStyle': {
                'range': {
                    'startIndex': start,
                    'endIndex': end - 1,  # exclude trailing \n
                    'tabId': DRAFT_TAB_ID
                },
                'textStyle': {
                    'bold': True
                },
                'fields': 'bold'
            }
        })

# ── Execute all requests ─────────────────────────────────────────────────────
print(f"\nSending {len(requests)} requests to Google Docs API...")

result = service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

print("Done. BAB I - Draft has been written successfully.")
print(f"Document: https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={DRAFT_TAB_ID}")
