import sys, re
sys.stdout.reconfigure(encoding='utf-8')

from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
DRAFT_TAB_ID = 't.prr0oo8xt561'

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

PT = "PT"

def indent(cm):
    return round(cm / 2.54 * 72, 1)

INDENT_BODY = indent(1.25)
INDENT_SUB  = indent(1.25)

STYLE_MAP = {
    'chapter':     {'font_size': 14, 'bold': True,  'align': 'CENTER',    'first_line': 0,           'left': 0},
    'section':     {'font_size': 12, 'bold': True,  'align': 'START',     'first_line': 0,           'left': 0},
    'body':        {'font_size': 12, 'bold': False, 'align': 'JUSTIFIED', 'first_line': INDENT_BODY, 'left': 0},
    'numbered':    {'font_size': 12, 'bold': False, 'align': 'JUSTIFIED', 'first_line': 0,           'left': 0},
    'subnumbered': {'font_size': 12, 'bold': False, 'align': 'JUSTIFIED', 'first_line': 0,           'left': INDENT_SUB},
    'bold_label':  {'font_size': 12, 'bold': True,  'align': 'JUSTIFIED', 'first_line': 0,           'left': 0},
    'sistematika': {'font_size': 12, 'bold': False, 'align': 'JUSTIFIED', 'first_line': 0,           'left': 0},
}

# ── Foreign terms to italicize (regex word-boundary search) ──────────────────
# Order matters: longer/compound terms first to avoid partial matches
ITALIC_TERMS = [
    r'early fusion',
    r'intermediate fusion',
    r'late fusion',
    r'vision-language',
    r'text-to-text',
    r'open-source',
    r'multi-task',
    r'per-trait',
    r'fine-tuning',
    r'fine-tuned',
    r'fine-tune',
    r'di-fine-tune',
    r'zero-shot',
    r'benchmark',
    r'pipeline',
    r'captioner',
    r'\bcaption\b',   # word boundary to avoid matching inside 'captioner'
]

# ── Content ───────────────────────────────────────────────────────────────────
segments = [

    # ─── BAB I ───────────────────────────────────────────────────────────────
    ("BAB I  PENDAHULUAN\n", 'chapter'),

    # ─── 1.1 Latar Belakang ──────────────────────────────────────────────────
    ("1.1  Latar Belakang\n", 'section'),

    # P1 — IELTS Task 1 multimodal context
    (
        "Penilaian esai merupakan komponen penting dalam ujian kemampuan berbahasa, "
        "salah satunya IELTS (International English Language Testing System). Pada "
        "IELTS Academic Writing Task 1, peserta ujian diminta untuk mendeskripsikan "
        "atau menganalisis informasi yang disajikan dalam bentuk visual seperti "
        "diagram batang, diagram garis, diagram lingkaran, tabel, peta, dan "
        "flowchart. Penilaian esai pada konteks ini tidak hanya bergantung pada "
        "kualitas teks yang ditulis, tetapi juga pada seberapa akurat dan relevan "
        "isi esai dalam merespons konten visual yang diberikan. Hal ini menjadikan "
        "penilaian IELTS Task 1 sebagai tugas multimodal, yaitu sebuah tugas yang "
        "memerlukan pemahaman simultan terhadap dua modalitas: gambar dan teks.\n",
        'body'
    ),

    # P2 — AES problem, traditional approaches ignore image
    (
        "Proses penilaian esai secara manual memerlukan waktu yang cukup lama dan "
        "memiliki potensi inkonsistensi antar penilai. Penelitian di bidang "
        "Automated Essay Scoring (AES) telah lama berupaya mengotomasi proses ini. "
        "Namun, sebagian besar pendekatan AES tradisional hanya mempertimbangkan "
        "teks esai saja, tanpa memperhitungkan konteks visual yang menjadi dasar "
        "penulisan esai tersebut (Su et al., 2025). Pada kasus IELTS Task 1, "
        "mengabaikan gambar berarti mengabaikan informasi yang fundamental dalam "
        "menilai apakah esai benar-benar membahas konten visual yang dimaksud.\n",
        'body'
    ),

    # P3 — EssayJudge + zero-shot limitation + Bucher 2024
    (
        "Su et al. (2025) memperkenalkan EssayJudge, sebuah benchmark pertama yang "
        "secara eksplisit mengevaluasi kemampuan Multimodal Large Language Models "
        "(MLLM) dalam menilai esai IELTS Task 1 secara multi-granular. EssayJudge "
        "menggunakan 1.054 esai dengan 10 rubrik penilaian yang mencakup aspek "
        "leksikal, sintaksis, dan wacana. Hasil evaluasi menunjukkan bahwa model "
        "MLLM open-source Qwen2-VL-7B, dengan 7 miliar parameter, hanya mampu "
        "mencapai rata-rata QWK (Quadratic Weighted Kappa) sekitar 0,16 dalam "
        "skenario zero-shot tanpa pelatihan khusus pada data berlabel. Hal ini "
        "memperlihatkan bahwa inferensi langsung dari MLLM, meskipun secara teknis "
        "mampu memahami gambar, masih jauh dari cukup untuk tugas penilaian esai "
        "yang terstruktur. Temuan ini sejalan dengan Bucher dan Martini (2024) yang "
        "menunjukkan bahwa model berukuran kecil yang di-fine-tune dengan data "
        "berlabel secara konsisten mengungguli model besar dalam mode zero-shot pada "
        "berbagai tugas klasifikasi teks.\n",
        'body'
    ),

    # P4 — Two parallel proposed approaches (conceptual introduction)
    (
        "Penelitian ini mengusulkan dua pendekatan berbasis pembelajaran terawasi "
        "untuk mengatasi keterbatasan tersebut: pendekatan Multimodal Fusion dan "
        "pendekatan Text-to-Text (T2T). Kedua pendekatan diinvestigasi secara paralel "
        "dengan tujuan mengidentifikasi strategi yang paling efektif dalam konteks "
        "AES multimodal berbasis dataset EssayJudge.\n",
        'body'
    ),

    # P5 — Fusion: conceptual only, no specific model names
    (
        "Pendekatan Multimodal Fusion menggabungkan representasi dari dua modalitas "
        "secara langsung ke dalam satu model terpadu. Terdapat tiga strategi fusion "
        "yang umum digunakan: early fusion yang menggabungkan fitur pada level input, "
        "intermediate fusion yang menggabungkan pada level representasi, dan late "
        "fusion yang menggabungkan pada level prediksi (Pereira-Gonzalez et al., "
        "2023). Penelitian ini menginvestigasi ketiga strategi tersebut serta "
        "pengaruh pemilihan arsitektur encoder teks untuk mengidentifikasi konfigurasi "
        "yang paling efektif dalam konteks AES multimodal.\n",
        'body'
    ),

    # P6 — T2T: literature-based motivation only, no our-own findings
    (
        "Pendekatan Text-to-Text (T2T) mengusulkan konversi gambar grafik menjadi "
        "deskripsi teks menggunakan model vision-language (VLM) sebelum dilakukan "
        "penilaian oleh model berbasis teks. Motivasi utama pendekatan ini "
        "berlandaskan pada temuan Liu et al. (2023) yang menunjukkan bahwa konversi "
        "grafik ke representasi teks memungkinkan model bahasa melakukan penalaran "
        "yang lebih efektif dibandingkan pemrosesan langsung dari piksel gambar. "
        "Hal ini diperkuat oleh Bursztyn et al. (2024) yang secara empiris "
        "membuktikan bahwa pendekatan berbasis teks mengungguli GPT-4 berbasis visi "
        "pada tugas pemahaman grafik dengan akurasi 99% berbanding 63%. Namun, VLM "
        "generalis memiliki keterbatasan dalam mengekstraksi data numerik secara "
        "akurat dari grafik dengan konten tabular, terutama untuk jenis bar chart dan "
        "pie chart (Liu et al., 2023). Hal ini memotivasi penggunaan model captioner "
        "khusus grafik sebagai komponen dalam pipeline T2T.\n",
        'body'
    ),

    # P7 — Research scope / closing framing
    (
        "Secara keseluruhan, penelitian ini menginvestigasi dua paradigma dalam AES "
        "multimodal: pendekatan Fusion yang menggunakan fitur visual secara langsung "
        "dan pendekatan T2T yang mengkonversi gambar menjadi teks terlebih dahulu. "
        "Pertanyaan mendasar yang ingin dijawab adalah: paradigma manakah yang "
        "menghasilkan performa lebih baik, dan bagaimana optimasi pada masing-masing "
        "paradigma berkontribusi terhadap akurasi penilaian esai IELTS Task 1 secara "
        "otomatis?\n",
        'body'
    ),

    # ─── 1.2 Rumusan Masalah ─────────────────────────────────────────────────
    ("1.2  Rumusan Masalah\n", 'section'),

    (
        "Berdasarkan latar belakang yang telah diuraikan, penelitian ini merumuskan "
        "masalah sebagai berikut:\n",
        'body'
    ),

    ("Pendekatan Multimodal Fusion:\n", 'bold_label'),

    (
        "1. Strategi fusion manakah (early, intermediate, atau late fusion) yang "
        "menghasilkan performa terbaik dalam penilaian esai IELTS Task 1 secara "
        "otomatis menggunakan BERT dan ResNet18 pada dataset EssayJudge?\n",
        'numbered'
    ),

    (
        "2. Apakah penggantian encoder teks dari BERT menjadi RoBERTa pada arsitektur "
        "late fusion dapat meningkatkan performa penilaian esai otomatis?\n",
        'numbered'
    ),

    ("Pendekatan Text-to-Text (T2T):\n", 'bold_label'),

    (
        "3. Apakah pendekatan Text-to-Text (T2T) menggunakan caption dari "
        "Qwen2-VL-7B-Instruct dan model Dual RoBERTa dapat mengungguli pendekatan "
        "Fusion terbaik dalam penilaian esai IELTS Task 1 pada dataset EssayJudge?\n",
        'numbered'
    ),

    (
        "4. Apakah penggunaan model captioner khusus grafik dalam pipeline T2T dapat "
        "meningkatkan performa penilaian esai otomatis dibandingkan penggunaan VLM "
        "generalis secara penuh?\n",
        'numbered'
    ),

    # ─── 1.3 Tujuan Penelitian ────────────────────────────────────────────────
    ("1.3  Tujuan Penelitian\n", 'section'),

    ("Berdasarkan rumusan masalah di atas, tujuan penelitian ini adalah:\n", 'body'),

    (
        "1. Membandingkan performa strategi early, intermediate, dan late fusion "
        "untuk mengidentifikasi strategi terbaik dalam konteks AES multimodal pada "
        "dataset EssayJudge.\n",
        'numbered'
    ),

    (
        "2. Mengevaluasi pengaruh pemilihan arsitektur encoder teks pada strategi "
        "late fusion terhadap performa penilaian esai IELTS Task 1.\n",
        'numbered'
    ),

    (
        "3. Mengimplementasikan dan mengevaluasi pendekatan T2T berbasis caption VLM "
        "dan Dual RoBERTa, serta membandingkannya dengan pendekatan Fusion terbaik.\n",
        'numbered'
    ),

    (
        "4. Mengevaluasi efektivitas model captioner khusus grafik dalam pipeline "
        "T2T hybrid untuk meningkatkan akurasi penilaian esai pada gambar jenis bar "
        "chart dan pie chart.\n",
        'numbered'
    ),

    # ─── 1.4 Batasan Penelitian ───────────────────────────────────────────────
    ("1.4  Batasan Penelitian\n", 'section'),

    (
        "Agar penelitian ini terfokus dan dapat diselesaikan dalam ruang lingkup yang "
        "terukur, ditetapkan batasan-batasan sebagai berikut:\n",
        'body'
    ),

    (
        "1. Dataset yang digunakan adalah EssayJudge (Su et al., 2025), terdiri dari "
        "1.054 esai IELTS Academic Writing Task 1 dengan anotasi skor pada 10 trait "
        "(skala 0 s.d. 5, langkah 0,5).\n",
        'numbered'
    ),

    (
        "2. Penelitian ini hanya mencakup IELTS Academic Writing Task 1, bukan "
        "Task 2 (esai argumentatif tanpa gambar).\n",
        'numbered'
    ),

    ("3. Model yang digunakan dalam penelitian ini adalah:\n", 'numbered'),

    (
        "a. Pendekatan Fusion: BERT-base-uncased dan RoBERTa-base sebagai encoder "
        "teks; ResNet18 sebagai ekstraktor fitur gambar (dibekukan).\n",
        'subnumbered'
    ),

    (
        "b. Pendekatan T2T: Qwen2-VL-7B-Instruct sebagai model captioner generalis; "
        "DePlot (google/deplot) sebagai captioner khusus grafik; dua instansi "
        "RoBERTa-base terpisah sebagai encoder caption dan encoder esai.\n",
        'subnumbered'
    ),

    (
        "4. Evaluasi menggunakan metrik Quadratic Weighted Kappa (QWK) dengan skala "
        "11 level (0 hingga 5 dengan selisih 0,5).\n",
        'numbered'
    ),

    (
        "5. Pelatihan pada eksperimen Fusion dilakukan secara per-trait (10 model "
        "terpisah). Pelatihan pada eksperimen T2T dilakukan secara multi-task (satu "
        "model untuk seluruh 10 trait sekaligus).\n",
        'numbered'
    ),

    (
        "6. Penelitian ini tidak melakukan fine-tuning pada model VLM maupun DePlot; "
        "seluruh caption dihasilkan sekali dan digunakan secara statis pada seluruh "
        "proses pelatihan.\n",
        'numbered'
    ),

    # ─── 1.5 Manfaat Penelitian ───────────────────────────────────────────────
    ("1.5  Manfaat Penelitian\n", 'section'),

    ("Penelitian ini diharapkan memberikan manfaat sebagai berikut:\n", 'body'),

    ("Bagi dunia akademik:\n", 'bold_label'),

    (
        "1. Memberikan bukti empiris perbandingan langsung antara strategi early, "
        "intermediate, dan late fusion dalam konteks AES multimodal berbasis dataset "
        "nyata.\n",
        'numbered'
    ),

    (
        "2. Menunjukkan bahwa pendekatan berbasis pelatihan supervised dengan data "
        "berlabel dapat secara signifikan mengungguli inferensi zero-shot dari MLLM "
        "berukuran besar pada tugas penilaian esai terstruktur.\n",
        'numbered'
    ),

    (
        "3. Mengidentifikasi peran kualitas caption dalam pipeline T2T dan "
        "menunjukkan efektivitas model captioner khusus grafik dibandingkan VLM "
        "generalis.\n",
        'numbered'
    ),

    (
        "4. Mengidentifikasi trait penilaian yang secara konsisten sulit diprediksi "
        "oleh model berbasis teks maupun fusion, sebagai arahan untuk penelitian "
        "lanjutan.\n",
        'numbered'
    ),

    ("Bagi praktisi pendidikan:\n", 'bold_label'),

    (
        "1. Menyediakan dasar implementasi sistem AES yang dapat membantu pengajar "
        "atau institusi dalam memberikan umpan balik awal yang konsisten dan cepat "
        "terhadap esai IELTS Task 1.\n",
        'numbered'
    ),

    (
        "2. Memperkuat wawasan mengenai aspek penulisan esai mana yang dapat "
        "diotomasi dan mana yang masih membutuhkan penilaian manusia.\n",
        'numbered'
    ),

    # ─── 1.6 Sistematika Penulisan ────────────────────────────────────────────
    ("1.6  Sistematika Penulisan\n", 'section'),

    ("Penulisan skripsi ini disusun dengan sistematika sebagai berikut:\n", 'body'),

    (
        "Bab I|membahas pendahuluan yang mencakup latar belakang penelitian, rumusan "
        "masalah, tujuan penelitian, batasan penelitian, manfaat penelitian, dan "
        "sistematika penulisan.\n",
        'sistematika'
    ),

    (
        "Bab II|membahas tinjauan pustaka yang meliputi penelitian terdahulu di "
        "bidang AES berbasis deep learning dan multimodal, serta dasar teori yang "
        "mencakup strategi fusion multimodal, arsitektur encoder teks berbasis "
        "transformer, model pengenalan citra, model vision-language, DePlot, dan "
        "metrik QWK.\n",
        'sistematika'
    ),

    (
        "Bab III|membahas metodologi penelitian yang mencakup deskripsi dataset "
        "EssayJudge, desain arsitektur seluruh pendekatan (Fusion dan T2T), "
        "konfigurasi pelatihan, serta alur eksperimen secara keseluruhan.\n",
        'sistematika'
    ),

    (
        "Bab IV|membahas hasil dan analisis eksperimen secara berurutan: perbandingan "
        "strategi fusion, pengaruh pemilihan encoder teks, perbandingan T2T terhadap "
        "Fusion terbaik, analisis kualitas caption, dan efektivitas model captioner "
        "khusus grafik.\n",
        'sistematika'
    ),

    (
        "Bab V|menyajikan kesimpulan yang menjawab seluruh rumusan masalah "
        "berdasarkan hasil penelitian, serta saran untuk penelitian selanjutnya.\n",
        'sistematika'
    ),
]

# ── Build full text and compute positions ─────────────────────────────────────
full_text = ""
seg_positions = []

for raw_text, seg_type in segments:
    inserted_text = raw_text.replace('|', ' ') if seg_type == 'sistematika' else raw_text
    start = len(full_text) + 1
    end = start + len(inserted_text)
    seg_positions.append((start, end, seg_type, raw_text))
    full_text += inserted_text

print(f"Characters: {len(full_text)} | Segments: {len(segments)}")

# ── Find italic ranges (foreign terms) ───────────────────────────────────────
italic_ranges = []
covered = set()  # track covered char positions to avoid overlaps

for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))  # +1 for doc offset

italic_ranges.sort()
print(f"Italic ranges found: {len(italic_ranges)}")

# ── Step 1: Delete existing content ──────────────────────────────────────────
doc = service.documents().get(
    documentId=DOCUMENT_ID,
    includeTabsContent=True
).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), DRAFT_TAB_ID)
body_content = tab.get('documentTab', {}).get('body', {}).get('content', [])
end_index = max((e.get('endIndex', 1) for e in body_content), default=1)

requests = []
if end_index > 2:
    requests.append({
        'deleteContentRange': {
            'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': DRAFT_TAB_ID}
        }
    })

# ── Step 2: Insert full text ──────────────────────────────────────────────────
requests.append({
    'insertText': {
        'location': {'index': 1, 'tabId': DRAFT_TAB_ID},
        'text': full_text
    }
})

# ── Step 3: Paragraph styles + explicit font/size ────────────────────────────
for start, end, seg_type, raw_text in seg_positions:
    s = STYLE_MAP[seg_type]

    requests.append({
        'updateParagraphStyle': {
            'range': {'startIndex': start, 'endIndex': end, 'tabId': DRAFT_TAB_ID},
            'paragraphStyle': {
                'alignment': s['align'],
                'indentFirstLine': {'magnitude': s['first_line'], 'unit': PT},
                'indentStart':     {'magnitude': s['left'],       'unit': PT},
            },
            'fields': 'alignment,indentFirstLine,indentStart'
        }
    })

    text_end = end - 1
    if text_end > start:
        requests.append({
            'updateTextStyle': {
                'range': {'startIndex': start, 'endIndex': text_end, 'tabId': DRAFT_TAB_ID},
                'textStyle': {
                    'weightedFontFamily': {'fontFamily': 'Times New Roman'},
                    'fontSize': {'magnitude': s['font_size'], 'unit': PT},
                    'bold': s['bold'],
                    'italic': False,
                },
                'fields': 'weightedFontFamily,fontSize,bold,italic'
            }
        })

# ── Step 4: Sistematika inline bold ──────────────────────────────────────────
for start, end, seg_type, raw_text in seg_positions:
    if seg_type == 'sistematika' and '|' in raw_text:
        bold_end = start + len(raw_text.split('|')[0])
        requests.append({
            'updateTextStyle': {
                'range': {'startIndex': start, 'endIndex': bold_end, 'tabId': DRAFT_TAB_ID},
                'textStyle': {
                    'bold': True,
                    'weightedFontFamily': {'fontFamily': 'Times New Roman'},
                    'fontSize': {'magnitude': 12, 'unit': PT}
                },
                'fields': 'bold,weightedFontFamily,fontSize'
            }
        })

# ── Step 5: Apply italic to foreign terms ────────────────────────────────────
for italic_start, italic_end in italic_ranges:
    requests.append({
        'updateTextStyle': {
            'range': {'startIndex': italic_start, 'endIndex': italic_end, 'tabId': DRAFT_TAB_ID},
            'textStyle': {'italic': True},
            'fields': 'italic'
        }
    })

# ── Execute ───────────────────────────────────────────────────────────────────
print(f"Sending {len(requests)} requests...")
service.documents().batchUpdate(
    documentId=DOCUMENT_ID,
    body={'requests': requests}
).execute()

print("Done.")
print(f"https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={DRAFT_TAB_ID}")
