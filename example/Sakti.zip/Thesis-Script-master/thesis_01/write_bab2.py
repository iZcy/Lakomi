import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'  # BAB II - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Content ──────────────────────────────────────────────────────────────────
# Types: chapter | section | subsection | body | numbered | subnumbered
segments = [
    ("chapter", "BAB II\nTINJAUAN PUSTAKA DAN DASAR TEORI"),

    ("section", "2.1 Tinjauan Pustaka"),
    ("body", "Subbab ini membahas penelitian-penelitian terdahulu yang relevan dengan topik skripsi ini, "
             "mencakup penelitian di bidang automated essay scoring (AES), strategi fusion multimoda, dan "
             "pemahaman grafik berbasis teks. Setiap penelitian dianalisis berdasarkan permasalahan yang "
             "diselesaikan, kontribusi utama, serta keterbatasan yang dimiliki, untuk kemudian "
             "diidentifikasi celah penelitian yang menjadi landasan pengembangan penelitian ini."),

    ("body", "Singh et al. (2024) memperkenalkan dataset EssayJudge sebagai benchmark pertama untuk "
             "penilaian esai multimoda pada tugas IELTS Task 1. Dataset ini memuat 1.054 esai mahasiswa "
             "beserta gambar grafik profesional dan anotasi skor untuk sepuluh dimensi penilaian. "
             "Penelitian tersebut mengevaluasi kemampuan beberapa multimodal large language model dalam "
             "kondisi zero-shot sebagai baseline, dengan hasil rata-rata QWK sekitar 0,164. Keterbatasan "
             "utama EssayJudge terletak pada fakta bahwa seluruh model yang diujikan bersifat zero-shot "
             "tanpa fine-tuning, sehingga belum ada sistem AES terlatih yang diusulkan secara eksplisit."),

    ("body", "Loukili et al. (2023) mengusulkan ProTACT, sebuah model AES lintas-prompt berbasis "
             "multi-trait untuk esai argumentatif. Kontribusi utama ProTACT mencakup mekanisme "
             "trait-similarity loss dan essay-prompt attention yang memungkinkan transfer pengetahuan "
             "antara prompt berbeda. Keterbatasan utama ProTACT adalah tidak adanya modalitas gambar; "
             "model ini hanya memproses teks esai tanpa mempertimbangkan gambar atau grafik yang menjadi "
             "rujukan esai, sehingga tidak dapat diterapkan langsung pada dataset EssayJudge."),

    ("body", "He et al. (2024) mengembangkan pendekatan Siamese RoBERTa dengan pembelajaran kontrastif "
             "untuk penilaian esai berdasarkan rubrik. Model dengan shared encoder dan fungsi loss "
             "gabungan cross-entropy, MSE, dan NT-Xent menunjukkan performa baik pada korpus berskala "
             "besar (8.000-14.000 sampel). Namun, pada skala dataset EssayJudge yang hanya memiliki "
             "sekitar 738 sampel pelatihan, pendekatan ini mengalami degradasi performa yang signifikan "
             "dibandingkan arsitektur dual-encoder independen, mengindikasikan bahwa pembelajaran "
             "kontrastif membutuhkan volume data yang lebih besar untuk bekerja secara efektif."),

    ("body", "Luo et al. (2025) mengusulkan CAFES (Collaborative Agentic Framework for Essay Scoring), "
             "sebuah kerangka kerja multi-agen berbasis model bahasa-visi besar yang menerapkan penilaian "
             "multi-granular pada dataset EssayJudge. CAFES mencapai peningkatan QWK relatif sebesar 21% "
             "dibandingkan pendekatan zero-shot. Keterbatasan utama CAFES adalah ketergantungannya pada "
             "layanan API model bahasa berukuran besar yang bersifat tertutup, sehingga biaya inferensi "
             "tinggi, tidak dapat di-fine-tune pada dataset spesifik, dan tidak dapat direproduksi tanpa "
             "akses API berbayar."),

    ("body", "Zhang et al. (2026) mengusulkan DLOM-GF (Decision-Level Ordinal Modeling with Gated "
             "Fusion), sebuah pendekatan penilaian ordinal berbasis LLM pada dataset EssayJudge. Model "
             "ini menggabungkan pemodelan ordinal pada tingkat keputusan dengan mekanisme gated fusion "
             "antara fitur teks dan gambar. Keterbatasan DLOM-GF serupa dengan CAFES, yaitu "
             "ketergantungan pada model LLM eksternal tanpa pipeline ekstraksi konten grafik yang "
             "eksplisit, sehingga pemahaman terhadap isi grafik bergantung sepenuhnya pada kemampuan "
             "zero-shot model bahasa-visi yang digunakan."),

    ("body", "Gold et al. (2025) meneliti strategi fusion untuk model multimoda berbasis BERT dan "
             "ResNet18 dengan mekanisme cross-attention sebagai intermediate fusion. Penelitian ini "
             "menunjukkan bahwa intermediate fusion dengan cross-attention dapat mengungguli early fusion "
             "pada beberapa tugas klasifikasi visi-teks. Namun, temuan ini bersifat tugas-spesifik; "
             "pada eksperimen yang dilakukan dalam penelitian ini (Langkah 2), late fusion terbukti "
             "memberikan hasil terbaik untuk penilaian esai IELTS Task 1, mengindikasikan bahwa "
             "pemisahan encoder antar modalitas lebih menguntungkan ketika representasi teks dan gambar "
             "memiliki karakteristik yang sangat berbeda."),

    ("body", "Liu et al. (2023) mengembangkan DePlot, sebuah model yang melakukan translasi gambar "
             "grafik menjadi tabel data terstruktur dalam satu langkah (one-shot plot-to-table "
             "translation). DePlot memungkinkan model bahasa melakukan reasoning atas data grafik tanpa "
             "melihat gambar secara langsung, dan terbukti meningkatkan akurasi reasoning grafik hingga "
             "24,0% secara absolut dibandingkan pendekatan berbasis gambar langsung. Keterbatasan DePlot "
             "adalah hanya bekerja efektif pada grafik terstruktur seperti bar chart, pie chart, dan "
             "line chart, sedangkan flow chart, peta, dan gambar komposit tidak memiliki struktur "
             "tabel yang dapat diekstraksi."),

    ("body", "Bursztyn et al. (2024) melakukan analisis komparatif representasi grafik untuk chart "
             "question answering pada konferensi IEEE VIS 2024. Hasil utama penelitian ini menunjukkan "
             "bahwa representasi berbasis teks mengungguli representasi berbasis gambar secara signifikan, "
             "dengan akurasi 99% dibandingkan 63% pada model berbasis visi. Penting untuk dicatat bahwa "
             "penelitian Bursztyn et al. menggunakan spesifikasi data terstruktur (CSV/JSON) sebagai "
             "input teks, sedangkan penelitian ini menghadapi kondisi yang lebih terbatas karena dataset "
             "EssayJudge tidak menyertakan data terstruktur di balik gambar, sehingga diperlukan VLM "
             "untuk mengekstraksi konten grafik dari gambar secara langsung."),

    ("body", "Tang et al. (2023) memperkenalkan VisText, sebuah benchmark untuk chart captioning yang "
             "kaya secara semantik. Penelitian ini menunjukkan bahwa kualitas deskripsi teks dari grafik "
             "secara langsung memengaruhi performa model NLP pada downstream tasks. Temuan kunci VisText "
             "adalah bahwa kualitas caption lebih menentukan performa downstream dibandingkan skala model "
             "yang digunakan, yang mendukung strategi penelitian ini dalam melakukan tinjauan kualitas "
             "caption secara manual sebelum memilih model captioner terbaik."),

    ("body", "Zhao et al. (2025) memperkenalkan EDU-CIRCUIT-HW, sebuah benchmark evaluasi untuk "
             "kemampuan multimodal LLM pada konten STEM tertulis tangan di tingkat universitas. "
             "Penelitian ini memvalidasi penggunaan pipeline image-to-text berbasis VLM untuk penilaian "
             "pendidikan, menunjukkan bahwa interpretasi teks dari konten visual dapat meningkatkan "
             "kinerja sistem penilaian otomatis. Relevansi terhadap penelitian ini terletak pada "
             "kesamaan domain penilaian akademik berbasis gambar, meskipun EssayJudge menggunakan "
             "gambar grafik profesional."),

    ("body", "Berdasarkan tinjauan pustaka di atas, terdapat beberapa celah penelitian yang belum "
             "terisi. Pertama, sistem AES yang ada pada umumnya hanya memproses modalitas teks tanpa "
             "mempertimbangkan gambar grafik yang dirujuk oleh esai. Kedua, penelitian terkini pada "
             "dataset EssayJudge (CAFES, DLOM-GF) bergantung pada model API tertutup berbiaya tinggi "
             "yang tidak dapat di-fine-tune secara spesifik. Ketiga, belum ada penelitian yang secara "
             "sistematis membandingkan strategi fusion (early, intermediate, late) maupun pendekatan "
             "text-to-text berbasis caption VLM untuk penilaian esai IELTS multimoda. Keempat, manfaat "
             "teknik chart-to-text seperti DePlot yang telah terbukti dalam reasoning grafik belum "
             "diterapkan pada domain penilaian esai. Penelitian ini mengisi celah tersebut dengan "
             "mengusulkan dan membandingkan dua jalur pendekatan secara bersamaan."),

    ("section", "2.2 Dasar Teori"),

    ("subsection", "2.2.1 Automated Essay Scoring"),
    ("body", "Automated Essay Scoring (AES) adalah tugas penilaian kualitas esai secara otomatis "
             "menggunakan komputer tanpa melibatkan penilaian manusia secara langsung. Sejarah AES "
             "dimulai dari sistem berbasis aturan seperti e-rater (Educational Testing Service, 1999) "
             "yang mengandalkan fitur linguistik terstruktur seperti panjang esai, keragaman kosakata, "
             "dan koherensi sintaksis. Seiring perkembangan kecerdasan buatan, AES berevolusi melalui "
             "pendekatan berbasis feature engineering menggunakan SVM dan regresi, kemudian beralih ke "
             "pembelajaran mendalam dengan LSTM dan Transformer."),

    ("body", "Penilaian esai dapat bersifat holistik (satu skor keseluruhan) atau analitik (beberapa "
             "dimensi trait). Penilaian analitik atau multi-trait lebih informatif karena "
             "mengidentifikasi kekuatan dan kelemahan spesifik pada setiap dimensi kualitas penulisan. "
             "IELTS Task 1 merupakan tugas deskripsi data di mana peserta tes diminta mendeskripsikan "
             "informasi yang tersaji dalam sebuah grafik, tabel, atau diagram dalam minimal 150 kata. "
             "Karena esai IELTS Task 1 secara inheren mengacu pada konten visual grafik, penilaian yang "
             "valid memerlukan pemahaman terhadap kedua modalitas: teks esai dan gambar grafik "
             "yang dirujuk."),

    ("subsection", "2.2.2 Multi-task Learning"),
    ("body", "Multi-task learning adalah paradigma pelatihan di mana satu model dioptimalkan secara "
             "bersamaan untuk beberapa tugas terkait menggunakan shared encoder. Dalam konteks penilaian "
             "esai multi-trait, satu encoder teks menghasilkan representasi umum yang kemudian "
             "diteruskan ke sepuluh output head independen, masing-masing memprediksi satu dimensi "
             "penilaian. Pendekatan ini memberikan sinyal gradien sepuluh kali lipat per pembaruan bobot "
             "dibandingkan pelatihan per-trait secara terpisah, sekaligus mendorong encoder mempelajari "
             "representasi yang dapat ditransfer lintas trait."),

    ("body", "Keunggulan utama multi-task learning untuk AES pada dataset berukuran kecil adalah "
             "regularisasi implisit: karena encoder harus menghasilkan representasi yang berguna untuk "
             "semua trait sekaligus, model cenderung lebih tahan terhadap overfitting. Hal ini sangat "
             "relevan untuk dataset EssayJudge yang hanya memiliki 738 sampel pelatihan, di mana "
             "pelatihan per-trait secara terpisah akan semakin rentan terhadap overfitting."),

    ("subsection", "2.2.3 Strategi Multimodal Fusion"),
    ("body", "Multimodal fusion adalah teknik menggabungkan representasi dari dua atau lebih modalitas "
             "input untuk menghasilkan prediksi bersama. Terdapat tiga strategi fusion utama yang "
             "dibedakan berdasarkan titik penggabungan dalam arsitektur model. Early fusion "
             "menggabungkan fitur dari kedua modalitas sebelum melewati encoder utama, menciptakan "
             "ketergantungan ketat antar modalitas sejak awal. Intermediate fusion menggabungkan "
             "representasi pada lapisan tengah, misalnya melalui mekanisme cross-attention antara "
             "fitur teks dan gambar. Late fusion mempertahankan encoder independen untuk masing-masing "
             "modalitas hingga tahap akhir, kemudian menggabungkan representasi final melalui "
             "concatenation sebelum lapisan keluaran."),

    ("body", "Late fusion memiliki keunggulan modularitas: setiap encoder dapat dioptimalkan secara "
             "independen sesuai karakteristik modalitasnya tanpa gangguan silang. Pada kasus di mana "
             "kedua modalitas memiliki distribusi representasi yang sangat berbeda, seperti teks esai "
             "dan gambar grafik, late fusion umumnya memberikan hasil yang lebih stabil karena "
             "menghindari interferensi representasi antar modalitas di lapisan awal pelatihan."),

    ("subsection", "2.2.4 BERT dan RoBERTa"),
    ("body", "BERT (Bidirectional Encoder Representations from Transformers) adalah model bahasa "
             "berbasis Transformer yang dilatih secara self-supervised menggunakan dua tugas "
             "pre-training: masked language modeling (MLM) dan next sentence prediction (NSP). "
             "BERT menggunakan token khusus [CLS] yang diletakkan di awal setiap urutan input; "
             "representasi [CLS] pada lapisan terakhir (768 dimensi) digunakan sebagai representasi "
             "kalimat untuk tugas downstream seperti klasifikasi dan regresi."),

    ("body", "RoBERTa (Robustly Optimized BERT Approach) adalah versi BERT yang dioptimalkan dengan "
             "menghilangkan tugas NSP yang terbukti kurang bermanfaat, menggunakan dynamic masking, "
             "batch size yang lebih besar, dan lebih banyak data pre-training. Perbedaan ini "
             "menghasilkan representasi yang lebih kuat untuk tugas downstream, terutama pada tugas "
             "regresi dan klasifikasi urutan. Dalam penelitian ini digunakan varian roberta-base dengan "
             "12 lapisan Transformer, dimensi hidden 768, dan sekitar 125 juta parameter."),

    ("subsection", "2.2.5 ResNet18"),
    ("body", "ResNet (Residual Network) adalah arsitektur jaringan saraf konvolusi yang memperkenalkan "
             "skip connection (koneksi residual) untuk mengatasi masalah vanishing gradient pada "
             "jaringan yang sangat dalam. Skip connection memungkinkan gradien mengalir langsung "
             "melewati beberapa lapisan selama backpropagation, sehingga jaringan dengan puluhan "
             "lapisan dapat dilatih secara efektif. ResNet18 adalah varian ResNet dengan 18 lapisan "
             "yang menyeimbangkan kapasitas representasi dan efisiensi komputasi."),

    ("body", "Dalam penelitian ini, ResNet18 yang telah di-pre-train pada dataset ImageNet digunakan "
             "sebagai image encoder. Lapisan klasifikasi terakhir dihapus sehingga global average "
             "pooling layer menghasilkan feature vector berukuran 512 dimensi. Input gambar "
             "diproses dengan resize ke 224x224 piksel dan normalisasi menggunakan mean serta "
             "standar deviasi ImageNet."),

    ("subsection", "2.2.6 Vision-Language Model: Qwen2-VL-7B-Instruct"),
    ("body", "Vision-Language Model (VLM) adalah kelas model yang mampu memproses input berupa gambar "
             "dan teks secara bersamaan. Qwen2-VL-7B-Instruct adalah VLM open-source dengan 7 miliar "
             "parameter yang dikembangkan oleh Alibaba, terdiri dari visual token encoder dan decoder "
             "berbasis Qwen2-7B. Model ini mampu menghasilkan deskripsi teks yang detail dari berbagai "
             "jenis gambar, termasuk grafik, diagram, dan tabel, melalui mekanisme instruksi "
             "berbasis teks."),

    ("body", "Dalam penelitian ini, Qwen2-VL-7B-Instruct digunakan sebagai frozen captioner (tidak "
             "di-fine-tune) untuk menghasilkan deskripsi teks dari gambar grafik pada dataset "
             "EssayJudge. Karena keterbatasan memori GPU, model dikuantisasi ke presisi 4-bit "
             "menggunakan teknik NF4 (Normal Float 4-bit) dengan library bitsandbytes, sehingga dapat "
             "dijalankan pada GPU Kaggle Tesla P100 16GB. Proses captioning dilakukan secara offline "
             "sebelum pelatihan model scoring agar tidak menambah beban komputasi selama training."),

    ("subsection", "2.2.7 DePlot"),
    ("body", "DePlot adalah model yang dikembangkan oleh Liu et al. (2023) yang melakukan translasi "
             "gambar grafik menjadi tabel data terstruktur dalam format linearized markdown. Model ini "
             "dibangun di atas arsitektur Pix2Struct dengan 282 juta parameter dan menerima gambar "
             "grafik sebagai input dengan prompt \"Generate underlying data table of the figure "
             "below:\". Output DePlot berformat header dan baris data, misalnya: \"Header: Tahun | "
             "Nilai\\nRow 1: 2010 | 45,2\"."),

    ("body", "Format tabel terstruktur dari DePlot memungkinkan model bahasa berikutnya untuk "
             "menghasilkan narasi grafik yang akurat secara faktual karena menggunakan data yang "
             "diekstraksi secara eksplisit alih-alih melakukan inferensi visual. DePlot efektif untuk "
             "bar chart, pie chart, dan line chart yang memiliki struktur tabel yang jelas, namun "
             "tidak dapat digunakan untuk flow chart, peta, dan gambar komposit. Pada pipeline "
             "penelitian ini, DePlot berperan sebagai tahap pertama (ekstraksi tabel) sebelum "
             "Qwen2-VL-7B menghasilkan deskripsi naratif pada tahap kedua."),

    ("subsection", "2.2.8 Metrik Evaluasi: Quadratic Weighted Kappa"),
    ("body", "Quadratic Weighted Kappa (QWK) adalah metrik yang mengukur tingkat kesepakatan antara "
             "dua set penilaian (predicted vs. ground truth) dengan memberikan penalti kuadrat untuk "
             "perbedaan yang lebih besar. QWK dihitung menggunakan matriks bobot kuadrat W di mana "
             "W[i,j] = (i-j)^2 / (N-1)^2, kemudian kappa = 1 - (sum(W*O) / sum(W*E)), dengan O "
             "adalah matriks frekuensi yang diamati dan E adalah matriks frekuensi yang diharapkan "
             "berdasarkan distribusi marjinal."),

    ("body", "Rentang nilai QWK adalah -1 hingga +1, di mana nilai 0 menunjukkan kesepakatan setara "
             "dengan kebetulan dan nilai 1 menunjukkan kesepakatan sempurna. Dalam literatur AES, "
             "nilai QWK di atas 0,7 umumnya dianggap sebagai kesepakatan yang kuat antar penilai. "
             "QWK dipilih sebagai metrik utama karena merupakan standar benchmark AES (digunakan "
             "dalam kompetisi ASAP dan dataset EssayJudge), sensitif terhadap kesalahan besar melalui "
             "penalti kuadrat, dan sesuai untuk data skor ordinal diskrit. Dalam penelitian ini, "
             "dilaporkan 10 nilai QWK per-trait serta rata-ratanya sebagai metrik perbandingan utama "
             "antar eksperimen."),

    ("section", "2.3 Analisis Perbandingan Metode"),
    ("body", "Berdasarkan tinjauan pustaka dan dasar teori yang telah dipaparkan, subbab ini "
             "menganalisis alasan pemilihan metode yang digunakan dalam penelitian ini secara "
             "kualitatif dan kuantitatif, sebagaimana disyaratkan oleh template penulisan skripsi "
             "DTETI UGM."),

    ("body", "Pemilihan late fusion sebagai strategi fusi pada Track A didasarkan pada dua "
             "pertimbangan. Secara teoritis, late fusion mempertahankan encoder independen untuk teks "
             "dan gambar sehingga masing-masing dapat dioptimalkan sesuai karakteristik modalitasnya "
             "tanpa interferensi silang. Secara empiris, hasil perbandingan tiga strategi fusi "
             "(Langkah 2, dengan konfigurasi identik menggunakan BERT + ResNet18) menunjukkan late "
             "fusion mencapai test QWK 0,4838, mengungguli intermediate fusion (0,4799) dan "
             "early fusion (0,4777)."),

    ("body", "Pemilihan RoBERTa sebagai text encoder menggantikan BERT didasarkan pada keunggulan "
             "pre-training yang lebih robust. RoBERTa menghilangkan NSP yang tidak relevan untuk "
             "tugas regresi skor esai, menggunakan dynamic masking per epoch, dan dilatih pada lebih "
             "banyak data dengan batch yang lebih besar. Hasil eksperimen (Langkah 3) mengkonfirmasi "
             "keunggulan ini: RoBERTa dengan late fusion mencapai test QWK 0,5126 dibandingkan BERT "
             "dengan late fusion 0,4838, peningkatan sebesar 0,029 poin dalam kondisi "
             "yang sepenuhnya identik."),

    ("body", "Motivasi pendekatan text-to-text pada Track B bersumber dari rantai bukti literatur. "
             "DePlot (Liu et al., 2023) membuktikan bahwa dekomposisi grafik menjadi teks terstruktur "
             "meningkatkan reasoning berbasis model bahasa. Bursztyn et al. (2024) menunjukkan "
             "superioritas representasi teks atas gambar untuk chart question answering (99% vs. 63%). "
             "VisText (Tang et al., 2023) mengkonfirmasi bahwa kualitas caption lebih menentukan "
             "performa downstream dibandingkan skala model. Pendekatan T2T menghilangkan image encoder "
             "dari loop pelatihan, mengurangi jumlah parameter yang dioptimalkan, dan memungkinkan "
             "pemanfaatan kemampuan pemahaman bahasa RoBERTa secara penuh."),

    ("body", "Pemilihan DePlot sebagai captioner khusus untuk bar chart dan pie chart didasarkan pada "
             "kriteria kualitas, bukan semata-mata angka QWK. Tinjauan manual terhadap 100 sampel "
             "caption Qwen7B menunjukkan tingkat kesalahan sekitar 22% pada bar chart dan pie chart "
             "berupa kesalahan nilai data, identifikasi puncak yang salah, dan kesalahan skala. "
             "Meskipun MATCHA menghasilkan skor QWK lebih tinggi (0,5213 vs. 0,5026 DePlot), tinjauan "
             "kualitas caption mengkonfirmasi tingkat kesalahan yang serupa, mengindikasikan skor yang "
             "tidak dapat dipercaya. DePlot dipilih karena menghasilkan ekstraksi tabel yang akurat "
             "secara struktural dan dapat direproduksi, konsisten dengan desain arsitekturnya untuk "
             "jenis grafik terstruktur."),
]

# ── Italic terms ─────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'vision-language', r'text-to-text', r'open-source',
    r'multi-task learning', r'multi-task', r'per-trait',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'feature vector', r'feature map', r'feature engineering',
    r'encoder', r'decoder', r'tokenizer', r'embedding',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream', r'backbone', r'pooling',
    r'dropout', r'batch size', r'learning rate',
    r'epoch', r'checkpoint', r'inference',
    r'softmax', r'sigmoid', r'output head',
    r'loss function', r'gradient', r'backpropagation',
    r'overfitting', r'regularization',
    r'skip connection', r'cross-attention',
    r'one-shot', r'few-shot',
    r'reasoning', r'question answering',
    r'shared encoder', r'image encoder', r'text encoder',
    r'global average pooling',
    r'masked language modeling',
    r'next sentence prediction',
    r'dynamic masking',
    r'self-supervised',
    r'self-supervised learning',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
PT  = lambda pt: {'magnitude': pt * 12700, 'unit': 'EMU'}
CM  = lambda cm: {'magnitude': cm * 914400 / 100 * 100, 'unit': 'EMU'}
IN  = lambda inc: {'magnitude': inc * 914400, 'unit': 'EMU'}

def pt_to_emu(pt):
    return int(pt * 12700)

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build document ────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []  # (start, end, type)

for seg_type, text in segments:
    start = len(full_text) + 1  # +1 for doc offset
    full_text += text + '\n'
    end = len(full_text)        # exclusive, includes \n
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# Find italic ranges
italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges found: {len(italic_ranges)}')

# ── Insert text (reverse order to preserve indices) ───────────────────────────
requests = []

# Insert all text forward
for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', 1, TAB_ID))

# Apply paragraph and text styles
for start, end, seg_type, text in seg_positions:
    if seg_type == 'chapter':
        for line in text.split('\n'):
            if line:
                # will handle via paragraph style below
                pass
        requests.append(req_para_style(start, end, TAB_ID, 'CENTER',
                                        space_above=0, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=14))

    elif seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'subsection':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=6, space_below=3))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type == 'numbered':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=0,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type == 'subnumbered':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=35.43,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

# Apply italics
for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
