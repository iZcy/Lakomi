import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'  # BAB II - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Step 1: Clear existing content ────────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1

if end_index > 2:
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': [{
            'deleteContentRange': {
                'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': TAB_ID}
            }
        }]}
    ).execute()
    print(f'Cleared {end_index - 2} characters.')

# ── Content — only papers from flow.md ────────────────────────────────────────
#
# Papers in flow.md:
#   Step 1: Gold et al. 2025 (BERT-ResNet Cross-Attention)
#   Step 2: Fusion comparison papers (generic, no specific title listed)
#   Step 3: Automatic Essay Multi-dimensional Scoring paper (no author listed)
#   Step 4: EDU-CIRCUIT-HW (2025)
#   Step 6: DePlot (Liu et al. 2023), MATCHA (Liu et al. 2023),
#            Multimodal Chart Retrieval = Bursztyn et al. (2024, IEEE VIS)
#   Dataset: EssayJudge (Singh et al. 2024)

segments = [
    ("chapter", "BAB II\nTINJAUAN PUSTAKA DAN DASAR TEORI"),

    ("section", "2.1 Tinjauan Pustaka"),
    ("body", "Subbab ini membahas penelitian-penelitian terdahulu yang relevan dengan topik "
             "skripsi ini, mencakup penelitian di bidang automated essay scoring (AES), strategi "
             "fusion multimoda, dan pemahaman grafik berbasis teks. Setiap penelitian dianalisis "
             "berdasarkan permasalahan yang diselesaikan, kontribusi utama, serta keterbatasan "
             "yang dimiliki, kemudian diidentifikasi celah penelitian yang menjadi landasan "
             "pengembangan penelitian ini."),

    # ── (A) EssayJudge dataset ──────────────────────────────────────────────
    ("body", "Singh et al. (2024) memperkenalkan EssayJudge sebagai benchmark pertama untuk "
             "penilaian esai multimoda pada tugas IELTS Task 1. Dataset ini memuat 1.054 esai "
             "mahasiswa beserta gambar grafik profesional dan anotasi skor untuk sepuluh dimensi "
             "penilaian. Penelitian tersebut mengevaluasi kemampuan beberapa multimodal large "
             "language model dalam kondisi zero-shot sebagai baseline, dengan rata-rata QWK "
             "sekitar 0,164. Keterbatasan utama EssayJudge terletak pada fakta bahwa seluruh "
             "model yang diujikan bersifat zero-shot tanpa fine-tuning, sehingga belum ada "
             "sistem AES terlatih yang diusulkan secara eksplisit untuk dataset ini."),

    # ── (B) Gold 2025 — fusion motivation ───────────────────────────────────
    ("body", "Gold et al. (2025) meneliti strategi fusion untuk model multimoda berbasis BERT "
             "dan ResNet18 dengan mekanisme cross-attention sebagai intermediate fusion. "
             "Penelitian ini memotivasi penggunaan arsitektur dual-encoder (teks + gambar) "
             "untuk tugas yang melibatkan dua modalitas berbeda, dan menunjukkan bahwa "
             "intermediate fusion dengan cross-attention dapat mengungguli early fusion pada "
             "beberapa tugas klasifikasi visi-teks. Keterbatasan penelitian Gold et al. adalah "
             "temuan yang bersifat tugas-spesifik; hasil eksperimen perbandingan dalam penelitian "
             "ini (Langkah 2) menunjukkan bahwa late fusion memberikan hasil terbaik untuk "
             "penilaian esai IELTS Task 1, di mana pemisahan encoder per modalitas lebih "
             "menguntungkan karena teks esai dan gambar grafik memiliki karakteristik "
             "representasi yang sangat berbeda."),

    # ── (C) EDU-CIRCUIT-HW ──────────────────────────────────────────────────
    ("body", "Zhao et al. (2025) memperkenalkan EDU-CIRCUIT-HW, sebuah benchmark evaluasi "
             "untuk kemampuan multimodal LLM pada konten STEM tertulis tangan di tingkat "
             "universitas. Penelitian ini memvalidasi penggunaan pipeline image-to-text berbasis "
             "VLM untuk penilaian pendidikan, menunjukkan bahwa interpretasi teks dari konten "
             "visual meningkatkan kinerja sistem penilaian otomatis dalam konteks akademik. "
             "Relevansi terhadap penelitian ini terletak pada kesamaan domain penilaian berbasis "
             "gambar, meskipun EssayJudge menggunakan gambar grafik profesional dan bukan "
             "tulisan tangan mahasiswa. Keterbatasan EDU-CIRCUIT-HW adalah fokusnya pada "
             "evaluasi model zero-shot tanpa fine-tuning pada dataset penilaian yang khusus."),

    # ── (D) DePlot ──────────────────────────────────────────────────────────
    ("body", "Liu et al. (2023) mengembangkan DePlot, sebuah model yang melakukan translasi "
             "gambar grafik menjadi tabel data terstruktur dalam satu langkah (one-shot "
             "plot-to-table translation). Dibangun di atas arsitektur Pix2Struct dengan 282 juta "
             "parameter, DePlot memungkinkan model bahasa melakukan reasoning atas data grafik "
             "tanpa melihat gambar secara langsung, dan terbukti meningkatkan akurasi reasoning "
             "grafik hingga 24,0% secara absolut dibandingkan pendekatan berbasis gambar "
             "langsung. Keterbatasan DePlot adalah hanya bekerja efektif pada grafik "
             "terstruktur seperti bar chart, pie chart, dan line chart, sedangkan flow chart, "
             "peta, dan gambar komposit tidak memiliki struktur tabel yang dapat diekstraksi."),

    # ── (E) MATCHA ──────────────────────────────────────────────────────────
    ("body", "Liu et al. (2023) juga mengembangkan MATCHA (Math Reasoning and Chart "
             "Derendering), sebuah model visual-language yang di-pre-train secara khusus untuk "
             "pemahaman grafik dan penalaran matematis. MATCHA menggunakan Pix2Struct sebagai "
             "backbone dan ditujukan untuk menghasilkan deskripsi atau menjawab pertanyaan "
             "tentang grafik secara langsung dari gambar. Dalam penelitian ini, MATCHA "
             "dievaluasi sebagai kandidat captioner khusus untuk bar chart dan pie chart dan "
             "menghasilkan skor QWK 0,5213. Namun, tinjauan kualitas manual terhadap 100 sampel "
             "caption mengkonfirmasi tingkat kesalahan yang tinggi pada bar chart dan pie chart, "
             "sehingga MATCHA ditolak meskipun skor QWK-nya lebih tinggi dibandingkan DePlot."),

    # ── (F) Bursztyn et al. 2024 (Multimodal Chart Retrieval / T2T motivation)
    ("body", "Bursztyn et al. (2024) melakukan studi mendalam mengenai representasi grafik "
             "untuk chart question answering pada konferensi IEEE VIS 2024. Hasil utama "
             "penelitian ini menunjukkan bahwa representasi berbasis teks secara signifikan "
             "mengungguli representasi berbasis gambar, dengan akurasi 99% dibandingkan 63% "
             "pada model berbasis visi. Hal ini menjadi motivasi akademis utama pendekatan "
             "text-to-text yang dikembangkan dalam penelitian ini. Perlu dicatat bahwa "
             "Bursztyn et al. menggunakan spesifikasi data terstruktur (CSV/JSON) sebagai "
             "input teks, sedangkan dataset EssayJudge tidak menyertakan data terstruktur "
             "di balik gambar sehingga diperlukan VLM untuk mengekstraksi konten grafik "
             "secara langsung dari gambar."),

    # ── Research gap ────────────────────────────────────────────────────────
    ("body", "Berdasarkan tinjauan pustaka di atas, terdapat beberapa celah penelitian yang "
             "belum terisi. Pertama, sistem AES yang ada umumnya hanya memproses modalitas "
             "teks tanpa mempertimbangkan gambar grafik yang dirujuk esai, sementara pendekatan "
             "berbasis LLM pada EssayJudge masih bersifat zero-shot. Kedua, manfaat teknik "
             "chart-to-text seperti DePlot yang terbukti meningkatkan reasoning grafik belum "
             "diterapkan pada domain penilaian esai. Ketiga, belum ada penelitian yang secara "
             "sistematis membandingkan strategi fusion (early, intermediate, late) maupun "
             "pendekatan text-to-text berbasis caption VLM untuk penilaian esai IELTS multimoda. "
             "Penelitian ini mengisi celah tersebut dengan mengusulkan dan membandingkan dua "
             "jalur pendekatan secara bersamaan: fusi multimoda terlatih dan text-to-text "
             "berbasis caption dari VLM."),

    # ── 2.2 Dasar Teori ──────────────────────────────────────────────────────
    ("section", "2.2 Dasar Teori"),

    ("subsection", "2.2.1 Automated Essay Scoring"),
    ("body", "Automated Essay Scoring (AES) adalah tugas penilaian kualitas esai secara "
             "otomatis menggunakan komputer tanpa melibatkan penilaian manusia secara langsung. "
             "Sejarah AES dimulai dari sistem berbasis aturan seperti e-rater (Educational "
             "Testing Service, 1999) yang mengandalkan fitur linguistik terstruktur seperti "
             "panjang esai, keragaman kosakata, dan koherensi sintaksis. Seiring perkembangan "
             "kecerdasan buatan, AES berevolusi melalui pendekatan feature engineering "
             "menggunakan SVM dan regresi, kemudian beralih ke pembelajaran mendalam "
             "berbasis LSTM dan Transformer."),

    ("body", "Penilaian esai dapat bersifat holistik (satu skor keseluruhan) atau analitik "
             "(beberapa dimensi trait). Penilaian multi-trait lebih informatif karena "
             "mengidentifikasi kekuatan dan kelemahan spesifik pada setiap dimensi kualitas. "
             "IELTS Task 1 merupakan tugas deskripsi data di mana peserta tes diminta untuk "
             "mendeskripsikan informasi yang tersaji dalam sebuah grafik, tabel, atau diagram "
             "dalam minimal 150 kata. Karena esai IELTS Task 1 secara inheren mengacu pada "
             "konten visual grafik, penilaian yang valid memerlukan pemahaman terhadap kedua "
             "modalitas: teks esai dan gambar grafik yang dirujuk."),

    ("subsection", "2.2.2 Multi-task Learning"),
    ("body", "Multi-task learning adalah paradigma pelatihan di mana satu model dioptimalkan "
             "secara bersamaan untuk beberapa tugas terkait menggunakan shared encoder. Dalam "
             "konteks penilaian esai multi-trait, satu encoder teks menghasilkan representasi "
             "umum yang kemudian diteruskan ke sepuluh output head independen, masing-masing "
             "memprediksi satu dimensi penilaian. Pendekatan ini memberikan sinyal gradien "
             "sepuluh kali lipat per pembaruan bobot dibandingkan pelatihan per-trait secara "
             "terpisah, sekaligus mendorong encoder mempelajari representasi yang dapat "
             "ditransfer lintas trait."),

    ("body", "Keunggulan utama multi-task learning untuk AES pada dataset berukuran kecil "
             "adalah regularisasi implisit: karena encoder harus menghasilkan representasi "
             "yang berguna untuk semua trait sekaligus, model cenderung lebih tahan terhadap "
             "overfitting. Hal ini sangat relevan untuk dataset EssayJudge yang hanya memiliki "
             "sekitar 738 sampel pelatihan, di mana pelatihan per-trait secara terpisah akan "
             "semakin rentan terhadap overfitting."),

    ("subsection", "2.2.3 Strategi Multimodal Fusion"),
    ("body", "Multimodal fusion adalah teknik menggabungkan representasi dari dua atau lebih "
             "modalitas input untuk menghasilkan prediksi bersama. Terdapat tiga strategi "
             "fusion utama yang dibedakan berdasarkan titik penggabungan dalam arsitektur "
             "model. Early fusion menggabungkan fitur dari kedua modalitas sebelum melewati "
             "encoder utama, menciptakan ketergantungan ketat antar modalitas sejak awal. "
             "Intermediate fusion menggabungkan representasi pada lapisan tengah, misalnya "
             "melalui mekanisme cross-attention antara fitur teks dan gambar. Late fusion "
             "mempertahankan encoder independen untuk masing-masing modalitas hingga tahap "
             "akhir, kemudian menggabungkan representasi final melalui concatenation sebelum "
             "lapisan keluaran."),

    ("body", "Late fusion memiliki keunggulan modularitas: setiap encoder dapat dioptimalkan "
             "secara independen sesuai karakteristik modalitasnya tanpa gangguan silang. Pada "
             "kasus di mana kedua modalitas memiliki distribusi representasi yang sangat "
             "berbeda, seperti teks esai dan gambar grafik, late fusion umumnya memberikan "
             "hasil yang lebih stabil karena menghindari interferensi representasi antar "
             "modalitas di lapisan awal pelatihan."),

    ("subsection", "2.2.4 BERT dan RoBERTa"),
    ("body", "BERT (Bidirectional Encoder Representations from Transformers) adalah model "
             "bahasa berbasis Transformer yang dilatih secara self-supervised menggunakan "
             "dua tugas pre-training: masked language modeling (MLM) dan next sentence "
             "prediction (NSP). BERT menggunakan token khusus [CLS] yang diletakkan di awal "
             "setiap urutan input; representasi [CLS] pada lapisan terakhir (768 dimensi) "
             "digunakan sebagai representasi kalimat untuk tugas downstream seperti "
             "klasifikasi dan regresi."),

    ("body", "RoBERTa (Robustly Optimized BERT Approach) adalah versi BERT yang dioptimalkan "
             "dengan menghilangkan tugas NSP yang terbukti kurang bermanfaat, menggunakan "
             "dynamic masking, batch size yang lebih besar, dan lebih banyak data "
             "pre-training. Perbedaan ini menghasilkan representasi yang lebih kuat untuk "
             "tugas downstream, terutama pada tugas regresi dan klasifikasi urutan. Dalam "
             "penelitian ini digunakan varian roberta-base dengan 12 lapisan Transformer, "
             "dimensi hidden 768, dan sekitar 125 juta parameter."),

    ("subsection", "2.2.5 ResNet18"),
    ("body", "ResNet (Residual Network) adalah arsitektur jaringan saraf konvolusi yang "
             "memperkenalkan skip connection (koneksi residual) untuk mengatasi masalah "
             "vanishing gradient pada jaringan yang sangat dalam. Skip connection "
             "memungkinkan gradien mengalir langsung melewati beberapa lapisan selama "
             "backpropagation, sehingga jaringan dengan puluhan lapisan dapat dilatih "
             "secara efektif. ResNet18 adalah varian ResNet dengan 18 lapisan yang "
             "menyeimbangkan kapasitas representasi dan efisiensi komputasi."),

    ("body", "Dalam penelitian ini, ResNet18 yang telah di-pre-train pada dataset ImageNet "
             "digunakan sebagai image encoder. Lapisan klasifikasi terakhir dihapus sehingga "
             "global average pooling layer menghasilkan feature vector berukuran 512 dimensi. "
             "Input gambar diproses dengan resize ke 224x224 piksel dan normalisasi "
             "menggunakan mean serta standar deviasi ImageNet."),

    ("subsection", "2.2.6 Vision-Language Model: Qwen2-VL-7B-Instruct"),
    ("body", "Vision-Language Model (VLM) adalah kelas model yang mampu memproses input "
             "berupa gambar dan teks secara bersamaan. Qwen2-VL-7B-Instruct adalah VLM "
             "open-source dengan 7 miliar parameter yang dikembangkan oleh Alibaba, "
             "terdiri dari visual token encoder dan decoder berbasis Qwen2-7B. Model ini "
             "mampu menghasilkan deskripsi teks yang detail dari berbagai jenis gambar, "
             "termasuk grafik, diagram, dan tabel, melalui mekanisme instruksi berbasis teks."),

    ("body", "Dalam penelitian ini, Qwen2-VL-7B-Instruct digunakan sebagai frozen captioner "
             "(tidak di-fine-tune) untuk menghasilkan deskripsi teks dari gambar grafik pada "
             "dataset EssayJudge. Karena keterbatasan memori GPU, model dikuantisasi ke "
             "presisi 4-bit menggunakan teknik NF4 (Normal Float 4-bit) dengan library "
             "bitsandbytes, sehingga dapat dijalankan pada GPU Kaggle Tesla P100 16GB. "
             "Proses captioning dilakukan secara offline sebelum pelatihan model scoring "
             "agar tidak menambah beban komputasi selama training."),

    ("subsection", "2.2.7 DePlot"),
    ("body", "DePlot adalah model yang dikembangkan oleh Liu et al. (2023) yang melakukan "
             "translasi gambar grafik menjadi tabel data terstruktur dalam format linearized "
             "markdown. Model ini dibangun di atas arsitektur Pix2Struct dengan 282 juta "
             "parameter dan menerima gambar grafik sebagai input dengan prompt \"Generate "
             "underlying data table of the figure below:\". Output DePlot berformat header "
             "dan baris data, misalnya: \"Header: Tahun | Nilai\\nRow 1: 2010 | 45,2\"."),

    ("body", "Format tabel terstruktur dari DePlot memungkinkan model bahasa berikutnya "
             "untuk menghasilkan narasi grafik yang akurat secara faktual karena menggunakan "
             "data yang diekstraksi secara eksplisit. DePlot efektif untuk bar chart, "
             "pie chart, dan line chart yang memiliki struktur tabel yang jelas, namun "
             "tidak dapat digunakan untuk flow chart, peta, dan gambar komposit. Pada "
             "pipeline penelitian ini, DePlot berperan sebagai tahap pertama (ekstraksi "
             "tabel) sebelum Qwen2-VL-7B menghasilkan deskripsi naratif pada tahap kedua."),

    ("subsection", "2.2.8 Metrik Evaluasi: Quadratic Weighted Kappa"),
    ("body", "Quadratic Weighted Kappa (QWK) adalah metrik yang mengukur tingkat kesepakatan "
             "antara dua set penilaian (predicted vs. ground truth) dengan memberikan penalti "
             "kuadrat untuk perbedaan yang lebih besar. QWK dihitung menggunakan matriks "
             "bobot kuadrat W di mana W[i,j] = (i-j)^2 / (N-1)^2, kemudian "
             "kappa = 1 - (sum(W*O) / sum(W*E)), dengan O adalah matriks frekuensi yang "
             "diamati dan E adalah matriks frekuensi yang diharapkan berdasarkan distribusi "
             "marjinal."),

    ("body", "Rentang nilai QWK adalah -1 hingga +1, di mana nilai 0 menunjukkan kesepakatan "
             "setara dengan kebetulan dan nilai 1 menunjukkan kesepakatan sempurna. Dalam "
             "literatur AES, nilai QWK di atas 0,7 umumnya dianggap sebagai kesepakatan yang "
             "kuat antar penilai. QWK dipilih sebagai metrik utama karena merupakan standar "
             "benchmark AES (digunakan dalam kompetisi ASAP dan dataset EssayJudge), sensitif "
             "terhadap kesalahan besar melalui penalti kuadrat, dan sesuai untuk data skor "
             "ordinal diskrit. Dalam penelitian ini, dilaporkan 10 nilai QWK per-trait serta "
             "rata-ratanya sebagai metrik perbandingan utama antar eksperimen."),

    # ── 2.3 Analisis Perbandingan Metode ────────────────────────────────────
    ("section", "2.3 Analisis Perbandingan Metode"),
    ("body", "Berdasarkan tinjauan pustaka dan dasar teori yang telah dipaparkan, subbab ini "
             "menganalisis alasan pemilihan metode yang digunakan dalam penelitian ini secara "
             "kualitatif dan kuantitatif."),

    ("body", "Pemilihan late fusion sebagai strategi fusi pada Track A didasarkan pada dua "
             "pertimbangan. Secara teoritis, late fusion mempertahankan encoder independen "
             "untuk teks dan gambar sehingga masing-masing dapat dioptimalkan sesuai "
             "karakteristik modalitasnya tanpa interferensi silang. Secara empiris, hasil "
             "perbandingan tiga strategi fusion (Langkah 2, konfigurasi identik menggunakan "
             "BERT + ResNet18) menunjukkan late fusion mencapai test QWK 0,4838, mengungguli "
             "intermediate fusion (0,4799) dan early fusion (0,4777), konsisten dengan temuan "
             "bahwa modularitas encoder menguntungkan untuk modalitas yang heterogen."),

    ("body", "Pemilihan RoBERTa sebagai text encoder menggantikan BERT didasarkan pada "
             "keunggulan pre-training yang lebih robust. RoBERTa menghilangkan NSP yang tidak "
             "relevan untuk tugas regresi skor esai, menggunakan dynamic masking, dan dilatih "
             "pada lebih banyak data dengan batch yang lebih besar. Hasil eksperimen (Langkah "
             "3) mengkonfirmasi keunggulan ini: RoBERTa dengan late fusion mencapai test QWK "
             "0,5126 dibandingkan BERT dengan late fusion 0,4838, peningkatan sebesar 0,029 "
             "poin dalam kondisi yang sepenuhnya identik."),

    ("body", "Motivasi pendekatan text-to-text pada Track B bersumber dari rantai bukti "
             "literatur. DePlot (Liu et al., 2023) membuktikan bahwa dekomposisi grafik "
             "menjadi teks terstruktur meningkatkan reasoning berbasis model bahasa. "
             "Bursztyn et al. (2024) menunjukkan superioritas representasi teks atas gambar "
             "untuk chart question answering (99% vs. 63%). EDU-CIRCUIT-HW (Zhao et al., "
             "2025) memvalidasi penggunaan pipeline image-to-text berbasis VLM dalam konteks "
             "penilaian akademik. Pendekatan T2T menghilangkan image encoder dari loop "
             "pelatihan, mengurangi parameter yang dioptimalkan, dan memanfaatkan kemampuan "
             "pemahaman bahasa RoBERTa secara penuh."),

    ("body", "Pemilihan DePlot sebagai captioner khusus untuk bar chart dan pie chart "
             "didasarkan pada kriteria kualitas, bukan semata-mata angka QWK. MATCHA "
             "menghasilkan skor QWK lebih tinggi (0,5213 vs. 0,5026), namun tinjauan kualitas "
             "manual terhadap 100 sampel caption mengkonfirmasi tingkat kesalahan yang tinggi "
             "pada bar chart dan pie chart berupa nilai data yang terbalik, identifikasi "
             "puncak yang salah, dan kesalahan skala. DePlot dipilih karena menghasilkan "
             "ekstraksi tabel yang akurat secara struktural dan dapat direproduksi, konsisten "
             "dengan desain arsitekturnya yang khusus untuk grafik terstruktur."),
]

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'vision-language', r'text-to-text', r'open-source',
    r'multi-task learning', r'multi-task', r'per-trait',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'feature vector', r'feature map', r'feature engineering',
    r'encoder', r'decoder', r'tokenizer', r'embedding',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream', r'backbone', r'pooling',
    r'dropout', r'batch size', r'learning rate',
    r'epoch', r'checkpoint', r'inference',
    r'output head', r'loss function', r'gradient',
    r'overfitting', r'regularization',
    r'skip connection', r'cross-attention',
    r'one-shot', r'few-shot',
    r'reasoning', r'question answering',
    r'shared encoder', r'image encoder', r'text encoder',
    r'global average pooling',
    r'self-supervised',
    r'masked language modeling',
    r'next sentence prediction',
    r'dynamic masking',
    r'fully connected',
    r'plot-to-table',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12,
                   font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build full text ────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges found: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
requests = []

for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', 1, TAB_ID))

for start, end, seg_type, text in seg_positions:
    if seg_type == 'chapter':
        requests.append(req_para_style(start, end, TAB_ID, 'CENTER',
                                        space_above=0, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=14))
    elif seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'subsection':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=6, space_below=3))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))
    elif seg_type in ('numbered', 'subnumbered'):
        indent = 35.43 if seg_type == 'subnumbered' else 0
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=indent,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
