import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.ulqqr4hsh3xe'  # BAB II - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Clear existing content ─────────────────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1

if end_index > 2:
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': [{
            'deleteContentRange': {
                'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': TAB_ID}
            }
        }]}
    ).execute()
    print(f'Cleared {end_index - 2} characters.')

# ── Content ────────────────────────────────────────────────────────────────────
# Subsection numbering:
#   2.2.1  Automated Essay Scoring
#   2.2.2  Multi-task Learning
#   2.2.3  Strategi Multimodal Fusion (expanded: early/intermediate/late)
#   2.2.4  BERT (split from old 2.2.4, with layer detail)
#   2.2.5  RoBERTa (split from old 2.2.4, with layer detail)
#   2.2.6  ResNet18
#   2.2.7  Vision-Language Model: Qwen2-VL-7B-Instruct
#   2.2.8  DePlot
#   2.2.9  MATCHA (new)
#   2.2.10 Metode Regresi: Arsitektur Scoring Head (new)
#   2.2.11 Uji Signifikansi Statistik (new)
#   2.2.12 Metrik Evaluasi: Quadratic Weighted Kappa

segments = [
    ("chapter", "BAB II\nTINJAUAN PUSTAKA DAN DASAR TEORI"),

    # ── 2.1 Tinjauan Pustaka ─────────────────────────────────────────────────
    ("section", "2.1 Tinjauan Pustaka"),
    ("body", "Subbab ini membahas penelitian-penelitian terdahulu yang relevan dengan topik "
             "skripsi ini, mencakup penelitian di bidang automated essay scoring, strategi "
             "fusion multimoda berbasis visi-teks, dan pemahaman grafik berbasis teks. Setiap "
             "penelitian dianalisis berdasarkan permasalahan yang diselesaikan, kontribusi "
             "utama, serta keterbatasan yang dimiliki, kemudian diidentifikasi celah penelitian "
             "yang menjadi landasan pengembangan penelitian ini."),

    ("body", "Singh et al. (2024) memperkenalkan EssayJudge sebagai benchmark pertama untuk "
             "penilaian esai multimoda pada tugas IELTS Task 1. Dataset ini memuat 1.054 esai "
             "mahasiswa beserta gambar grafik profesional dan anotasi skor untuk sepuluh dimensi "
             "penilaian. Penelitian tersebut mengevaluasi kemampuan beberapa multimodal large "
             "language model dalam kondisi zero-shot dan menunjukkan bahwa model-model tersebut "
             "belum mampu memberikan penilaian yang akurat tanpa pelatihan khusus pada domain "
             "IELTS Task 1. Keterbatasan utama EssayJudge adalah tidak adanya sistem AES "
             "terlatih yang diusulkan secara eksplisit, sehingga terbuka peluang bagi "
             "pendekatan fine-tuning yang lebih terspesialisasi."),

    ("body", "Gold et al. (2025) meneliti strategi fusion untuk model multimoda yang "
             "menggabungkan encoder teks berbasis BERT dengan encoder gambar berbasis ResNet. "
             "Penelitian ini membandingkan beberapa strategi penggabungan representasi, "
             "termasuk intermediate fusion dengan mekanisme cross-attention, dan menunjukkan "
             "keunggulannya dibandingkan early fusion pada beberapa tugas klasifikasi visi-teks. "
             "Keterbatasan penelitian ini adalah temuan yang bersifat tugas-spesifik sehingga "
             "perlu divalidasi pada domain yang berbeda, termasuk pada tugas penilaian esai "
             "multimoda seperti yang diangkat dalam penelitian ini."),

    ("body", "Zhao et al. (2025) memperkenalkan EDU-CIRCUIT-HW, sebuah benchmark evaluasi "
             "untuk kemampuan multimodal LLM pada konten STEM tertulis tangan di tingkat "
             "universitas. Penelitian ini menunjukkan bahwa pipeline image-to-text berbasis "
             "VLM dapat meningkatkan kinerja sistem penilaian otomatis dalam konteks akademik "
             "dibandingkan pendekatan yang memproses gambar secara langsung. Keterbatasan "
             "EDU-CIRCUIT-HW adalah fokusnya pada evaluasi model zero-shot tanpa fine-tuning "
             "pada dataset penilaian yang spesifik, sehingga belum menunjukkan potensi penuh "
             "pendekatan image-to-text ketika dikombinasikan dengan pelatihan yang ditargetkan."),

    ("body", "Liu et al. (2023) mengembangkan DePlot, sebuah model yang melakukan translasi "
             "gambar grafik menjadi tabel data terstruktur dalam satu langkah (one-shot "
             "plot-to-table translation). Dibangun di atas arsitektur Pix2Struct dengan 282 "
             "juta parameter, DePlot memungkinkan model bahasa melakukan reasoning atas data "
             "grafik tanpa memproses gambar secara langsung, dan terbukti meningkatkan akurasi "
             "reasoning grafik hingga 24,0% secara absolut dibandingkan pendekatan berbasis "
             "gambar langsung pada benchmark ChartQA. Keterbatasan DePlot adalah hanya "
             "bekerja efektif pada grafik terstruktur seperti bar chart, pie chart, dan "
             "line chart yang memiliki representasi tabel yang dapat diekstraksi, "
             "sedangkan flow chart, peta, dan gambar komposit tidak dapat diproses."),

    ("body", "Liu et al. (2023) juga mengembangkan MATCHA (Math Reasoning and Chart "
             "Understanding), sebuah model visual-language yang di-pre-train secara khusus "
             "untuk pemahaman grafik dan penalaran matematis. MATCHA menggunakan Pix2Struct "
             "sebagai backbone dan dirancang untuk menghasilkan deskripsi teks atau menjawab "
             "pertanyaan tentang grafik secara langsung dari gambar tanpa memerlukan tahap "
             "ekstraksi tabel terpisah. Keterbatasan MATCHA adalah keandalan output yang "
             "bergantung pada kemampuan model dalam menginterpretasikan data visual secara "
             "langsung, sehingga rentan terhadap kesalahan halusinasi pada grafik dengan "
             "skala atau format yang tidak umum."),

    ("body", "Bursztyn et al. (2024) melakukan studi mendalam mengenai representasi grafik "
             "untuk chart question answering pada konferensi IEEE VIS 2024. Hasil utama "
             "penelitian ini menunjukkan bahwa representasi berbasis teks secara signifikan "
             "mengungguli representasi berbasis gambar, dengan akurasi 99% dibandingkan 63% "
             "pada model berbasis visi untuk tugas yang sama. Temuan ini mengonfirmasi bahwa "
             "informasi teks yang diekstraksi dari grafik lebih efektif sebagai input untuk "
             "model bahasa dibandingkan fitur visual langsung. Keterbatasan penelitian "
             "Bursztyn et al. adalah penggunaan spesifikasi data terstruktur (CSV/JSON) "
             "yang sudah tersedia, sehingga tidak membahas skenario di mana data terstruktur "
             "tidak tersedia dan harus diekstraksi dari gambar menggunakan VLM."),

    ("body", "Berdasarkan tinjauan pustaka di atas, terdapat beberapa celah penelitian yang "
             "belum terisi. Pertama, sistem penilaian esai yang ada umumnya hanya memproses "
             "teks tanpa mempertimbangkan gambar grafik yang dirujuk esai, sementara pendekatan "
             "berbasis LLM pada EssayJudge masih bersifat zero-shot. Kedua, manfaat teknik "
             "chart-to-text seperti yang ditunjukkan DePlot dan Bursztyn et al. belum "
             "diterapkan pada domain penilaian esai. Ketiga, belum ada penelitian yang secara "
             "sistematis membandingkan strategi fusion (early, intermediate, late) maupun "
             "pendekatan text-to-text berbasis caption VLM untuk tugas penilaian esai IELTS "
             "Task 1 multimoda. Penelitian ini mengisi celah tersebut dengan mengusulkan dan "
             "membandingkan dua jalur pendekatan: fusi multimoda terlatih dan text-to-text "
             "berbasis caption VLM."),

    # ── 2.2 Dasar Teori ──────────────────────────────────────────────────────
    ("section", "2.2 Dasar Teori"),

    # 2.2.1 Automated Essay Scoring
    ("subsection", "2.2.1 Automated Essay Scoring"),
    ("body", "Automated Essay Scoring (AES) adalah tugas penilaian kualitas esai secara "
             "otomatis menggunakan komputer tanpa melibatkan penilai manusia secara langsung. "
             "Sejarah AES dimulai dari sistem berbasis aturan seperti e-rater (Educational "
             "Testing Service, 1999) yang mengandalkan fitur linguistik terstruktur seperti "
             "panjang esai, keragaman kosakata, dan koherensi sintaksis. Seiring perkembangan "
             "kecerdasan buatan, AES berevolusi melalui pendekatan feature engineering "
             "menggunakan SVM dan regresi, kemudian beralih ke pembelajaran mendalam "
             "berbasis LSTM dan Transformer."),

    ("body", "Penilaian esai dapat bersifat holistik (satu skor keseluruhan) atau analitik "
             "(beberapa dimensi trait). Penilaian multi-trait lebih informatif karena "
             "mengidentifikasi kekuatan dan kelemahan spesifik pada setiap dimensi kualitas "
             "penulisan. IELTS Task 1 merupakan tugas deskripsi data di mana peserta tes "
             "diminta mendeskripsikan informasi yang tersaji dalam sebuah grafik, tabel, atau "
             "diagram dalam minimal 150 kata. Karena esai IELTS Task 1 secara inheren mengacu "
             "pada konten visual grafik, penilaian yang valid memerlukan pemahaman terhadap "
             "kedua modalitas: teks esai dan gambar grafik yang dirujuk."),

    # 2.2.2 Multi-task Learning
    ("subsection", "2.2.2 Multi-task Learning"),
    ("body", "Multi-task learning adalah paradigma pelatihan di mana satu model dioptimalkan "
             "secara bersamaan untuk beberapa tugas terkait menggunakan shared encoder. Dalam "
             "konteks penilaian esai multi-trait, satu encoder teks menghasilkan representasi "
             "umum yang kemudian diteruskan ke sejumlah output head independen, masing-masing "
             "memprediksi satu dimensi penilaian. Pendekatan ini memberikan sinyal gradien "
             "yang lebih banyak per pembaruan bobot dibandingkan pelatihan per-trait secara "
             "terpisah, sekaligus mendorong encoder mempelajari representasi yang dapat "
             "ditransfer lintas trait."),

    ("body", "Keunggulan utama multi-task learning untuk AES pada dataset berukuran kecil "
             "adalah regularisasi implisit: karena encoder harus menghasilkan representasi "
             "yang berguna untuk semua trait sekaligus, model cenderung lebih tahan terhadap "
             "overfitting dibandingkan pelatihan per-trait yang terpisah. Caruana (1997) "
             "menunjukkan bahwa multi-task learning secara konsisten meningkatkan generalisasi "
             "pada tugas-tugas yang berbagi struktur representasi yang sama."),

    # 2.2.3 Strategi Multimodal Fusion
    ("subsection", "2.2.3 Strategi Multimodal Fusion"),
    ("body", "Multimodal fusion adalah teknik menggabungkan representasi dari dua atau lebih "
             "modalitas input untuk menghasilkan prediksi bersama. Terdapat tiga strategi "
             "fusion utama yang dibedakan berdasarkan titik penggabungan dalam arsitektur "
             "model: early fusion, intermediate fusion, dan late fusion. Baltrusaitis et al. "
             "(2019) memberikan taksonomi komprehensif atas ketiga strategi ini dan menunjukkan "
             "bahwa pemilihannya bergantung pada sifat modalitas, ukuran dataset, dan tujuan "
             "tugas yang ingin diselesaikan."),

    ("body", "Early fusion menggabungkan representasi mentah dari kedua modalitas sebelum "
             "melewati encoder utama yang lebih dalam. Dalam implementasi tipikal, embedding "
             "awal dari teks dan gambar dikoncatenasi atau dijumlahkan, kemudian hasilnya "
             "diproses bersama oleh satu encoder gabungan. Kelebihan pendekatan ini adalah "
             "kemungkinan interaksi lintas-modalitas sejak tahap representasi paling awal. "
             "Namun, fitur dari modalitas yang berbeda sering kali memiliki skala dan "
             "distribusi yang tidak kompatibel, sehingga encoder gabungan lebih sulit "
             "dioptimalkan dan rentan terhadap dominasi satu modalitas."),

    ("body", "Intermediate fusion menggabungkan representasi pada lapisan tengah arsitektur, "
             "setelah masing-masing modalitas telah diproses sebagian oleh encoder-nya sendiri. "
             "Mekanisme yang umum digunakan adalah cross-attention, di mana query berasal dari "
             "satu modalitas dan key serta value berasal dari modalitas lain, sehingga setiap "
             "elemen representasi satu modalitas dapat memperhatikan bagian representasi "
             "modalitas lain yang paling relevan. Kelebihan intermediate fusion adalah "
             "kemampuan menangkap interaksi lintas-modalitas yang lebih kaya dibandingkan "
             "late fusion. Kekurangannya adalah kompleksitas komputasi yang lebih tinggi "
             "dan risiko overfitting yang lebih besar pada dataset berukuran kecil."),

    ("body", "Late fusion mempertahankan encoder yang sepenuhnya independen untuk setiap "
             "modalitas hingga tahap representasi akhir, kemudian menggabungkan representasi "
             "final melalui operasi sederhana seperti concatenation, penjumlahan, atau "
             "perkalian elemen-per-elemen sebelum lapisan output. Setiap encoder "
             "dioptimalkan secara independen sesuai karakteristik modalitasnya tanpa "
             "interferensi dari modalitas lain selama proses encoding. Kelebihan late fusion "
             "adalah stabilitas optimasi yang lebih baik, terutama ketika kedua modalitas "
             "memiliki distribusi representasi yang sangat berbeda. Baltrusaitis et al. "
             "(2019) menunjukkan bahwa late fusion umumnya lebih robust pada dataset kecil "
             "dan menjadi pilihan yang tepat ketika sumber daya komputasi terbatas."),

    # 2.2.4 BERT
    ("subsection", "2.2.4 BERT"),
    ("body", "BERT (Bidirectional Encoder Representations from Transformers) adalah model "
             "bahasa berbasis Transformer yang diperkenalkan oleh Devlin et al. (2019). "
             "Arsitektur BERT-base terdiri dari 12 lapisan Transformer encoder (L=12), "
             "12 attention head (A=12), dan dimensi hidden 768 (H=768), dengan total sekitar "
             "110 juta parameter. Setiap lapisan Transformer terdiri dari dua komponen utama: "
             "(1) Multi-Head Self-Attention yang memungkinkan setiap token memperhatikan "
             "semua token lain dalam urutan secara bidirectional, menghasilkan representasi "
             "yang bergantung konteks penuh; dan (2) Feed-Forward Network (FFN) berukuran "
             "3.072 dimensi (empat kali H) dengan aktivasi GELU."),

    ("body", "Input BERT menggunakan dua token khusus: [CLS] diletakkan di awal setiap "
             "urutan dan [SEP] sebagai pemisah segmen atau akhir urutan. Representasi token "
             "[CLS] pada lapisan terakhir menghasilkan vektor 768 dimensi yang berfungsi "
             "sebagai sentence-level embedding untuk tugas downstream seperti klasifikasi "
             "dan regresi. Pre-training BERT menggunakan dua tugas secara bersamaan: "
             "masked language modeling (MLM), di mana 15% token disamarkan secara acak dan "
             "model diminta memprediksinya dari konteks sekitar; dan next sentence prediction "
             "(NSP), di mana model diminta menentukan apakah dua segmen kalimat merupakan "
             "pasangan berurutan dalam dokumen asli. Pre-training dilakukan pada gabungan "
             "BookCorpus (800 juta kata) dan English Wikipedia (2,5 miliar kata)."),

    # 2.2.5 RoBERTa
    ("subsection", "2.2.5 RoBERTa"),
    ("body", "RoBERTa (Robustly Optimized BERT Approach) diperkenalkan oleh Liu et al. (2019) "
             "sebagai hasil studi sistematis terhadap pilihan desain prosedur pre-training BERT. "
             "Arsitektur RoBERTa-base identik dengan BERT-base: 12 lapisan Transformer encoder, "
             "12 attention head, dan dimensi hidden 768, sehingga representasi [CLS] pada "
             "lapisan terakhir juga berukuran 768 dimensi. Perbedaan mendasar RoBERTa dari "
             "BERT terletak sepenuhnya pada prosedur pre-training."),

    ("body", "Liu et al. (2019) melakukan ablasi sistematis dan menemukan empat modifikasi "
             "kunci yang secara konsisten meningkatkan performa downstream. Pertama, tugas NSP "
             "dihilangkan karena terbukti tidak meningkatkan dan bahkan menurunkan performa "
             "pada beberapa benchmark. Kedua, dynamic masking diterapkan sehingga pola masking "
             "dihasilkan secara baru setiap epoch, berbeda dengan static masking BERT yang "
             "menggunakan satu pola tetap per contoh. Ketiga, ukuran batch diperbesar secara "
             "signifikan (hingga 8.000 sequence) dengan jumlah langkah pelatihan yang "
             "disesuaikan. Keempat, data pre-training diperbanyak hingga 160GB teks "
             "(dibandingkan 16GB pada BERT) dengan tokenisasi Byte-Pair Encoding menggunakan "
             "vocabulary 50.000 subword unit. Kombinasi keempat modifikasi ini menghasilkan "
             "model yang secara konsisten mengungguli BERT pada tugas-tugas benchmark NLP, "
             "khususnya tugas yang melibatkan pemahaman urutan tunggal seperti regresi skor."),

    # 2.2.6 ResNet18
    ("subsection", "2.2.6 ResNet18"),
    ("body", "ResNet (Residual Network) diperkenalkan oleh He et al. (2016) dan memperkenalkan "
             "skip connection (koneksi residual) untuk mengatasi masalah vanishing gradient "
             "pada jaringan yang sangat dalam. Skip connection memungkinkan gradien mengalir "
             "langsung melewati beberapa lapisan selama backpropagation, sehingga jaringan "
             "dengan puluhan lapisan dapat dilatih secara efektif. ResNet18 adalah varian "
             "ResNet dengan 18 lapisan yang menyeimbangkan kapasitas representasi dan "
             "efisiensi komputasi, serta secara konsisten digunakan sebagai backbone image "
             "encoder pada berbagai tugas visi komputer."),

    ("body", "Dalam konteks transfer learning, ResNet18 yang di-pre-train pada ImageNet "
             "(Deng et al., 2009) menghasilkan representasi visual yang kaya secara semantik "
             "melalui feature extraction dari lapisan penultimate. He et al. (2016) "
             "menunjukkan bahwa fitur yang dipelajari dari ImageNet dapat ditransfer secara "
             "efektif ke domain gambar yang berbeda, termasuk gambar medis, dokumen, dan "
             "diagram teknis, dengan menghapus lapisan klasifikasi terakhir dan menggunakan "
             "output global average pooling sebagai feature vector berukuran 512 dimensi."),

    # 2.2.7 Vision-Language Model: Qwen2-VL-7B-Instruct
    ("subsection", "2.2.7 Vision-Language Model: Qwen2-VL-7B-Instruct"),
    ("body", "Vision-Language Model (VLM) adalah kelas model yang mampu memproses input "
             "berupa gambar dan teks secara bersamaan. Qwen2-VL-7B-Instruct adalah VLM "
             "open-source dengan 7 miliar parameter yang dikembangkan oleh Alibaba (Wang "
             "et al., 2024), terdiri dari visual token encoder dan decoder berbasis Qwen2-7B. "
             "Model ini dirancang untuk mengikuti instruksi berbasis teks dan menghasilkan "
             "deskripsi detail dari berbagai jenis gambar, termasuk grafik, diagram, dan tabel."),

    ("body", "Teknik kuantisasi 4-bit menggunakan metode NF4 (Normal Float 4-bit) yang "
             "dikembangkan oleh Dettmers et al. (2023) memungkinkan model berukuran besar "
             "untuk dijalankan pada perangkat keras dengan memori GPU terbatas tanpa "
             "degradasi performa yang signifikan. Pendekatan ini menjadi praktis untuk "
             "penggunaan VLM sebagai frozen captioner pada lingkungan komputasi terbatas, "
             "di mana model tidak perlu di-fine-tune dan hanya digunakan untuk inference."),

    # 2.2.8 DePlot
    ("subsection", "2.2.8 DePlot"),
    ("body", "DePlot diperkenalkan oleh Liu et al. (2023) sebagai pendekatan two-step untuk "
             "chart question answering: tahap pertama mengekstraksi tabel data terstruktur "
             "dari gambar grafik, dan tahap kedua menggunakan model bahasa untuk melakukan "
             "reasoning atas tabel tersebut. Model DePlot dibangun di atas arsitektur "
             "Pix2Struct dengan 282 juta parameter dan menerima gambar grafik sebagai input "
             "dengan prompt \"Generate underlying data table of the figure below:\", "
             "menghasilkan tabel dalam format linearized markdown."),

    ("body", "Liu et al. (2023) menunjukkan bahwa pendekatan plot-to-table translation ini "
             "meningkatkan akurasi reasoning grafik hingga 24,0% secara absolut pada benchmark "
             "ChartQA dibandingkan pendekatan end-to-end berbasis gambar. DePlot efektif untuk "
             "grafik terstruktur seperti bar chart, pie chart, dan line chart, namun tidak "
             "dapat digunakan untuk flow chart, peta, dan gambar komposit yang tidak memiliki "
             "representasi tabel yang dapat diekstraksi. Keunggulan utama DePlot dibandingkan "
             "VLM generalis adalah adanya representasi tabel eksplisit sebagai jangkar faktual, "
             "yang meminimalkan risiko halusinasi nilai numerik pada output akhir."),

    # 2.2.9 MATCHA
    ("subsection", "2.2.9 MATCHA"),
    ("body", "MATCHA (Math Reasoning and Chart Understanding) adalah model visual-language "
             "yang dikembangkan oleh Liu et al. (2023) di atas backbone Pix2Struct, dirancang "
             "khusus untuk tugas pemahaman grafik dan penalaran matematis. MATCHA di-pre-train "
             "menggunakan dua tugas tambahan: (1) chart derendering, yaitu menghasilkan "
             "representasi terstruktur (kode atau tabel) dari gambar grafik; dan (2) math "
             "reasoning, yaitu menjawab pertanyaan yang memerlukan operasi matematika "
             "berdasarkan konten visual."),

    ("body", "Berbeda dengan DePlot yang secara eksplisit memisahkan tahap ekstraksi tabel "
             "dan reasoning, MATCHA beroperasi secara end-to-end: model menghasilkan jawaban "
             "atau deskripsi teks langsung dari gambar grafik tanpa memerlukan tahap "
             "pemrosesan terpisah. Pendekatan ini menjadikan MATCHA lebih fleksibel dalam "
             "format output namun lebih rentan terhadap kesalahan halusinasi pada data "
             "numerik, karena tidak ada representasi tabel eksplisit sebagai jangkar faktual "
             "dalam proses decoding. MATCHA tersedia dalam dua ukuran: MATCHA-base (282 juta "
             "parameter, identik dengan DePlot dalam jumlah parameter) dan MATCHA-large."),

    # 2.2.10 Metode Regresi: Arsitektur Scoring Head
    ("subsection", "2.2.10 Metode Regresi: Arsitektur Scoring Head"),
    ("body", "Dalam penelitian ini, prediksi skor esai dimodelkan sebagai tugas regresi "
             "kontinu multi-output, di mana model harus memprediksi sepuluh nilai skor "
             "secara bersamaan dari satu representasi encoder gabungan. Pendekatan regresi "
             "dipilih karena skor EssayJudge bersifat kontinu pada rentang [0, 5], dan "
             "model regresi memungkinkan pengoptimalan langsung terhadap jarak numerik "
             "antara prediksi dan skor referensi."),

    ("body", "Arsitektur scoring head yang digunakan adalah jaringan fully connected "
             "multi-task dengan struktur bertahap: vektor konkatenasi encoder berukuran D "
             "dimensi (D = 1.280 untuk Track A, D = 1.536 untuk Track B) diproses melalui "
             "lapisan Linear(D, 768) dengan aktivasi ReLU dan dropout 0,3, kemudian "
             "Linear(768, 256) dengan aktivasi ReLU dan dropout 0,3, dan akhirnya "
             "Linear(256, 10) tanpa aktivasi. Setiap nilai dari 10 output ditransformasi "
             "menggunakan fungsi sigmoid yang membatasi nilai ke rentang (0, 1), kemudian "
             "dikalikan 5,0 untuk memetakan ke rentang [0,0; 5,0] sesuai skala skor "
             "EssayJudge."),

    ("body", "Fungsi loss yang digunakan adalah Mean Squared Error (MSE) yang dihitung "
             "secara independen per trait kemudian dirata-ratakan atas seluruh 10 trait: "
             "L = (1/10) x jumlah MSE(y_pred_i, y_true_i) untuk i = 1 sampai 10. "
             "Penggunaan MSE memberikan penalti kuadrat terhadap perbedaan prediksi dan "
             "nilai sebenarnya, sehingga kesalahan besar dihukum lebih berat. Arsitektur "
             "multi-task ini memungkinkan semua trait berbagi representasi encoder yang "
             "sama, memberikan sinyal gradien 10 kali lebih banyak per batch dibandingkan "
             "pelatihan per-trait secara terpisah."),

    # 2.2.11 Uji Signifikansi Statistik
    ("subsection", "2.2.11 Uji Signifikansi Statistik"),
    ("body", "Dalam penelitian ini, signifikansi perbedaan antara prediksi sistem dan "
             "anotasi manusia diuji menggunakan paired t-test per trait dengan koreksi "
             "Bonferroni. Paired t-test (uji-t berpasangan Student) digunakan untuk "
             "membandingkan dua pengukuran yang berpasangan pada subjek yang sama: dalam "
             "konteks ini, prediksi model dan skor manusia untuk setiap sampel esai secara "
             "individual. Statistik uji t dihitung sebagai t = mean(d) / (std(d) / akar(n)), "
             "di mana d adalah vektor perbedaan per-sampel antara prediksi model dan skor "
             "referensi manusia, dan n adalah jumlah sampel uji."),

    ("body", "Karena uji dilakukan secara simultan untuk 10 trait, diperlukan koreksi untuk "
             "multiple comparisons guna mengendalikan family-wise error rate (FWER). Koreksi "
             "Bonferroni menetapkan ambang signifikansi per uji sebagai alpha per uji = "
             "alpha keluarga dibagi jumlah uji = 0,05 / 10 = 0,005, di mana 10 adalah "
             "jumlah trait yang diuji. Sebuah trait dinyatakan tidak berbeda signifikan dari "
             "anotasi manusia jika nilai p > 0,005 (gagal menolak hipotesis nol). Pendekatan "
             "ini bersifat konservatif namun tepat untuk dataset berukuran kecil (158 sampel "
             "uji) di mana kontrol FWER penting untuk menghindari klaim positif palsu yang "
             "tidak valid."),

    # 2.2.12 Metrik Evaluasi: Quadratic Weighted Kappa
    ("subsection", "2.2.12 Metrik Evaluasi: Quadratic Weighted Kappa"),
    ("body", "Quadratic Weighted Kappa (QWK) adalah metrik yang mengukur tingkat kesepakatan "
             "antara dua set penilaian dengan memberikan penalti kuadrat untuk perbedaan yang "
             "lebih besar. QWK dihitung menggunakan matriks bobot kuadrat W di mana "
             "W[i,j] = (i-j)^2 / (N-1)^2, kemudian kappa = 1 - (sum(W*O) / sum(W*E)), "
             "dengan O adalah matriks frekuensi yang diamati dan E adalah matriks frekuensi "
             "yang diharapkan berdasarkan distribusi marjinal."),

    ("body", "Rentang nilai QWK adalah -1 hingga +1, di mana nilai 0 menunjukkan kesepakatan "
             "setara dengan kebetulan dan nilai 1 menunjukkan kesepakatan sempurna. Cohen "
             "(1968) memperkenalkan weighted kappa sebagai ekstensi dari kappa Cohen standar "
             "untuk data ordinal. Dalam literatur AES, Yannakoudakis et al. (2011) "
             "mempopulerkan QWK sebagai metrik standar melalui kompetisi ASAP karena "
             "kemampuannya memberikan penalti proporsional terhadap besarnya kesalahan "
             "prediksi, yang sangat relevan untuk penilaian berbasis rubrik dengan skala ordinal."),

    # ── 2.3 Analisis Perbandingan Metode ─────────────────────────────────────
    ("section", "2.3 Analisis Perbandingan Metode"),
    ("body", "Berdasarkan tinjauan pustaka dan dasar teori yang telah dipaparkan, subbab ini "
             "menganalisis secara kualitatif alasan pemilihan metode yang digunakan dalam "
             "penelitian ini, dikaitkan dengan bukti dari literatur."),

    ("body", "Pemilihan strategi late fusion untuk Track A didasarkan pada dua argumen dari "
             "literatur. Pertama, Gold et al. (2025) membuktikan bahwa arsitektur dual-encoder "
             "untuk tugas visi-teks menghasilkan representasi yang lebih kaya dibandingkan "
             "pendekatan single-encoder. Kedua, Baltrusaitis et al. (2019) menunjukkan bahwa "
             "late fusion lebih robust ketika kedua modalitas memiliki distribusi representasi "
             "yang sangat berbeda, karena masing-masing encoder dapat dioptimalkan secara "
             "independen sesuai karakteristik modalitasnya tanpa interferensi silang. "
             "Representasi gambar grafik (ResNet18, 512 dimensi) dan teks esai (RoBERTa, "
             "768 dimensi) memiliki karakteristik yang sangat berbeda, sehingga late fusion "
             "menjadi pilihan yang tepat."),

    ("body", "Pemilihan RoBERTa sebagai text encoder didasarkan pada bukti empiris dari Liu "
             "et al. (2019) yang menunjukkan bahwa RoBERTa secara konsisten mengungguli BERT "
             "pada tugas downstream, khususnya tugas yang melibatkan pemahaman urutan tunggal. "
             "Penghilangan NSP dan penggunaan dynamic masking menjadikan RoBERTa lebih sesuai "
             "untuk tugas regresi skor esai di mana hubungan antar kalimat tidak diperlukan "
             "secara eksplisit dalam pre-training."),

    ("body", "Motivasi pendekatan text-to-text bersumber dari tiga bukti literatur yang "
             "saling mendukung. Liu et al. (2023) melalui DePlot membuktikan bahwa "
             "dekomposisi grafik menjadi teks terstruktur meningkatkan akurasi reasoning "
             "berbasis model bahasa secara signifikan. Bursztyn et al. (2024) menunjukkan "
             "superioritas representasi teks atas gambar untuk chart question answering "
             "(99% vs. 63%). Zhao et al. (2025) memvalidasi penggunaan pipeline "
             "image-to-text berbasis VLM dalam konteks penilaian akademik. Ketiga temuan "
             "ini bersama-sama mendukung hipotesis bahwa mengonversi gambar grafik menjadi "
             "teks deskriptif sebelum pelatihan model scoring akan meningkatkan kinerja "
             "penilaian esai yang mengacu pada grafik."),

    ("body", "Pemilihan DePlot sebagai captioner khusus untuk bar chart dan pie chart "
             "didasarkan pada keunggulan arsitekturalnya: DePlot dirancang secara eksplisit "
             "untuk mengekstraksi data terstruktur dari grafik dan terbukti meningkatkan "
             "akurasi reasoning sebesar 24,0% pada ChartQA (Liu et al., 2023). Pendekatan "
             "MATCHA, meskipun memiliki kemampuan pemahaman grafik secara umum, beroperasi "
             "tanpa representasi tabel eksplisit sehingga lebih rentan terhadap kesalahan "
             "halusinasi pada grafik dengan nilai data numerik yang padat atau skala yang "
             "tidak konvensional, sebagaimana dikonfirmasi oleh tinjauan kualitas caption "
             "dalam penelitian ini."),
]

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'vision-language', r'text-to-text', r'open-source',
    r'multi-task learning', r'multi-task', r'per-trait',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'feature vector', r'feature map', r'feature engineering',
    r'encoder', r'decoder', r'tokenizer', r'embedding',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream', r'backbone', r'pooling',
    r'dropout', r'batch size', r'learning rate',
    r'epoch', r'checkpoint', r'inference',
    r'output head', r'loss function', r'gradient',
    r'overfitting', r'regularization',
    r'skip connection', r'cross-attention',
    r'one-shot', r'few-shot',
    r'reasoning', r'question answering',
    r'shared encoder', r'image encoder', r'text encoder',
    r'global average pooling',
    r'self-supervised',
    r'masked language modeling',
    r'next sentence prediction',
    r'dynamic masking',
    r'fully connected',
    r'plot-to-table',
    r'transfer learning',
    r'two-step',
    r'end-to-end',
    r'frozen captioner',
    r'sentence-level embedding',
    r'static masking',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12,
                   font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build ──────────────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges found: {len(italic_ranges)}')

requests = []
for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', 1, TAB_ID))

for start, end, seg_type, text in seg_positions:
    if seg_type == 'chapter':
        requests.append(req_para_style(start, end, TAB_ID, 'CENTER',
                                        space_above=0, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=14))
    elif seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'subsection':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=6, space_below=3))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))
    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))
    elif seg_type in ('numbered', 'subnumbered'):
        indent = 35.43 if seg_type == 'subnumbered' else 0
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=indent,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
