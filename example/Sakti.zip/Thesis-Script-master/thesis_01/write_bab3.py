import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.re803sjptjxa'  # BAB III - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Clear existing content ─────────────────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()

def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1

if end_index > 2:
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': [{
            'deleteContentRange': {
                'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': TAB_ID}
            }
        }]}
    ).execute()
    print(f'Cleared {end_index - 2} characters.')

# ── Content ───────────────────────────────────────────────────────────────────
# Structure:
#   3.1 Alat dan Bahan (3.1.1 Alat, 3.1.2 Bahan)
#   3.2 Pembagian Data
#   3.3 Alur Tugas Akhir
#   3.4 Arsitektur Model (3.4.1 Track A, 3.4.2 Track B)
#   3.5 Konfigurasi Pelatihan
#   3.6 Metrik Evaluasi

segments = [
    ("chapter", "BAB III\nMETODE PENELITIAN"),

    ("body", "Bab ini menjelaskan metode dan prosedur yang digunakan dalam penelitian ini untuk "
             "mencapai tujuan sebagaimana dirumuskan dalam Bab I. Penelitian ini mengusulkan dan "
             "membandingkan dua jalur pendekatan penilaian esai multimoda: Track A berupa fusi "
             "multimoda (ResNet18 + RoBERTa) dan Track B berupa pendekatan text-to-text berbasis "
             "caption VLM (Dual RoBERTa). Kedua jalur dikembangkan secara bertahap melalui sepuluh "
             "langkah eksperimen yang saling berkesinambungan."),

    # ── 3.1 Alat dan Bahan ───────────────────────────────────────────────────
    ("section", "3.1 Alat dan Bahan"),

    ("subsection", "3.1.1 Alat"),
    ("body", "Penelitian ini menggunakan perangkat keras dan perangkat lunak berikut."),
    ("numbered", "1. Perangkat keras lokal: laptop dengan prosesor Intel Core i7, GPU NVIDIA GeForce "
                 "RTX 3060 Laptop 6GB VRAM, dan RAM 16GB. Perangkat ini digunakan untuk seluruh "
                 "eksperimen pelatihan model scoring."),
    ("numbered", "2. Komputasi cloud: Kaggle Notebook dengan GPU Tesla P100 16GB VRAM. Platform ini "
                 "digunakan khusus untuk proses caption generation yang membutuhkan memori GPU besar "
                 "(model Qwen2-VL-7B-Instruct dan DePlot)."),
    ("numbered", "3. Perangkat lunak utama: Python 3.12, PyTorch 2.x dengan dukungan CUDA 12, dan "
                 "library HuggingFace Transformers untuk model BERT, RoBERTa, dan VLM. Library "
                 "bitsandbytes digunakan untuk kuantisasi 4-bit, torchvision untuk ResNet18, serta "
                 "pandas dan scikit-learn untuk manajemen data dan komputasi metrik QWK."),

    ("subsection", "3.1.2 Bahan: Dataset EssayJudge"),
    ("body", "Dataset yang digunakan adalah EssayJudge, sebuah benchmark untuk penilaian esai "
             "multimoda IELTS Task 1 yang dikembangkan oleh Singh et al. (2024). Dataset ini memuat "
             "1.054 sampel, di mana setiap sampel terdiri dari: (1) teks esai yang ditulis oleh "
             "mahasiswa sebagai respons terhadap tugas deskripsi grafik, (2) gambar grafik "
             "profesional IELTS yang menjadi rujukan esai, dan (3) skor untuk sepuluh dimensi "
             "penilaian dengan rentang nilai 0 hingga 5."),

    ("body", "Distribusi jenis gambar grafik pada dataset adalah sebagai berikut: flow chart "
             "sebanyak 305 sampel, bar chart sebanyak 211 sampel, tabel sebanyak 153 sampel, "
             "line chart sebanyak 145 sampel, composite chart sebanyak 107 sampel, pie chart "
             "sebanyak 71 sampel, dan peta sebanyak 62 sampel. Kesepuluh dimensi penilaian "
             "(trait) yang digunakan adalah sebagai berikut."),
    ("numbered", "1. argument_clarity: kejelasan argumen utama yang disampaikan dalam esai."),
    ("numbered", "2. justifying_persuasiveness: kemampuan penulis menyajikan justifikasi "
                 "yang persuasif berdasarkan data grafik."),
    ("numbered", "3. organizational_structure: keteraturan struktur dan alur esai secara keseluruhan."),
    ("numbered", "4. coherence: koherensi dan kohesi antarkalimat serta antarparagraf."),
    ("numbered", "5. essay_length: kesesuaian panjang esai dengan standar minimal IELTS Task 1."),
    ("numbered", "6. grammatical_accuracy: ketepatan penggunaan tata bahasa Inggris."),
    ("numbered", "7. grammatical_diversity: keragaman struktur gramatikal yang digunakan."),
    ("numbered", "8. lexical_accuracy: ketepatan pemilihan kosakata."),
    ("numbered", "9. lexical_diversity: keragaman kosakata yang digunakan."),
    ("numbered", "10. punctuation_accuracy: ketepatan penggunaan tanda baca."),

    # ── 3.2 Pembagian Data ───────────────────────────────────────────────────
    ("section", "3.2 Pembagian Data"),
    ("body", "Dataset EssayJudge yang berjumlah 1.054 sampel dibagi menjadi tiga subset mengikuti "
             "protokol benchmark EssayJudge. Sebelum pembagian, seluruh sampel diacak menggunakan "
             "seed tetap (random_state=42) untuk memastikan distribusi yang representatif dan "
             "hasil yang dapat direproduksi. Pembagian dilakukan secara sekuensial setelah "
             "pengacakan dengan rasio 70% data pelatihan (sekitar 738 sampel), 15% data validasi "
             "(sekitar 158 sampel), dan 15% data uji (sekitar 158 sampel). Validasi silang "
             "(cross-validation) tidak digunakan agar konsisten dengan protokol evaluasi "
             "benchmark EssayJudge."),

    # ── 3.3 Alur Tugas Akhir ─────────────────────────────────────────────────
    ("section", "3.3 Alur Tugas Akhir"),
    ("body", "Penelitian ini dilaksanakan melalui sepuluh langkah eksperimen yang bersifat "
             "inkremental, di mana setiap langkah membangun di atas temuan langkah sebelumnya. "
             "Alur ini dirancang untuk menjawab rumusan masalah secara sistematis, mulai dari "
             "pengukuran baseline hingga pengembangan sistem terbaik."),

    ("numbered", "1. Pengukuran Baseline. Model Qwen2-VL-7B-Instruct digunakan secara zero-shot "
                 "tanpa fine-tuning untuk menilai esai pada seluruh sepuluh trait secara langsung "
                 "melalui prompting. Hasil rata-rata QWK sebesar 0,164 menunjukkan bahwa MLLM "
                 "tanpa pelatihan khusus tidak memadai untuk tugas penilaian esai terstruktur, "
                 "menegaskan perlunya model terlatih dengan data EssayJudge."),

    ("numbered", "2. Model Terlatih Pertama (Exp 031). Arsitektur BERT + ResNet18 dengan "
                 "intermediate fusion dan multi-task learning dilatih pada dataset EssayJudge. "
                 "Hasil test QWK 0,4799 memvalidasi bahwa supervised fine-tuning secara dramatis "
                 "meningkatkan kinerja scoring, dengan peningkatan sebesar +0,316 poin "
                 "dibandingkan baseline zero-shot."),

    ("numbered", "3. Perbandingan Strategi Fusion (Exp 030, 031, 032). Tiga strategi fusion "
                 "dievaluasi dalam kondisi identik menggunakan BERT + ResNet18. Hasil: early "
                 "fusion (Exp 030) = 0,4777; intermediate fusion (Exp 031) = 0,4799; late fusion "
                 "(Exp 032) = 0,4838. Late fusion dipilih untuk seluruh eksperimen selanjutnya."),

    ("numbered", "4. Peningkatan Text Encoder (Exp 033). BERT diganti dengan RoBERTa-base dengan "
                 "mempertahankan late fusion dan ResNet18. Test QWK meningkat dari 0,4838 menjadi "
                 "0,5126 (+0,029), mengonfirmasi keunggulan RoBERTa. Hasil ini menetapkan batas "
                 "atas Track A."),

    ("numbered", "5. Jalur T2T Awal (Exp 08, Exp 081). Caption Qwen2-VL-7B-Instruct untuk "
                 "seluruh 1.054 sampel digunakan sebagai input teks kedua pada arsitektur Dual "
                 "RoBERTa. Exp 08 (tanpa seed) menghasilkan QWK 0,4579 dan Exp 081 (seeded) "
                 "menghasilkan 0,4796. Hasilnya masih di bawah Track A (0,5126), "
                 "mengindikasikan perlunya peningkatan kualitas caption untuk jenis "
                 "grafik tertentu."),

    ("numbered", "6. Analisis Kualitas Caption. Tinjauan manual terhadap 100 sampel caption "
                 "Qwen2-VL-7B menunjukkan tingkat kesalahan sekitar 22% pada bar chart dan pie "
                 "chart, berupa kesalahan nilai data, identifikasi puncak yang salah, dan "
                 "kesalahan skala. Temuan ini memotivasi penggunaan captioner khusus yang "
                 "dirancang untuk jenis grafik terstruktur tersebut."),

    ("numbered", "7. Eksperimen Eksklusi Jenis Grafik (Exp 092, Exp 093). Berdasarkan temuan "
                 "tinjauan kualitas caption pada langkah 6, model dilatih hanya pada sampel dengan "
                 "caption andal. Eksperimen 092 mengeksklusi bar chart, pie chart, dan composite "
                 "chart menghasilkan QWK 0,4941. Eksperimen 093 mengeksklusi hanya bar chart dan "
                 "pie chart dengan mempertahankan composite chart, menggunakan seed=42, dan "
                 "menghasilkan QWK 0,5778. Hasil ini melampaui Track A dengan margin +0,065 dan "
                 "menjadi hasil terbaik keseluruhan. Gain seeding sebesar +0,083 merupakan "
                 "peningkatan terbesar sepanjang penelitian ini."),

    ("numbered", "8. Evaluasi Captioner Khusus untuk Bar Chart dan Pie Chart (Exp 103, Exp 020). "
                 "DePlot+Qwen7B dan MATCHA dievaluasi sebagai captioner alternatif untuk bar chart "
                 "dan pie chart. DePlot+Qwen7B (Exp 103) menghasilkan QWK 0,5026 dengan error "
                 "rate bar chart turun dari 54% menjadi 23%. MATCHA (Exp 020) menghasilkan QWK "
                 "lebih tinggi (0,5213) namun error rate 100% pada kedua jenis grafik berdasarkan "
                 "tinjauan manual; DePlot+Qwen7B dipilih karena akurasi faktual lebih penting "
                 "dari fluency semata. PaliGemma (Exp 021) tidak dapat digunakan karena caption "
                 "generation gagal sepenuhnya pada lingkungan Kaggle P100."),

    ("numbered", "9. Perbandingan VLM dalam Batasan 7B Parameter (Exp 093, Exp 12, pending). "
                 "Qwen2-VL-7B-Instruct (Exp 093) digunakan sebagai baseline VLM dengan batasan "
                 "<=7B parameter. InternVL2-8B (Exp 12) diuji sebagai referensi konteks meskipun "
                 "sedikit di luar batasan, menghasilkan QWK 0,5017 yang setara dengan "
                 "DePlot+Qwen7B (0,5026), mengkonfirmasi bahwa skala VLM bukan faktor penentu "
                 "utama. DeepSeek-VL-7B direncanakan sebagai pembanding utama Qwen2-VL-7B namun "
                 "eksperimen belum selesai dijalankan."),

    ("numbered", "10. Uji Signifikansi Statistik (pending). Paired t-test per trait dengan "
                 "koreksi Bonferroni (alpha=0,005) akan dijalankan pada prediksi per-sampel "
                 "Eksperimen 093 untuk mengkonfirmasi apakah sistem terbaik menghasilkan "
                 "prediksi yang tidak berbeda signifikan dari anotasi manusia pada setiap trait."),

    # ── 3.4 Arsitektur Model ─────────────────────────────────────────────────
    ("section", "3.4 Arsitektur Model"),

    ("subsection", "3.4.1 Track A: Fusi Multimoda (DualEncoderFusion)"),
    ("body", "Track A mengimplementasikan arsitektur DualEncoderFusion yang menggabungkan image "
             "encoder ResNet18 dengan text encoder RoBERTa menggunakan strategi late fusion. "
             "Gambar grafik diproses oleh ResNet18 yang telah di-pre-train pada ImageNet; lapisan "
             "klasifikasi terakhir dihapus sehingga global average pooling layer menghasilkan "
             "feature vector berukuran 512 dimensi. Teks esai diproses oleh RoBERTa-base; "
             "representasi token [CLS] pada lapisan terakhir menghasilkan sentence embedding "
             "berukuran 768 dimensi."),

    ("body", "Kedua representasi digabungkan melalui concatenation menjadi vektor 1.280 dimensi "
             "(512 + 768). Vektor ini kemudian diproses oleh jaringan fully connected multi-task: "
             "1.280 dimensi diredulsi menjadi 768 (aktivasi ReLU, dropout 0,3), kemudian 256 "
             "(aktivasi ReLU, dropout 0,3), dan menghasilkan 10 nilai output. Setiap output "
             "ditransformasi menggunakan fungsi sigmoid kemudian dikalikan 5,0 untuk memetakan "
             "nilai ke rentang [0,0; 5,0] sesuai skala skor EssayJudge."),

    ("subsection", "3.4.2 Track B: Text-to-Text (DualRoBERTaMultitask)"),
    ("body", "Track B mengimplementasikan arsitektur DualRoBERTaMultitask yang beroperasi "
             "sepenuhnya dalam domain teks tanpa image encoder dalam loop pelatihan. Pendekatan "
             "ini terdiri dari dua tahap terpisah: tahap caption generation yang dilakukan secara "
             "offline menggunakan GPU Kaggle, dan tahap model scoring yang dilakukan secara "
             "lokal pada GPU RTX 3060."),

    ("body", "Pada tahap caption generation, setiap gambar grafik dikonversi menjadi deskripsi "
             "teks melalui pipeline yang berbeda berdasarkan jenis grafik. Untuk bar chart dan "
             "pie chart, digunakan pipeline dua langkah: DePlot mengekstraksi tabel data "
             "terstruktur dari gambar, kemudian Qwen2-VL-7B-Instruct menggunakan tabel tersebut "
             "sebagai konteks untuk menghasilkan deskripsi naratif yang akurat secara faktual. "
             "Untuk semua jenis grafik lainnya (flow chart, tabel, line chart, composite chart, "
             "dan peta), Qwen2-VL-7B-Instruct langsung menghasilkan deskripsi dari gambar "
             "tanpa tahap ekstraksi tabel."),

    ("body", "Pada tahap model scoring, caption teks dan teks esai masing-masing diproses oleh "
             "encoder RoBERTa-base yang independen, menghasilkan dua vektor [CLS] berukuran 768 "
             "dimensi. Keduanya digabungkan melalui concatenation menjadi vektor 1.536 dimensi "
             "(768 + 768), yang kemudian diproses oleh jaringan fully connected multi-task "
             "identik dengan Track A: 1.536 -> 768 (ReLU, dropout 0,3) -> 256 (ReLU, "
             "dropout 0,3) -> 10 output, dengan transformasi sigmoid x 5,0."),

    # ── 3.5 Konfigurasi Pelatihan ────────────────────────────────────────────
    ("section", "3.5 Konfigurasi Pelatihan"),
    ("body", "Kedua track menggunakan konfigurasi pelatihan yang seragam untuk memastikan "
             "perbandingan yang adil. Fungsi loss yang digunakan adalah Mean Squared Error (MSE) "
             "per-trait, dirata-ratakan atas 10 trait. Optimizer AdamW digunakan dengan learning "
             "rate 1e-4 dan weight decay 0,01. Penjadwalan learning rate menggunakan "
             "ReduceLROnPlateau dengan patience 3 epoch dan faktor pengurangan 0,5 berdasarkan "
             "peningkatan val QWK."),

    ("body", "Pelatihan dijalankan hingga maksimum 30 epoch dengan mekanisme early stopping jika "
             "val QWK tidak meningkat selama 10 epoch berturut-turut. Model terbaik berdasarkan "
             "val QWK disimpan sebagai checkpoint dan digunakan untuk evaluasi akhir pada test "
             "set. Reprodusibilitas dijamin dengan seed 42 pada dua level: pengacakan dataset "
             "(df.sample dengan random_state=42) dan inisialisasi model (set_seed(42) untuk "
             "PyTorch dan NumPy). Batch size yang digunakan adalah 16 untuk semua eksperimen."),

    # ── 3.6 Metrik Evaluasi ──────────────────────────────────────────────────
    ("section", "3.6 Metrik Evaluasi"),
    ("body", "Metrik utama yang digunakan dalam penelitian ini adalah Quadratic Weighted Kappa "
             "(QWK) sebagaimana dijelaskan pada Subbab 2.2.12. QWK dihitung untuk setiap trait "
             "secara individual menghasilkan 10 nilai per eksperimen; rata-rata dari 10 nilai "
             "tersebut digunakan sebagai angka perbandingan utama antar eksperimen. Pemilihan "
             "checkpoint model terbaik selama pelatihan menggunakan val QWK rata-rata, sementara "
             "pelaporan hasil akhir menggunakan test QWK rata-rata."),

    ("body", "Untuk keperluan analisis mendalam pada Bab IV, nilai QWK per-trait juga dilaporkan "
             "guna mengidentifikasi trait yang secara konsisten sulit diprediksi oleh seluruh "
             "model. Trait argument_clarity secara konsisten menghasilkan QWK terendah di seluruh "
             "eksperimen (berkisar antara 0,16 hingga 0,33), yang akan dibahas lebih lanjut "
             "dalam konteks tantangan semantik pada penilaian paragraf pembuka esai IELTS Task 1. "
             "Sebaliknya, trait seperti essay_length dan punctuation_accuracy cenderung lebih "
             "mudah diprediksi karena bergantung pada fitur permukaan teks yang lebih eksplisit."),
]

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'vision-language', r'text-to-text', r'open-source',
    r'multi-task learning', r'multi-task', r'per-trait',
    r'fine-tuning', r'fine-tuned', r'fine-tune', r'di-fine-tune',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'feature vector', r'feature map', r'feature engineering',
    r'encoder', r'decoder', r'tokenizer', r'embedding',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream', r'backbone', r'pooling',
    r'dropout', r'batch size', r'learning rate',
    r'epoch', r'checkpoint', r'inference',
    r'softmax', r'sigmoid', r'output head',
    r'loss function', r'gradient', r'backpropagation',
    r'overfitting', r'regularization',
    r'skip connection', r'cross-attention',
    r'one-shot', r'few-shot',
    r'reasoning', r'question answering',
    r'shared encoder', r'image encoder', r'text encoder',
    r'global average pooling',
    r'self-supervised',
    r'cross-validation',
    r'fully connected',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build document ─────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges found: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
requests = []

for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', 1, TAB_ID))

for start, end, seg_type, text in seg_positions:
    if seg_type == 'chapter':
        requests.append(req_para_style(start, end, TAB_ID, 'CENTER',
                                        space_above=0, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=14))

    elif seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'subsection':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=6, space_below=3))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type in ('numbered', 'subnumbered'):
        indent = 35.43 if seg_type == 'subnumbered' else 0
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=indent,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
