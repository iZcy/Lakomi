import sys
sys.stdout.reconfigure(encoding='utf-8')
import re
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.qqd2qneuql48'  # BAB IV - Draft

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Content ───────────────────────────────────────────────────────────────────
segments = [
    ("chapter", "BAB IV\nHASIL DAN PEMBAHASAN"),

    ("body",
     "Bab ini menyajikan hasil dan pembahasan eksperimen yang dilakukan untuk menjawab "
     "enam rumusan masalah (RQ1-RQ6) penelitian ini. Pembahasan diorganisasikan ke dalam "
     "dua jalur utama: Track A (fusi multimoda ResNet18 + RoBERTa) yang menjawab RQ1 dan "
     "RQ2, serta Track B (pendekatan text-to-text berbasis caption VLM) yang menjawab RQ3 "
     "hingga RQ5. Bagian 4.3 memaparkan narasi penemuan pendekatan text-to-text secara "
     "menyeluruh dan sekaligus menjawab RQ3. Seluruh eksperimen dievaluasi menggunakan "
     "metrik Quadratic Weighted Kappa (QWK) pada test set 158 sampel. RQ5 dan RQ6 masih "
     "dalam status pending dan akan dilengkapi setelah data tersedia."),

    # ── 4.1 ──────────────────────────────────────────────────────────────────
    ("section", "4.1 Perbandingan Strategi Fusion pada Track A"),

    ("body",
     "Subbab ini menjawab RQ1: strategi fusion mana (early, intermediate, atau late) "
     "yang menghasilkan QWK tertinggi pada arsitektur BERT + ResNet18?"),

    ("subsection", "4.1.1 Dasar Teori: Strategi Fusion Multimodal"),

    ("body",
     "Baltrusaitis et al. (2019) mengklasifikasikan strategi penggabungan modalitas ke "
     "dalam tiga kategori utama. Pertama, early fusion menggabungkan sinyal mentah atau "
     "representasi awal dari semua modalitas sebelum encoder utama dijalankan. Pendekatan "
     "ini sederhana namun memaksa satu model untuk memproses dua ruang representasi yang "
     "sangat berbeda secara bersamaan. Kedua, intermediate fusion memproses tiap modalitas "
     "secara penuh oleh encoder masing-masing, kemudian menggabungkan representasi di "
     "lapisan tengah melalui mekanisme seperti cross-attention sebelum masuk ke decision "
     "head. Ketiga, late fusion memproses tiap modalitas hingga representasi akhir secara "
     "independen, baru kemudian menggabungkan (biasanya melalui concatenation) sebelum "
     "masuk ke lapisan keputusan."),

    ("body",
     "Baltrusaitis et al. (2019) memprediksi bahwa late fusion cenderung lebih unggul "
     "ketika dua modalitas memiliki distribusi yang sangat berbeda, karena setiap encoder "
     "dapat dioptimalkan secara independen tanpa trade-off ruang representasi. Berdasarkan "
     "prediksi ini, hipotesis RQ1 adalah bahwa late fusion akan menghasilkan QWK tertinggi "
     "pada arsitektur BERT + ResNet18 dengan dataset esai IELTS Task 1, di mana modalitas "
     "teks (esai mahasiswa) dan gambar (grafik profesional IELTS) memiliki karakteristik "
     "yang sangat berbeda."),

    ("subsection", "4.1.2 Early Fusion"),

    ("body",
     "Pada arsitektur early fusion, ResNet18 menghasilkan feature map yang di-flatten dan "
     "digabungkan dengan BERT token embeddings sebelum encoder utama dijalankan. Kedua "
     "modalitas kemudian diproses bersama oleh fully connected head. Konfigurasi pelatihan "
     "yang digunakan adalah: learning rate 1e-4, dropout 0,3, batch size 16, seed=42, "
     "fungsi loss MSE multi-task, dengan pembagian data 737/158/159 (train/val/test)."),

    ("body",
     "Hasil evaluasi Eksperimen 030 pada test set menghasilkan QWK keseluruhan sebesar "
     "0,4777. Perincian per trait adalah sebagai berikut: AC=0,161, JP=0,464, OS=0,486, "
     "CH=0,525, EL=0,419, GA=0,542, GD=0,541, LA=0,582, LD=0,536, PA=0,407. Trait "
     "argument_clarity (AC) menghasilkan nilai terendah (0,161), yang mengindikasikan "
     "bahwa penggabungan representasi pixel dan token pada tahap awal mendegradasi "
     "representasi teks, khususnya untuk trait yang membutuhkan pemahaman argumen "
     "holistik."),

    ("subsection", "4.1.3 Intermediate Fusion"),

    ("body",
     "Pada arsitektur intermediate fusion, BERT memproses teks esai secara penuh "
     "menghasilkan representasi [CLS] berukuran 768 dimensi, sementara ResNet18 memproses "
     "gambar menghasilkan feature map 512 dimensi. Kedua representasi digabungkan melalui "
     "mekanisme cross-attention, di mana essay [CLS] berfungsi sebagai query dan image "
     "features sebagai key/value. Output cross-attention kemudian di-concatenate dengan "
     "[CLS] sebelum masuk ke fully connected head. Konfigurasi pelatihan identik dengan "
     "Eksperimen 030."),

    ("body",
     "Eksperimen 031 menghasilkan QWK keseluruhan 0,4799 pada test set. Perincian per "
     "trait: AC=0,241, JP=0,390, OS=0,540, CH=0,552, EL=0,415, GA=0,535, GD=0,599, "
     "LA=0,602, LD=0,511, PA=0,414. Terdapat peningkatan kecil dibandingkan early fusion "
     "(+0,002). Mekanisme cross-attention memberikan kontribusi pada peningkatan GD dan "
     "LA, yang mengindikasikan bahwa keragaman linguistik berkorelasi dengan konten visual. "
     "Nilai AC meningkat menjadi 0,241 karena encoder teks bebas berjalan penuh. Namun "
     "demikian, parameter fusion tambahan membutuhkan lebih banyak data untuk dilatih "
     "secara efektif, sehingga gain-nya terbatas."),

    ("subsection", "4.1.4 Late Fusion"),

    ("body",
     "Pada arsitektur late fusion, BERT menghasilkan representasi [CLS] 768 dimensi dan "
     "ResNet18 menghasilkan vektor global average pooling 512 dimensi secara independen "
     "penuh. Kedua representasi digabungkan melalui concatenation menjadi vektor 1.280 "
     "dimensi, yang kemudian diproses oleh fully connected head: 1.280 -> 768 (ReLU, "
     "dropout 0,3) -> 256 (ReLU, dropout 0,3) -> 10 output dengan transformasi sigmoid "
     "x 5,0. Konfigurasi pelatihan identik dengan Eksperimen 030."),

    ("body",
     "Eksperimen 032 menghasilkan QWK keseluruhan 0,4838 pada test set, nilai tertinggi "
     "di antara ketiga strategi fusion. Perincian per trait: AC=0,318, JP=0,421, OS=0,502, "
     "CH=0,596, EL=0,427, GA=0,527, GD=0,578, LA=0,587, LD=0,493, PA=0,388. AC naik "
     "secara signifikan (0,318 vs 0,161 pada early fusion) karena encoder teks dapat "
     "dioptimalkan sepenuhnya untuk pemahaman bahasa tanpa gangguan modalitas gambar. "
     "Trait coherence (CH=0,596) mencapai nilai tertinggi di seluruh Track A, "
     "mengkonfirmasi bahwa koherensi teks didominasi oleh sinyal linguistik murni."),

    ("subsection", "4.1.5 Perbandingan Antar Strategi dan Jawaban RQ1"),

    ("body",
     "Tabel 4.1 merangkum perbandingan ketiga strategi fusion yang diuji."),

    ("body",
     "Tabel 4.1 Perbandingan QWK Tiga Strategi Fusion\n"
     "Strategi | Test QWK | AC | OS | CH | GA\n"
     "Early Fusion (Exp030) | 0,4777 | 0,161 | 0,486 | 0,525 | 0,542\n"
     "Intermediate Fusion (Exp031) | 0,4799 | 0,241 | 0,540 | 0,552 | 0,535\n"
     "Late Fusion (Exp032) | 0,4838 | 0,318 | 0,502 | 0,596 | 0,527"),

    ("body",
     "Jawaban RQ1: late fusion adalah strategi optimal, konsisten dengan prediksi "
     "Baltrusaitis et al. (2019). Ketika dua modalitas memiliki distribusi yang sangat "
     "berbeda (teks esai mahasiswa vs. gambar IELTS profesional), pemisahan optimasi "
     "encoder terbukti lebih efektif dibandingkan penggabungan representasi di awal atau "
     "tengah proses. Intermediate fusion sedikit mengungguli early fusion pada trait OS "
     "melalui mekanisme cross-attention, namun gain ini tidak mencukupi untuk "
     "mengkompensasi biaya parameter fusion tambahan. Late fusion selanjutnya ditetapkan "
     "sebagai arsitektur standar untuk seluruh eksperimen Track A berikutnya."),

    # ── 4.2 ──────────────────────────────────────────────────────────────────
    ("section", "4.2 Pengaruh Pilihan Text Encoder: BERT vs RoBERTa"),

    ("body",
     "Subbab ini menjawab RQ2: apakah penggantian text encoder dari BERT ke RoBERTa "
     "meningkatkan performa pada arsitektur late fusion dengan konfigurasi pelatihan "
     "identik?"),

    ("subsection", "4.2.1 Dasar Teori: RoBERTa sebagai Optimasi Pre-training BERT"),

    ("body",
     "Liu et al. (2019) mengidentifikasi bahwa BERT mengalami under-training akibat "
     "jadwal pelatihan yang terlalu singkat, ukuran batch yang terlalu kecil, dan "
     "penggunaan Next Sentence Prediction (NSP) yang tidak selalu menguntungkan untuk "
     "downstream tasks. RoBERTa diajukan sebagai solusi dengan menghapus NSP, menerapkan "
     "dynamic masking (mask yang berbeda di setiap epoch), menggunakan batch yang lebih "
     "besar, dan meningkatkan data pre-training hingga 10 kali lipat (160GB vs. 16GB). "
     "Liu et al. (2019) menunjukkan bahwa RoBERTa secara konsisten mengungguli BERT-base "
     "pada benchmark GLUE, SQuAD, dan RACE."),

    ("body",
     "Berdasarkan temuan ini, hipotesis RQ2 adalah bahwa RoBERTa-base akan menghasilkan "
     "QWK lebih tinggi dari BERT-base pada arsitektur late fusion yang sama, terutama "
     "untuk trait yang bergantung pada pemahaman kosakata dan struktur wacana seperti "
     "grammatical_accuracy (GA), lexical_accuracy (LA), lexical_diversity (LD), dan "
     "organizational_structure (OS)."),

    ("subsection", "4.2.2 BERT-base pada Arsitektur Late Fusion"),

    ("body",
     "Eksperimen 032 menggunakan BERT-base-uncased dengan tokenizer WordPiece, 12 lapisan "
     "transformer, dan dimensi representasi 768. Pre-training BERT menggunakan MLM dan NSP "
     "pada Wikipedia serta BookCorpus (16GB). Lapisan embedding dan layer 0-5 di-freeze "
     "(6 dari 12 layer), sementara layer 6-11 dan head dilatih. Arsitektur late fusion "
     "dengan ResNet18 menghasilkan vektor concatenation 1.280 dimensi. Hasil test QWK "
     "pada Eksperimen 032 adalah 0,4838 (direferensikan dari 4.1.4)."),

    ("subsection", "4.2.3 RoBERTa-base pada Arsitektur Late Fusion"),

    ("body",
     "Eksperimen 033 mengganti BERT-base dengan RoBERTa-base (tokenizer GPT-2 BPE, 12 "
     "lapisan, 768 dimensi) dengan mempertahankan seluruh konfigurasi lainnya secara "
     "identik: late fusion + ResNet18, freeze 6/12 layer, learning rate 1e-4, seed=42. "
     "Pre-training RoBERTa menghapus NSP, menggunakan dynamic masking, batch lebih besar, "
     "dan data 160GB."),

    ("body",
     "Eksperimen 033 menghasilkan QWK keseluruhan 0,5126 pada test set. Perincian per "
     "trait: AC=0,271, JP=0,463, OS=0,622, CH=0,579, EL=0,443, GA=0,591, GD=0,586, "
     "LA=0,581, LD=0,542, PA=0,446. Peningkatan signifikan sebesar +0,029 QWK "
     "dibandingkan BERT (Eksperimen 032). RoBERTa unggul pada 8 dari 10 trait. OS naik "
     "drastis (0,622 vs. 0,502, +0,120), mengkonfirmasi bahwa representasi RoBERTa lebih "
     "kaya untuk pemahaman struktur wacana. GA (0,591) dan LA (0,581) juga meningkat "
     "konsisten dengan hipotesis."),

    ("subsection", "4.2.4 Analisis: Dynamic Masking, NSP, dan Relevansinya untuk AES"),

    ("body",
     "RoBERTa mengungguli BERT pada trait linguistik per-kalimat (GA, GD, LA, LD, PA) "
     "karena dynamic masking dan data pre-training yang lebih besar menghasilkan "
     "representasi kata yang lebih robust dan beragam. Namun BERT sedikit lebih baik pada "
     "trait AC (0,318 vs. 0,271) dan CH (0,596 vs. 0,579). Mekanisme NSP pada BERT "
     "kemungkinan membantu encoder memahami relasi argumen antar-kalimat, yang relevan "
     "untuk penilaian holistik kejelasan argumen dan koherensi pada esai IELTS. Hal ini "
     "mengimplikasikan bahwa untuk dataset AES di mana sebagian besar trait bersifat "
     "per-kalimat, RoBERTa adalah pilihan yang lebih tepat."),

    ("subsection", "4.2.5 Jawaban RQ2"),

    ("body",
     "Jawaban RQ2: RoBERTa-base mengungguli BERT-base sebesar +0,029 QWK dengan "
     "konfigurasi yang identik, mengkonfirmasi temuan Liu et al. (2019) pada domain AES "
     "multimodal. RoBERTa selanjutnya ditetapkan sebagai text encoder untuk seluruh "
     "eksperimen Track B. Eksperimen 033 dengan QWK=0,5126 menjadi batas atas Track A "
     "dan titik pembanding utama untuk evaluasi Track B pada bagian 4.3."),

    # ── 4.3 ──────────────────────────────────────────────────────────────────
    ("section", "4.3 Pendekatan Text-to-Text: Motivasi, Baseline, dan Analisis Kualitas Caption"),

    ("body",
     "Bagian ini tidak hanya menjawab satu RQ, melainkan membangun fondasi naratif untuk "
     "seluruh Track B. Alur pembahasan mengikuti perjalanan penemuan: motivasi teoritis "
     "text-to-text -> implementasi baseline -> distribusi jenis grafik -> evaluasi kualitas "
     "caption -> bukti empiris eksklusi -> kesimpulan permasalahan VLM -> perbandingan "
     "formal Track A vs. Track B (jawaban RQ3)."),

    ("subsection", "4.3.1 Dasar Teori: Mengapa Text-to-Text Berpotensi Lebih Baik?"),

    ("body",
     "Bursztyn et al. (2024) menunjukkan bahwa model berbasis teks (T5, GPT) mencapai "
     "akurasi 99% pada tugas chart question answering ketika diberikan representasi teks "
     "dari grafik, dibandingkan hanya 63% ketika model menerima gambar secara langsung. "
     "Temuan ini mengkonfirmasi bahwa representasi teks grafik secara inheren lebih "
     "informatif bagi language model dibandingkan raw image features."),

    ("body",
     "Zhao et al. (2025) pada dataset EDU-CIRCUIT-HW mendemonstrasikan pipeline VLM -> "
     "caption -> LLM untuk penilaian esai berbasis gambar, mencapai peningkatan signifikan "
     "dibandingkan model yang menerima gambar secara langsung. Temuan ini mengkonfirmasi "
     "bahwa representasi teks perantara merupakan bottleneck yang produktif dalam "
     "educational assessment berbasis gambar."),

    ("body",
     "Motivasi langsung untuk penelitian ini: pada dataset EssayJudge, setiap esai berisi "
     "deskripsi verbal dari grafik IELTS. Jika caption VLM dapat merepresentasikan grafik "
     "secara akurat dalam teks, maka RoBERTa dapat membandingkan esai vs. caption secara "
     "semantik penuh, memanfaatkan kemampuan pre-training bahasa tanpa batasan yang "
     "dimiliki image encoder. Berdasarkan hal ini, hipotesis yang diajukan adalah bahwa "
     "pipeline text-to-text (Qwen2-VL-7B-Instruct -> caption -> Dual RoBERTa) akan "
     "melampaui Track A setelah kualitas caption dioptimalkan."),

    ("subsection", "4.3.2 T2T Baseline: Qwen2-VL-7B-Instruct, Full 1.054 Sampel"),

    ("body",
     "Eksperimen 081 mengimplementasikan arsitektur Dual RoBERTa-base independen sebagai "
     "T2T baseline. Caption encoder memproses teks caption menghasilkan representasi [CLS] "
     "768 dimensi, sementara essay encoder memproses teks esai menghasilkan representasi "
     "[CLS] 768 dimensi secara terpisah. Keduanya digabungkan melalui concatenation "
     "menjadi 1.536 dimensi, kemudian diproses oleh fully connected head: 1.536 -> 768 "
     "(ReLU, dropout 0,3) -> 256 (ReLU, dropout 0,3) -> 10 output dengan sigmoid x 5,0. "
     "Konfigurasi: freeze embed + layer 0-5 (6/12), AdamW lr=1e-4, ReduceLROnPlateau, "
     "seed=42. Caption dihasilkan oleh Qwen2-VL-7B-Instruct (kuantisasi 4-bit NF4, "
     "Kaggle P100) untuk seluruh 1.054 sampel tanpa perlakuan khusus pada jenis grafik "
     "tertentu."),

    ("body",
     "Eksperimen 081 menghasilkan QWK keseluruhan 0,4796 pada test set. Perincian per "
     "trait: AC=0,227, JP=0,450, OS=0,532, CH=0,550, EL=0,467, GA=0,548, GD=0,571, "
     "LA=0,540, LD=0,482, PA=0,429. T2T baseline melampaui Track A early fusion (0,4777) "
     "dan intermediate fusion (0,4799), namun masih di bawah Track A terbaik yaitu "
     "RoBERTa late fusion (Eksperimen 033 = 0,5126). Gap sebesar -0,033 ini "
     "mengindikasikan bahwa potensi T2T belum terealisasi sepenuhnya dan kemungkinan "
     "disebabkan oleh noise pada caption jenis grafik tertentu."),

    ("subsection", "4.3.3 Distribusi Jenis Grafik pada Dataset EssayJudge"),

    ("body",
     "Sebelum melakukan analisis kualitas caption, penting untuk memahami distribusi jenis "
     "grafik dalam dataset EssayJudge. Dataset memiliki 1.054 baris namun hanya 125 gambar "
     "unik, karena satu gambar digunakan oleh banyak esai yang berbeda. Proses caption "
     "generation dilakukan pada 125 gambar unik tersebut, kemudian hasilnya diperluas ke "
     "seluruh 1.054 baris melalui URL mapping."),

    ("body",
     "Tabel 4.2 Distribusi Jenis Grafik pada Dataset EssayJudge\n"
     "Jenis Grafik | Jumlah Sampel | Persentase | Gambar Unik\n"
     "flow_chart | 305 | 28,9% | 32\n"
     "bar_chart | 211 | 20,0% | 30\n"
     "table | 153 | 14,5% | 17\n"
     "line_chart | 145 | 13,8% | 15\n"
     "composite_chart | 107 | 10,2% | 13\n"
     "pie_chart | 71 | 6,7% | 10\n"
     "map | 62 | 5,9% | 8\n"
     "Total | 1.054 | 100% | 125"),

    ("body",
     "Bar chart dan pie chart bersama-sama mencakup 282 sampel atau 26,7% dari total "
     "dataset. Kedua jenis ini memiliki karakteristik berbasis angka presisi yang "
     "membutuhkan kemampuan visual parsing numerik dari VLM, berbeda dengan flow chart "
     "dan map yang lebih bersifat deskriptif proses dan geografis."),

    ("subsection", "4.3.4 Evaluasi Kualitas Caption Qwen2-VL-7B per Jenis Grafik"),

    ("body",
     "Untuk mengidentifikasi sumber noise pada caption, dilakukan tinjauan manual terhadap "
     "100 sampel caption yang dihasilkan oleh Qwen2-VL-7B-Instruct. Setiap caption "
     "dikategorikan ke dalam tiga kelas: Akurat (nilai numerik dan kategori benar), Parsial "
     "(sebagian informasi benar), dan Salah (nilai numerik tidak sesuai, kategori tertukar, "
     "atau deskripsi tidak relevan dengan konten grafik)."),

    ("body",
     "Tabel 4.3 Error Rate Caption Qwen2-VL-7B per Jenis Grafik\n"
     "Jenis Grafik | Error Rate | Masalah Utama\n"
     "pie_chart | ~67% | Nilai persentase salah, kategori tertukar\n"
     "bar_chart | ~54% | Nilai batang tidak akurat, skala salah baca\n"
     "composite_chart | ~18% | Sebagian komponen grafik gabungan tidak terbaca\n"
     "flow_chart | <10% | Qwen efektif mendeskripsikan alur proses\n"
     "table | <10% | Struktur tabel terbaca dengan baik\n"
     "line_chart | <10% | Tren naik/turun dideskripsikan dengan baik\n"
     "map | <10% | Lokasi dan label geografis terbaca"),

    ("body",
     "Error rate keseluruhan pada 100 sampel tinjauan adalah sekitar 22%, sesuai dengan "
     "proporsi bar+pie (~27%) dalam dataset dikalikan rata-rata error rate bar+pie (~60%). "
     "Temuan utama: Qwen2-VL-7B-Instruct efektif untuk grafik berbasis proses dan teks "
     "(flow chart, tabel, peta, line chart) dengan error rate di bawah 10%, namun tidak "
     "andal untuk grafik berbasis angka presisi (bar chart dan pie chart) dengan error rate "
     "54-67%. Nilai numerik pada grafik terstruktur sulit dibaca secara akurat oleh VLM "
     "generalis."),

    ("subsection", "4.3.5 Bukti Empiris: Eksklusi Bar+Pie Meningkatkan QWK"),

    ("body",
     "Untuk membuktikan secara kuantitatif bahwa caption noisy pada bar chart dan pie chart "
     "adalah penyebab gap performa (bukan faktor lain seperti arsitektur atau hyperparameter), "
     "dilakukan eksperimen eksklusi: model dilatih hanya pada sampel yang caption-nya andal."),

    ("body",
     "Eksperimen 092 mengeksklusi bar_chart (211 sampel) + pie_chart (71 sampel) + "
     "composite_chart (107 sampel) = 389 sampel, menyisakan 665 sampel dengan split "
     "465/99/101. Hasil test QWK = 0,4941, meningkat +0,015 dibandingkan Eksperimen 081 "
     "(0,4796). Perincian per trait: AC=0,181, JP=0,494, OS=0,418, CH=0,558, EL=0,446, "
     "GA=0,642, GD=0,530, LA=0,519, LD=0,601, PA=0,552. Meskipun terjadi peningkatan "
     "overall, trait OS turun drastis menjadi 0,418 karena composite chart memiliki sinyal "
     "visual-struktural yang berguna untuk penilaian organizational structure."),

    ("body",
     "Eksperimen 093 hanya mengeksklusi bar_chart (211) + pie_chart (71) = 282 sampel, "
     "mempertahankan composite chart. Sisa 772 sampel dibagi menjadi 540/115/117. "
     "Seeding dengan seed=42 memastikan distribusi tipe grafik merata di train/val/test; "
     "tanpa seeding (Eksperimen 091), QWK hanya 0,4945 karena bias clustering jenis grafik "
     "pada split sekuensial. Gain dari seeding sebesar +0,083 merupakan gain terbesar "
     "sepanjang penelitian ini."),

    ("body",
     "Eksperimen 093 menghasilkan QWK keseluruhan 0,5778, nilai terbaik di seluruh "
     "penelitian. Perincian per trait: AC=0,330, JP=0,572, OS=0,589, CH=0,606, EL=0,503, "
     "GA=0,688, GD=0,653, LA=0,658, LD=0,610, PA=0,570. Seluruh 10 trait mencapai nilai "
     "QWK tertinggi masing-masing dibandingkan semua varian T2T sebelumnya. Perbandingan "
     "antara Eksperimen 092 dan 093 mengkonfirmasi bahwa composite chart dengan error rate "
     "18% masih memberikan sinyal berguna dan tidak seharusnya dieksklusi."),

    ("body",
     "Kesimpulan dari eksperimen eksklusi: menghapus hanya bar+pie (+0,098 vs. Eksperimen "
     "081) jauh lebih efektif dibandingkan menghapus bar+pie+composite (+0,015). Keputusan "
     "eksklusi harus proporsional dengan error rate caption, bukan sekadar menghapus semua "
     "jenis grafik yang berpotensi bermasalah."),

    ("subsection", "4.3.6 Kesimpulan: Qwen2-VL-7B Tidak Andal pada Bar Chart dan Pie Chart"),

    ("body",
     "Dua bentuk bukti yang saling mengkonfirmasi menunjukkan masalah yang sama pada "
     "Qwen2-VL-7B-Instruct dalam konteks caption grafik IELTS. Pertama, bukti kualitatif "
     "dari tinjauan manual menunjukkan error rate ~54-67% pada bar chart dan pie chart "
     "berupa kesalahan nilai numerik dan kategori yang tertukar. Kedua, bukti kuantitatif "
     "dari eksklusi bar+pie: QWK meningkat dari 0,4796 ke 0,5778 (+0,098), gain terbesar "
     "sepanjang penelitian ini."),

    ("body",
     "Implikasi dari temuan ini adalah bahwa permasalahan bukan terletak pada arsitektur "
     "text-to-text, melainkan pada kemampuan VLM generalis dalam menginterpretasikan grafik "
     "terstruktur berbasis angka presisi. Dua arah solusi yang dieksplorasi selanjutnya "
     "adalah: (a) penggunaan captioner yang dikhususkan untuk grafik terstruktur seperti "
     "DePlot dan MATCHA (dibahas pada RQ4, Subbab 4.4), dan (b) pengujian VLM alternatif "
     "dengan kemampuan chart understanding yang lebih baik (dibahas pada RQ5, Subbab 4.5)."),

    ("subsection", "4.3.7 Track A vs. Track B (Text-to-Text)"),

    ("body",
     "RQ3 bertanya: apakah pendekatan text-to-text berbasis caption VLM menghasilkan QWK "
     "lebih tinggi dibandingkan fusi multimoda langsung (ResNet18 + RoBERTa)? Untuk "
     "menjawab pertanyaan ini, dilakukan perbandingan head-to-head antara sistem terbaik "
     "kedua track: Eksperimen 033 (Track A, RoBERTa late fusion, QWK=0,5126) vs. "
     "Eksperimen 093 (Track B, T2T excl bar+pie seeded, QWK=0,5778)."),

    ("body",
     "Tabel 4.4 Perbandingan Per-Trait: Track A (Exp033) vs. Track B (Exp093)\n"
     "Trait | Track A (Exp033) | Track B (Exp093) | Selisih\n"
     "AC | 0,271 | 0,330 | +0,059\n"
     "JP | 0,463 | 0,572 | +0,109\n"
     "OS | 0,622 | 0,589 | -0,033\n"
     "CH | 0,579 | 0,606 | +0,027\n"
     "EL | 0,443 | 0,503 | +0,060\n"
     "GA | 0,591 | 0,688 | +0,097\n"
     "GD | 0,586 | 0,653 | +0,067\n"
     "LA | 0,581 | 0,658 | +0,077\n"
     "LD | 0,542 | 0,610 | +0,068\n"
     "PA | 0,446 | 0,570 | +0,124\n"
     "Overall | 0,5126 | 0,5778 | +0,065"),

    ("body",
     "Track B mengungguli Track A pada 9 dari 10 trait dengan keseluruhan selisih +0,065 "
     "QWK. Satu-satunya trait di mana Track A lebih unggul adalah organizational_structure "
     "(OS: 0,622 vs. 0,589). Hal ini dapat dijelaskan oleh kemampuan ResNet18 dalam "
     "menangkap aspek visual layout grafik (kepadatan elemen, panjang visual, tata letak "
     "spasial) yang tidak tersampaikan secara eksplisit dalam teks caption."),

    ("body",
     "Jawaban RQ3: Track B (text-to-text) secara keseluruhan lebih baik (+0,065 QWK), "
     "mengkonfirmasi prediksi Bursztyn et al. (2024) dan Zhao et al. (2025). Konversi "
     "masalah multimodal menjadi teks murni memungkinkan RoBERTa memanfaatkan kemampuan "
     "pre-training bahasa secara penuh untuk semua trait linguistik. Pengecualian pada "
     "trait OS mengindikasikan bahwa fitur visual ResNet18 masih relevan untuk penilaian "
     "aspek struktural, dan penelitian lanjutan dapat mengeksplorasi ensemble T2T + image "
     "feature untuk trait ini."),

    # ── 4.4 ──────────────────────────────────────────────────────────────────
    ("section", "4.4 Perbandingan Captioner untuk Bar Chart dan Pie Chart"),

    ("body",
     "Subbab ini menjawab RQ4: di antara DePlot dan MATCHA, captioner mana yang "
     "menghasilkan caption lebih andal dan memberikan kontribusi terbaik terhadap performa "
     "scoring pada dataset EssayJudge?"),

    ("subsection", "4.4.1 Dasar Teori: DePlot dan MATCHA sebagai Captioner Grafik Terstruktur"),

    ("body",
     "DePlot (Liu et al., 2023) adalah model berbasis Pix2Struct yang dilatih khusus "
     "untuk mengekstraksi tabel terstruktur dari grafik (plot-to-table). Output DePlot "
     "berupa tabel markdown yang merepresentasikan data numerik secara terstruktur. "
     "Kekuatan utama DePlot adalah kemampuannya mengekstraksi nilai numerik secara "
     "struktural dari grafik, namun output mentahnya bukan narasi sehingga memerlukan "
     "VLM kedua untuk menghasilkan deskripsi naratif (pipeline dua langkah)."),

    ("body",
     "MATCHA (Liu et al., 2023) juga berbasis Pix2Struct, namun dilatih pada dataset "
     "chart2text-statista untuk langsung menghasilkan narasi deskriptif dari grafik "
     "dalam satu langkah. Kekuatan MATCHA adalah narasi yang natural dan efisiensi "
     "komputasi (pipeline satu langkah), namun akurasi nilai numerik tidak dijamin "
     "karena bergantung pada visual parsing VLM secara holistik."),

    ("body",
     "Hipotesis RQ4: DePlot+Qwen7B diperkirakan lebih unggul karena grounding numerik "
     "struktural menghasilkan caption yang lebih faktual, meskipun MATCHA lebih efisien. "
     "Untuk tugas AES, akurasi konten caption lebih penting dibandingkan kelancaran "
     "narasi semata."),

    ("subsection", "4.4.2 DePlot+Qwen7B sebagai Captioner Bar+Pie"),

    ("body",
     "Eksperimen 103 mengimplementasikan pipeline dua langkah untuk bar chart dan pie "
     "chart: DePlot mengekstraksi tabel markdown dari gambar grafik, kemudian "
     "Qwen2-VL-7B-Instruct menerima gambar beserta tabel tersebut sebagai konteks untuk "
     "menghasilkan narasi yang akurat secara faktual. Untuk jenis grafik lainnya, "
     "Qwen7B langsung menghasilkan caption dari gambar. Konfigurasi pelatihan identik "
     "dengan Eksperimen 081 (seed=42, freeze 6/12, lr=1e-4) dengan split 737/158/159 "
     "yang mencakup seluruh 1.054 sampel."),

    ("body",
     "Eksperimen 103 menghasilkan QWK keseluruhan 0,5026 pada test set. Perincian per "
     "trait: AC=0,276, JP=0,493, OS=0,542, CH=0,560, EL=0,486, GA=0,576, GD=0,573, "
     "LA=0,562, LD=0,520, PA=0,439. Nilai ini menjadi baseline untuk perbandingan RQ4. "
     "DePlot grounding meningkatkan akurasi deskripsi nilai numerik bar+pie, yang "
     "berkontribusi pada peningkatan trait JP karena persuasiveness didukung oleh data "
     "yang akurat."),

    ("subsection", "4.4.3 MATCHA sebagai Captioner Bar+Pie"),

    ("body",
     "Eksperimen 020 menggunakan MATCHA (282M parameter, Pix2Struct, dilatih pada "
     "chart2text-statista) sebagai captioner langsung untuk bar chart dan pie chart. "
     "Konfigurasi pelatihan scoring model identik dengan Eksperimen 103 (split, seed=42, "
     "freeze, hyperparameter)."),

    ("body",
     "Eksperimen 020 menghasilkan QWK keseluruhan 0,5213 pada test set, lebih tinggi "
     "dibandingkan DePlot+Qwen7B (Eksperimen 103 = 0,5026). Meskipun secara numerik "
     "MATCHA menghasilkan QWK yang lebih baik, tinjauan manual terhadap 100 sampel "
     "caption mengungkapkan masalah yang serius pada kualitas faktual caption, "
     "sebagaimana dibahas pada Subbab 4.4.4. Berdasarkan temuan tersebut, MATCHA "
     "tidak dipilih sebagai captioner meskipun QWK-nya lebih tinggi."),

    ("subsection", "4.4.4 Evaluasi Kualitas Caption: DePlot vs. MATCHA"),

    ("body",
     "Untuk memahami perbedaan kualitas caption antara DePlot+Qwen7B dan MATCHA secara "
     "kualitatif, dilakukan tinjauan manual terhadap 100 sampel caption bar+pie dari "
     "masing-masing captioner. Setiap caption dikategorikan berdasarkan akurasi faktual: "
     "Akurat (nilai numerik dan kategori benar), Parsial, atau Salah."),

    ("body",
     "Tabel 4.5 Perbandingan Error Rate Caption per Jenis Grafik\n"
     "Captioner | Bar Chart Error Rate | Pie Chart Error Rate\n"
     "Qwen7B baseline (dari 4.3.4) | 54% | 67%\n"
     "DePlot+Qwen7B (Exp103) | 23% | 67%\n"
     "MATCHA (Exp020) | 100% | 100%"),

    ("body",
     "Analisis DePlot+Qwen7B: error rate bar chart turun drastis dari 54% menjadi 23% "
     "(-31 poin persentase). DePlot berhasil mengekstraksi nilai batang secara struktural "
     "dari tabel markdown, dan Qwen7B kemudian menggunakan tabel tersebut sebagai grounding "
     "numerik. Namun demikian, error rate pie chart tetap 67% karena proporsi pie sulit "
     "dikonversi ke tabel terstruktur secara akurat oleh DePlot."),

    ("body",
     "Analisis MATCHA: error rate mencapai 100% pada kedua jenis grafik. Setiap caption "
     "yang dihasilkan mengandung nilai yang salah atau kategori yang tertukar. Yang menarik, "
     "narasi tetap terdengar koheren secara linguistik meskipun konten faktualnya "
     "sepenuhnya salah. Fenomena ini menjelaskan mengapa MATCHA menghasilkan QWK lebih "
     "tinggi (0,5213) dibandingkan DePlot+Qwen7B (0,5026): RoBERTa merespons kualitas "
     "bahasa (fluency) dan pola tekstual, bukan akurasi konten grafik. QWK tinggi MATCHA "
     "adalah artefak koherensi linguistik, bukan refleksi pemahaman grafik yang benar."),

    ("subsection", "4.4.5 Mengapa DePlot Dipilih Meskipun QWK-nya Lebih Rendah"),

    ("body",
     "Pemilihan DePlot+Qwen7B atas MATCHA didasarkan pada prinsip bahwa akurasi faktual "
     "caption adalah prasyarat yang tidak dapat dikompromikan untuk sistem AES yang dapat "
     "dipertanggungjawabkan secara akademik. QWK tidak selalu merefleksikan keandalan "
     "sistem: kasus MATCHA membuktikan bahwa metrik QWK dapat dimanipulasi secara tidak "
     "sengaja oleh fluency linguistik yang tinggi, bahkan ketika konten faktual caption "
     "sepenuhnya salah."),

    ("body",
     "DePlot dengan nilai numerik terstruktur menghasilkan caption yang dapat diverifikasi "
     "dan terpercaya, lebih sesuai sebagai komponen dalam sistem penilaian akademik. "
     "Sebagai catatan tambahan, PaliGemma juga dievaluasi sebagai kandidat ketiga "
     "(Eksperimen 021), namun proses caption generation gagal sepenuhnya pada lingkungan "
     "Kaggle P100 sehingga tidak dapat digunakan."),

    ("subsection", "4.4.6 Captioner Alternatif: Llama3.2-11B"),

    ("body",
     "Eksperimen 13 menggunakan Llama3.2-11B-Vision sebagai captioner untuk seluruh "
     "1.054 sampel dengan konfigurasi seeded (seed=42). Hasil test QWK = 0,4701, lebih "
     "rendah dibandingkan Qwen7B full (Eksperimen 081 = 0,4796) sebesar -0,010. Perincian "
     "per trait: AC=0,235, JP=0,429, OS=0,540, CH=0,513, EL=0,431, GA=0,554, GD=0,556, "
     "LA=0,524, LD=0,504, PA=0,416."),

    ("body",
     "Eksperimen 112 menggabungkan DePlot+Llama3.2-11B untuk bar chart dan pie chart "
     "dengan Qwen7B untuk jenis grafik lainnya, dalam konfigurasi seeded. Hasil test "
     "QWK = 0,4690, lebih rendah dibandingkan DePlot+Qwen7B (Eksperimen 103 = 0,5026) "
     "sebesar -0,034. Perincian per trait: AC=0,256, JP=0,389, OS=0,532, CH=0,528, "
     "EL=0,430, GA=0,532, GD=0,558, LA=0,582, LD=0,476, PA=0,408."),

    ("body",
     "Temuan dari kedua eksperimen ini mengkonfirmasi bahwa ukuran model VLM yang lebih "
     "besar (11B vs. 7B parameter) bukan faktor penentu kualitas caption untuk AES. "
     "Llama3.2-11B menghasilkan caption yang lebih verbose namun kurang terkalibrasi "
     "untuk format deskripsi grafik IELTS. Spesialisasi domain captioner jauh lebih "
     "menentukan dibandingkan skala model semata."),

    ("subsection", "4.4.7 Jawaban RQ4"),

    ("body",
     "Jawaban RQ4: DePlot+Qwen7B dipilih sebagai captioner untuk bar chart dan pie chart "
     "meskipun MATCHA menghasilkan QWK lebih tinggi (0,5213 vs. 0,5026). Tinjauan manual "
     "mengkonfirmasi bahwa caption MATCHA sepenuhnya tidak akurat secara faktual (error "
     "rate 100% pada kedua jenis grafik), sementara QWK tinggi yang dihasilkan merupakan "
     "artefak dari koherensi linguistik bukan pemahaman grafik."),

    ("body",
     "Temuan penting dari RQ4: metrik QWK saja tidak mencukupi sebagai kriteria pemilihan "
     "captioner dalam sistem AES berbasis T2T. Evaluasi kualitas caption secara manual "
     "diperlukan untuk memastikan sistem yang dapat diandalkan. Selain itu, ukuran model "
     "bukan faktor penentu kualitas caption (Llama3.2-11B < Qwen7B < DePlot+Qwen7B)."),

    # ── 4.5 ──────────────────────────────────────────────────────────────────
    ("section", "4.5 Perbandingan VLM 7B: Qwen2-VL-7B-Instruct vs. DeepSeek-VL-7B"),

    ("body",
     "Subbab ini menjawab RQ5: apakah terdapat perbedaan performa yang signifikan antara "
     "Qwen2-VL-7B-Instruct dan DeepSeek-VL-7B sebagai captioner dalam pipeline T2T, "
     "dalam batasan parameter model maksimal 7B?"),

    ("subsection", "4.5.1 Konteks: Baseline Zero-Shot VLM pada EssayJudge"),

    ("body",
     "Singh et al. (2024) melaporkan hasil evaluasi zero-shot berbagai MLLM pada "
     "EssayJudge (Tabel 2 pada paper). DeepSeek-VL-7B menghasilkan rata-rata QWK ~0,11, "
     "sementara Qwen2-VL-7B-Instruct menghasilkan ~0,14. Dalam setting zero-shot, "
     "Qwen2-VL-7B unggul +0,03 atas DeepSeek-VL-7B."),

    ("body",
     "Hipotesis RQ5: dalam pipeline T2T dengan supervised training, perbedaan performa "
     "zero-shot ini mungkin diperkuat atau justru hilang, tergantung seberapa baik tiap "
     "VLM menghasilkan caption yang dapat dimanfaatkan oleh RoBERTa scorer. Kemampuan "
     "zero-shot tidak selalu berkorelasi dengan kualitas caption untuk downstream scoring."),

    ("subsection", "4.5.2 Qwen2-VL-7B-Instruct sebagai Baseline"),

    ("body",
     "Eksperimen 093 menggunakan Qwen2-VL-7B-Instruct (kuantisasi 4-bit NF4, Kaggle P100) "
     "untuk menghasilkan caption 772 sampel non-bar/non-pie (83 gambar unik). Dengan "
     "konfigurasi T2T Dual RoBERTa yang telah dioptimalkan (seed=42, freeze 6/12, "
     "split 540/115/117), Eksperimen 093 menghasilkan test QWK = 0,5778 (direferensikan "
     "dari Subbab 4.3.5). Perbandingan dengan zero-shot Qwen (0,5778 vs. ~0,14) "
     "menunjukkan bahwa supervised T2T memberikan peningkatan hampir 4 kali lipat, "
     "mengkonfirmasi nilai fine-tuning scorer pada caption VLM."),

    ("subsection", "4.5.3 DeepSeek-VL-7B sebagai Captioner Alternatif"),

    ("body",
     "[DATA PENDING \u2014 eksperimen belum dijalankan] DeepSeek-VL-7B memiliki jumlah "
     "parameter identik dengan Qwen2-VL-7B namun arsitektur yang berbeda. Rencana: "
     "menghasilkan caption untuk 772 sampel non-bar/non-pie yang sama (konfigurasi "
     "Eksperimen 093), kemudian melatih scoring model dengan konfigurasi identik (split, "
     "seed=42, freeze, hyperparameter). Hasil akan diisi setelah eksperimen selesai."),

    ("subsection", "4.5.4 Konteks Tambahan: InternVL2-8B"),

    ("body",
     "Sebagai referensi konteks, InternVL2-8B (8B parameter, sedikit di luar batasan "
     "penelitian yaitu <=7B) diuji pada konfigurasi full 1.054 sampel seeded. Eksperimen "
     "12 menghasilkan test QWK = 0,5017 dengan perincian per trait: AC=0,300, JP=0,453, "
     "OS=0,577, CH=0,580, EL=0,484, GA=0,532, GD=0,558, LA=0,576, LD=0,507, PA=0,452. "
     "Nilai ini hampir identik dengan DePlot+Qwen7B (Eksperimen 103 = 0,5026, selisih "
     "hanya 0,001). Temuan ini mengkonfirmasi bahwa penambahan 1B parameter VLM tidak "
     "memberikan gain yang signifikan; bottleneck bukan pada kapasitas VLM melainkan "
     "pada strategi captioning dan penanganan jenis grafik bermasalah."),

    ("subsection", "4.5.5 Jawaban RQ5"),

    ("body",
     "[Akan dilengkapi setelah eksperimen DeepSeek selesai] Hipotesis berdasarkan "
     "performa zero-shot: Qwen2-VL-7B akan mengungguli DeepSeek-VL-7B dalam pipeline "
     "T2T. Jika terkonfirmasi, hal ini mengindikasikan bahwa pemilihan VLM 7B berpengaruh "
     "pada kualitas AES dan Qwen2-VL lebih sesuai untuk caption grafik IELTS. Jika "
     "DeepSeek menghasilkan performa yang setara, maka arsitektur VLM 7B yang berbeda "
     "dapat menghasilkan performa comparable dan faktor lain seperti strategi sampling "
     "serta prompt engineering menjadi lebih menentukan."),

    # ── 4.6 ──────────────────────────────────────────────────────────────────
    ("section", "4.6 Signifikansi Statistik"),

    ("body",
     "Subbab ini menjawab RQ6: apakah prediksi sistem terbaik (Eksperimen 093) tidak "
     "berbeda secara signifikan dari anotasi manusia pada setiap trait?"),

    ("subsection", "4.6.1 Metodologi Uji Statistik"),

    ("body",
     "Uji statistik yang digunakan adalah paired t-test per trait dengan koreksi "
     "Bonferroni. Uji ini menguji apakah prediksi sistem terbaik secara sistematis "
     "berbeda dari anotasi manusia pada setiap trait secara individual. Koreksi "
     "Bonferroni diterapkan untuk 10 trait secara bersamaan menghasilkan ambang "
     "signifikansi alpha = 0,05/10 = 0,005. Referensi metodologi dari Yannakoudakis "
     "et al. (2011) dan Zhao et al. (2025) untuk evaluasi statistik sistem AES."),

    ("body",
     "Setup: test set 158 sampel dari Eksperimen 093. H0 untuk setiap trait: "
     "mean(prediksi Eksperimen 093) = mean(ground truth). Jika p > 0,005 (gagal tolak "
     "H0), prediksi tidak berbeda signifikan dari anotasi manusia untuk trait tersebut. "
     "Jika p < 0,005 (tolak H0), terdapat systematic bias pada prediksi."),

    ("subsection", "4.6.2 Paired T-Test per Trait"),

    ("body",
     "[DATA PENDING \u2014 memerlukan prediksi per-sampel dari Eksperimen 093] "
     "Berdasarkan nilai QWK per trait, hipotesis tentang hasil uji adalah sebagai berikut. "
     "Untuk trait dengan QWK tinggi (GA=0,688, GD=0,653, LA=0,658, LD=0,610, CH=0,606), "
     "diperkirakan p > 0,005 (gagal tolak H0), yang berarti prediksi tidak berbeda "
     "signifikan dari anotasi manusia. Untuk trait AC (QWK=0,330 sebagai outlier "
     "terendah), diperkirakan p < 0,005 (tolak H0), yang mengindikasikan adanya "
     "systematic bias di mana model cenderung underpredict kejelasan argumen. "
     "Hasil aktual akan diisi setelah data prediksi per-sampel tersedia."),

    ("subsection", "4.6.3 Interpretasi dan Diskusi"),

    ("body",
     "Trait dengan QWK tinggi seperti grammatical_accuracy (0,688) dan "
     "lexical_accuracy (0,658) mengindikasikan bahwa prediksi mendekati anotasi manusia; "
     "sistem dapat diandalkan untuk trait linguistik yang terukur secara eksplisit. "
     "Trait ini bergantung pada fitur permukaan teks yang konsisten dan dapat "
     "diidentifikasi oleh RoBERTa melalui pre-training pada teks bahasa Inggris berskala "
     "besar."),

    ("body",
     "Argument_clarity (AC = 0,330) merupakan outlier dengan QWK terendah di seluruh "
     "penelitian. Penilaian kejelasan argumen memerlukan pemahaman holistik terhadap "
     "tema dan posisi penulis secara keseluruhan, sesuatu yang sulit ditangkap oleh "
     "fitur linguistik lokal RoBERTa. Implikasi praktis: sistem Eksperimen 093 dapat "
     "digunakan dengan kepercayaan tinggi untuk trait linguistik (GA, GD, LA, LD, PA) "
     "namun masih memerlukan evaluasi manusia untuk trait AC dan sebagian JP."),

    # ── 4.7 ──────────────────────────────────────────────────────────────────
    ("section", "4.7 Perbandingan dengan Penelitian Terdahulu dan Keterbatasan"),

    ("subsection", "4.7.1 Perbandingan vs. Baseline Zero-Shot MLLM"),

    ("body",
     "Tabel 4.6 membandingkan performa sistem yang dikembangkan dalam penelitian ini "
     "dengan baseline zero-shot MLLM yang dilaporkan oleh Singh et al. (2024) pada "
     "benchmark EssayJudge."),

    ("body",
     "Tabel 4.6 Perbandingan dengan Baseline Zero-Shot pada EssayJudge\n"
     "Model | Tipe | Avg QWK\n"
     "Yi-VL 6B | Open-source, zero-shot | ~0,07\n"
     "DeepSeek-VL 7B | Open-source, zero-shot | ~0,11\n"
     "LLaMA-3.2-Vision 11B | Open-source, zero-shot | ~0,13\n"
     "Qwen2-VL 7B | Open-source, zero-shot | ~0,14\n"
     "MiniCPM-LLaMA3-V2.5 8B | Open-source, zero-shot | ~0,21\n"
     "GPT-4o | Closed-source, zero-shot | ~0,54\n"
     "Exp033, Track A (ours) | Fine-tuned, supervised | 0,5126\n"
     "Exp093, Track B (ours) | Fine-tuned, supervised | 0,5778"),

    ("body",
     "Eksperimen 093 melampaui seluruh MLLM open-source zero-shot dengan selisih lebih "
     "dari 0,35 QWK. Selain itu, Eksperimen 093 melampaui GPT-4o zero-shot sebesar +0,04 "
     "meskipun perbandingan ini tidak sepenuhnya setara (GPT-4o menggunakan format "
     "evaluasi yang berbeda dalam paper EssayJudge). Temuan ini mengkonfirmasi bahwa "
     "supervised fine-tuning dengan 737 sampel berlabel jauh lebih efektif dibandingkan "
     "zero-shot inference dari model besar manapun untuk tugas AES IELTS Task 1 yang "
     "spesifik."),

    ("subsection", "4.7.2 Konfirmasi Temuan Literatur"),

    ("body",
     "Tabel 4.7 merangkum konfirmasi terhadap klaim-klaim utama dari literatur yang "
     "menjadi landasan penelitian ini."),

    ("body",
     "Tabel 4.7 Konfirmasi Klaim Literatur berdasarkan Hasil Eksperimen\n"
     "Klaim Literatur | Sumber | Terkonfirmasi?\n"
     "Late fusion lebih baik dari early/intermediate untuk modalitas berbeda | Baltrusaitis et al. (2019) | Ya (Exp030-032)\n"
     "RoBERTa mengungguli BERT pada downstream tasks | Liu et al. (2019) | Ya (Exp032-033, +0,029)\n"
     "Teks lebih informatif dari fitur visual untuk chart reasoning | Bursztyn et al. (2024) | Ya (Track B > Track A)\n"
     "DePlot meningkatkan akurasi reasoning grafik terstruktur | Liu et al. (2023) | Ya (Exp103 vs Exp081)\n"
     "Pipeline VLM meningkatkan penilaian akademik berbasis gambar | Zhao et al. (2025) | Ya (Track B terbaik)"),

    ("subsection", "4.7.3 Keterbatasan Penelitian"),

    ("body",
     "Terdapat beberapa keterbatasan dalam penelitian ini yang perlu diperhatikan dalam "
     "interpretasi hasil."),

    ("numbered",
     "1. Dataset kecil: test set hanya terdiri dari 158 sampel, sehingga estimasi QWK "
     "memiliki variance yang relatif tinggi. Hasil mungkin tidak sepenuhnya stabil pada "
     "pembagian data yang berbeda."),

    ("numbered",
     "2. Batasan VLM <=7B parameter: model dengan parameter lebih besar (>13B) tidak "
     "dievaluasi akibat keterbatasan GPU (RTX 3060 6GB dan Kaggle P100 16GB). "
     "InternVL2-8B (Eksperimen 12) menunjukkan tidak ada gain signifikan dari penambahan "
     "1B parameter, namun temuan ini belum tentu berlaku untuk model yang jauh lebih besar."),

    ("numbered",
     "3. RQ5 pending: eksperimen DeepSeek-VL-7B belum dijalankan sehingga kesimpulan "
     "RQ5 masih bersifat sementara berdasarkan performa zero-shot."),

    ("numbered",
     "4. RQ6 pending: prediksi per-sampel Eksperimen 093 belum diekstraksi sehingga "
     "hasil uji statistik paired t-test per trait belum tersedia."),

    ("numbered",
     "5. Argument_clarity konsisten sulit diprediksi (QWK terbaik = 0,330): penilaian "
     "kejelasan argumen memerlukan pemahaman holistik yang melampaui fitur linguistik "
     "lokal RoBERTa."),

    ("numbered",
     "6. Tidak ada evaluasi lintas-dataset: generalisasi sistem ke dataset AES lain "
     "seperti ASAP atau ASAP++ belum diverifikasi."),

    ("numbered",
     "7. Caption dihasilkan sekali (frozen inference): fine-tuning VLM pada domain IELTS "
     "secara khusus berpotensi meningkatkan kualitas caption secara substansial, namun "
     "di luar cakupan penelitian ini akibat keterbatasan sumber daya komputasi."),
]

# ── Italic terms ──────────────────────────────────────────────────────────────
ITALIC_TERMS = [
    r'early fusion', r'intermediate fusion', r'late fusion',
    r'text-to-text', r'open-source', r'closed-source',
    r'multi-task learning', r'multi-task', r'per-trait',
    r'fine-tuning', r'fine-tuned', r'fine-tune',
    r'zero-shot', r'benchmark', r'pipeline', r'captioner',
    r'\bcaption\b', r'\bcaptions\b',
    r'feature vector', r'feature map',
    r'encoder', r'decoder', r'tokenizer', r'embedding',
    r'pre-training', r'pre-trained', r'pre-train',
    r'downstream', r'backbone', r'pooling',
    r'dropout', r'batch size', r'learning rate',
    r'epoch', r'checkpoint', r'inference',
    r'softmax', r'sigmoid',
    r'loss function', r'gradient',
    r'overfitting',
    r'cross-attention',
    r'reasoning', r'question answering',
    r'image encoder', r'text encoder',
    r'global average pooling',
    r'fully connected',
    r'plot-to-table', r'chart2text',
    r'fluency', r'grounding',
]

# ── Helpers ───────────────────────────────────────────────────────────────────
def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment, named='NORMAL_TEXT',
                   first_line=None, indent_start=None, space_above=None, space_below=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': 'namedStyleType,alignment,indentFirstLine,indentStart,spaceAbove,spaceBelow'
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False, size_pt=12, font='Times New Roman'):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'bold': bold, 'italic': italic,
            'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
            'weightedFontFamily': {'fontFamily': font},
        },
        'fields': 'bold,italic,fontSize,weightedFontFamily'
    }}

# ── Build document ─────────────────────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text in segments:
    start = len(full_text) + 1
    full_text += text + '\n'
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

italic_ranges = []
covered = set()
for term_pattern in ITALIC_TERMS:
    pattern = re.compile(term_pattern, re.IGNORECASE)
    for match in pattern.finditer(full_text):
        ms, me = match.start(), match.end()
        if any(i in covered for i in range(ms, me)):
            continue
        covered.update(range(ms, me))
        italic_ranges.append((ms + 1, me + 1))

print(f'Italic ranges found: {len(italic_ranges)}')

# ── Build requests ─────────────────────────────────────────────────────────────
requests = []

for seg_type, text in reversed(segments):
    requests.append(req_insert(text + '\n', 1, TAB_ID))

for start, end, seg_type, text in seg_positions:
    if seg_type == 'chapter':
        requests.append(req_para_style(start, end, TAB_ID, 'CENTER',
                                        space_above=0, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=14))

    elif seg_type == 'section':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=12, space_below=6))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'subsection':
        requests.append(req_para_style(start, end, TAB_ID, 'START',
                                        space_above=6, space_below=3))
        requests.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'body':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=35.43, space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

    elif seg_type == 'numbered':
        requests.append(req_para_style(start, end, TAB_ID, 'JUSTIFIED',
                                        first_line=0, indent_start=0,
                                        space_above=0, space_below=0))
        requests.append(req_text_style(start, end, TAB_ID, bold=False, italic=False, size_pt=12))

for (ms, me) in italic_ranges:
    requests.append(req_text_style(ms, me, TAB_ID, italic=True, size_pt=12))

print(f'Sending {len(requests)} requests...')

BATCH = 50
for i in range(0, len(requests), BATCH):
    service.documents().batchUpdate(
        documentId=DOCUMENT_ID,
        body={'requests': requests[i:i+BATCH]}
    ).execute()
    print(f'  Batch {i//BATCH + 1}/{(len(requests)-1)//BATCH + 1} done')

print('Done.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
