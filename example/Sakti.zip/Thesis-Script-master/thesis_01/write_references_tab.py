import sys
sys.stdout.reconfigure(encoding='utf-8')
import time
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/documents']
SERVICE_ACCOUNT_FILE = 'C:/Outpost/Skripsi/Research 4/primal-index-492509-s6-133bb47b7a74.json'
DOCUMENT_ID = '1F4gu8nGzh_SM1m001cipTlcQZPg6lzlO5Hd-w1_7tLY'
TAB_ID = 't.catchhmle3jf'

creds = service_account.Credentials.from_service_account_file(SERVICE_ACCOUNT_FILE, scopes=SCOPES)
service = build('docs', 'v1', credentials=creds)

# ── Helpers ────────────────────────────────────────────────────────────────────
def find_tab(tabs, target_id):
    for tab in tabs:
        if tab.get('tabProperties', {}).get('tabId') == target_id:
            return tab
        child = find_tab(tab.get('childTabs', []), target_id)
        if child:
            return child
    return None

def req_insert(text, index, tab_id):
    return {'insertText': {'text': text, 'location': {'index': index, 'tabId': tab_id}}}

def req_para_style(start, end, tab_id, alignment='START', named='NORMAL_TEXT',
                   first_line=None, indent_start=None,
                   space_above=None, space_below=None, line_spacing=None):
    ps = {'namedStyleType': named, 'alignment': alignment}
    fields = 'namedStyleType,alignment'
    if first_line is not None:
        ps['indentFirstLine'] = {'magnitude': first_line, 'unit': 'PT'}
        fields += ',indentFirstLine'
    if indent_start is not None:
        ps['indentStart'] = {'magnitude': indent_start, 'unit': 'PT'}
        fields += ',indentStart'
    if space_above is not None:
        ps['spaceAbove'] = {'magnitude': space_above, 'unit': 'PT'}
        fields += ',spaceAbove'
    if space_below is not None:
        ps['spaceBelow'] = {'magnitude': space_below, 'unit': 'PT'}
        fields += ',spaceBelow'
    if line_spacing is not None:
        ps['lineSpacing'] = line_spacing
        fields += ',lineSpacing'
    return {'updateParagraphStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'paragraphStyle': ps,
        'fields': fields,
    }}

def req_text_style(start, end, tab_id, bold=False, italic=False,
                   size_pt=11, font='Times New Roman', underline=False):
    ts = {
        'bold': bold, 'italic': italic, 'underline': underline,
        'fontSize': {'magnitude': size_pt, 'unit': 'PT'},
        'weightedFontFamily': {'fontFamily': font},
    }
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': ts,
        'fields': 'bold,italic,underline,fontSize,weightedFontFamily',
    }}

def req_link(start, end, tab_id, url):
    return {'updateTextStyle': {
        'range': {'startIndex': start, 'endIndex': end, 'tabId': tab_id},
        'textStyle': {
            'link': {'url': url},
            'foregroundColor': {'color': {'rgbColor': {'red': 0.07, 'green': 0.36, 'blue': 0.73}}},
            'underline': True,
        },
        'fields': 'link,foregroundColor,underline',
    }}

def batch_update(reqs):
    BATCH = 50
    for i in range(0, len(reqs), BATCH):
        service.documents().batchUpdate(
            documentId=DOCUMENT_ID,
            body={'requests': reqs[i:i + BATCH]}
        ).execute()

# ── Phase 1: Clear tab ─────────────────────────────────────────────────────────
doc = service.documents().get(documentId=DOCUMENT_ID, includeTabsContent=True).execute()
tab = find_tab(doc.get('tabs', []), TAB_ID)
body = tab.get('documentTab', {}).get('body', {})
content = body.get('content', [])
end_index = content[-1].get('endIndex', 1) if content else 1

if end_index > 2:
    batch_update([{
        'deleteContentRange': {
            'range': {'startIndex': 1, 'endIndex': end_index - 1, 'tabId': TAB_ID}
        }
    }])
    print(f'Cleared {end_index - 2} characters.')

# ── Reference data ─────────────────────────────────────────────────────────────
# Format: (number, citation_text, url, note)
# url=None = no link; note=None = no note

REFS_221 = [
    (
        '1.',
        'Page, E. B. (1966). The imminence of grading essays by computer. '
        'Phi Delta Kappan, 47(5), 238-243.',
        'https://www.yumpu.com/en/document/view/9445921/the-imminence-of-grading-essays-by-computer',
        'Seminal PEG paper; pre-internet, no DOI. Yumpu scan only.',
    ),
    (
        '2.',
        'Burstein, J. (2003). The e-rater scoring engine: Automated essay scoring with '
        'natural language processing. In M. D. Shermis & J. Burstein (Eds.), Automated '
        'Essay Scoring: A Cross-Disciplinary Perspective (pp. 113-122). Lawrence Erlbaum.',
        'https://www.researchgate.net/publication/285641086_The_e-raterR_automated_essay_scoring_system',
        'Book chapter; no direct DOI. ResearchGate has PDF preview.',
    ),
    (
        '3.',
        'Landauer, T. K., Foltz, P. W., & Laham, D. (1998). An introduction to latent '
        'semantic analysis. Discourse Processes, 25(2-3), 259-284.',
        'https://doi.org/10.1080/01638539809545028',
        'CATATAN: Ditulis di teks sebagai Landauer et al. (1997) '
        'tetapi tahun publikasi sebenarnya adalah 1998. Perlu dikoreksi di naskah.',
    ),
    (
        '4.',
        'Shermis, M. D., & Burstein, J. (Eds.). (2013). Handbook of Automated Essay '
        'Evaluation: Current Applications and New Directions. Routledge.',
        'https://doi.org/10.4324/9780203122761',
        'Edited volume; DOI mengarah ke halaman buku Taylor & Francis.',
    ),
    (
        '5.',
        'Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., '
        'Kaiser, L., & Polosukhin, I. (2017). Attention is all you need. '
        'Advances in Neural Information Processing Systems, 30.',
        'https://arxiv.org/abs/1706.03762',
        None,
    ),
    (
        '6.',
        'Devlin, J., Chang, M.-W., Lee, K., & Toutanova, K. (2019). BERT: Pre-training '
        'of deep bidirectional transformers for language understanding. '
        'Proceedings of NAACL-HLT 2019, 4171-4186.',
        'https://arxiv.org/abs/1810.04805',
        None,
    ),
    (
        '7.',
        'Caruana, R. (1997). Multitask learning. Machine Learning, 28(1), 41-75.',
        'https://doi.org/10.1023/A:1007379606734',
        None,
    ),
    (
        '8.',
        'Singh, R., et al. (2025). EssayJudge: A multi-granular benchmark for assessing '
        'automated essay scoring capabilities of multimodal large language models. '
        'arXiv:2502.11916.',
        'https://arxiv.org/abs/2502.11916',
        'CATATAN: Dikutip di teks sebagai Singh et al. (2024) '
        'tetapi arXiv submission adalah Februari 2025. Perlu konfirmasi tahun final.',
    ),
    (
        '9.',
        'Zhao, Y., et al. (2025). EDU-CIRCUIT-HW: Evaluating multimodal large language '
        'models on real-world university-level STEM student handwritten solutions. '
        'arXiv:2602.00095.',
        'https://arxiv.org/abs/2602.00095',
        None,
    ),
]

REFS_222 = [
    (
        '1.',
        'Ngiam, J., Khosla, A., Kim, M., Nam, J., Lee, H., & Ng, A. Y. (2011). '
        'Multimodal deep learning. Proceedings of the 28th International Conference '
        'on Machine Learning (ICML 2011), 689-696.',
        'https://dl.acm.org/doi/10.5555/3104482.3104569',
        'ICML 2011 proceedings. ACM DL link; preprint also available via Stanford.',
    ),
    (
        '2.',
        'Baltrusaitis, T., Ahuja, C., & Morency, L.-P. (2019). Multimodal machine '
        'learning: A survey and taxonomy. IEEE Transactions on Pattern Analysis and '
        'Machine Intelligence, 41(2), 423-443.',
        'https://doi.org/10.1109/TPAMI.2018.2798607',
        'Comprehensive survey; primary reference for modality taxonomy and fusion classification.',
    ),
]

REFS_223 = [
    (
        '1.',
        'Baltrusaitis, T., Ahuja, C., & Morency, L.-P. (2019). [Lihat 2.2.2 Ref 2] '
        'Multimodal machine learning: A survey and taxonomy. IEEE TPAMI, 41(2), 423-443.',
        'https://doi.org/10.1109/TPAMI.2018.2798607',
        'Digunakan juga di 2.2.2. Bagian yang relevan untuk 2.2.3: Section IV (Fusion). '
        'Sumber klasifikasi early/intermediate/late fusion.',
    ),
    (
        '2.',
        'Pereira-Gonzalez, L. M., Salazar Afanador, A., & Vergara Dominguez, L. (2023). '
        'A comparative analysis of early and late fusion for the multimodal two-class problem. '
        'IEEE Access, 11, 78021-78032.',
        'https://ieeexplore.ieee.org/document/10185035/',
        'Cite key: pereiragonzalez2023fusion. Mathematical analysis: early fusion better '
        'with perfect model knowledge; late fusion better with finite training sets. '
        'Directly supports decision to use late fusion for Pendekatan A (738 samples). '
        'PDF available locally: Research 3/Papers/Paper_1_...',
    ),
    (
        '3.',
        'Wang, Y., Xu, X., Yu, W., Xu, R., Cao, Z., & Shen, H. T. (2021). Combine early '
        'and late fusion together: A hybrid fusion framework for image-text matching. '
        '2021 IEEE International Conference on Multimedia and Expo (ICME), pp. 1-6.',
        'https://ieeexplore.ieee.org/document/9428201/',
        'Cite key: wang2021celft. CELFT framework. Hybrid fusion combining early+late. '
        'PDF available locally: Research 3/Papers/Paper_2_...',
    ),
    (
        '4.',
        'Kumar, P., Khokher, V., Gupta, Y., & Raman, B. (2021). Hybrid fusion based approach '
        'for multimodal emotion recognition with insufficient labeled data. '
        '2021 IEEE International Conference on Image Processing (ICIP), pp. 314-318.',
        'https://ieeexplore.ieee.org/document/9506714/',
        'Cite key: kumar2021hybridfusion. Hybrid intermediate+late fusion on small labeled dataset. '
        'Directly relevant: small dataset scenario similar to EssayJudge (738 samples). '
        'PDF available locally: Research 3/Papers/Paper_4_...',
    ),
    (
        '5.',
        'Gold, R. G. (2025). A BERT-ResNet cross-attention fusion network and modality '
        'utilization assessment for multimodal sentiment classification. '
        'MS Thesis, Rochester Institute of Technology.',
        'https://repository.rit.edu/theses/12090/',
        'Cite key: gold2025fusion. Intermediate fusion via cross-attention (BERT + ResNet). '
        'Used to describe cross-attention as intermediate fusion mechanism in 2.2.3.2.',
    ),
]

REFS_224 = [
    (
        '1.',
        'Singh, R., et al. (2025). [Lihat 2.2.1 Ref 8] EssayJudge: A multi-granular '
        'benchmark for assessing automated essay scoring capabilities of multimodal '
        'large language models. arXiv:2502.11916.',
        'https://arxiv.org/abs/2502.11916',
        'Digunakan juga di 2.2.1. Primary dataset reference untuk penelitian ini.',
    ),
    (
        '2.',
        'Bursztyn, V. S., Hoffswell, J., Koh, E., & Guo, S. (2024). Representing charts '
        'as text for language models: An in-depth study of question answering for bar '
        'charts. 2024 IEEE Visualization and Visual Analytics (VIS), '
        'St. Pete Beach, FL, USA, pp. 266-270.',
        'https://doi.org/10.1109/VIS55277.2024.00061',
        'Cite key: bursztyn2024charts. Key finding: text repr 99% vs image repr 63% accuracy '
        'on chart QA (GPT-4). Dataset: 359 bar charts. PDF available locally in Research 3/Papers/.',
    ),
    (
        '3.',
        'Zhao, Y., et al. (2025). [Lihat 2.2.1 Ref 9] EDU-CIRCUIT-HW: Evaluating '
        'multimodal large language models on real-world university-level STEM student '
        'handwritten solutions. arXiv:2602.00095.',
        'https://arxiv.org/abs/2602.00095',
        'Digunakan juga di 2.2.1. Relevan di 2.2.4: menunjukkan VLM image-to-text pipeline '
        'meningkatkan kinerja penilaian otomatis konteks akademik.',
    ),
]

# ── Build segments ─────────────────────────────────────────────────────────────
def add_section(segments, subheading, refs):
    segments.append(('subheading', subheading, None))
    for num, citation, url, note in refs:
        segments.append(('ref_num', num, None))
        segments.append(('ref_citation', citation, None))
        if url:
            segments.append(('ref_link_label', 'Link: ', None))
            segments.append(('ref_link_text', url, url))
        if note:
            segments.append(('ref_note', '[Catatan: ' + note + ']', None))
        segments.append(('blank', '', None))

segments = []
segments.append(('heading', 'Daftar Referensi per Subbab', None))

REFS_225 = [
    (
        '1.',
        'LeCun, Y., Bengio, Y., & Hinton, G. (2015). Deep learning. Nature, 521(7553), 436-444.',
        'https://doi.org/10.1038/nature14539',
        None,
    ),
    (
        '2.',
        'Hendrycks, D., & Gimpel, K. (2016). Gaussian error linear units (GELUs). '
        'arXiv:1606.08415.',
        'https://arxiv.org/abs/1606.08415',
        'Introduced GELU activation used in Transformer feed-forward layers (BERT, RoBERTa).',
    ),
]

REFS_226 = [
    (
        '1.',
        'Rumelhart, D. E., Hinton, G. E., & Williams, R. J. (1986). Learning representations '
        'by back-propagating errors. Nature, 323(6088), 533-536.',
        'https://doi.org/10.1038/323533a0',
        'Seminal backpropagation paper.',
    ),
    (
        '2.',
        'Goodfellow, I., Bengio, Y., & Courville, A. (2016). Deep Learning. MIT Press.',
        'https://www.deeplearningbook.org/',
        'Textbook reference for gradient descent, optimization landscape, and training dynamics.',
    ),
]

REFS_227 = [
    (
        '1.',
        'Srivastava, N., Hinton, G., Krizhevsky, A., Sutskever, I., & Salakhutdinov, R. '
        '(2014). Dropout: A simple way to prevent neural networks from overfitting. '
        'Journal of Machine Learning Research, 15(56), 1929-1958.',
        'https://jmlr.org/papers/v15/srivastava14a.html',
        None,
    ),
    (
        '2.',
        'Loshchilov, I., & Hutter, F. (2019). Decoupled weight decay regularization. '
        'Proceedings of ICLR 2019.',
        'https://arxiv.org/abs/1711.05101',
        'Also at OpenReview: https://openreview.net/forum?id=Bkg6RiCqY7 — Introduces AdamW.',
    ),
]

REFS_228 = [
    (
        '1.',
        'Kingma, D. P., & Ba, J. (2015). Adam: A method for stochastic optimization. '
        'Proceedings of ICLR 2015.',
        'https://arxiv.org/abs/1412.6980',
        'No formal DOI; cited via arXiv. ICLR 2015 proceedings.',
    ),
    (
        '2.',
        'Loshchilov, I., & Hutter, F. (2019). [Lihat 2.2.7 Ref 2] Decoupled weight decay '
        'regularization. ICLR 2019.',
        'https://arxiv.org/abs/1711.05101',
        'Digunakan juga di 2.2.7. Relevan di 2.2.8: AdamW formulation and learning rate scheduling.',
    ),
]

REFS_229 = [
    (
        '1.',
        'Pan, S. J., & Yang, Q. (2010). A survey on transfer learning. IEEE Transactions '
        'on Knowledge and Data Engineering, 22(10), 1345-1359.',
        'https://doi.org/10.1109/TKDE.2009.191',
        None,
    ),
    (
        '2.',
        'Hu, E. J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., Wang, L., '
        '& Chen, W. (2022). LoRA: Low-rank adaptation of large language models. '
        'Proceedings of ICLR 2022.',
        'https://arxiv.org/abs/2106.09685',
        'Also at OpenReview: https://openreview.net/forum?id=nZeVKeeFYf9',
    ),
]

add_section(segments, '2.2.1 Evolusi Automated Essay Scoring', REFS_221)
add_section(segments, '2.2.2 Pemrosesan Multimoda', REFS_222)
add_section(segments, '2.2.3 Strategi Multimodal Fusion', REFS_223)
add_section(segments, '2.2.4 Penilaian Esai Multimoda', REFS_224)
add_section(segments, '2.2.5 Jaringan Saraf Tiruan dan Fungsi Aktivasi', REFS_225)
add_section(segments, '2.2.6 Backpropagation dan Optimisasi Gradient', REFS_226)
add_section(segments, '2.2.7 Regularisasi', REFS_227)
add_section(segments, '2.2.8 AdamW dan Learning Rate Scheduling', REFS_228)
add_section(segments, '2.2.9 Transfer Learning dan Fine-tuning', REFS_229)

# ── Build full text and positions ──────────────────────────────────────────────
full_text = ''
seg_positions = []

for seg_type, text, url in segments:
    start = len(full_text) + 1
    line = text + '\n'
    full_text += line
    end = len(full_text)
    seg_positions.append((start, end, seg_type, text, url))

print(f'Characters: {len(full_text)} | Segments: {len(segments)}')

# ── Build API requests ─────────────────────────────────────────────────────────
reqs = []

for seg_type, text, url in reversed(segments):
    reqs.append(req_insert(text + '\n', 1, TAB_ID))

for start, end, seg_type, text, url in seg_positions:
    if seg_type == 'heading':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   space_above=0, space_below=6, line_spacing=150))
        reqs.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=13))

    elif seg_type == 'subheading':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   space_above=12, space_below=4, line_spacing=150))
        reqs.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=12))

    elif seg_type == 'ref_num':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   space_above=8, space_below=0, line_spacing=130))
        reqs.append(req_text_style(start, end, TAB_ID, bold=True, size_pt=11))

    elif seg_type == 'ref_citation':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   first_line=-28.0, indent_start=28.0,
                                   space_above=0, space_below=0, line_spacing=130))
        reqs.append(req_text_style(start, end, TAB_ID, bold=False, size_pt=11))

    elif seg_type == 'ref_link_label':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   indent_start=28.0,
                                   space_above=0, space_below=0, line_spacing=130))
        reqs.append(req_text_style(start, end, TAB_ID, bold=False, size_pt=11))

    elif seg_type == 'ref_link_text':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   indent_start=28.0,
                                   space_above=0, space_below=0, line_spacing=130))
        reqs.append(req_text_style(start, end, TAB_ID, bold=False, size_pt=11, underline=True))
        if url:
            reqs.append(req_link(start, end - 1, TAB_ID, url))

    elif seg_type == 'ref_note':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   indent_start=28.0,
                                   space_above=0, space_below=0, line_spacing=130))
        reqs.append(req_text_style(start, end, TAB_ID, bold=False, italic=True, size_pt=10))

    elif seg_type == 'blank':
        reqs.append(req_para_style(start, end, TAB_ID, 'START',
                                   space_above=0, space_below=0))

print(f'Sending {len(reqs)} requests...')
batch_update(reqs)

print('\nDone.')
print(f'https://docs.google.com/document/d/{DOCUMENT_ID}/edit?tab={TAB_ID}')
