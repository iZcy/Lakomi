"""
Flowchart generator for BAB III, Gambar 3.X
B&W, Times New Roman, Visio-style (oval/rect/diamond), white background.
Output: thesis_03/figures/flowchart_alur.png (300 dpi)
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import numpy as np

# ── Font setup ────────────────────────────────────────────────────────────────
import matplotlib.font_manager as fm
available_fonts = [f.name for f in fm.fontManager.ttflist]
if 'Times New Roman' in available_fonts:
    FONT = 'Times New Roman'
elif 'DejaVu Serif' in available_fonts:
    FONT = 'DejaVu Serif'
else:
    FONT = 'serif'

plt.rcParams.update({
    'font.family': FONT,
    'font.size': 9,
    'axes.linewidth': 0,
})

# ── Helpers ───────────────────────────────────────────────────────────────────
FC_EDGE = 'black'
FC_FILL = 'white'
ARROW_STYLE = dict(arrowstyle='->', color='black', lw=1.0,
                   mutation_scale=10)

def draw_rect(ax, cx, cy, w, h, text, fs=8.5, bold=False):
    """Rounded rectangle centered at (cx, cy)."""
    x0, y0 = cx - w/2, cy - h/2
    p = mpatches.FancyBboxPatch(
        (x0, y0), w, h,
        boxstyle='round,pad=0.04',
        linewidth=1.0,
        edgecolor=FC_EDGE, facecolor=FC_FILL,
        zorder=2
    )
    ax.add_patch(p)
    weight = 'bold' if bold else 'normal'
    ax.text(cx, cy, text, ha='center', va='center',
            fontsize=fs, fontfamily=FONT, fontweight=weight,
            wrap=True, zorder=3,
            multialignment='center')

def draw_oval(ax, cx, cy, w, h, text, fs=8.5):
    """Oval / terminator centered at (cx, cy)."""
    el = mpatches.Ellipse(
        (cx, cy), w, h,
        linewidth=1.0,
        edgecolor=FC_EDGE, facecolor=FC_FILL,
        zorder=2
    )
    ax.add_patch(el)
    ax.text(cx, cy, text, ha='center', va='center',
            fontsize=fs, fontfamily=FONT, fontweight='bold',
            zorder=3)

def draw_arrow(ax, x0, y0, x1, y1):
    """Draw a straight arrow between two points."""
    ax.annotate('', xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.0))

def draw_arrow_corner(ax, x0, y0, x_mid, y_mid, x1, y1):
    """Draw a right-angle arrow: (x0,y0) → (x_mid,y_mid) → (x1,y1)."""
    ax.plot([x0, x_mid, x1], [y0, y_mid, y1],
            color='black', lw=1.0, zorder=1)
    ax.annotate('', xy=(x1, y1),
                xytext=(x1, y_mid + 0.05),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.0))

def draw_line(ax, x0, y0, x1, y1):
    """Draw a simple line (no arrowhead)."""
    ax.plot([x0, x1], [y0, y1], color='black', lw=1.0, zorder=1)

# ── Figure setup ──────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(8, 13))
ax.set_xlim(0, 10)
ax.set_ylim(-0.5, 23.5)
ax.axis('off')
fig.patch.set_facecolor('white')

# ── Box dimensions ────────────────────────────────────────────────────────────
OVL_W, OVL_H   = 2.0, 0.75   # oval (start/end)
WIDE_W, ROW_H  = 5.2, 0.85   # wide centre boxes
SIDE_W         = 3.8          # side-column boxes

CX = 5.0   # centre x
LA = 2.5   # left-column x  (Pendekatan A)
RB = 7.5   # right-column x (Pendekatan B)

# ── Y positions (top → bottom) ───────────────────────────────────────────────
Y = {
    'start':    22.5,
    'id_masalah': 21.0,
    'tinjauan':   19.5,
    'dataset':    18.0,
    # parallel block
    'pa_des':   16.2,   # Pendekatan A: desain
    'pa_train': 14.5,   # Pendekatan A: pelatihan
    'pb_des':   16.2,   # Pendekatan B: desain
    'pb_cap':   14.5,   # Pendekatan B: captioning
    'pb_train': 12.8,   # Pendekatan B: pelatihan
    'pb_anal':  11.1,   # Pendekatan B: analisis
    # converge
    'pilih':     9.2,
    'uji':       7.5,
    'kesimpulan': 5.8,
    'end':        4.4,
}

# ── Draw shapes ───────────────────────────────────────────────────────────────
# Terminators
draw_oval(ax, CX, Y['start'], OVL_W, OVL_H, 'MULAI')
draw_oval(ax, CX, Y['end'],   OVL_W, OVL_H, 'SELESAI')

# Sequential top boxes
draw_rect(ax, CX, Y['id_masalah'], WIDE_W, ROW_H, 'Identifikasi Masalah')
draw_rect(ax, CX, Y['tinjauan'],   WIDE_W, ROW_H, 'Tinjauan Pustaka')
draw_rect(ax, CX, Y['dataset'],    WIDE_W, ROW_H, 'Persiapan Dataset EssayJudge')

# Pendekatan A column (left)
draw_rect(ax, LA, Y['pa_des'],   SIDE_W, ROW_H,
          'Desain Arsitektur Fusion\n(Pendekatan A)', fs=8.0)
draw_rect(ax, LA, Y['pa_train'], SIDE_W, ROW_H,
          'Pelatihan & Evaluasi\nFusion (Exp 030–033)', fs=8.0)

# Pendekatan B column (right)
draw_rect(ax, RB, Y['pb_des'],   SIDE_W, ROW_H,
          'Desain Pipeline T2T\n(Pendekatan B)', fs=8.0)
draw_rect(ax, RB, Y['pb_cap'],   SIDE_W, ROW_H,
          'Pembuatan Caption\n(DePlot + Qwen2-VL-7B)', fs=8.0)
draw_rect(ax, RB, Y['pb_train'], SIDE_W, ROW_H,
          'Pelatihan & Evaluasi\nT2T (Exp 08–103)', fs=8.0)
draw_rect(ax, RB, Y['pb_anal'],  SIDE_W, ROW_H,
          'Analisis Kualitas Caption\n(100-sampel manual)', fs=8.0)

# Converge boxes
draw_rect(ax, CX, Y['pilih'],      WIDE_W, ROW_H, 'Pemilihan Sistem Terbaik')
draw_rect(ax, CX, Y['uji'],        WIDE_W, ROW_H, 'Uji Statistik (Paired t-test,\nBonferroni)')
draw_rect(ax, CX, Y['kesimpulan'], WIDE_W, ROW_H, 'Penarikan Kesimpulan')

# ── Vertical arrows (sequential top) ─────────────────────────────────────────
half = ROW_H / 2
draw_arrow(ax, CX, Y['start']     - OVL_H/2,  CX, Y['id_masalah'] + half)
draw_arrow(ax, CX, Y['id_masalah']- half,       CX, Y['tinjauan']   + half)
draw_arrow(ax, CX, Y['tinjauan']  - half,       CX, Y['dataset']    + half)

# ── Split: dataset → two columns ─────────────────────────────────────────────
# horizontal line from centre to left then down, and centre to right then down
split_y = Y['dataset'] - half        # bottom of dataset box
join_y  = (Y['pa_des'] + half)       # top of pa_des / pb_des

# left branch
draw_line(ax, CX, split_y, LA, split_y)
draw_arrow(ax, LA, split_y, LA, join_y)
# right branch
draw_line(ax, CX, split_y, RB, split_y)
draw_arrow(ax, RB, split_y, RB, join_y)

# ── Arrows within Pendekatan A column ────────────────────────────────────────
draw_arrow(ax, LA, Y['pa_des']   - half, LA, Y['pa_train'] + half)

# ── Arrows within Pendekatan B column ────────────────────────────────────────
draw_arrow(ax, RB, Y['pb_des']   - half, RB, Y['pb_cap']   + half)
draw_arrow(ax, RB, Y['pb_cap']   - half, RB, Y['pb_train'] + half)
draw_arrow(ax, RB, Y['pb_train'] - half, RB, Y['pb_anal']  + half)

# ── Merge: both columns → Pemilihan Sistem Terbaik ───────────────────────────
merge_y = Y['pilih'] + half          # top of pilih box

# left merge: PA bottom → down to merge_y, then right to CX
pa_bot = Y['pa_train'] - half
draw_line(ax, LA, pa_bot, LA, merge_y)
draw_line(ax, LA, merge_y, CX - WIDE_W/2, merge_y)
draw_arrow(ax, CX - WIDE_W/2, merge_y, CX - WIDE_W/2 + 0.01, merge_y)

# right merge: PB bottom → down to merge_y, then left to CX
pb_bot = Y['pb_anal'] - half
draw_line(ax, RB, pb_bot, RB, merge_y)
draw_line(ax, RB, merge_y, CX + WIDE_W/2, merge_y)
draw_arrow(ax, CX + WIDE_W/2, merge_y, CX + WIDE_W/2 - 0.01, merge_y)

# centre downward arrow into pilih
draw_arrow(ax, CX, merge_y, CX, Y['pilih'] + half - 0.01)

# ── Arrows within converge section ───────────────────────────────────────────
draw_arrow(ax, CX, Y['pilih']      - half, CX, Y['uji']        + half)
draw_arrow(ax, CX, Y['uji']        - half, CX, Y['kesimpulan'] + half)
draw_arrow(ax, CX, Y['kesimpulan'] - half, CX, Y['end']        + OVL_H/2)

# ── Labels for parallel columns ───────────────────────────────────────────────
ax.text(LA, 17.15, 'Pendekatan A', ha='center', va='center',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')
ax.text(RB, 17.15, 'Pendekatan B', ha='center', va='center',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')

# ── Save ──────────────────────────────────────────────────────────────────────
out = r'C:\Outpost\Skripsi\Research 4\thesis_03\figures\flowchart_alur.png'
plt.tight_layout(pad=0.2)
plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
print('Saved:', out)
