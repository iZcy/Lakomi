"""
Convert all booktabs-style tables to full-border style in a .tex file.
  - {p{Xcm} p{Ycm}...} / {@{}clll@{}} -> {|p{Xcm}|p{Ycm}|...|} / {|c|l|l|l|}
  - \\toprule -> \\hline  (+ bold the next data row)
  - \\midrule -> \\hline
  - \\bottomrule -> \\hline
  - \\addlinespace -> (removed)
"""
import re, sys

# ─── balanced-brace finder ────────────────────────────────────────────────────

def find_braced(text, start):
    """Return (content_incl_braces, end_index) for the {..} starting at start."""
    if start >= len(text) or text[start] != '{':
        return None, start
    depth = 0
    for i in range(start, len(text)):
        if text[i] == '{':
            depth += 1
        elif text[i] == '}':
            depth -= 1
            if depth == 0:
                return text[start:i+1], i + 1
    return None, start


# ─── column-spec converter ────────────────────────────────────────────────────

def convert_col_spec(spec):
    """'{@{}p{3cm} p{5cm}@{}}' -> '{|p{3cm}|p{5cm}|}'"""
    inner = spec.strip()
    if inner.startswith('{'):
        inner = inner[1:]
    if inner.endswith('}'):
        inner = inner[:-1]
    # strip @{...} prefix / suffix (handles @{}, @{\hspace{...}}, etc.)
    while True:
        m = re.match(r'^@\{[^}]*\}', inner)
        if m:
            inner = inner[m.end():].strip()
        else:
            break
    while True:
        m = re.search(r'@\{[^}]*\}$', inner)
        if m:
            inner = inner[:m.start()].strip()
        else:
            break

    # tokenise column definitions
    cols = []
    i = 0
    while i < len(inner):
        ch = inner[i]
        if ch in ' \t':
            i += 1
        elif ch == 'p' and i + 1 < len(inner) and inner[i+1] == '{':
            spec_part, end = find_braced(inner, i + 1)
            cols.append('p' + spec_part)
            i = end
        elif ch in 'clrXLR':
            cols.append(ch)
            i += 1
        elif ch == '|':
            i += 1          # drop existing pipes; we'll add our own
        else:
            # unknown token — keep it
            cols.append(ch)
            i += 1

    if not cols:
        return '{' + inner + '}'
    return '{|' + '|'.join(cols) + '|}'


# ─── header-row bolding ───────────────────────────────────────────────────────

def bold_row(line):
    """Bold every & cell in a single-line table row ending with \\\\."""
    m = re.search(r'\\\\', line)
    if not m:
        return line
    body  = line[:m.start()]
    trail = line[m.start():]   # '\\' + anything after (comments etc.)
    cells = body.split('&')
    bolded = []
    for cell in cells:
        stripped = cell.strip()
        if stripped and not stripped.startswith('\\textbf{'):
            bolded.append(' \\textbf{' + stripped + '} ')
        else:
            bolded.append(cell)
    return '&'.join(bolded) + trail


# ─── main table transformer ───────────────────────────────────────────────────

def find_tabular_spec_in_line(line):
    """
    If line contains \\begin{tabular}{...}, return
    (col_spec_str, spec_start_in_line, spec_end_in_line).
    Handles arbitrarily nested braces.
    """
    m = re.search(r'\\begin\{tabular\}', line)
    if not m:
        return None, -1, -1
    pos = m.end()
    spec, end = find_braced(line, pos)
    if spec is None:
        return None, -1, -1
    return spec, pos, end


def transform(text):
    lines  = text.split('\n')
    result = []
    in_tab      = False
    next_is_hdr = False

    for line in lines:
        stripped = line.strip()

        # ── start of tabular ──────────────────────────────────────────────────
        spec, s, e = find_tabular_spec_in_line(line)
        if spec is not None:
            new_spec = convert_col_spec(spec)
            line = line[:s] + new_spec + line[e:]
            in_tab      = True
            next_is_hdr = False

        if not in_tab:
            result.append(line)
            continue

        # ── end of tabular ────────────────────────────────────────────────────
        if stripped == r'\end{tabular}':
            in_tab = False
            result.append(line)
            continue

        # ── rule replacements ─────────────────────────────────────────────────
        indent = line[: len(line) - len(line.lstrip())]

        if stripped == r'\toprule':
            result.append(indent + r'\hline')
            next_is_hdr = True
            continue

        if stripped == r'\midrule':
            result.append(indent + r'\hline')
            continue

        if stripped == r'\bottomrule':
            result.append(indent + r'\hline')
            continue

        if stripped == r'\addlinespace':
            continue   # remove entirely

        # ── header row bolding ────────────────────────────────────────────────
        if next_is_hdr and stripped and not stripped.startswith('%'):
            if re.search(r'\\\\', line):   # single-line row
                line = bold_row(line)
                next_is_hdr = False

        result.append(line)

    return '\n'.join(result)


# ─── entry point ─────────────────────────────────────────────────────────────

if __name__ == '__main__':
    for path in sys.argv[1:]:
        with open(path, encoding='utf-8') as f:
            original = f.read()
        converted = transform(original)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(converted)
        changed = original != converted
        print(f'{"CHANGED" if changed else "unchanged"}: {path}')
