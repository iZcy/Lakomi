"""
Diagram pipeline DePlot + Qwen2-VL-7B untuk bar+pie chart (Pendekatan B, Langkah 7-8)
Output: thesis_04/figures/deplot_pipeline.png (300 dpi)
B&W, Times New Roman
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.font_manager as fm
import os

available = [f.name for f in fm.fontManager.ttflist]
FONT = 'Times New Roman' if 'Times New Roman' in available else 'DejaVu Serif'
plt.rcParams.update({'font.family': FONT, 'font.size': 9, 'axes.linewidth': 0})

EDGE = 'black'
FILL = 'white'
GRAY = '#DDDDDD'

def draw_rect(ax, cx, cy, w, h, text, fs=8.5, bold=False, fill=FILL):
    x0, y0 = cx - w/2, cy - h/2
    p = mpatches.FancyBboxPatch((x0, y0), w, h,
        boxstyle='round,pad=0.04', linewidth=1.0,
        edgecolor=EDGE, facecolor=fill, zorder=2)
    ax.add_patch(p)
    ax.text(cx, cy, text, ha='center', va='center',
            fontsize=fs, fontfamily=FONT,
            fontweight='bold' if bold else 'normal',
            zorder=3, multialignment='center')

def draw_oval(ax, cx, cy, w, h, text, fs=8.5):
    el = mpatches.Ellipse((cx, cy), w, h, linewidth=1.0,
        edgecolor=EDGE, facecolor=FILL, zorder=2)
    ax.add_patch(el)
    ax.text(cx, cy, text, ha='center', va='center',
            fontsize=fs, fontfamily=FONT, fontweight='bold', zorder=3,
            multialignment='center')

def draw_arrow(ax, x0, y0, x1, y1):
    ax.annotate('', xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.0))

def draw_line(ax, x0, y0, x1, y1):
    ax.plot([x0, x1], [y0, y1], color='black', lw=1.0, zorder=1)

fig, ax = plt.subplots(figsize=(12, 6))
ax.set_xlim(0, 15)
ax.set_ylim(0, 7)
ax.axis('off')
fig.patch.set_facecolor('white')

# ── Two input paths ───────────────────────────────────────────
# Top path: bar_chart / pie_chart (2-step)
# Bottom path: other types (1-step)

Y_TOP = 5.2
Y_BOT = 2.2
Y_MID = 3.7   # merge point

# ── Shared input: Image ───────────────────────────────────────
draw_oval(ax, 1.3, Y_MID, 2.0, 0.75, 'Gambar\nGrafik')

# ── Branch labels ─────────────────────────────────────────────
ax.text(1.3, Y_TOP + 0.85, 'bar chart / pie chart', ha='center', va='bottom',
        fontsize=8.0, fontfamily=FONT, fontstyle='italic')
ax.text(1.3, Y_BOT - 0.85, 'flow chart, line chart,\ntabel, peta, composite', ha='center', va='top',
        fontsize=8.0, fontfamily=FONT, fontstyle='italic')

# ── Split lines from input ────────────────────────────────────
X_split = 2.35
draw_line(ax, X_split, Y_MID, X_split, Y_TOP)
draw_arrow(ax, X_split, Y_TOP, X_split + 0.01, Y_TOP)
draw_line(ax, X_split, Y_MID, X_split, Y_BOT)
draw_arrow(ax, X_split, Y_BOT, X_split + 0.01, Y_BOT)

# ── TOP PATH: DePlot step ─────────────────────────────────────
X_deplot = 4.5
draw_rect(ax, X_deplot, Y_TOP, 2.4, 0.85,
          'DePlot\n(282M, Pix2Struct)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_split, Y_TOP, X_deplot - 1.2, Y_TOP)

# Markdown table output
X_table = 7.0
draw_rect(ax, X_table, Y_TOP, 2.0, 0.85, 'Tabel Markdown\n(data numerik)', fs=8.0)
draw_arrow(ax, X_deplot + 1.2, Y_TOP, X_table - 1.0, Y_TOP)

# Qwen with table context
X_qwen_top = 9.6
draw_rect(ax, X_qwen_top, Y_TOP, 2.6, 0.85,
          'Qwen2-VL-7B\n(table + image context)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_table + 1.0, Y_TOP, X_qwen_top - 1.3, Y_TOP)

# Caption output top
X_cap_top = 12.5
draw_rect(ax, X_cap_top, Y_TOP, 2.2, 0.85, 'Caption Naratif\n(bar/pie)', fs=8.0)
draw_arrow(ax, X_qwen_top + 1.3, Y_TOP, X_cap_top - 1.1, Y_TOP)

# ── BOTTOM PATH: direct Qwen ──────────────────────────────────
X_qwen_bot = 5.5
draw_rect(ax, X_qwen_bot, Y_BOT, 2.6, 0.85,
          'Qwen2-VL-7B\n(image only)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_split, Y_BOT, X_qwen_bot - 1.3, Y_BOT)

X_cap_bot = 9.0
draw_rect(ax, X_cap_bot, Y_BOT, 2.2, 0.85, 'Caption Naratif\n(other types)', fs=8.0)
draw_arrow(ax, X_qwen_bot + 1.3, Y_BOT, X_cap_bot - 1.1, Y_BOT)

# ── Merge captions ────────────────────────────────────────────
X_merge = 13.5
draw_oval(ax, X_merge, Y_MID, 2.0, 0.75, 'Caption\nJSON')

draw_line(ax, X_cap_top + 1.1, Y_TOP, X_merge, Y_TOP)
draw_line(ax, X_merge, Y_TOP, X_merge, Y_MID + 0.38)
draw_arrow(ax, X_merge, Y_MID + 0.38, X_merge, Y_MID + 0.37)

draw_line(ax, X_cap_bot + 1.1, Y_BOT, X_merge, Y_BOT)
draw_line(ax, X_merge, Y_BOT, X_merge, Y_MID - 0.38)
draw_arrow(ax, X_merge, Y_MID - 0.38, X_merge, Y_MID - 0.01)

# ── Step labels ───────────────────────────────────────────────
ax.text(X_deplot, Y_TOP + 0.7, 'Langkah 1', ha='center', va='bottom',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')
ax.text(X_table,  Y_TOP + 0.7, 'Output', ha='center', va='bottom',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')
ax.text(X_qwen_top, Y_TOP + 0.7, 'Langkah 2', ha='center', va='bottom',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')
ax.text(X_qwen_bot, Y_BOT - 0.7, 'Langkah tunggal', ha='center', va='top',
        fontsize=7.5, fontfamily=FONT, fontstyle='italic', color='#555555')

out = r'C:\Outpost\Skripsi\Research 4\thesis_04\figures\deplot_pipeline.png'
os.makedirs(os.path.dirname(out), exist_ok=True)
plt.tight_layout(pad=0.3)
plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
print('Saved:', out)
