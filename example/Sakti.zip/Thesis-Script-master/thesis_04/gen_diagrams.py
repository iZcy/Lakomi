"""
Generate all chapter-4 architecture diagrams in drawio style:
  fillColor=#f5f5f5, strokeColor=#666666, fontColor=#333333,
  Times New Roman 11pt bold, rounded corners, gray arrows.

Outputs: thesis-main/contents/chapter-4/figures/*.png
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.font_manager as fm
import os

available = [f.name for f in fm.fontManager.ttflist]
FONT  = 'Times New Roman' if 'Times New Roman' in available else 'DejaVu Serif'
FILL  = '#f5f5f5'
EDGE  = '#666666'
TXT   = '#333333'
FS    = 10
OUT   = r'C:\Outpost\Skripsi\Research 4\thesis-main\contents\chapter-4\figures'
os.makedirs(OUT, exist_ok=True)

plt.rcParams.update({'font.family': FONT, 'font.size': FS, 'axes.linewidth': 0})


def box(ax, cx, cy, w, h, text, fs=FS, bold=True):
    x0, y0 = cx - w/2, cy - h/2
    p = mpatches.FancyBboxPatch((x0, y0), w, h,
        boxstyle='round,pad=0.06', linewidth=1.2,
        edgecolor=EDGE, facecolor=FILL, zorder=2)
    ax.add_patch(p)
    ax.text(cx, cy, text, ha='center', va='center', color=TXT,
            fontsize=fs, fontfamily=FONT,
            fontweight='bold' if bold else 'normal',
            zorder=3, multialignment='center', linespacing=1.3)


def arr(ax, x0, y0, x1, y1):
    ax.annotate('', xy=(x1, y1), xytext=(x0, y0),
        arrowprops=dict(arrowstyle='->', color=EDGE, lw=1.2))


def hline(ax, x0, y0, x1, y1):
    ax.plot([x0, x1], [y0, y1], color=EDGE, lw=1.2, zorder=1)


# ═══════════════════════════════════════════════════════════
#  LATE FUSION
# ═══════════════════════════════════════════════════════════
def make_late():
    fig, ax = plt.subplots(figsize=(7, 8.5))
    ax.set_xlim(0, 7); ax.set_ylim(0, 9); ax.axis('off')
    fig.patch.set_facecolor('white')

    BW, BH = 2.6, 0.72
    XL, XR = 1.5, 5.0
    Y = [7.5, 6.1, 4.7, 3.0, 1.5]  # Input, Encoder, Feature, Concat, Output

    box(ax, XL, Y[0], BW, BH, 'Teks (Essay)')
    box(ax, XR, Y[0], BW, BH, 'Gambar (Chart)')

    box(ax, XL, Y[1], BW, BH, 'RoBERTa\n[CLS]')
    box(ax, XR, Y[1], BW, BH, 'ResNet18\nAvgPool')

    box(ax, XL, Y[2], BW, BH, 'Vektor 768d')
    box(ax, XR, Y[2], BW, BH, 'Vektor 512d')

    box(ax, 3.25, Y[3], 3.4, BH, 'Concat [1.280d]')
    box(ax, 3.25, Y[4], 3.0, BH, 'Scoring Head\n(10 Output, Sigmoid×5)')

    for X in (XL, XR):
        arr(ax, X, Y[0]-BH/2, X, Y[1]+BH/2)
        arr(ax, X, Y[1]-BH/2, X, Y[2]+BH/2)

    MX = 3.25
    hline(ax, XL, Y[2]-BH/2, XL, (Y[2]-BH/2 + Y[3]+BH/2)/2)
    hline(ax, XL, (Y[2]-BH/2 + Y[3]+BH/2)/2, MX, (Y[2]-BH/2 + Y[3]+BH/2)/2)
    arr(ax, MX, (Y[2]-BH/2 + Y[3]+BH/2)/2, MX, Y[3]+BH/2)
    hline(ax, XR, Y[2]-BH/2, XR, (Y[2]-BH/2 + Y[3]+BH/2)/2)
    hline(ax, XR, (Y[2]-BH/2 + Y[3]+BH/2)/2, MX, (Y[2]-BH/2 + Y[3]+BH/2)/2)

    arr(ax, MX, Y[3]-BH/2, MX, Y[4]+BH/2)

    ax.text(MX, Y[4]-BH/2-0.2, '10 Skor Trait  (skala 0–5)',
            ha='center', va='top', fontsize=8.5, fontfamily=FONT,
            fontstyle='italic', color=TXT)

    plt.tight_layout(pad=0.2)
    plt.savefig(os.path.join(OUT, 'fusion_late.png'), dpi=300,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print('fusion_late.png saved')


# ═══════════════════════════════════════════════════════════
#  EARLY FUSION
# ═══════════════════════════════════════════════════════════
def make_early():
    fig, ax = plt.subplots(figsize=(7, 8.5))
    ax.set_xlim(0, 7); ax.set_ylim(0, 9); ax.axis('off')
    fig.patch.set_facecolor('white')

    BW, BH = 2.6, 0.72
    XL, XR = 1.5, 5.0
    MX = 3.25
    Y0 = 7.5   # inputs
    Y1 = 3.3   # early concat
    Y2 = 2.0   # bert encoder (joint)
    Y3 = 0.8   # output

    box(ax, XL, Y0, BW, BH, 'Teks (Essay)\nToken Embeddings')
    box(ax, XR, Y0, BW, BH, 'Gambar (Chart)\nResNet18 Features')

    box(ax, MX, Y1, 3.4, BH, 'Concat (Penggabungan Awal)')
    box(ax, MX, Y2, 3.2, BH, 'BERT Encoder\n(memproses bersama)')
    box(ax, MX, Y3, 3.0, BH, 'Scoring Head\n(10 Output, Sigmoid×5)')

    # arrows from inputs down toward concat level
    mid_y = (Y0 - BH/2 + Y1 + BH/2) / 2
    hline(ax, XL, Y0-BH/2, XL, mid_y)
    hline(ax, XL, mid_y, MX, mid_y)
    arr(ax, MX, mid_y, MX, Y1+BH/2)
    hline(ax, XR, Y0-BH/2, XR, mid_y)
    hline(ax, XR, mid_y, MX, mid_y)

    arr(ax, MX, Y1-BH/2, MX, Y2+BH/2)
    arr(ax, MX, Y2-BH/2, MX, Y3+BH/2)

    ax.text(MX, Y3-BH/2-0.2, '10 Skor Trait  (skala 0–5)',
            ha='center', va='top', fontsize=8.5, fontfamily=FONT,
            fontstyle='italic', color=TXT)

    plt.tight_layout(pad=0.2)
    plt.savefig(os.path.join(OUT, 'fusion_early.png'), dpi=300,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print('fusion_early.png saved')


# ═══════════════════════════════════════════════════════════
#  INTERMEDIATE FUSION
# ═══════════════════════════════════════════════════════════
def make_intermediate():
    fig, ax = plt.subplots(figsize=(7, 9))
    ax.set_xlim(0, 7); ax.set_ylim(0, 9.5); ax.axis('off')
    fig.patch.set_facecolor('white')

    BW, BH = 2.6, 0.72
    XL, XR = 1.5, 5.0
    MX = 3.25
    Y = [8.2, 6.8, 5.4, 4.0, 2.6, 1.2]

    box(ax, XL, Y[0], BW, BH, 'Teks (Essay)')
    box(ax, XR, Y[0], BW, BH, 'Gambar (Chart)')

    box(ax, XL, Y[1], BW, BH, 'BERT Encoder\n[CLS] 768d')
    box(ax, XR, Y[1], BW, BH, 'ResNet18\n512d Features')

    box(ax, MX, Y[2], 3.6, BH, 'Cross-Attention\n(essay sebagai query)')

    box(ax, MX, Y[3], 3.4, BH, 'Concat [CLS + Attn]')
    box(ax, MX, Y[4], 3.4, BH, 'FC Layer')
    box(ax, MX, Y[5], 3.0, BH, 'Scoring Head\n(10 Output, Sigmoid×5)')

    for X in (XL, XR):
        arr(ax, X, Y[0]-BH/2, X, Y[1]+BH/2)

    mid_y = (Y[1] - BH/2 + Y[2] + BH/2) / 2
    hline(ax, XL, Y[1]-BH/2, XL, mid_y)
    hline(ax, XL, mid_y, MX, mid_y)
    arr(ax, MX, mid_y, MX, Y[2]+BH/2)
    hline(ax, XR, Y[1]-BH/2, XR, mid_y)
    hline(ax, XR, mid_y, MX, mid_y)

    for i in range(2, 5):
        arr(ax, MX, Y[i]-BH/2, MX, Y[i+1]+BH/2)

    ax.text(MX, Y[5]-BH/2-0.2, '10 Skor Trait  (skala 0–5)',
            ha='center', va='top', fontsize=8.5, fontfamily=FONT,
            fontstyle='italic', color=TXT)

    plt.tight_layout(pad=0.2)
    plt.savefig(os.path.join(OUT, 'fusion_intermediate.png'), dpi=300,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print('fusion_intermediate.png saved')


# ═══════════════════════════════════════════════════════════
#  T2T DUAL ROBERTA
# ═══════════════════════════════════════════════════════════
def make_t2t():
    fig, ax = plt.subplots(figsize=(11, 7.5))
    ax.set_xlim(0, 14); ax.set_ylim(0, 9); ax.axis('off')
    fig.patch.set_facecolor('white')

    BH = 0.75
    XI  = 1.5
    XV  = 3.5
    XC  = 5.8
    XE  = 8.1
    XF  = 10.3
    XK  = 11.7
    XO  = 13.2
    YT  = 6.5   # caption stream
    YE  = 2.5   # essay stream
    YM  = 4.5   # merge level

    # Caption stream
    box(ax, XI, YT, 2.2, BH, 'Gambar Grafik\n(chart image)', fs=9)
    box(ax, XV, YT, 2.4, BH, 'Qwen2-VL-7B\n(captioner)', fs=9)
    box(ax, XC, YT, 2.4, BH, 'Teks Caption\n(natural language)', fs=9)
    box(ax, XE, YT, 2.4, BH, 'RoBERTa-base\n(caption encoder)', fs=9)
    box(ax, XF, YT, 1.8, BH, '[CLS]\n768d', fs=9)

    # Essay stream
    box(ax, XI, YE, 2.2, BH, 'Teks Esai\n(student essay)', fs=9)
    box(ax, XE, YE, 2.4, BH, 'RoBERTa-base\n(essay encoder)', fs=9)
    box(ax, XF, YE, 1.8, BH, '[CLS]\n768d', fs=9)

    # Merge + FC
    box(ax, XK, YM, 1.6, BH, 'Concat\n1.536d', fs=9)
    box(ax, XO, YM+1.1, 1.8, BH, 'FC 768\nReLU', fs=8.5)
    box(ax, XO, YM,     1.8, BH, 'FC 256\nReLU', fs=8.5)
    box(ax, XO, YM-1.1, 1.8, BH, 'FC 10\nSigmoid×5', fs=8.5)

    # Caption stream arrows
    arr(ax, XI+1.1, YT, XV-1.2, YT)
    arr(ax, XV+1.2, YT, XC-1.2, YT)
    arr(ax, XC+1.2, YT, XE-1.2, YT)
    arr(ax, XE+1.2, YT, XF-0.9, YT)

    # Essay stream arrows
    arr(ax, XI+1.1, YE, XE-1.2, YE)
    arr(ax, XE+1.2, YE, XF-0.9, YE)

    # Converge to Concat
    hline(ax, XF+0.9, YT, XK, YT)
    hline(ax, XK, YT, XK, YM+BH/2)
    arr(ax, XK, YM+BH/2, XK, YM+BH/2-0.01)
    hline(ax, XF+0.9, YE, XK, YE)
    hline(ax, XK, YE, XK, YM-BH/2)
    arr(ax, XK, YM-BH/2, XK, YM-BH/2+0.01)

    # FC chain
    arr(ax, XK+0.8, YM, XO-0.9, YM+1.1)
    arr(ax, XO, YM+1.1-BH/2, XO, YM+BH/2)
    arr(ax, XO, YM-BH/2, XO, YM-1.1+BH/2)

    ax.text(XO, YM-1.1-BH/2-0.15, '10 Skor Trait\n(skala 0–5)',
            ha='center', va='top', fontsize=8.5, fontfamily=FONT,
            fontstyle='italic', color=TXT)

    # Stream labels
    ax.text(0.3, YT, 'Alur\nCaption', ha='center', va='center',
            fontsize=8, fontfamily=FONT, color=TXT, fontstyle='italic')
    ax.text(0.3, YE, 'Alur\nEsai', ha='center', va='center',
            fontsize=8, fontfamily=FONT, color=TXT, fontstyle='italic')

    plt.tight_layout(pad=0.2)
    plt.savefig(os.path.join(OUT, 't2t_architecture.png'), dpi=300,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print('t2t_architecture.png saved')


# ═══════════════════════════════════════════════════════════
#  DEPLOT PIPELINE
# ═══════════════════════════════════════════════════════════
def make_deplot():
    fig, ax = plt.subplots(figsize=(11, 6))
    ax.set_xlim(0, 14); ax.set_ylim(0, 7); ax.axis('off')
    fig.patch.set_facecolor('white')

    BH = 0.72
    YT = 5.2   # bar/pie stream
    YB = 2.2   # other types stream
    YM = 3.7   # merge level

    # Top stream: bar/pie
    box(ax, 1.4, YT, 2.4, BH, 'Bar/Pie Chart\n(grafik batang/lingkaran)', fs=9)
    box(ax, 4.2, YT, 2.2, BH, 'DePlot\n(282M, Pix2Struct)', fs=9)
    box(ax, 7.0, YT, 2.4, BH, 'Tabel Markdown\n(data numerik)', fs=9)
    box(ax, 9.8, YT, 2.4, BH, 'Qwen2-VL-7B\n+ tabel sebagai konteks)', fs=9)

    # Bottom stream: other types
    box(ax, 1.4, YB, 2.4, BH, 'Flow/Table/Map\n/Line/Composite', fs=9)
    box(ax, 9.8, YB, 2.4, BH, 'Qwen2-VL-7B\n(langsung)', fs=9)

    # Merge
    box(ax, 12.6, YM, 2.0, BH, 'Caption JSON\n(1.054 sampel)', fs=9)

    # Top arrows
    arr(ax, 2.6, YT, 3.1, YT)
    arr(ax, 5.3, YT, 5.8, YT)
    arr(ax, 8.2, YT, 8.6, YT)

    # Bottom arrow
    arr(ax, 2.6, YB, 8.6, YB)

    # Converge to JSON
    arr(ax, 11.0, YT, 11.6, YT)
    hline(ax, 11.6, YT, 12.6, YT)
    hline(ax, 12.6, YT, 12.6, YM+BH/2)
    arr(ax, 12.6, YM+BH/2, 12.6, YM+BH/2-0.01)

    arr(ax, 11.0, YB, 11.6, YB)
    hline(ax, 11.6, YB, 12.6, YB)
    hline(ax, 12.6, YB, 12.6, YM-BH/2)
    arr(ax, 12.6, YM-BH/2, 12.6, YM-BH/2+0.01)

    # Labels
    ax.text(0.2, YT, 'Grafik\nTerstruktur', ha='center', va='center',
            fontsize=8, fontfamily=FONT, color=TXT, fontstyle='italic')
    ax.text(0.2, YB, 'Grafik\nLainnya', ha='center', va='center',
            fontsize=8, fontfamily=FONT, color=TXT, fontstyle='italic')

    plt.tight_layout(pad=0.2)
    plt.savefig(os.path.join(OUT, 'deplot_pipeline.png'), dpi=300,
                bbox_inches='tight', facecolor='white')
    plt.close()
    print('deplot_pipeline.png saved')


if __name__ == '__main__':
    make_late()
    make_early()
    make_intermediate()
    make_t2t()
    make_deplot()
    print('All diagrams generated.')
