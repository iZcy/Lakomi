"""
Diagram arsitektur Pendekatan B: Dual RoBERTa T2T
Output: thesis_04/figures/t2t_architecture.png (300 dpi)
B&W, Times New Roman, Visio-style
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.font_manager as fm

available = [f.name for f in fm.fontManager.ttflist]
FONT = 'Times New Roman' if 'Times New Roman' in available else 'DejaVu Serif'

plt.rcParams.update({'font.family': FONT, 'font.size': 9, 'axes.linewidth': 0})

EDGE = 'black'
FILL = 'white'
GRAY = '#DDDDDD'

def draw_rect(ax, cx, cy, w, h, text, fs=8.5, bold=False, fill=FILL):
    x0, y0 = cx - w/2, cy - h/2
    p = mpatches.FancyBboxPatch((x0, y0), w, h,
        boxstyle='round,pad=0.04', linewidth=1.0,
        edgecolor=EDGE, facecolor=fill, zorder=2)
    ax.add_patch(p)
    ax.text(cx, cy, text, ha='center', va='center',
            fontsize=fs, fontfamily=FONT,
            fontweight='bold' if bold else 'normal',
            zorder=3, multialignment='center')

def draw_arrow(ax, x0, y0, x1, y1):
    ax.annotate('', xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle='->', color='black', lw=1.0))

def draw_line(ax, x0, y0, x1, y1):
    ax.plot([x0, x1], [y0, y1], color='black', lw=1.0, zorder=1)

fig, ax = plt.subplots(figsize=(10, 7))
ax.set_xlim(0, 14)
ax.set_ylim(0, 9)
ax.axis('off')
fig.patch.set_facecolor('white')

# ── Column positions ──────────────────────────────────────────
X_IMG  = 1.6    # Image (left input)
X_VLM  = 3.5    # VLM captioner
X_CAP  = 5.7    # Caption text
X_ENC  = 8.0    # Encoders
X_FEAT = 10.2   # Feature vectors
X_CAT  = 11.5   # Concat
X_FC   = 12.9   # FC + output

# ── Row positions ─────────────────────────────────────────────
Y_TOP = 6.5   # caption stream
Y_BOT = 2.5   # essay stream
Y_MID = 4.5   # concat / FC level

# ── INPUT: Image ──────────────────────────────────────────────
draw_rect(ax, X_IMG, Y_TOP, 1.8, 0.8, 'Gambar Grafik\n(chart image)', fs=8.0)

# ── VLM: Qwen2-VL-7B ─────────────────────────────────────────
draw_rect(ax, X_VLM, Y_TOP, 2.4, 0.8, 'Qwen2-VL-7B\n(caption generator)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_IMG + 0.9, Y_TOP, X_VLM - 1.2, Y_TOP)

# ── Caption Text ──────────────────────────────────────────────
draw_rect(ax, X_CAP, Y_TOP, 2.0, 0.8, 'Teks Caption\n(natural language)', fs=8.0)
draw_arrow(ax, X_VLM + 1.2, Y_TOP, X_CAP - 1.0, Y_TOP)

# ── INPUT: Essay ──────────────────────────────────────────────
draw_rect(ax, X_IMG, Y_BOT, 1.8, 0.8, 'Teks Esai\n(student essay)', fs=8.0)

# ── Caption RoBERTa encoder ───────────────────────────────────
draw_rect(ax, X_ENC, Y_TOP, 2.2, 0.8, 'RoBERTa-base\n(caption encoder)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_CAP + 1.0, Y_TOP, X_ENC - 1.1, Y_TOP)

# ── Essay RoBERTa encoder ─────────────────────────────────────
draw_rect(ax, X_ENC, Y_BOT, 2.2, 0.8, 'RoBERTa-base\n(essay encoder)', fs=8.0, fill=GRAY)
draw_arrow(ax, X_IMG + 0.9, Y_BOT, X_ENC - 1.1, Y_BOT)

# ── Feature vectors ────────────────────────────────────────────
draw_rect(ax, X_FEAT, Y_TOP, 1.6, 0.8, '[CLS]\n768d', fs=8.5)
draw_arrow(ax, X_ENC + 1.1, Y_TOP, X_FEAT - 0.8, Y_TOP)
draw_rect(ax, X_FEAT, Y_BOT, 1.6, 0.8, '[CLS]\n768d', fs=8.5)
draw_arrow(ax, X_ENC + 1.1, Y_BOT, X_FEAT - 0.8, Y_BOT)

# ── Concat ─────────────────────────────────────────────────────
draw_rect(ax, X_CAT, Y_MID, 1.4, 0.8, 'Concat\n1536d', fs=8.5, bold=True)
draw_line(ax, X_FEAT + 0.8, Y_TOP, X_CAT, Y_TOP)
draw_line(ax, X_CAT, Y_TOP, X_CAT, Y_MID + 0.4)
draw_arrow(ax, X_CAT, Y_MID + 0.4, X_CAT, Y_MID + 0.41)

draw_line(ax, X_FEAT + 0.8, Y_BOT, X_CAT, Y_BOT)
draw_line(ax, X_CAT, Y_BOT, X_CAT, Y_MID - 0.4)
draw_arrow(ax, X_CAT, Y_MID - 0.4, X_CAT, Y_MID - 0.01)

# ── FC stack ───────────────────────────────────────────────────
FC1_X = X_FC
FC1_Y = Y_MID + 1.2
FC2_Y = Y_MID
FC3_Y = Y_MID - 1.2

draw_rect(ax, FC1_X, FC1_Y, 1.4, 0.65, 'FC 768\nReLU, Dropout 0.3', fs=7.5)
draw_rect(ax, FC1_X, FC2_Y, 1.4, 0.65, 'FC 256\nReLU, Dropout 0.3', fs=7.5)
draw_rect(ax, FC1_X, FC3_Y, 1.4, 0.65, 'FC 10\nSigmoid x 5.0', fs=7.5, bold=True)

draw_arrow(ax, X_CAT + 0.7, Y_MID, FC1_X - 0.7, FC1_Y)
draw_arrow(ax, FC1_X, FC1_Y - 0.325, FC1_X, FC2_Y + 0.325)
draw_arrow(ax, FC1_X, FC2_Y - 0.325, FC1_X, FC3_Y + 0.325)

# ── Output label ──────────────────────────────────────────────
ax.text(FC1_X, FC3_Y - 0.55, '10 Skor Trait\n(skala 0–5)', ha='center', va='top',
        fontsize=8.0, fontfamily=FONT, fontstyle='italic')

# ── Column labels ─────────────────────────────────────────────
for x, lbl in [(X_IMG, 'Input'), (X_VLM, 'Captioner\n(frozen)'),
               (X_CAP, 'Teks'), (X_ENC, 'Encoder\n(fine-tuned)'),
               (X_FEAT, 'Fitur'), (X_CAT, 'Fusion'), (X_FC, 'Prediksi')]:
    ax.text(x, 8.1, lbl, ha='center', va='bottom', fontsize=7.5,
            fontfamily=FONT, fontstyle='italic', color='#555555')

# ── Brace labels for streams ──────────────────────────────────
ax.text(0.2, Y_TOP, 'Alur\nCaption', ha='center', va='center',
        fontsize=7.5, fontfamily=FONT, color='#333333')
ax.text(0.2, Y_BOT, 'Alur\nEsai', ha='center', va='center',
        fontsize=7.5, fontfamily=FONT, color='#333333')

out = r'C:\Outpost\Skripsi\Research 4\thesis_04\figures\t2t_architecture.png'
import os; os.makedirs(os.path.dirname(out), exist_ok=True)
plt.tight_layout(pad=0.3)
plt.savefig(out, dpi=300, bbox_inches='tight', facecolor='white')
print('Saved:', out)
