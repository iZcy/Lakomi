"""
Generate 4 fusion strategy diagrams as .drawio (XML) files.
Open each file in https://app.diagrams.net, then File > Export > PNG (300 DPI).
Output: thesis_latex/diagrams/fusion_*.drawio
"""
import os

OUT_DIR = 'C:/Outpost/Skripsi/Research 4/thesis_latex/diagrams'

# ── Shared styles ─────────────────────────────────────────────────────────────
FONT = 'Times New Roman'
BASE = f'rounded=1;whiteSpace=wrap;html=1;fontFamily={FONT};fontSize=11;fontStyle=1;'
S_TEXT   = BASE + 'fillColor=#dae8fc;strokeColor=#6c8ebf;'
S_IMG    = BASE + 'fillColor=#f8cecc;strokeColor=#b85450;'
S_EARLY  = BASE + 'fillColor=#ffe6cc;strokeColor=#d79b00;'
S_FUSE   = BASE + 'fillColor=#fff2cc;strokeColor=#d6b656;'
S_OUTPUT = BASE + 'fillColor=#d5e8d4;strokeColor=#82b366;'
S_ENC    = BASE + 'fillColor=#f5f5f5;strokeColor=#666666;fontColor=#333333;'
S_LATE   = BASE + 'fillColor=#e1d5e7;strokeColor=#9673a6;'
S_TEXT_L = BASE + 'fillColor=#dae8fc;strokeColor=#6c8ebf;opacity=60;'
S_IMG_L  = BASE + 'fillColor=#f8cecc;strokeColor=#b85450;opacity=60;'
S_EARLY_L= BASE + 'fillColor=#ffe6cc;strokeColor=#d79b00;opacity=60;'

S_TITLE = (f'text;html=1;strokeColor=none;fillColor=none;align=center;'
           f'verticalAlign=middle;whiteSpace=wrap;rounded=0;'
           f'fontFamily={FONT};fontSize=14;fontStyle=1;')
S_SUB   = (f'text;html=1;strokeColor=none;fillColor=none;align=center;'
           f'verticalAlign=middle;whiteSpace=wrap;rounded=0;'
           f'fontFamily={FONT};fontSize=9;fontStyle=2;fontColor=#555555;')

E_DEFAULT = 'edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;jettySize=auto;html=1;'
E_CROSS   = ('endArrow=open;startArrow=open;startFill=0;endFill=0;dashed=1;'
             'strokeColor=#E67E22;strokeWidth=2;html=1;'
             'exitX=1;exitY=0.5;exitDx=0;exitDy=0;'
             'entryX=0;entryY=0.5;entryDx=0;entryDy=0;'
             f'fontFamily={FONT};fontSize=9;fontStyle=3;')


def v(cid, label, x, y, w, h, style):
    return (f'    <mxCell id="{cid}" value="{label}" style="{style}" '
            f'vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry" />'
            f'</mxCell>\n')


def e(cid, label, src, tgt, style=None, extra=''):
    s = style if style else E_DEFAULT + extra
    return (f'    <mxCell id="{cid}" value="{label}" style="{s}" '
            f'edge="1" source="{src}" target="{tgt}" parent="1">'
            f'<mxGeometry relative="1" as="geometry" /></mxCell>\n')


def wrap(cells, pw=560, ph=500):
    return (f'<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" '
            f'guides="1" tooltips="1" connect="1" arrows="1" fold="1" '
            f'page="1" pageScale="1" pageWidth="{pw}" pageHeight="{ph}" '
            f'math="0" shadow="0">\n'
            f'  <root>\n'
            f'    <mxCell id="0" />\n'
            f'    <mxCell id="1" parent="0" />\n'
            + cells +
            f'  </root>\n'
            f'</mxGraphModel>\n')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 1 — Early Fusion
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('t1',  'Early Fusion',                           0,   8, 500,  28, S_TITLE)
c += v('tk',  'Teks&#xa;(Essay)',                      85,  60, 140,  50, S_TEXT)
c += v('gm',  'Gambar&#xa;(Chart)',                   275,  60, 140,  50, S_IMG)
c += v('cc',  'Concat / Merge&#xa;(Level Input)',      100, 175, 300,  50, S_EARLY)
c += v('se',  'Shared Encoder&#xa;(Bersama)',          100, 285, 300,  50, S_ENC)
c += v('op',  'Output&#xa;(Prediksi Skor)',            125, 395, 250,  50, S_OUTPUT)
c += v('sb',  'Penggabungan di level input sebelum encoder bersama.',
                                                         0, 455, 500,  25, S_SUB)

c += e('e1', '', 'tk', 'cc', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.25;entryY=0;entryDx=0;entryDy=0;')
c += e('e2', '', 'gm', 'cc', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.75;entryY=0;entryDx=0;entryDy=0;')
c += e('e3', '', 'cc', 'se')
c += e('e4', '', 'se', 'op')

with open(os.path.join(OUT_DIR, 'fusion_early.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=500, ph=490))
print('Saved: fusion_early.drawio')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 2 — Intermediate Fusion
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('t1',  'Intermediate Fusion',                   0,   8, 600,  28, S_TITLE)
c += v('tk',  'Teks&#xa;(Essay)',                     55,  58, 150,  50, S_TEXT)
c += v('gm',  'Gambar&#xa;(Chart)',                  395,  58, 150,  50, S_IMG)
c += v('te',  'Text&#xa;Encoder',                    55, 168, 150,  50, S_TEXT_L)
c += v('ie',  'Image&#xa;Encoder',                  395, 168, 150,  50, S_IMG_L)
c += v('ht',  'h&#95;text',                          55, 278, 150,  50, S_TEXT_L)
c += v('hi',  'h&#95;image',                        395, 278, 150,  50, S_IMG_L)
c += v('fu',  'Fused Representation',               150, 388, 300,  50, S_FUSE)
c += v('op',  'Output&#xa;(Prediksi Skor)',          175, 498, 250,  50, S_OUTPUT)
c += v('sb',  'Penggabungan di level representasi tersembunyi via cross-attention.',
                                                       0, 558, 600,  25, S_SUB)

c += e('e1', '', 'tk', 'te')
c += e('e2', '', 'gm', 'ie')
c += e('e3', '', 'te', 'ht')
c += e('e4', '', 'ie', 'hi')
c += e('e5', 'Cross-Attention', 'ht', 'hi', E_CROSS)
c += e('e6', '', 'ht', 'fu', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.2;entryY=0;entryDx=0;entryDy=0;')
c += e('e7', '', 'hi', 'fu', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.8;entryY=0;entryDx=0;entryDy=0;')
c += e('e8', '', 'fu', 'op')

with open(os.path.join(OUT_DIR, 'fusion_intermediate.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=600, ph=592))
print('Saved: fusion_intermediate.drawio')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 3 — Late Fusion
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('t1',  'Late Fusion',                           0,   8, 600,  28, S_TITLE)
c += v('tk',  'Teks&#xa;(Essay)',                     55,  58, 150,  50, S_TEXT)
c += v('gm',  'Gambar&#xa;(Chart)',                  395,  58, 150,  50, S_IMG)
c += v('te',  'RoBERTa&#xa;[CLS]',                   55, 168, 150,  50, S_TEXT_L)
c += v('ie',  'ResNet18&#xa;AvgPool',               395, 168, 150,  50, S_IMG_L)
c += v('ht',  '768-dim&#xa;vector',                  55, 278, 150,  50, S_TEXT_L)
c += v('hi',  '512-dim&#xa;vector',                 395, 278, 150,  50, S_IMG_L)
c += v('ct',  'Concat [1280-dim]',                  150, 388, 300,  50, S_LATE)
c += v('op',  'Scoring Head&#xa;(Output)',           175, 498, 250,  50, S_OUTPUT)
c += v('sb',  'Penggabungan di level output setelah encoder bekerja sepenuhnya independen.',
                                                       0, 558, 600,  25, S_SUB)

c += e('e1', '', 'tk', 'te')
c += e('e2', '', 'gm', 'ie')
c += e('e3', '', 'te', 'ht')
c += e('e4', '', 'ie', 'hi')
c += e('e5', '', 'ht', 'ct', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.2;entryY=0;entryDx=0;entryDy=0;')
c += e('e6', '', 'hi', 'ct', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.8;entryY=0;entryDx=0;entryDy=0;')
c += e('e7', '', 'ct', 'op')

with open(os.path.join(OUT_DIR, 'fusion_late.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=600, ph=592))
print('Saved: fusion_late.drawio')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 4 — Hybrid Fusion
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('t1',  'Hybrid Fusion (Early + Late)',          0,   8, 700,  28, S_TITLE)

# Inputs
c += v('tk',  'Teks&#xa;(Essay)',                     80,  58, 150,  50, S_TEXT)
c += v('gm',  'Gambar&#xa;(Chart)',                  470,  58, 150,  50, S_IMG)

# Path A — Early
c += v('ea',  'Early Concat&#xa;(Path A)',           225, 168, 250,  50, S_EARLY)
c += v('es',  'Shared Encoder',                      225, 278, 250,  50, S_ENC)
c += v('he',  'h&#95;early',                         250, 388, 200,  50, S_EARLY_L)

# Path B — Late (text side)
c += v('lte', 'Text&#xa;Encoder',                    30, 278, 140,  50, S_TEXT_L)
c += v('ht',  'h&#95;text',                          30, 388, 140,  50, S_TEXT_L)

# Path B — Late (image side)
c += v('lie', 'Image&#xa;Encoder',                  530, 278, 140,  50, S_IMG_L)
c += v('hi',  'h&#95;image',                        530, 388, 140,  50, S_IMG_L)

# Merge + Output
c += v('hm',  'Hybrid Merge&#xa;(h&#95;early + h&#95;text + h&#95;image)',
                                                     150, 498, 400,  55, S_FUSE)
c += v('op',  'Output',                             275, 613, 150,  45, S_OUTPUT)
c += v('sb',  'Menggabungkan early fusion (Path A: shared encoder) dan late fusion (Path B: encoder independen).',
                                                       0, 668, 700,  25, S_SUB)

# Arrows — inputs to Path A
c += e('e1', '', 'tk', 'ea', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.2;entryY=0;entryDx=0;entryDy=0;')
c += e('e2', '', 'gm', 'ea', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.8;entryY=0;entryDx=0;entryDy=0;')
# Arrows — inputs to Path B
c += e('e3', '', 'tk', 'lte', E_DEFAULT + 'exitX=0;exitY=0.5;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;')
c += e('e4', '', 'gm', 'lie', E_DEFAULT + 'exitX=1;exitY=0.5;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;')
# Path A chain
c += e('e5', '', 'ea', 'es')
c += e('e6', '', 'es', 'he')
# Path B chains
c += e('e7', '', 'lte', 'ht')
c += e('e8', '', 'lie', 'hi')
# All to Hybrid Merge
c += e('e9',  '', 'he', 'hm', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;')
c += e('e10', '', 'ht', 'hm', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.1;entryY=0;entryDx=0;entryDy=0;')
c += e('e11', '', 'hi', 'hm', E_DEFAULT + 'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.9;entryY=0;entryDx=0;entryDy=0;')
c += e('e12', '', 'hm', 'op')

with open(os.path.join(OUT_DIR, 'fusion_hybrid.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=700, ph=702))
print('Saved: fusion_hybrid.drawio')

print('\nAll 4 .drawio files generated.')
print('Open each in https://app.diagrams.net')
print('Then: File > Export As > PNG (300 DPI, fit page)')
