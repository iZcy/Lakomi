"""
Generate draw.io XML files for BAB II theory diagrams.
All content is purely theoretical — no research-specific context.
  1. multimodal_pipeline.drawio  — modality types flowing into a fusion system
  2. transfer_learning.drawio    — pretrain -> fine-tune strategies diagram
Open each in https://app.diagrams.net, then Export As PNG (300 DPI, fit page).
"""
import os

OUT_DIR = 'C:/Outpost/Skripsi/Research 4/thesis_latex/diagrams'
FONT = 'Times New Roman'

BASE  = f'rounded=1;whiteSpace=wrap;html=1;fontFamily={FONT};fontSize=11;fontStyle=1;'
S_TXT = BASE + 'fillColor=#dae8fc;strokeColor=#6c8ebf;'
S_IMG = BASE + 'fillColor=#f8cecc;strokeColor=#b85450;'
S_AUD = BASE + 'fillColor=#e1d5e7;strokeColor=#9673a6;'
S_VID = BASE + 'fillColor=#d5e8d4;strokeColor=#82b366;'
S_ENC = BASE + 'fillColor=#f5f5f5;strokeColor=#666666;fontColor=#333333;'
S_FUS = BASE + 'fillColor=#fff2cc;strokeColor=#d6b656;'
S_OUT = BASE + 'fillColor=#d5e8d4;strokeColor=#82b366;'
S_PRE = BASE + 'fillColor=#dae8fc;strokeColor=#6c8ebf;'
S_FRZ = BASE + 'fillColor=#f5f5f5;strokeColor=#666666;fontColor=#555555;'
S_HD  = BASE + 'fillColor=#ffe6cc;strokeColor=#d79b00;'
S_ACT = BASE + 'fillColor=#d5e8d4;strokeColor=#82b366;'
S_LBL = (f'text;html=1;strokeColor=none;fillColor=none;align=center;'
         f'verticalAlign=middle;whiteSpace=wrap;rounded=0;'
         f'fontFamily={FONT};fontSize=9;fontStyle=2;fontColor=#555555;')
S_TTL = (f'text;html=1;strokeColor=none;fillColor=none;align=center;'
         f'verticalAlign=middle;whiteSpace=wrap;rounded=0;'
         f'fontFamily={FONT};fontSize=14;fontStyle=1;')
S_SEC = (f'text;html=1;strokeColor=none;fillColor=#E8EAF6;align=center;'
         f'verticalAlign=middle;whiteSpace=wrap;rounded=1;'
         f'fontFamily={FONT};fontSize=10;fontStyle=1;fontColor=#3949AB;'
         f'strokeColor=#3949AB;')

E = ('edgeStyle=orthogonalEdgeStyle;rounded=0;orthogonalLoop=1;'
     'jettySize=auto;html=1;')


def v(cid, label, x, y, w, h, style):
    return (f'    <mxCell id="{cid}" value="{label}" style="{style}" '
            f'vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry" />'
            f'</mxCell>\n')


def e(cid, label, src, tgt, extra=''):
    return (f'    <mxCell id="{cid}" value="{label}" style="{E+extra}" '
            f'edge="1" source="{src}" target="{tgt}" parent="1">'
            f'<mxGeometry relative="1" as="geometry" /></mxCell>\n')


def wrap(cells, pw=700, ph=600):
    return (f'<mxGraphModel dx="1422" dy="762" grid="1" gridSize="10" '
            f'guides="1" tooltips="1" connect="1" arrows="1" fold="1" '
            f'page="1" pageScale="1" pageWidth="{pw}" pageHeight="{ph}" '
            f'math="0" shadow="0">\n'
            f'  <root>\n'
            f'    <mxCell id="0" />\n'
            f'    <mxCell id="1" parent="0" />\n'
            + cells +
            f'  </root>\n'
            f'</mxGraphModel>\n')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 1 — Multimodal Pipeline (2.2.2)
# Generic: Text + Image + Audio + Video → encoders → fusion → task output
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('ttl', 'Arsitektur Umum Sistem Pemrosesan Multimoda',
       0, 8, 680, 28, S_TTL)

# Input modalities
c += v('m1', 'Teks',        40,  60, 110, 46, S_TXT)
c += v('m2', 'Gambar',     190,  60, 110, 46, S_IMG)
c += v('m3', 'Audio',      340,  60, 110, 46, S_AUD)
c += v('m4', 'Video',      490,  60, 110, 46, S_VID)

# Modality-specific encoders
c += v('e1', 'Text&#xa;Encoder',        40, 166, 110, 46, S_TXT)
c += v('e2', 'Image&#xa;Encoder',      190, 166, 110, 46, S_IMG)
c += v('e3', 'Audio&#xa;Encoder',      340, 166, 110, 46, S_AUD)
c += v('e4', 'Video&#xa;Encoder',      490, 166, 110, 46, S_VID)

# Representations
c += v('r1', 'h&#95;text',   40, 272, 110, 40, S_TXT)
c += v('r2', 'h&#95;image', 190, 272, 110, 40, S_IMG)
c += v('r3', 'h&#95;audio', 340, 272, 110, 40, S_AUD)
c += v('r4', 'h&#95;video', 490, 272, 110, 40, S_VID)

# Fusion module
c += v('fu', 'Fusion&#xa;(Early / Intermediate / Late)',
       140, 375, 360, 50, S_FUS)

# Task output
c += v('op', 'Output&#xa;(Klasifikasi / Regresi / Generasi)',
       165, 490, 310, 50, S_OUT)

# Subtitle
c += v('sb',
       'Setiap modalitas diproses oleh encoder khusus; representasi digabungkan melalui modul fusion.',
       0, 550, 680, 24, S_LBL)

# Arrows
for src, tgt in [('m1','e1'),('m2','e2'),('m3','e3'),('m4','e4'),
                  ('e1','r1'),('e2','r2'),('e3','r3'),('e4','r4')]:
    c += e(f'a_{src}_{tgt}', '', src, tgt)

for src in ['r1','r2','r3','r4']:
    c += e(f'b_{src}', '', src, 'fu',
           'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;')

c += e('c1', '', 'fu', 'op')

with open(os.path.join(OUT_DIR, 'multimodal_pipeline.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=680, ph=585))
print('Saved: multimodal_pipeline.drawio')


# ══════════════════════════════════════════════════════════════════════════════
# Diagram 2 — Transfer Learning Strategies (2.2.9)
# Generic: one pretrained model → 4 strategy branches
# ══════════════════════════════════════════════════════════════════════════════
c = ''
c += v('ttl', 'Strategi Transfer Learning dari Model Pretrained',
       0, 8, 820, 28, S_TTL)

# Pretrained model (shared source)
c += v('pre', 'Pretrained Model&#xa;(dilatih pada data besar)',
       310, 58, 200, 52, S_PRE)

# Strategy column headers
strategies = [
    ('s1', 'Feature&#xa;Extraction',       40,  195, 150, 46),
    ('s2', 'Full&#xa;Fine-tuning',         220, 195, 150, 46),
    ('s3', 'Partial&#xa;Fine-tuning',      400, 195, 150, 46),
    ('s4', 'PEFT&#xa;(LoRA / QLoRA)',      580, 195, 150, 46),
]
for sid, lbl, x, y, w, h in strategies:
    c += v(sid, lbl, x, y, w, h, S_SEC)

# Frozen / trainable encoder representations
frozen_blocks = [
    ('f1', 'Encoder&#xa;(dibekukan)',  40,  310, 150, 40, S_FRZ),
    ('f2', 'Encoder&#xa;(semua lapisan dilatih)',  220, 310, 150, 40, S_ACT),
    ('f3', 'Encoder&#xa;(sebagian dibekukan)',  400, 310, 150, 40, S_FRZ),
    ('f4', 'Encoder&#xa;(dibekukan + adapter)',  580, 310, 150, 40, S_FRZ),
]
for fid, lbl, x, y, w, h, sty in frozen_blocks:
    c += v(fid, lbl, x, y, w, h, sty)

# LoRA adapter badge for s4
c += v('lora', 'LoRA&#xa;Adapter',  600, 360, 110, 36,
       BASE + 'fillColor=#fff2cc;strokeColor=#d6b656;fontStyle=2;fontSize=10;')

# Task heads (trained)
heads = [
    ('h1',  40,  420, 150, 40),
    ('h2', 220,  420, 150, 40),
    ('h3', 400,  420, 150, 40),
    ('h4', 580,  420, 150, 40),
]
for hid, x, y, w, h in heads:
    c += v(hid, 'Task Head&#xa;(dilatih)', x, y, w, h, S_HD)

# Task output
outputs = [
    ('o1',  40,  525, 150, 40),
    ('o2', 220,  525, 150, 40),
    ('o3', 400,  525, 150, 40),
    ('o4', 580,  525, 150, 40),
]
for oid, x, y, w, h in outputs:
    c += v(oid, 'Output&#xa;(Task Target)', x, y, w, h, S_OUT)

# Description labels under each column
descs = [
    ('d1',  40,  572, 150, 32,
     'Hanya head baru&#xa;yang dilatih.'),
    ('d2', 220,  572, 150, 32,
     'Semua bobot&#xa;dilatih ulang.'),
    ('d3', 400,  572, 150, 32,
     'Lapisan atas dilatih;&#xa;lapisan bawah beku.'),
    ('d4', 580,  572, 150, 32,
     'Adapter low-rank;&#xa;bobot asli beku.'),
]
for did, x, y, w, h, lbl in descs:
    c += v(did, lbl, x, y, w, h, S_LBL)

# Arrows from pretrained to each strategy
for sid in ['s1','s2','s3','s4']:
    c += e(f'pa_{sid}', '', 'pre', sid,
           'exitX=0.5;exitY=1;exitDx=0;exitDy=0;entryX=0.5;entryY=0;entryDx=0;entryDy=0;')

# Arrows within each column
pairs = [('s1','f1'),('s2','f2'),('s3','f3'),('s4','f4'),
         ('f1','h1'),('f2','h2'),('f3','h3'),('f4','h4'),
         ('h1','o1'),('h2','o2'),('h3','o3'),('h4','o4')]
for src, tgt in pairs:
    c += e(f'ca_{src}_{tgt}', '', src, tgt)

# LoRA annotation arrow
c += e('lora_e', '', 'lora', 'f4',
       'endArrow=open;startArrow=none;dashed=1;strokeColor=#d6b656;html=1;'
       'exitX=0;exitY=0.5;exitDx=0;exitDy=0;entryX=1;entryY=0.5;entryDx=0;entryDy=0;')

with open(os.path.join(OUT_DIR, 'transfer_learning.drawio'), 'w', encoding='utf-8') as f:
    f.write(wrap(c, pw=820, ph=618))
print('Saved: transfer_learning.drawio')

print('\nAll draw.io theory diagrams generated.')
print('Open in https://app.diagrams.net -> Export As PNG (300 DPI, fit page)')
