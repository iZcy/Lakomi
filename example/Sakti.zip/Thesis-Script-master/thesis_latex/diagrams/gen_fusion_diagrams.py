"""
Generate 4 fusion strategy diagrams for BAB II section 2.2.3.
Output: thesis_latex/contents/chapter-2/figures/fusion_*.png
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import os

OUT_DIR = 'C:/Outpost/Skripsi/Research 4/thesis_latex/contents/chapter-2/figures'
os.makedirs(OUT_DIR, exist_ok=True)

# ── Shared style ───────────────────────────────────────────────────────────────
FONT = 'Times New Roman'
plt.rcParams['font.family'] = FONT
plt.rcParams['font.size'] = 10

C_TEXT  = '#2E86AB'   # blue  — text modality
C_IMAGE = '#E84855'   # red   — image modality
C_FUSE  = '#F9DC5C'   # yellow — fusion point
C_PRED  = '#4CAF50'   # green — output/prediction
C_EARLY = '#FF9800'   # orange — early concat
C_LATE  = '#9C27B0'   # purple — late decision

def box(ax, x, y, w, h, color, label, fontsize=9, alpha=0.85, radius=0.05):
    rect = FancyBboxPatch((x - w/2, y - h/2), w, h,
                          boxstyle=f'round,pad=0.01,rounding_size={radius}',
                          facecolor=color, edgecolor='#333', linewidth=1.2, alpha=alpha,
                          zorder=3)
    ax.add_patch(rect)
    ax.text(x, y, label, ha='center', va='center', fontsize=fontsize,
            fontweight='bold', zorder=4, wrap=True,
            multialignment='center')

def arrow(ax, x1, y1, x2, y2, color='#333', lw=1.5):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=color, lw=lw),
                zorder=2)


# ══════════════════════════════════════════════════════════════════════════════
# Figure 1 — Early Fusion
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(6, 4.5))
ax.set_xlim(0, 6); ax.set_ylim(0, 5); ax.axis('off')
ax.set_facecolor('#FAFAFA'); fig.patch.set_facecolor('#FAFAFA')

# Inputs
box(ax, 1.5, 4.2, 1.8, 0.55, C_TEXT,  'Teks\n(Essay)', fontsize=9)
box(ax, 4.5, 4.2, 1.8, 0.55, C_IMAGE, 'Gambar\n(Chart)', fontsize=9)

# Arrows down to concat
arrow(ax, 1.5, 3.92, 1.5, 3.28)
arrow(ax, 4.5, 3.92, 4.5, 3.28)

# Arrows converge to concat box
arrow(ax, 1.5, 3.28, 3.0, 3.05)
arrow(ax, 4.5, 3.28, 3.0, 3.05)

# Concat / early merge
box(ax, 3.0, 2.7, 2.4, 0.6, C_EARLY, 'Concat / Merge\n(Level Input)', fontsize=9)

# Arrow to shared encoder
arrow(ax, 3.0, 2.4, 3.0, 1.9)
box(ax, 3.0, 1.6, 2.4, 0.6, '#B0BEC5', 'Shared Encoder\n(Bersama)', fontsize=9)

# Arrow to output
arrow(ax, 3.0, 1.3, 3.0, 0.8)
box(ax, 3.0, 0.5, 1.8, 0.55, C_PRED, 'Output\n(Prediksi Skor)', fontsize=9)

ax.set_title('Early Fusion', fontsize=13, fontweight='bold', pad=8)
ax.text(3.0, -0.1, 'Penggabungan dilakukan di level input sebelum encoder bersama',
        ha='center', fontsize=7.5, style='italic', color='#555')

plt.tight_layout()
out = os.path.join(OUT_DIR, 'fusion_early.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')


# ══════════════════════════════════════════════════════════════════════════════
# Figure 2 — Intermediate Fusion
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(6, 5))
ax.set_xlim(0, 6); ax.set_ylim(0, 5.5); ax.axis('off')
ax.set_facecolor('#FAFAFA'); fig.patch.set_facecolor('#FAFAFA')

# Inputs
box(ax, 1.5, 5.1, 1.8, 0.55, C_TEXT,  'Teks\n(Essay)', fontsize=9)
box(ax, 4.5, 5.1, 1.8, 0.55, C_IMAGE, 'Gambar\n(Chart)', fontsize=9)

# Separate encoders
arrow(ax, 1.5, 4.82, 1.5, 4.2)
arrow(ax, 4.5, 4.82, 4.5, 4.2)

box(ax, 1.5, 3.9, 1.8, 0.55, C_TEXT,  'Text\nEncoder', fontsize=9, alpha=0.6)
box(ax, 4.5, 3.9, 1.8, 0.55, C_IMAGE, 'Image\nEncoder', fontsize=9, alpha=0.6)

# Hidden representations
arrow(ax, 1.5, 3.62, 1.5, 3.0)
arrow(ax, 4.5, 3.62, 4.5, 3.0)

box(ax, 1.5, 2.7, 1.8, 0.55, C_TEXT,  'h_text', fontsize=9, alpha=0.5)
box(ax, 4.5, 2.7, 1.8, 0.55, C_IMAGE, 'h_image', fontsize=9, alpha=0.5)

# Cross-attention / fusion arrows (bidirectional dashed)
ax.annotate('', xy=(3.8, 2.7), xytext=(2.4, 2.7),
            arrowprops=dict(arrowstyle='<->', color='#E67E22', lw=1.8, linestyle='dashed'))
ax.text(3.0, 2.78, 'Cross-Attention', ha='center', fontsize=7.5,
        color='#E67E22', fontweight='bold')

# Merge
arrow(ax, 1.5, 2.42, 3.0, 1.95)
arrow(ax, 4.5, 2.42, 3.0, 1.95)
box(ax, 3.0, 1.65, 2.4, 0.55, C_FUSE, 'Fused\nRepresentation', fontsize=9)

# Output
arrow(ax, 3.0, 1.37, 3.0, 0.8)
box(ax, 3.0, 0.5, 1.8, 0.55, C_PRED, 'Output\n(Prediksi Skor)', fontsize=9)

ax.set_title('Intermediate Fusion', fontsize=13, fontweight='bold', pad=8)
ax.text(3.0, -0.1,
        'Penggabungan di level representasi tersembunyi via cross-attention',
        ha='center', fontsize=7.5, style='italic', color='#555')

plt.tight_layout()
out = os.path.join(OUT_DIR, 'fusion_intermediate.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')


# ══════════════════════════════════════════════════════════════════════════════
# Figure 3 — Late Fusion
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(6, 5))
ax.set_xlim(0, 6); ax.set_ylim(0, 5.5); ax.axis('off')
ax.set_facecolor('#FAFAFA'); fig.patch.set_facecolor('#FAFAFA')

# Inputs
box(ax, 1.5, 5.1, 1.8, 0.55, C_TEXT,  'Teks\n(Essay)', fontsize=9)
box(ax, 4.5, 5.1, 1.8, 0.55, C_IMAGE, 'Gambar\n(Chart)', fontsize=9)

# Separate encoders
arrow(ax, 1.5, 4.82, 1.5, 4.2)
arrow(ax, 4.5, 4.82, 4.5, 4.2)
box(ax, 1.5, 3.9, 1.8, 0.55, C_TEXT,  'RoBERTa\n[CLS]', fontsize=9, alpha=0.6)
box(ax, 4.5, 3.9, 1.8, 0.55, C_IMAGE, 'ResNet18\nAvgPool', fontsize=9, alpha=0.6)

# Final representations
arrow(ax, 1.5, 3.62, 1.5, 3.0)
arrow(ax, 4.5, 3.62, 4.5, 3.0)
box(ax, 1.5, 2.7, 1.8, 0.55, C_TEXT,  '768-dim\nvector', fontsize=9, alpha=0.5)
box(ax, 4.5, 2.7, 1.8, 0.55, C_IMAGE, '512-dim\nvector', fontsize=9, alpha=0.5)

# Concat at output level
arrow(ax, 1.5, 2.42, 3.0, 1.95)
arrow(ax, 4.5, 2.42, 3.0, 1.95)
box(ax, 3.0, 1.65, 2.4, 0.55, C_LATE, 'Concat\n[1280-dim]', fontsize=9)

# Scoring head
arrow(ax, 3.0, 1.37, 3.0, 0.82)
box(ax, 3.0, 0.5, 1.8, 0.55, C_PRED, 'Scoring Head\n(Output)', fontsize=9)

ax.set_title('Late Fusion', fontsize=13, fontweight='bold', pad=8)
ax.text(3.0, -0.1,
        'Penggabungan di level output setelah encoder bekerja sepenuhnya independen',
        ha='center', fontsize=7.5, style='italic', color='#555')

plt.tight_layout()
out = os.path.join(OUT_DIR, 'fusion_late.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')


# ══════════════════════════════════════════════════════════════════════════════
# Figure 4 — Hybrid Fusion (Early + Late, CELFT-style)
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(7, 5.5))
ax.set_xlim(0, 7); ax.set_ylim(0, 6); ax.axis('off')
ax.set_facecolor('#FAFAFA'); fig.patch.set_facecolor('#FAFAFA')

# Inputs
box(ax, 1.5, 5.6, 1.8, 0.55, C_TEXT,  'Teks\n(Essay)', fontsize=9)
box(ax, 5.5, 5.6, 1.8, 0.55, C_IMAGE, 'Gambar\n(Chart)', fontsize=9)

# ── Path A: Early Fusion branch ───
arrow(ax, 1.5, 5.32, 1.5, 4.75)
arrow(ax, 5.5, 5.32, 5.5, 4.75)
arrow(ax, 1.5, 4.75, 3.5, 4.4)
arrow(ax, 5.5, 4.75, 3.5, 4.4)
box(ax, 3.5, 4.1, 2.2, 0.55, C_EARLY, 'Early Concat\n(Path A)', fontsize=8.5)
arrow(ax, 3.5, 3.82, 3.5, 3.28)
box(ax, 3.5, 3.0, 2.0, 0.5, C_EARLY, 'Shared\nEncoder', fontsize=8.5, alpha=0.6)
arrow(ax, 3.5, 2.75, 3.5, 2.28)
box(ax, 3.5, 2.0, 1.8, 0.5, C_EARLY, 'h_early', fontsize=8.5, alpha=0.5)

# ── Path B: Late Fusion branch (text) ───
arrow(ax, 1.5, 5.32, 0.9, 4.0)
box(ax, 0.9, 3.7, 1.4, 0.5, C_TEXT, 'Text\nEncoder', fontsize=8, alpha=0.6)
arrow(ax, 0.9, 3.45, 0.9, 2.95)
box(ax, 0.9, 2.65, 1.3, 0.5, C_TEXT, 'h_text', fontsize=8, alpha=0.5)

# ── Path B: Late Fusion branch (image) ───
arrow(ax, 5.5, 5.32, 6.1, 4.0)
box(ax, 6.1, 3.7, 1.4, 0.5, C_IMAGE, 'Image\nEncoder', fontsize=8, alpha=0.6)
arrow(ax, 6.1, 3.45, 6.1, 2.95)
box(ax, 6.1, 2.65, 1.3, 0.5, C_IMAGE, 'h_image', fontsize=8, alpha=0.5)

# ── All three converge to hybrid merge ───
arrow(ax, 3.5, 1.75, 3.5, 1.35)
arrow(ax, 0.9, 2.40, 3.5, 1.35)
arrow(ax, 6.1, 2.40, 3.5, 1.35)
box(ax, 3.5, 1.05, 2.6, 0.55, C_FUSE, 'Hybrid Merge\n(h_early + h_text + h_image)', fontsize=8)

arrow(ax, 3.5, 0.77, 3.5, 0.3)
box(ax, 3.5, 0.05, 1.8, 0.45, C_PRED, 'Output', fontsize=8.5)

ax.set_title('Hybrid Fusion (Early + Late)', fontsize=13, fontweight='bold', pad=8)
ax.text(3.5, -0.5,
        'Menggabungkan keunggulan early fusion (Path A) dan late fusion (Path B)',
        ha='center', fontsize=7.5, style='italic', color='#555')

plt.tight_layout()
out = os.path.join(OUT_DIR, 'fusion_hybrid.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')

print('\nAll 4 diagrams generated.')
