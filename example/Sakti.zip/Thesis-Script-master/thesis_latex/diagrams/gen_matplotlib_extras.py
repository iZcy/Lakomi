"""
Generate matplotlib-based diagrams for BAB II (Dasar Teori).
All content is purely theoretical — no research-specific context.
  1. activation_functions.png  — ReLU / GELU / Sigmoid curves
  2. aes_timeline.png          — AES evolution timeline (3 eras, published papers only)
Output: thesis_latex/contents/chapter-2/figures/
"""
import sys
sys.stdout.reconfigure(encoding='utf-8')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from scipy.stats import norm
import os

FONT = 'Times New Roman'
plt.rcParams['font.family'] = FONT
OUT = 'C:/Outpost/Skripsi/Research 4/thesis_latex/contents/chapter-2/figures'
os.makedirs(OUT, exist_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
# Figure 1 — Activation Functions (pure theory, no research context)
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(8, 5))
fig.patch.set_facecolor('#FAFAFA')
ax.set_facecolor('#FAFAFA')

x = np.linspace(-4, 4, 600)
relu    = np.maximum(0, x)
gelu    = x * norm.cdf(x)
sigmoid = 1 / (1 + np.exp(-x))

ax.plot(x, relu,    color='#E65100', lw=2.5, label='ReLU:     f(x) = max(0, x)', zorder=3)
ax.plot(x, gelu,    color='#1565C0', lw=2.5,
        label='GELU:     f(x) = x \u00b7 \u03a6(x)',
        linestyle='--', zorder=3)
ax.plot(x, sigmoid, color='#2E7D32', lw=2.5,
        label='Sigmoid:  f(x) = 1 / (1 + e\u207b\u02e3)',
        linestyle=':', zorder=3)

ax.axhline(0, color='#888', lw=0.8, zorder=1)
ax.axvline(0, color='#888', lw=0.8, zorder=1)
ax.set_xlim(-4, 4)
ax.set_ylim(-0.6, 4.2)
ax.set_xlabel('x', fontsize=12)
ax.set_ylabel('f(x)', fontsize=12)
ax.tick_params(labelsize=10)
ax.grid(True, alpha=0.25, linewidth=0.8)

# Annotate output ranges — purely mathematical descriptions
ax.annotate('Output: [0, \u221e)',
    xy=(3.5, relu[int(3.5/8*600 + 300)]),
    xytext=(2.2, 3.6), fontsize=9, color='#E65100',
    arrowprops=dict(arrowstyle='->', color='#E65100', lw=0.9))
ax.annotate('Output: (\u22120.17, \u221e)',
    xy=(3.0, gelu[int(3.0/8*600 + 300)]),
    xytext=(1.0, 2.4), fontsize=9, color='#1565C0',
    arrowprops=dict(arrowstyle='->', color='#1565C0', lw=0.9))
ax.annotate('Output: (0, 1)',
    xy=(3.5, sigmoid[int(3.5/8*600 + 300)]),
    xytext=(1.2, 0.08), fontsize=9, color='#2E7D32',
    arrowprops=dict(arrowstyle='->', color='#2E7D32', lw=0.9))

ax.legend(fontsize=10, loc='upper left', framealpha=0.88,
          prop={'family': FONT, 'size': 10})
ax.set_title('Perbandingan Fungsi Aktivasi: ReLU, GELU, dan Sigmoid',
             fontsize=13, fontweight='bold', pad=10)

plt.tight_layout()
out = os.path.join(OUT, 'activation_functions.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')


# ══════════════════════════════════════════════════════════════════════════════
# Figure 2 — AES Evolution Timeline (published papers only, no our-research refs)
# ══════════════════════════════════════════════════════════════════════════════
fig, ax = plt.subplots(figsize=(13, 5.5))
fig.patch.set_facecolor('#FAFAFA')
ax.set_facecolor('#FAFAFA')
ax.axis('off')
ax.set_xlim(1960, 2028)
ax.set_ylim(-2.8, 2.8)

# Era background bands
era_data = [
    (1963, 2003, '#BBDEFB', '#1565C0',
     'Era 1: Rule-based\n(1966\u20132003)'),
    (2003, 2016, '#FFE0B2', '#E65100',
     'Era 2: Machine Learning\n(2003\u20132016)'),
    (2016, 2026, '#C8E6C9', '#2E7D32',
     'Era 3: Deep Learning\n& Multimodal (2017\u2013kini)'),
]

for x0, x1, fill, stroke, label in era_data:
    ax.add_patch(mpatches.FancyBboxPatch(
        (x0 + 0.3, -0.42), x1 - x0 - 0.6, 0.84,
        boxstyle='round,pad=0.3', linewidth=1.2,
        facecolor=fill, edgecolor=stroke, alpha=0.65, zorder=1))
    mid = (x0 + x1) / 2
    ax.text(mid, 0, label, ha='center', va='center',
            fontsize=8.5, fontweight='bold', color=stroke,
            multialignment='center', zorder=2)

# Timeline arrow
ax.annotate('', xy=(2027, 0), xytext=(1962, 0),
    arrowprops=dict(arrowstyle='->', color='#333', lw=2.0), zorder=5)

# Year ticks
for yr in range(1965, 2026, 5):
    ax.plot([yr, yr], [-0.12, 0.12], color='#666', lw=0.8, zorder=3)
    ax.text(yr, -0.26, str(yr), ha='center', va='top',
            fontsize=7, color='#555')

# Milestones: (year, label, above, color)
milestones = [
    (1966, 'Page (1966)\nProject Essay Grade',        True,  '#1565C0'),
    (1998, 'Landauer et al. (1998)\nLSA-based AES',   False, '#1565C0'),
    (2003, 'Burstein et al. (2003)\ne-rater',          True,  '#E65100'),
    (2013, 'Shermis &\nBurstein (2013)\nML Benchmark', False, '#E65100'),
    (2017, 'Vaswani et al. (2017)\nTransformer',       True,  '#2E7D32'),
    (2019, 'Devlin et al. (2019)\nBERT',               False, '#2E7D32'),
    (2025, 'Singh et al. (2025)\nEssayJudge',          True,  '#2E7D32'),
]

for yr, label, above, color in milestones:
    stem_top =  0.44 if above else -0.44
    stem_ext = stem_top * 2.05
    va = 'bottom' if above else 'top'

    ax.plot([yr, yr], [stem_top, stem_ext], color=color,
            lw=1.3, linestyle='--', zorder=3)
    ax.plot(yr, 0, 'o', color=color, ms=8, zorder=6,
            markeredgecolor='white', markeredgewidth=1.5)
    ax.text(yr, stem_ext * 1.05, label, ha='center', va=va,
            fontsize=8.5, color=color, multialignment='center',
            fontweight='bold', zorder=7)

ax.set_title(
    'Evolusi Automated Essay Scoring: dari Sistem Rule-based hingga Deep Learning',
    fontsize=12, fontweight='bold', pad=16)

plt.tight_layout()
out = os.path.join(OUT, 'aes_timeline.png')
plt.savefig(out, dpi=150, bbox_inches='tight', facecolor='#FAFAFA')
plt.close()
print(f'Saved: {out}')

print('\nAll matplotlib diagrams generated.')
