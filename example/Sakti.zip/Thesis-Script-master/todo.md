# TODO — Research 4 Skripsi

## Pending

### DeepSeek Kaggle Notebook (Exp022)
- [ ] Change GPU to T4 on Kaggle web UI for notebook `exp022-deepseek-vl-7b-captions`
- [ ] Verify v18 notebook runs end-to-end on T4

---

## Writing / Thesis

- [ ] Rebuild PDF after any further edits
- [x] Remove RQ5 (VLM comparison with DeepSeek) — not needed; Qwen2-VL-7B is best ≤7B open-source VLM per singh2025
- [x] Fill in RQ6 (now RQ5) t-test results for Exp033 and Exp103
- [x] Update tab:master-results to match flow.md experiment list
- [x] Remove unused sections (4.5.4 Llama, 4.6.3 InternVL2-8B)
- [x] Reframe 093 as ablation; Pendekatan B valid = Exp103
